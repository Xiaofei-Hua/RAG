# Critic Review — Remove Measured Irrelevant Evidence Before Preparation

**Review date**: 2026-11-11  
**Scope**: `core/procedure_generation.py`、`core/fast_mode.py`、`agent/skills/generate/skill.py` 的本次预选接线，以及相关单元/API 测试；复核 marker、请求温度和完整发布路径未扩展。  
**Mode**: 完整 critic，生成热路径。未读取 defender，未运行模型，未修改业务或测试代码。

## Decision

- Critical: 0 new
- High: 0 new
- Medium: 0 new
- Low: 0 new
- **无代码阻断，允许完成开发候选验收；不据此关闭 F-12 或启用默认。**

## Findings

本次差异未发现新的可复现实现缺陷。最终 API 的 F-12（Fast L4 两轮遗漏记录追溯用途）仍由真实全文复测判定，单元通过不能替代该结论。

## Evidence and State Review

**praise (non-blocking)**：修复放在实际生成证据的准备边界，而不是只从模型提示删除一段后仍把该段显示为本次依据。它针对已复现的低相关背景干扰，无新提示字段、评分前向或模型请求。

`_eligible_evidence`（`core/procedure_generation.py:66`）只读取标记为真实 probability 且已 rerank 的 raw 值。存在同语种 ≥0.9，并且所有异语项都有 ≤0.01 的有效值时，才返回同语种集合；任何异语缺分、未知量纲、过高或缺强同语依据都返回未通过。`select_procedure_evidence` 返回原输入集合而不部分过滤失败集合，也不原地删除项目。None 保持不可用，未转换为 0；原有上下文预算规则继续作用于该返回集合。

Fast 三入口均调用 `_prepare_documents(documents, query, llm)`，先由实际文档生成证据、按资格预选，再进行既有 `prepare_evidence` 预算。`kept_documents` 从同一 prepared evidence 重建，模型 context、真实来源列表和输出检查 contexts 都取自此集合。未改变原检索结果及 diagnostics。

Generate 同步、异步都调用 `_prepare_retrieval_evidence`。预选发生在历史预算计算之后、证据预算之前；随后 `generation_evidence`、`retrieved_contexts`、`sources` 从 prepared 结果写到其现有所有者边界。`retrieval_evidence` 仅被规范化和读取，没有改写；历史继续附在证据块之外。旧消息回退路径未获得结构化证据时保持原行为。

直接 `generation_chain` 的 `prepare_procedure` 也调用同一资格函数，替换原完整证据块为筛后编号块，其他历史保持。条款引用通过真实源名在调用者 sources 中定位，而非借用显示标签。无资格或映射/证据块不匹配则仍选原 GroundedAnswer 请求。

## Unchanged Contracts

false、非流程、comparison、rewrite 均由既有 `segmented_enabled` 判定排除预选。Procedure 仍温度 0，其余完整生成仍 0.7；2048、top_p 0.8、none、单次生成未变。没有引入 v5 omitted 字段或条款相关性计算。

reranker 仍使用原 predict 调用、原分值与排序，只由实际 Sigmoid 类型添加局部 `rerank_output_space`；未加入会影响旧消费者的 `rerank_prob` / `rerank_probability`。完整 stop 后渲染、一次整体检查、一次发布以及失败时不发布半成品的路径未变。

## Validation Evidence

已读 `validation/noise-red.log`：5 failed / 8 passed / 36 deselected，失败包含直接准备中低相关异语仍在 context，以及 Fast JSON/SSE 的 stop/length 四种来源未去噪。

已读 `validation/noise-green.log`：69 passed。定向测试参数包含 Fast/Thinking、JSON/SSE、stop/length、普通题/流程/流程带噪；带噪场景检查实际 HTTP 模型消息和 API sources 均排除 noise.txt，保留 PII 脱敏、完整正文/保存历史一致、每次唯一结构化生成与失败 confidence=None 断言。单元覆盖强同语+低异语、异语高分/None/未知 marker/缺强依据，及历史、真实来源、映射失败回退。

本次没有重复运行整个测试矩阵，也没有调用真实模型。下一门槛是新候选 24 答与保留的 false 基线逐题全文比较，尤其 F-12 两个 Fast L4 样本须实际保留记录追溯用途及全部其他步骤/目的/触发条件；不能仅凭关键词或 schema stop 关闭。

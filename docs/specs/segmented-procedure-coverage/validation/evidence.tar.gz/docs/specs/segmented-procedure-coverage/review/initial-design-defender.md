# Defender Review — Segmented Procedure Coverage

**Object**: `requirements.md`, `design.md` v1, `tasks.md`；独立设计评审，未读取 critic 报告。
**Date**: 2026-11-11
**Decision**: 可以进入既定最小 prompt 实现与有界实验；没有新增 Critical/High 设计阻断。此结论不表示已修复旧缺陷，也不授权默认启用。

## Evidence

- `data/profiles/general.yaml:33` 要求第一段直接回答所有问题；`:34` 又将后段降为“仅在必要时简洁解释”，禁止重复且条件只能在 conditions。对用户明确要求 practical walkthrough 的任务，这组指令确实容易使操作步骤被概括替代。
- 已直接读取旧归档 `docs/specs/local-scheduling-streaming/validation/evidence.tar.gz` 内 `data/eval/local-adaptive-holdout-candidate/results.jsonl` 的四个 `v5h_scanner_procedure` 槽位。第1轮 Fast、第2轮 Fast、第2轮 Thinking 没有说明准备指定参考纸及保留失败记录；第1轮 Thinking 则在后段包含这些动作。遗漏并非单一措辞差异，旧结构也并非绝对无法输出正确后段。
- 同归档 `model-http.jsonl` 中 generation 索引 1、9、10、18 的实际输入均含 `Prepare the designated reference sheet` 与 `keep failed-check records`，参数均为 2048 / none / 0.7 / 0.8。因此检索缺句不能解释这四次候选里的遗漏；仍不能据此断言 prompt 是唯一原因。
- `core/segmented_generation.py:17` 只定义 conditions 和至少一段 answer；`:99` 将全部 conditions 拼入第一答案段；`:107` 只验证 stop、完整 JSON 与段数。实现没有语义步骤覆盖断言，`generation_complete=true` 不能证明流程完整。

## Decisions

本表为独立评审命题，不声称转述尚未阅读的 critic finding。

| ID | Severity | Decision | Reason | Design disposition |
|---|---|---|---|---|
| D-01 | High | accepted | 已复现具体准备、记录动作遗漏；局部替换旧压缩指令符合缺陷范围，新增在线核验不是必要前提。 | v1 `Minimal Strategy` 第1–3项已覆盖；修复效果等待真实输出验证。 |
| D-02 | Medium | rejected (factual error) | “先写全部限制与后写步骤必然互相矛盾”不成立。`design.md:13` 保留影响执行的条件，`:14` 放具体动作，`:15` 明确允许条件随动作重述；不同层次的信息可共存。 | 无需新增 schema 或路由；实际 prompt 必须删除旧“条件只写在conditions中/不重复首段”的绝对约束。 |
| D-03 | Medium | accepted | 研究提供任务分解的启发，并未证明本地9B、无额外计划输出的方案必然有效。设计已明确这一外推边界。 | v1 `Research and Transfer` 与 `Validation and Budget` 已覆盖。 |

## D-01 Decision Tree

1. **Fact**：旧四条用户答案存在明确动作遗漏；HTTP输入包含被遗漏句子，见上方可定位的 archive member 与索引。
2. **Trigger**：用户同时要求工作规则、限制、初始化、周期检查、更换后的恢复、记录与目的，旧 `general.yaml:33–34` 把所有问题推向第一段并弱化后段。无需构造未知异常即可触发。
3. **Cost**：局部 prompt 修改和已有框架内真实对照的成本有限；遗漏会使操作说明不可用，应接受修复。
4. **Scope**：就是本次已授权的第4步长流程缺陷；无需扩大为语义审查平台、分类器或第二模型调用。
5. **Alternative**：按阶段组织用户可见最终答案、保持同一生成和既有来源检查，是范围内可验证的候选缓解。没有证据支持未经实验即宣布等价于完整覆盖保证。

## Conditions Versus Actions

首段必须包含会改变操作结论的适用、计时、失败与未知边界；后段应把动作放回正确阶段，并将相应触发条件与动作配对。相同条件在首段和对应步骤重述是明确允许的。首段可以说检查通过后才能投入使用，后段继续解释先准备什么、记录什么、失败记录怎么保留；这不引入新的限制。

真正必须避免的是仍要求“第一段回答所有问题”却把后段当作可选解释，或为了首段短而把关键前置条件移到后段。当前设计已避开这两点。条件多时首段仍可能较长；这是本方案的实际成本，必须测量，不能承诺所有流程均变快。

## Validation Obligations

- 按槽位检查首段和全文：动作、动作所属阶段、触发/起算事件、失败分支、具体记录项目、所问目的、未知边界、引用；不能用段数、关键词或合法 JSON 代替。
- 同一旧/新机制对照保持证据与采样预算不变。Fast 与 Thinking 分开记录最终生成调用和整个请求调用；Thinking 控制调用存在时不能概括为“整个请求仅一次模型调用”。
- 无输出、检索终态、截断分别报告；不能把它们作为低延迟正确回答计入首段收益。
- 旧四条题目已经是开发回归。新中英流程留出须在候选固定后才由独立 reviewer 创建；当前未创建。任何依留出修改当前 prompt 的行为都会使这些题退为开发集。
- 有遗漏、计时事件合并、条件/引用实质退步或调用增加时，不能仅凭平均速度改善通过默认门槛。继续保留 `LOCAL_RAG_SEGMENTED=false`。

## Research Boundary

[Plan-and-Solve 原论文页面](https://aclanthology.org/2023.acl-long.147/)明确讨论推理任务中的漏步，并通过分解子任务进行缓解；其GPT-3推理题实验只能支持本次假设来源。把资料支持的动作按用户所问阶段组织，是本项目的迁移推断，收益必须由本项目的真实模型结果决定。

## Limited Claims

本次只阅读现有证据并评审设计，没有修改业务代码、调用真实模型或提前制作新留出；没有宣称旧缺陷已关闭。无新增范围外 issue，也没有新增安全或一致性门禁。默认启用与交付结论应在完成冻结留出及最终质量评审后单独记录。
# API Development Defender Review

**Date**: 2026-11-11  
**Protocol**: `validation/api-development.json`，6 个开发题 × Fast/Thinking × 2 轮，每侧 24 答。  
**Evidence**: `data/eval/procedure-api-dev-{baseline,candidate}/{results.jsonl,model-http.jsonl}`。下文行号为 results.jsonl 的 1-based 行号。  
**Method**: 独立逐答审原文、引用和发布事件，核对真实请求路由；未读 critic，未调用模型，未创建留出。

## Decision

**本轮不具备默认启用或冻结留出资格。** 全文严格质量为基线 16/24、候选 16/24；同总数掩盖配对退步，不能称质量持平通过。流程为 1/8 → 2/8；非流程为 15/16 → 14/16。

已确认的机制收益仍存在：Thinking 4 个候选流程的具体动作、记录、用途、事件起算和引用支持均完整，未再把换件后的复位推广到普通失败复查。其中 2 答加入无关包装/库存，违反预先冻结的相关性判据，因此只有 2/4 整题合格。Fast 的 4 答都因第三份低相关异语言证据而在生成前回到完整 GroundedAnswer，未实际执行原文选择机制，仍重复原遗漏。

## Procedure Pairs

| Row | Round / Mode / Case | Baseline full | Candidate full | Actual observation |
|---|---|---|---|---|
| 5 | R1 / Fast / scanner | Fail | Fail | 基线漏准备、日期/结果/失败记录和用途，并对服务费句混入不相关中文引用。候选仍漏准备、记录与用途，后文把更换或普通失败纠正后的通过均说成重新起算。 |
| 6 | R1 / Fast / printer | Fail | Fail | 两侧虽有准备及主要运行规则，仍未完整给出检查后日期/样张/结果/失败样张记录，以及初始、周期和追溯用途。 |
| 11 | R1 / Thinking / scanner | Fail | Fail | 基线把结果记录写在检查前，且有复位/记录语义问题。候选原文动作、用途与事件绑定完整；最后 `Service Charge and Packaging` 同时加入蓝色纸箱、92 箱库存，失败原因是无关内容。 |
| 12 | R1 / Thinking / printer | Pass | Pass | 两侧流程、全部记录、用途和起算完整。候选的准备标题虽挂首次阶段，原句“检查前”并未被改写成“仅首次”，后文通用记录仍明确；无须因非排他标题或重复一概失败。 |
| 17 | R2 / Fast / scanner | Fail | Fail | 基线漏准备、结果/失败记录、周期和追溯等用途。候选明确把普通失败纠正后复查通过说成新 37 小时起算，且漏准备与记录，属于事实和覆盖失败。 |
| 18 | R2 / Fast / printer | Fail | Fail | 两侧漏完整检查后记录、失败样张保留和追溯用途。候选写出部分目的，但不能替代缺失记录动作。 |
| 23 | R2 / Thinking / scanner | Fail | Pass | 基线周期段泛化“new check passes”即重新起算，且漏完整结果/失败记录及追溯用途。候选完整覆盖，重复的准备/失败段没有改变适用关系，无包装干扰。 |
| 24 | R2 / Thinking / printer | Fail | Fail | 基线缺记录追溯目的。候选核心流程完整，但“特殊事项说明”含蓝色包装、92 只库存；严格相关性失败。 |

这 8 个候选均为完整答案一次 token 发布。四个 Thinking 选择答均在完整选择完成后发布，未以半份选择结果提前交付。全文不合格不会因发布结构合法而变成合格。

## Routing and Publication

- 候选 Fast 行 5/17 的 kept sources 含低相关中文打印台资料，`rerank_score=0.0012379003455862403`；行 6/18 含低相关英文扫描器规则，`rerank_score=0.0038072040770202875`。保守语言资格遇到任一异语言即回退。这四个真实生成请求为 GroundedAnswer，没有 `[条款]`，不能把它们当作已试过选择机制的失败或成功。
- 候选 Thinking 行 11/12/23/24 只有相应两份同语言资料，实际进入 ProcedureAnswer。四答均有原文动作、目的、失败记录，复位仍绑定更换后的检查。
- 新发布保证是等待完整 stop 后检查并一次发布，故程序的“第一次正文发布”就是全文。内部书面首段仍单独按 v2 审：四个选择答均给出运行约束与适用范围；英文首段给失败后继续停机直至纠正并通过的主规则，中文首段给首次合格才打印与起算规则，均非仅环境。
- 旧“书面首段含全部关键阶段条件”判据：这四个选择答仍为 0/4，不翻案、不把新发布方式宣称为旧首段通过。Fast 完整回退首段另有普通失败复位错误，不能因它写得长就判满足全部条件。
- 通用准备、记录在全文中的段落位置和重复没有实际删掉适用条件；本轮不将其单独判为失败。真正失败是遗漏、错误起算、错误支持或明确离题内容。

## Non-procedure Pairs

| Row | Round / Mode / Case | Baseline full | Candidate full | Observation |
|---|---|---|---|---|
| 1 | R1 / Fast / comparison | Pass | Pass | 600 分钟=10 小时；保留 5 W/8 W 条件，未外推同负载。 |
| 2 | R1 / Fast / zero | Fail | Pass | 基线“零不等于缺测”段只引打印台记录；候选引用对应计时器记录。 |
| 3 | R1 / Fast / calibration | Pass | Pass | 120 日、首次投入确认和换探头后校准完成日起算正确。 |
| 4 | R1 / Fast / missing | Pass | Fail | 候选价格未知、交付起 18 月正确，但后续附计时偏差及水质计校准，与本问题无关。 |
| 7 | R1 / Thinking / comparison | Pass | Pass | 数值、单位、负载限制和来源完整。 |
| 8 | R1 / Thinking / zero | Pass | Pass | 零值与缺测区分正确。 |
| 9 | R1 / Thinking / calibration | Pass | Pass | 全文正确；候选首次 token 只答 120 日，首次/换件起算在后两个 token，旧非流程首答契约另记失败。 |
| 10 | R1 / Thinking / missing | Pass | Pass | 未编价格，交付起 18 月正确。 |
| 13 | R2 / Fast / comparison | Pass | Pass | 同条件边界和比较正确。 |
| 14 | R2 / Fast / zero | Pass | Pass | 零值、10 分钟及引用正确。 |
| 15 | R2 / Fast / calibration | Pass | Fail | 所问校准答案正确，但候选后续附整个扫描器流程及计时偏差，构成离题退步。 |
| 16 | R2 / Fast / missing | Pass | Pass | 所问数值和未知边界正确。 |
| 19 | R2 / Thinking / comparison | Pass | Pass | 记录比较正确，未得出同负载优劣。 |
| 20 | R2 / Thinking / zero | Pass | Pass | 数值和证据正确。 |
| 21 | R2 / Thinking / calibration | Pass | Pass | 周期与起算正确。 |
| 22 | R2 / Thinking / missing | Pass | Pass | 无价格编造或保修起算改变。 |

候选行 4/9/15 使用原有非流程分段路径且为 3 次 token 发布；其余非流程本轮为一次。所问核心事实均正确不等于全文没有退步。原非流程 prompt 已恢复主干，本任务不继续迭代这部分 prompt；默认 false，保留这些失败记录。

## Cost and Timing

两侧均 60 条实际 HTTP：每个 Fast 请求 1 次最终生成；每个 Thinking 请求 3 次控制调用 + 1 次最终生成。没有重试、补写或二次翻译。全部请求完成，不用截断/拒答收益充当性能收益。

下表为本次小样本的秒数；P95 使用线性插值，不能据此宣称稳定分位数优势。

| Subset | n/side | Baseline first P50 / P95 | Candidate first P50 / P95 | Baseline full P50 | Candidate full P50 |
|---|---:|---:|---:|---:|---:|
| Fast procedure | 4 | 8.012 / 9.106 | 8.301 / 9.954 | 8.012 | 8.302 |
| Thinking procedure | 4 | 11.091 / 14.537 | 7.481 / 8.671 | 11.204 | 7.595 |
| Fast non-procedure | 8 | 3.410 / 6.987 | 2.411 / 3.519 | 3.411 | 2.956 |
| Thinking non-procedure | 8 | 5.912 / 6.336 | 4.887 / 6.043 | 6.019 | 5.617 |

选择路径的 Thinking 耗时下降有观察价值，但相关性 2/4 失败，不能作为质量合格的上线收益。Fast 未进入选择机制，耗时变化不可归因于选择渲染。

## Next Scope

保留本轮失败。下一最小实验只处理已经复现的两点：低相关异语言尾部资料导致全体回退；原文选择把明确无关包装句选入。条款 BGE 阈值诊断见 `validation/clause-relevance-profile.json`：中文无关颜色 0.633、库存 0.552，超过必要价格 0.489、部分记录 0.577，统一低分阈值无法保留全部必要内容并清除两句，故不引入该计算。

可试同次选择 JSON 先给 `omitted_clause_ids` 再编排答案的小机制，但须继续对完整动作/用途/引用/相关性人工审核，结构 ID 归属不证明语义。资格排除需先明确 reranker 概率量纲，低分异语言才可排除，None 或高相关异语言继续完整生成。候选未冻结；本 reviewer 未创建或提供任何新留出题。
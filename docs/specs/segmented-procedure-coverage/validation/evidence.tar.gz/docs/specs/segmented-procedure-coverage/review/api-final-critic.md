# Critic Review — Final API Comparison

**Review date**: 2026-11-11  
**Evidence**: `procedure-api-final-baseline` 与 `procedure-api-final-candidate` 的全部 24 配对结果和原始模型 HTTP；协议 `validation/api-development.json`。  
**Independence**: 阅读全部 48 份完整答案，核对实际请求、候选原文及选择；未读取 defender 报告，未调用模型或修改业务代码。

## Decision

**当前候选不准入新留出，默认保持 false。**

- 流程完整质量：baseline **1/8**，candidate **6/8**。候选两轮 Fast L4 均遗漏所问记录追溯用途，不能以其他动作齐全或没有包装干扰判完整通过。
- 其余 16 题：baseline **15/16**，candidate **16/16**；未见新增实质退步或无关追加。
- 候选 8 条流程全部实际进入 **ProcedureAnswer/temperature 0**，16 条非流程全部为 **GroundedAnswer/0.7**。文档门控与路由收窄已在真实 API 生效。
- 每侧 **60 次模型请求 = 24 次最终生成 + 36 次既有控制**；每答只有一次最终生成。Fast 每题总计 1 次，Thinking 每题总计 4 次。
- Fast 流程首份完整正文 P50 **7.927s→3.893s**，Thinking **12.895s→7.410s**。速度收益成立，但不抵消缺失用途。

候选没有把原本通过的配对改成失败；本次阻断来自目标完整性仍未闭合，并非新造防御门槛。记录用途一直在问题、资料和冻结 manual_required 中。

## Procedure Pair Review

行号为两侧 `results.jsonl` 相同配对位置。P 为完整动作、目的、条件、未知信息、引用与相关性均通过。

| Line | Round / Mode / Case | Baseline | Candidate | Exact assessment |
|---|---|---|---|---|
| 5 | R1 Fast / R7 | Fail | P | 基线缺指定参考纸/序列号、检查后记录与保留失败记录、记录用途及换头复位完整说明；候选完整。 |
| 6 | R1 Fast / L4 | Fail | Fail | 基线缺检查后记录/失败样张等；候选补齐具体动作和失败记录，但漏“保存机台、托盘与样张记录便于追溯偏移来源”。 |
| 11 | R1 Thinking / R7 | Fail | P | 基线明确要求 Before the initial check 记录 pass/fail，且缺记录追溯用途；候选没有该时间错误，动作和目的完整。 |
| 12 | R1 Thinking / L4 | Fail | P | 基线漏记录追溯用途；候选保留。基线周期检查用途一段仅引运行规程，也没有完整支持该段用途。 |
| 17 | R2 Fast / R7 | Fail | P | 基线仍主要重复规则，缺具体准备、检查后记录/失败记录与所问用途；候选完整。 |
| 18 | R2 Fast / L4 | Fail | Fail | 两侧都有具体动作和主要规则，但都没有解释保存编号及样张记录用于追溯偏移来源；候选遗漏与 R1 相同。 |
| 23 | R2 Thinking / R7 | Fail | P | 基线有准备、记录和追溯，但漏周期检查“确认仍在记录基准内”的用途；候选完整。 |
| 24 | R2 Thinking / L4 | P | P | 两侧准备、检查后字段/失败样张、全部用途、计数及未知边界齐全。 |

**praise (non-blocking)**：候选所有 8 条保留了具体准备、检查、记录字段、失败记录，以及正确的初次/换件计数触发和失败恢复。R7 的 fresh interval 仍明确绑定扫描头更换后的检查；没有把普通失败纠正泛化成复位。中英文引用对应实际原文，未编造服务价格或户外规则，未包含包装颜色/库存。

两条 L4 失败不应描述为“具体动作全漏”或“包装问题仍在”。问题更窄：用户明确要求解释记录作用，答案缺了对应用途。该用途也没有由其他段落等价表达。

## Exact Remaining Failure

candidate HTTP **index 6 和 36**（R1/R2 Fast L4）输入中都实际包含：

> [条款10] 保存机台、托盘与样张记录便于追溯偏移来源。

两次返回的选择相同，选中编号集合为 **2、3、4、5、7、8、9、11**，没有 10。原始响应 finish_reason=stop；生成与渲染没有删除已选文字，模型根本没有选择该句。最终答案包含检查记录字段与失败样张，但没有追溯偏移来源这一用途。

所以根因是同次选择在真实 Fast 上下文中仍遗漏所问内容，不是检索没提供、token 截断、映射错误或输出检查删句。温度 0 让这个遗漏在两轮重复，并没有保证完整性。两份同语种资料机制实验通过不能替代真实包含第三份背景的 API 结果。

## Other 16 Pairs

| Line | Round / Mode / Case | Baseline | Candidate | Assessment |
|---|---|---|---|---|
| 1 | R1 Fast / comparison | Fail | P | 基线只并列芦序 10h/5W 与赤砚 9h/8W，再说明不能同负载外推，没有给所问的记录大小关系；冻结判据要求明确比较。候选明确芦序记录更长。 |
| 2 | R1 Fast / zero | P | P | 两个已测零值等价，10 分钟条件与非缺测说明正确。 |
| 3 | R1 Fast / calibration | P | P | 正常连续使用、120 日历日、首次和换探头起算正确。 |
| 4 | R1 Fast / missing price | P | P | 未虚构价格，18 个月从交付起算，无其他设备追加。 |
| 7 | R1 Thinking / comparison | P | P | 统一单位、记录关系、两种负载与不可外推均保留。 |
| 8 | R1 Thinking / zero | P | P | 数值、基准与非缺测正确，引用支持。 |
| 9 | R1 Thinking / calibration | P | P | 使用范围和两个起算事件完整。 |
| 10 | R1 Thinking / missing price | P | P | 价格未知和保修期/起点正确。 |
| 13 | R2 Fast / comparison | P | P | 记录大小关系与同负载限制正确。 |
| 14 | R2 Fast / zero | P | P | 零值等价、基准条件及非缺测正确。 |
| 15 | R2 Fast / calibration | P | P | 起算与换件先校准正确；候选无无关后段。 |
| 16 | R2 Fast / missing price | P | P | 价格未知及交付起 18 个月正确。 |
| 19 | R2 Thinking / comparison | P | P | 已有记录较长与不能外推都回答。 |
| 20 | R2 Thinking / zero | P | P | 0ms=0s，不是缺测。 |
| 21 | R2 Thinking / calibration | P | P | 120 日历日、正常连续使用及两起点保留。 |
| 22 | R2 Thinking / missing price | P | P | 来源支持价格未知和保修期。 |

普通题没有实质退步。候选恢复 GroundedAnswer 后，本批没有重现旧 API 中“正确首段后添加计时测试/校准/R7 无关材料”的问题；F-11 的有限范围回退方案得到实际支持。这不改变旧普通分段曾失败的记录。

## Actual Requests and Publication

所有 48 个请求 HTTP=200、最终生成 stop、done=complete。每条答案仅 1 个 token 正文事件，该事件等于最终全篇。因此首份实际发布正文的质量与全文相同：流程候选 **6/8**，非流程 **16/16**。协议 complete 不证明全部目的已覆盖。

候选 8 条视觉首节均包含主要操作规则及通用适用范围；旧“所有后续条件放在视觉首节”的标准为 0/8，作为历史/排版观察单独保留，不混入实际完整发布的判断。没有检查前泄露部分流程。

正式模型请求参数核对：baseline 24 条均 0.7/2048/top_p0.8/none；candidate 8 条流程为 0，其余 16 条仍 0.7，其他参数一致。没有重试、额外生成或生成后的修复调用。

Fast 四个流程请求仍保留完整异语尾项原文及来源：R7 请求含 L4 检查记录背景，L4 请求含 R7 运行规程背景。未通过删除背景伪造准入，实际来源映射与编号选择限制生效。F-09 的“一份异语尾项导致全部 Fast 回退”机制已修复；本次残留目的遗漏单列为 F-12，不再归因于旧门控。

## Latency

P95 使用样本线性插值。数据为小规模分批开发对照，不能视为独立随机大样本。

| Group | N per side | First full-body P50 baseline → candidate | P95 baseline → candidate | Request completion P50 baseline → candidate |
|---|---:|---:|---:|---:|
| Procedure / Fast | 4 | 7.927s → 3.893s | 9.541s → 4.015s | 7.927s → 3.894s |
| Procedure / Thinking | 4 | 12.895s → 7.410s | 15.158s → 8.585s | 13.010s → 7.512s |
| Other / Fast | 8 | 3.207s → 3.122s | 4.022s → 3.896s | 3.207s → 3.122s |
| Other / Thinking | 8 | 5.646s → 5.551s | 5.790s → 5.854s | 5.752s → 5.658s |

候选流程交付更快，且大部分原有遗漏修复；两条缺记录用途的响应也计入这些时延，不能把其速度当完整质量合格的收益。当前不应用总通过数或总体更快抵消冻结的全文缺失。

## Finding

### F-12 — Fast L4 仍漏用户明确所问的记录追溯用途

**issue (blocking for qualification)**

- **id**: F-12
- **severity**: Critical。critic §2(a)：目标“覆盖用户所问动作及目的”在真实生成路径仍可复现，非新增措辞偏好。
- **location**: candidate `results.jsonl:6`、`:18`；`model-http.jsonl` index 6、36；`core/procedure_generation.py:148-157` 发布所选原文。
- **symptom**: 输入提供条款 10，用户要求解释作用；两次选择均漏掉条款 10，最终正文没有记录用于追溯偏移来源的说明。
- **impact**: 流程完整质量只有 6/8；虽然具体步骤、失败记录与其他目的已改善，仍不能宣布开发复现全部修复或进入新留出资格。
- **root_cause**: 完整 stop 和正确原文渲染只能保证已选条款忠实，不能保证选择覆盖全部所问目的；温度 0 稳定复现同一遗漏。
- **recommendation**: 维持 `core/segmented_generation.py` 的默认 false，在结果文档明确该失败，不冻结新留出、不硬编码条款 10、不附录补原文或放宽用途要求。按 v6 的最后有界实验约束收束当前路线；任何后续独立修复方案另经设计，而非继续针对开发词汇堆提示。
- **verification**: 以这两个已归档真实请求和最终答案作为失败回归依据；须实际回答记录追溯用途并保持全部其他行为，ID 合法/stop/无包装均不能替代该验证。
- **status**: open; default enablement rejected

F-07/F-08 的资格修复仍有效；F-09 的实际路由问题已解决，F-10 本批无包装干扰，F-11 本批非流程无回退方案退步。以上进展如实保留，但 F-12 使本次整体完整质量准入失败。

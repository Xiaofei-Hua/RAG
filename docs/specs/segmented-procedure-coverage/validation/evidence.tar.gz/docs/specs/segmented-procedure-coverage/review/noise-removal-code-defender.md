# Noise Removal Code Defender Review

**Date**: 2026-11-11  
**Object**: `_eligible_evidence` / `select_procedure_evidence` / `prepare_procedure`、Fast 三入口、Generate 共享 preparation、相关单元/E2E 和红绿日志。  
**Decision**: **本次实现符合已审最小修正，未发现新增 Critical/High 阻断，可继续真实候选 API 验收。** 模型、prompt、温度和默认开关未改；尚不创建留出。

## Shared Preparation

`core/fast_mode.py:118` 的 `_prepare_documents` 接收 query 与实际 llm，仅在统一 segmented_enabled 资格通过时预选，再调用原 prepare_evidence 预算。`fast_generate`、`fast_generate_stream`、`fast_generate_async` 分别在 233、349、464 行调用该公共入口，没有只修流式的分叉。

返回的 context 与 kept_documents 均来自同一个 prepared evidence。随后模型输入 evidence、来源名、输出检查 contexts 和 API sources 都由这些 kept_documents 建立，低相关 foreign 不再只从 prompt 隐藏却保留为本次生成来源。

`agent/skills/generate/skill.py:458` 的 `_prepare_retrieval_evidence` 被同步/异步共用。预选在 481–485 行、原 prepare_evidence 之前；history 的预算和注入仍走原逻辑。两入口分别将 prepared evidence、contexts 和 sources 写入已有 generation_evidence/retrieved_contexts/sources 键，未修改 retrieval_evidence 或 retrieval_diagnostics。

## Atomic Qualification and Fallback

`_eligible_evidence` 先读取全部语言/已测概率，并对所有异语言项完成统一资格判断，之后才生成保留同语项的列表。任一 foreign 高于 0.01、缺分、缺量纲或没有同语 ≥0.9 的强证据，均先返回 None；不会先删除低分 foreign，再留下一个被部分裁剪的失败集合。

`select_procedure_evidence` 对不合格输入返回原集合，保留项字典没有原地改写。后续沿用原有 evidence 预算；本次没有改预算算法或原召回状态。None 与非法概率仍由原 probability 校验排除，未当成 0。未知 profile 不做流程预选。

高分/缺分 foreign 在实际 kept 中时，`prepare_procedure` 再用同一资格函数返回 None，由既有 generation_chain 走原完整 GroundedAnswer，不追加第二次调用。false、非流程、比较和 rewrite 均被调用处统一资格挡住，不进入新预选。

## Direct Chain, History and Publication

直接 generation_chain 调用的 `prepare_procedure` 也以同一个资格函数确定可选证据。它用 original_evidence 渲染的完整块定位旧上下文，再以过滤且编号后的块替换，保留 history 与其他上下文；条款 source_id 仍从真实 sources 映射，没有把重新编号的显示证据序号误当来源编号。

stop/schema/ID 验证、原文渲染、一次输出检查和整篇发布未改。新处理只缩小生成依据，不更改保留原句、不新增核验、评分或生成调用。失败 confidence=None 的新增 E2E 断言沿用已存在的失败契约。

## Test Evidence

`validation/noise-red.log` 保留 5 failed / 8 passed / 36 deselected：直接准备仍含 foreign，以及 Fast JSON/SSE 的 prompt/API 来源仍暴露 noise。`noise-green.log` 为 69 passed。

E2E 增加 procedure_with_noise，并通过真实 mock HTTP 输入断言 noise.txt 不在最终生成消息，同时不在 API sources；覆盖 Fast/Thinking、JSON/SSE、stop/length。原 PII、保存正文、done、history 和单次最终生成断言继续保留；失败完成状态还明确断言 confidence=None。单元回归把原“背景保留”断言改为实际移除，并保留高分/缺分/缺量纲/无强同语不合格分支。

本 reviewer 独立读了实际日志与断言，没有重复跑同组已通过测试；未读 critic、未改代码、未调用模型。Thinking 的部分低相关资料也可能在更早的既有检索层被过滤，因此不能只凭该 E2E 通过声称所有 Generate 预选分支都被触发；本轮入口一致性同时依据实际共用 preparation 源码核查。

## Remaining Qualification

false 路径仍不调用预选，原 baseline 行为和生成参数保持，可按已审计划复用 api-final-baseline。旧 api-final-candidate 的 2 条遗漏未覆盖或删除；新候选在独立目录重测。真实 API 仍须按完整动作、用途、引用、相关性和调用数评审，不能只看漏掉的条款 10 是否出现。

模型/prompt/温度继续冻结。只有该实际候选通过后才创建全新中英流程留出，当前默认仍 false。
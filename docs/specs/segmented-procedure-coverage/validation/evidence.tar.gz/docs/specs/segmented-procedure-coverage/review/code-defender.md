# Code Defender Review — Procedure Prompt v1

**Date**: 2026-11-11
**Scope**: 当前 `general.yaml`、单元/E2E diff、流程 golden 与已有红绿日志；未读取 critic 报告，未重跑测试或新增实验。
**Decision**: 未发现新的 Critical/High 实现缺陷。代码变更符合已审最小范围；真实质量仍未通过，见 `mechanism-v1-defender.md`。

## Implementation

- `data/profiles/general.yaml:33–35` 将两条压缩指令替换为三条流程组织指令：首段主要规则、后段具体动作/记录/目的、按动作配对条件且允许重述。业务变更只有此处，没有改 schema、路由、生成次数、预算或默认开关。
- 非流程仍要求逐项直接作答，比较路径继续使用既有完整 schema。没有在业务 prompt 中硬编码开发题名称、材料或计时间隔。
- 原“条件只写在conditions中/不重复首段”已删除，因此没有残留的绝对重复禁令与流程展开要求相冲突。

## Tests and Evidence Boundary

- `tests/unit/test_segmented_generation.py:183` 使用真实 generation_chain 与模型传输替身，检查实际请求绑定 golden prompt、单次生成和 2048/none，保留多段结果。
- `tests/e2e/test_segmented_api.py:13` 扩展原API测试到 records/procedure 两类，覆盖 Fast/Thinking、JSON/SSE、stop/length；检查 PII 清理、引用、token/done/保存/历史，以及最终 schema 生成恰好一次。用原框架扩展测试而未另建业务旁脚本。
- `tests/fixtures/local_segmented_procedure.json` 的回答是固定模型替身数据。该测试证明新 prompt 被发送且多段内容经过正确发布，不证明真实模型会遵从流程覆盖要求。
- `validation/red.log` 的9个失败均为实际 system prompt 与新 golden 不同（1单元+8个流程API参数）；其余30通过。`validation/green.log` 记录39通过。红绿证据是请求绑定回归，不应报告为“真实遗漏先失败后修复”。
- 未发现为通过测试而改变业务默认、比较/rewrite路径或用户答案拼接策略。记录场景的问题文字改短不改变被断言的核心契约，无需扩展修复。

## Delivery Limit

本地确定性检查通过支持进入真实对照；不能独立关闭动作遗漏的质量问题。v1真实输出已经暴露首段条件缺失、操作时序错误和目的遗漏，不能用39通过抵消这些结果。
# Critic Review — Segmented Procedure Coverage (v1 History)

**Review target**: `docs/specs/segmented-procedure-coverage/design.md` v1  
**Review mode**: 完整 critic（生成热路径）；不启用 STRIDE/FMEA，本轮不改安全边界或领域故障诊断机制。  
**Review date**: 2026-11-11  
**Independence**: 独立读取设计、实际实现和旧实验原始输入/输出；未读取 defender 报告，未修改业务代码，未运行真实模型。

## Summary

- Critical: 0
- High: 0
- Medium: 0
- Low: 0
- Decision: **可进入编码与有界实验**。没有编码前必须修订的阻断项。
- 这仅批准最小 prompt 修复的试验，不证明流程质量已修复，也不批准默认开启。默认仍应为 `false`，直到 REQ-603/604 的真实答案、调用与时延验收完成。

## Findings

未发现需要登记为 open 的设计缺陷。按根 AGENTS §0.1，不能仅因生成有随机性、将来可能漏步骤而增设分类器、覆盖平台、额外模型核验或新发布门禁；现有设计已把这种不确定性交给必要的真实对照和新留出验证。

## Evidence and Causal Review

### Reproduced Failure

`data/eval/local-adaptive-holdout-candidate/model-http.jsonl` 中扫描器对应 generation index 1、9、10、18 的实际输入均包含指定参考纸准备、序列号、日期/结果记录以及保留失败记录；四次实际预算均为 2048。本次准备/记录遗漏不应归因于检索缺句。

原始模型 JSON 的 answer 段数依次为 1、2、1、1。index 18（Thinking R2）的原始 JSON 已经遗漏指定参考纸准备与保留失败记录；发布后的完整正文同样遗漏，不是解析器或 PII 检查删掉动作。对应完整生成基线 index 18 保留这两个动作，构成已复现的配对退步。Fast 两次的步骤/记录也不完整；不能用它们更短、更快当作质量合格收益。

### Prompt Mechanism

`data/profiles/general.yaml:33-34` 同时要求首段回答所有问题、后续仅在必要时简洁解释、不重复首段、条件只在 conditions。对多阶段流程，这些指令推动把实际步骤压成概述。设计 v1 第 13–15 行解除上述冲突，并明确动作、触发条件和所问目的的关系，是与已复现问题直接对应的最小改动。

**praise (non-blocking)**：设计保留 conditions→answer，把答案本身按步骤组织，没有额外事实摘要、内部计划或第二次生成。它区分“记录的目的”与“需要记录什么”，并禁止混合不同阶段的起算事件，覆盖了旧输出中实际可见的两类质量问题。

这是合理的因果假设；不能仅依据提示词出现“完整”或 mock 输出包含步骤，就宣称假设得到验证。

## Invariant Review

| Item | Finding |
|---|---|
| Evidence and cost | `core/local_rag_generation.py:build_generation_request` 仍绑定原 sources/kept 输入、2048、none、0.7、0.8；设计不增加模型或在线核验。实际 HTTP 数仍须由实验确认。 |
| Parser and publication | `ParagraphParser` 只有在 conditions 完整且首个 answer 对象带合法分隔符时才合并发布；增加后续 answer 不要求修改 parser。 |
| Output checks | `CheckedParagraphs.append` 检查累计正文、只能追加已检查前缀；设计允许条件随步骤重述，不要求改写已发布文本。 |
| Failure and unavailable signals | 非 stop、无效来源、检查拒绝继续既有未完成/不可用终态；分段生成的 confidence 仍为 None/degraded。设计未把协议完成或结构合法当语义正确。 |
| State and concurrency | 无新增 shared_state 键、实例状态、缓存或持久化；Skills 状态所有权和并发契约不受影响。无需为本次 prompt 修改另建并发机制。 |
| Routing | 比较问题与 rewrite_count>0 仍走原完整 schema；不能把回退问题计为分段覆盖或分段加速。 |
| Security | 不执行资料指令、来源编号校验及原 PII 检查保留；不使用绕过检查的原文拼接。没有本轮需新增安全控制的事实。 |
| Rollback | 只恢复 general profile 的本段 prompt；默认 false 时，默认用户路径保持原完整生成。 |

## Validation Review

设计第 23–28 行的矩阵与本次风险相称：

- prompt golden 覆盖实际加载到请求的系统提示；单元和两模式 Graph/API 测试证明多段正文、引用、done、历史与单次最终生成契约。既有解析/检查失败回归继续运行；mock 不能证明语义完整。
- 机制三轮对照核对真实输入相同，按操作及触发事件读完整答案，同时保留原始模型 JSON 与检查后的正文。准备材料、记录项目、失败记录与重置起点均是已复现问题，不能只检查某个数字或词。
- 最终开发 API 与新中英流程留出逐槽审首段和全文；未生成、截断与正文完整分列。设计第 27 行“完整答案仍须覆盖所有所问动作”是绝对质量要求：即使基线也漏同一步，也不能把候选该槽位标成完整合格。
- 只有质量合格的发布才能支撑首段收益结论。首段可以概括规则，实际步骤在后续；不能把影响执行的条件推迟到后段换取提前发布。
- 新留出在候选固定后冻结；若输出触发 prompt 再修改，该题退为开发回归并另冻新题。两题、两模式、三轮有界规模可用于本次决策，不足以宣称普遍消除所有长流程遗漏。

## Minimum Revision

**无强制设计修订。** 按现有 v1 实施即可。若实际输出仍遗漏动作、混合起算点或因新增细节截断，应记为本轮实验未合格，保持默认 false，再根据复现事实修订；不能把质量缺口改成措辞差异或以更低时延抵消。

## Implementation Follow-up

最小业务修改、golden 实际请求绑定和两模式 API 多段/历史/单调用契约与 v1 设计一致，红 9 failed/30 passed → 绿 39 passed，无额外实现阻断。随后真实机制 v1 出现已复现语义失败；详见 [机制评审](mechanism-v1-critic.md)。设计准入不等于质量通过，当前不得据 v1 提高默认或跳过失败修订进入留出。

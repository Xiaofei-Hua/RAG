# Production Code Defender Review

**Date**: 2026-11-11
**Object**: tracked diff、`core/procedure_generation.py`、`tests/unit/test_procedure_generation.py`、流程golden及红绿日志。
**Method**: 独立读代码及已有测试证据；只对原源码中语言/流程判断函数做AST提取后的确定性计算，未读critic、未改代码、未调用模型或创建留出。
**Decision**: 完整生成后检查发布、证据映射与history保留主线符合设计；发现1个High语言边界和1个Medium流程误分流，需要在候选冻结前修复。明确同语言的既定API开发对照仍可提供有效证据。

## Verified Main Path

- `core/procedure_generation.py:91–99` 在任何正文渲染前要求stop、完整schema和有效条款ID，不能用半个选择输出生成部分原文。
- `core/segmented_generation.py:149–159` 等待generation_chain返回完整答案，再调用CheckedParagraphs一次并发布一个token与done。检查抛错时publisher还没有正文，走固定不可用；没有原句旁路。
- `core/local_rag_generation.py:119–141` 在调用前准备语言/证据/上下文，失败即选择完整GroundedAnswer；sync/async均一次invoke。调用后的渲染错误不会额外调用模型。
- `core/procedure_generation.py:55–84` 使用结构化evidence渲染的完整证据块进行一次替换，保留其余context；来源来自结构化source与inputs.sources，允许同源多chunk，不从正文猜来源。
- Fast sync/async/SSE与Generate sync/async均传递本次kept evidence。未新增shared_state、持久化、REST字段；非流程prompt恢复主干。
- 指代合并在单个evidence项内部进行，英文匹配有词边界；跨来源不合并。若相同来源的不同chunk并非相邻，当前也不会冒充已解决跨chunk指代。

## Findings

### PCD-01

- **Severity**: High
- **Location**: `core/procedure_generation.py:33–36`、`:49–54`
- **Symptom**: `_language`把任意拉丁字母文本当作英文，把含任意一个汉字的文本当作中文。已确定性复现：`Le contrôle doit être effectué avant utilisation.` → `en`；`说明：Prepare the sheet and keep failed records.` → `zh`。
- **Impact**: 英文流程问题配法语资料，或中文问题配中文标题/英文正文，会被视为同语言而进入原文编排；交付正文语言可能直接不符合用户要求。违反已明确约定的混合/跨语言调用前回退。
- **Root cause**: 用字符出现与否替代同语言资格检查，且没有表示不确定/混合的状态。
- **Recommendation**: 收窄到有把握的中英文同语言输入；混合或不能确定的证据在调用前使用既有完整生成。只需修本预路由，不要求通用语言识别平台。
- **Verification**: 增加上述法语及中英混合资料回归，经过真实generation_chain请求绑定断言选择GroundedAnswer、模型仅一次；保留现有纯中/英文正例。
- **Status**: open。

### PCD-02

- **Severity**: Medium
- **Location**: `core/procedure_generation.py:9–12`、`:29–30`
- **Symptom**: 已确定性复现：`如何理解这个结果？`、`How can these results be interpreted?`都被判为流程请求。
- **Impact**: 这些解释性问题在开关开启时会改变为原句选择流程，超出“明确要求流程/步骤/如何操作”的已审范围，可能无法形成用户所求解释。
- **Root cause**: 所有“如何/怎样/怎么”及泛化how can/how do都直接作为流程充分条件，没有操作语义或明确流程词要求。
- **Recommendation**: 使用明确流程/步骤/操作请求作为保守正例；一般理解、解释、原因类问题维持原分流。不要加入模型分类调用。
- **Verification**: 为上述非流程问句增加请求schema回归；保留当前两个实际开发流程仍进入选择路径的断言。
- **Status**: open。

## Test Evidence and Limits

`validation/production-red.log`记录17failed/32passed；`production-green.log`记录49passed。新测试覆盖完整选择、真实请求参数/golden、history、同源多chunk、缺映射/证据/块回退、length/非法ID/检查失败和两模式API正文/引用/历史。API还在所选原文中注入电话，证明现有PII检查没有被抽取路径绕开。

目前跨语言回归只覆盖英文资料+中文问题；没有覆盖含拉丁字母的非英文、混合正文或一般“如何理解”误分流，所以49通过不能消除上面两项。golden是固定模型替身输出，只证明接线/渲染契约，不代替真实步骤完整性；真实v4机制通过与生产API验证仍须分别归档。

没有提出原变更范围之外的审查平台、额外模型或新默认门禁。修复以上预路由边界并定向红绿后可复审冻结；默认继续false。
## Qualification Fix Follow-up

两项已按最小边界修正并独立复核：流程检测移除泛化“如何/How do/How can”，保留明确步骤/流程/操作顺序/how to 等；语言检测对非 ASCII 外语字母、显著混合正文和缺少英文功能词依据的资料返回不确定。直接提取当前函数复测，上述两个解释问句不再进入流程；法语和“说明：Prepare the sheet and keep failed records.”均不再视为同语言可抽取正文。

`tests/unit/test_procedure_generation.py`新增对应真实请求绑定回归，断言回到完整 GroundedAnswer 且单次请求；保留纯中/英文及指代合并正例。`validation/routing-green.log`的首次 1 failed / 54 passed 仍保留，最终 `validation/routing-green-final.log`为 55 passed。没有调用真实模型来完成此修正复核。

PCD-01/02的代码问题现已 **verified-fixed**；正式 tracking 的 closed 仍须在交付提交后填修复 commit 和永久回归列。此结论仅确认资格修正，不赋予质量默认启用资格；实际 API 的低相关 foreign 回退与无关条款选择失败详见 `api-development-defender.md`。按主任务最新决定暂停留出冻结。
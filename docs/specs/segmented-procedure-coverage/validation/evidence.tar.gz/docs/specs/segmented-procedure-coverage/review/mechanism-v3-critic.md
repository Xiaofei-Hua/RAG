# Critic Review — Procedure Mechanism v3

**Review date**: 2026-11-11  
**Review target**: `data/eval/procedure-mechanism-v3/results.jsonl`、`model-http.jsonl` 与逐题 `units`；`validation/mechanism.json` 全文要求和 v2 分段发布契约。  
**Independence**: 未读取 defender 报告；未调用模型，未新增实验。

## Decision

**v3 未合格：候选全文 0/6 通过，对应既有分段基线全文 1/6 通过。** 基线唯一完整通过的是中文 R1。候选 v2 首段综合 2/6，原全局首段 0/6；所有候选均未形成全篇正确且各操作段完整的结果。不接入生产解析器，不进入 API/新留出资格，默认保持 false。

关键失败没有被句级 ID 解决：模型仍把属于换头事件的重置句放入普通周期段；被选择的来源句中也仍有关键事实没有写进正文。ID 合法、文档引用由 ID 派生，都不能证明这些关系或全文覆盖成立。

## Execution Facts

- 六个基线与六个候选均 stop，每答一次正式 generation；共12次正式生成加一次预热 control。
- 正式请求均为2048/none/0.7/0.8。没有 length 样本；“未截断”不等于内容完整。
- 候选来源编号映射为英文18条、中文13条，均可在所给完整文档定位。本评审核对了原始 JSON 的 support_ids/text，不只看渲染后的来源名。

## Per-slot Review

`Old lead` 是原全局首段完整条件契约；`v2 lead` 是主要操作规则、通用范围与相关引用。全文按具体动作、目的、失败记录、起算/重置与支持关系判定，不因段数或同义表述失败。

| Case | Round | Variant | Old lead | v2 lead | Full answer | Concrete evidence |
|---|---:|---|---|---|---|---|
| Scanner | 1 | baseline | Pass | Pass | Fail | 没有准备指定参考纸及保留失败记录；缺周期检查用途与旧头结果不能替代新头资格的说明。 |
| Scanner | 1 | candidate | Fail | Pass | Fail | 第3段把换头重置句用于普通周期复查；该段 support_ids=[5,6,8,9]，没有第7条换头触发。 |
| Printer | 1 | baseline | Pass | Pass | Pass | 准备、全部检查后记录、失败样张、三个阶段目的、初始/换托盘起算、350触发与未知边界齐全。 |
| Printer | 1 | candidate | Fail | Pass | Fail | 缺首次检查建立定位基准的目的；准备与记录被放到“周期复查与记录”而未完成初次流程。第11条已选中，但其初始目的没有实现。 |
| Scanner | 2 | candidate | Fail | Fail | Fail | 首段只有环境及泛称存在检查要求，没有可执行主要规则；全文漏保留失败记录，普通周期被赋予重置，换头阶段没有明确通过后重置及周期检查目的。 |
| Scanner | 2 | baseline | Pass | Pass | Fail | 缺参考纸准备、序列号、日期/结果及保留失败记录等具体动作，不能用“keeping records”概括代替。 |
| Printer | 2 | candidate | Fail | Fail | Fail | 首段只有环境。全文没有周期复查用于确认定位未偏移的目的，即使第11条已选择；其余关键动作大多恢复。 |
| Printer | 2 | baseline | Pass | Pass | Fail | 缺指定纸、机台/托盘编号、检查后日期/样张/结果及初始建立基准的说明。 |
| Scanner | 3 | baseline | Fail | Fail | Fail | 把失败后通过写成重新起算；缺指定参考纸与失败记录，换头重置关系不明确。 |
| Scanner | 3 | candidate | Fail | Fail | Fail | 漏初始起算事件，把普通周期通过写成重置，换头段没有通过后重置；首段初始用途与第3段周期用途只引运行规则，实际来自检查记录。 |
| Printer | 3 | baseline | Pass | Pass | Fail | 缺具体准备、编号和检查后记录项目；未解释首次建立定位基准。 |
| Printer | 3 | candidate | Fail | Fail | Fail | 首段只有环境；全文漏初次计数从检查合格开始及周期复查确认无偏移的目的。unit3与unit11虽被选中，对应事实仍没有写出。 |

汇总：基线旧首段5/6、v2首段5/6、全文1/6；候选旧首段0/6、v2首段2/6、全文0/6。候选英文 R3 的主要规则/范围正文存在，但引用支持不全，因此不能算合格首段。局部操作段契约也不能整体通过：英文的周期段错误重置，中文的阶段目的或起算缺失都发生在实际操作段中。

## Decisive Samples

### Scanner R1: Valid IDs Do Not Preserve the Trigger

英文第7条是“换扫描头后重新检查”，第8条紧接着规定该次检查通过才开始新37小时区间。候选在普通周期段选择 [5,6,8,9]，生成“Begin a fresh 37-operating-hour interval only when the check passes”。它没有同时绑定第7条事件，且把第8条的指代改成周期检查。后面的换头段正确再次使用 [7,8,16]，也不能抵消前一段新增的错误规则。

该答案实际上已选择所有承载事实的英文条款（未选择的仅检查记录标题），仍然错误。覆盖编号不能作为此机制的合格条件。

### Scanner R2: Selecting a Sentence Does Not Realize All Its Facts

第二段选择第13条：该条同时要求记录日期、结果并保留失败记录。正文写了日期与结果，却没有保留失败记录。第三段 [6,5,8] 又将换头重置句脱离触发事件使用；第四段虽说明旧头资格不能替代新头，却没有把通过后重新计时写回换头阶段。编号既未保证复合事实覆盖，也未保证正确归属。

### Printer R3: All Content IDs Selected, Yet Key Facts Missing

候选覆盖所有承载事实的中文条款，仍漏了两项：unit3 的“首次计数从初检合格开始，不从通电/装纸开始”；unit11 的“周期复查确认定位没有偏移”。全文只写换托盘后的重新累计，不能补足首次起点；写周期复查动作也不能替代用户要求的作用解释。

### Scanner R3: Derived Document Citation Still Misses Support

首段 support_ids=[1,2,10]，正文却增加初始检查建立安装基准的目的（第14条，检查记录文档）；周期段 support_ids=[5,8,9]，正文增加周期检查用途（第15条，检查记录文档）。程序据所选条款派生的引用仅有运行规则，仍不能支持这些用途。细粒度选择先于文本，未保证后续文本不越过所选支持范围。

## Findings

### F-05 — 逐段条款选择仍未关闭步骤/目的缺漏和错误事件绑定

**issue (blocking, must-fix)**

- **id**: F-05
- **severity**: Critical，critic §2(a)：目标缺漏及错误重置在 v3 仍可复现；v1/v2 同类发现不能关闭。
- **location**: `data/eval/procedure-mechanism-v3/results.jsonl:2`、`:5`、`:7`、`:10`、`:12`，对应原始 generation HTTP 3、6、8、11、13；REQ-601。
- **symptom**: 三个英文候选均把重置移至普通周期段；中文候选仍漏初始/周期目的或计数起点，部分是在相应ID已经选中后遗漏。
- **impact**: 用户答案仍不可按原规则完整执行；语义错误被合法编号和 stop 包装，不能算修复。
- **root_cause**: 支持编号是模型自报选择，不能强制正文表达全部被选事实，也不能让含指代的条款自动绑定正确事件。
- **recommendation**: 本轮机制不得接入生产或进入默认资格。保留失败原文、ID与对应事件，以其作为下一设计必须解决的真实问题；不要通过强制所有ID出现、把所有原句附加到答案或再加同义禁止提示来关闭。
- **verification**: 任何后续方案仍须在真实最终正文中分别验证初始/周期/更换/失败事件、所有具体记录项目及所问目的；编号命中不计语义通过。
- **status**: open

### F-06 — 从所选条款派生来源未保证生成主张受其支持

**issue (blocking, must-fix)**

- **id**: F-06
- **severity**: High，critic §2：已复现生成热路径的引用支持失效，v2 F-04 未关闭。
- **location**: `data/eval/procedure-mechanism-v3/results.jsonl:10` 的第1/3段，原始 HTTP11；英文支持条款14/15所属文档为检查记录。
- **symptom**: 最终正文加入所问目的，但该段只选择运行规则条款，派生的文档引用缺少实际支持用途的检查记录。
- **impact**: 用户沿引用仍无法核对段落全部主张；只验证ID存在与所属来源的程序无法识别此错误。
- **root_cause**: 先写 support_ids 没有约束之后 text 的语义范围；自动来源派生只能忠实反映错误选择。
- **recommendation**: 不把映射正确计作引用支持正确；当前实验不推广。后续方案需对实际正文和来源关系提供实测证据，保持现有人工全文评审，不新加在线模型。
- **verification**: 检查初始/周期用途是否真正由本段支持条款覆盖，且引用包含检查记录来源；仅增加合法ID而正文仍错误不算关闭。
- **status**: open

## Timing and Qualification

原始首段P50：基线3.166s → 候选1.652s；全文P50：基线3.512s → 候选5.024s。候选较短首段包括三个只有环境或泛称规则的开头，且全文0/6合格，不能作为可交付性能收益。当前证据支持否决 v3 的生产准入，不支持“全部ID合法所以质量已修复”。

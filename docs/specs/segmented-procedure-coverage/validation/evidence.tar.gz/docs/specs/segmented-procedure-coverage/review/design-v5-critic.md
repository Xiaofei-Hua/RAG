# Critic Review — Explicit Negative Selection

**Review date**: 2026-11-11  
**Target**: `design.md` 最新 v5 末节、`validation/v5-prompt.txt`；文档门控以 `rerank_output_space="probability"` 修订为准。  
**Independence**: 未读取 defender 报告，未调用真实模型，未修改业务或测试代码。核对了现有重排/证据代码、本地 Sentence Transformers 5.4.1 的激活加载与 predict 路径，以及官方接口说明。

## Decision

- Critical: 0
- High: 0
- Medium: 0
- Low: 0
- **允许开始 v4/v5 每侧 12 条机制实验；允许按最新范围实现文档门控的定向红绿。无剩余设计阻断。**

本准入不表示 v5 已改善语义，也不表示 API 或默认启用合格。F-09/F-10 仍待实际验证；非流程 F-11 不因流程实验通过而关闭。默认继续 false，新留出仍须等候选固定。

## Selection Mechanism

**praise (non-blocking)**：把“哪些条款不相关”作为同一次结构化输出的先行决策，直接针对 API 中已经发生的包装/库存误选；随后仍只编排原文。该变化比新增条款评分平台更小，也没有重新引入 v1–v3 的自由事实改写、全篇计划或第二次摘要。

全部编号归于 omitted 或 answer、两者互斥，只验证选择结构有结果。模型仍可能把失败记录、检查目的、起算条件或价格未知误分到 omitted。因此全文必须继续由独立审阅逐项确认；没有遗漏分类不等于没有语义遗漏。跨答案段必要重述允许，未分类不得由程序补回。非法分类、未 stop 或输出检查失败仍不可用，不能增加一次生成修复。

实验比较同两开发题、原/逆来源顺序、各三轮，v4/v5 每侧 12 条，能够检查显式负选择是否降低实际干扰误选以及是否受来源位置影响。题目和无关句均已暴露，不能计作新留出。所有失败、无效分类和截断均留在原分母中；完整动作/目的、无关内容、首个完整发布、耗时和实际调用分别报告。

2048/none/0.7/0.8 与一次最终生成保持。omitted 数组会增加少量输出成本，不能把未完成的更快响应算作收益；整个选择 stop 后一次检查并发布的契约不变。

## Qualified Mixed-Evidence Admission

最新修订已排除初稿的范围问题：**不强制覆盖模型激活，不新增会被其他路径消费的 rerank_prob/rerank_probability。** 只在实际模型默认激活已知为 Sigmoid 时标记原 rerank_score 的输出空间，流程门控局部读取；原值、predict 参数、既有全局消费者和前向次数不变。

官方接口说明 predict 可使用模型自带 activation_fn；本地实现也会先加载模型保存的激活配置，再使用默认值。因此“单标签默认 Sigmoid”不能被解释为所有可配置模型都可强制改成 Sigmoid 且旧值不变。当前类型识别与未知回退的修订正确处理了这一点。[Sentence Transformers CrossEncoder](https://www.sbert.net/docs/package_reference/cross_encoder/model.html)

门控仅在同语种至少一份有效已重排概率 ≥0.9、所有异语资料均有效已重排且概率 ≤0.01 时允许原文选择。低相关异语资料保留在上下文作为无编号背景，原 sources 与共享 kept 不变；这些背景没有可选条款 ID，不伪装成答案引用。高相关异语、缺失/非法概率、未知输出空间或重排失败继续生成前回完整路径。None 不被填成 0。

这些数值只是本次已观察强弱分离的局部门槛，不是覆盖充分性的证明，也不能称为校准后的正确性概率。门控成效须由真实 Fast 请求的实际 schema 和答案质量确认；仅把 eligibility 从 False 变为 True 不算修复 F-09。

## Verification Boundary

定向回归应覆盖本次变化直接触及的行为：

- 真实 Sigmoid 输出类型才写 marker；Identity/未知类型不伪装成概率；predict 次数和既有 raw 值保持。
- 强同语种加极低异语时仍保留完整背景和历史、实际选择来源映射正确；高相关异语、缺分或重排失败回原完整单次生成。
- omitted/answer 互斥与总编号分配、跨段重复、无效结果不提前发布；仍通过原 PII/输出检查。
- 真实机制结果不能用 mock 或合法 ID 代替语义；机制合格后再对实际 API 做配对复核。

这些是改动边界的直接验证，不需要扩展全局重排分数统一工程。中文包装/库存评分高于必需未知价格的诊断已否定硬阈值删条款，停止该方向符合最小实验原则；本次不增加条款 BGE 计算或其他在线模型调用。

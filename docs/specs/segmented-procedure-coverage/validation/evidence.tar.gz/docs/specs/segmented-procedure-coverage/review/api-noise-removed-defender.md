# Noise-Removed API Defender Review

**Date**: 2026-11-11  
**Candidate**: `data/eval/procedure-api-noise-removed-candidate/{results.jsonl,model-http.jsonl}`，24 答。  
**Baseline**: 已独立审阅且保持冻结的 `data/eval/procedure-api-final-baseline/`，24 答；false 路径未改，按已审计划复用。  
**Protocol**: `validation/api-development.json`，六题 × 两模式 × 两轮。  
**Decision**: **被改流程 8/8 通过；严格非流程两侧各 15/16，候选总计 23/24。保留一条未改路径的配对下降，不宣称全题无退步。可继续有限流程的新留出；默认仍待留出和最终矩阵决定。**

**Scoring correction**: 初版将数值并列视为已完成记录排序，口径偏宽。按原 manual_required 的明确记录比较要求，候选行 13 与基线行 1 均应失败。下文已更正；没有改判据、题目或模型输入。独立复核 16 对非流程完整生成请求逐字段相同，故本次有限资格评估保留随机未改路径失败，不重新调未改提示追逐单批全胜。

## Procedure Pairs

行号为各自 results.jsonl 的 1-based 行号；基线失败细节保留在 `api-final-defender.md`。

| Row | Round / Mode / Case | Baseline | Candidate | Full-answer result |
|---|---|---|---|---|
| 5 | R1 / Fast / scanner | Fail | Pass | 准备、全部记录、初始/周期/换头/追溯用途、37 小时及排除项完整；正确初始/换头起算，未知户外/费用齐全。 |
| 6 | R1 / Fast / printer | Fail | Pass | 此前漏掉的记录追溯目的已在通用检查记录段恢复；其余准备、检查、具体记录、失败样张、用途和条件仍完整。 |
| 11 | R1 / Thinking / scanner | Fail | Pass | 全部动作、用途、事件及引用完整，未将普通失败复查泛化为复位。 |
| 12 | R1 / Thinking / printer | Fail | Pass | 各阶段动作/记录/用途齐全，350 张复查和换托盘起算分别成立。 |
| 17 | R2 / Fast / scanner | Fail | Pass | 与 R1 对应正文相同；无新遗漏或不相关背景扩写。 |
| 18 | R2 / Fast / printer | Fail | Pass | 与 R1 对应正文相同，追溯目的仍明确保留。 |
| 23 | R2 / Thinking / scanner | Fail | Pass | 完整覆盖，周期验证用途没有被省略。 |
| 24 | R2 / Thinking / printer | Pass | Pass | 全文记录和用途完整，保留基线已合格能力。 |

候选所有流程都没有包装颜色/库存。通过依据不是这两个干扰词未出现，也不是合法 schema，而是实际全文中各动作、先决条件、失败处置、记录项目、所问目的与引用支持全部成立。温度 0 的各 mode/case 两轮正文相同，作为重复确认报告，不夸大独立样本量。

英文 Fast 采用资料说明与许可条件分段的结构，记录说明可能先于 `Starting Ordinary Scanning` 段，但没有写“检查前记录通过/失败结果”；准备明确 before the check、扫描许可明确 initial check passes。换头原句在 Failure Handling 下重述时仍有 After replacing 前提，不会变成普通失败强制换头或重置。中文通用记录段对合格与不合格均适用，未实际缩限到某一检查阶段。无实质影响的重复不单独失败。

候选内部首段均有主要运行规则和范围，符合 v2；旧“书面首段列全所有阶段条件”仍未满足，历史结论不改。实际第一次公开正文是完整全文，经过 stop 与输出检查后一次发布。

## Non-procedure Pairs

每个列出的行号都与冻结基线逐题比较；严格两侧各 15/16。候选行 13 相对基线下降，候选行 1 相对基线上升，两者均保留，不用相同总分抵消配对结果。旧非流程分段的无关扩写未再出现。

| Case | R1 Fast / Thinking | R2 Fast / Thinking | Assessment |
|---|---|---|---|
| Battery records | 1 / 7 | 13 / 19 | 数值和负载边界正确，但候选行 13 未明确给记录排序，基线行 1 同类不足；其余两侧通过。 |
| Zero measurement | 2 / 8 | 14 / 20 | 10 分钟、0 ms=0 s、已经测量而非缺测，引用正确。 |
| Calibration | 3 / 9 | 15 / 21 | 120 日历日及正常连续使用条件、首次投入确认、换探头后先校准并从完成日起算均正确。 |
| Price / warranty | 4 / 10 | 16 / 22 | 价格未知，交付日起 18 月保修；未把显示尺寸当价格，语言和引用正确。 |

R2 Fast 行 13 先列 10 小时与 9 小时，随后说无法直接比较；虽然没有数值错误，也说明同负载不足，但没有直接完成用户要求的“先按记录比较”。严格判失败，不以读者能自行推断 10>9 替代所问结论。同样标准下，冻结基线行 1 只并列数值而未明确给出记录排序，也判失败。这是对评审口径的纠正，不是新加模型要求。

## Actual Evidence and Calls

- 候选 Fast 两类流程的真实生成输入都只有两份相应资料，API sources 同样只有这两份；原低相关异语言背景已从 prompt 和本次生成来源同时移除。相关原文与正确引用保留。
- Fast 中文两轮实际正文均包含“保存机台、托盘与样张记录便于追溯偏移来源”，它在当前完整记录段中发挥解释作用，不是尾部附录补指标。旧候选漏句记录仍保留，未覆盖旧失败。
- 8 个流程实际为 ProcedureParagraph / conditions+answer，temperature=0；16 个其他问题实际为 GroundedAnswer / basis+conditions+conclusion，temperature=0.7。
- 共 60 条实际 HTTP，与基线相同：每个 Fast 1 次最终生成；每个 Thinking 3 次原控制 + 1 次最终生成。全部 stop，2048/none/top_p=0.8；没有新增核验、重试、补写或翻译。每条正文一次 token 发布。

## Timing and Limits

下表单位秒，P95 为小样本线性插值。基线来自前一冻结批次，不是同期交错实验；不能将批次/首请求波动直接归因于流程选择。

| Subset | n/side | Baseline first P50 / P95 | Candidate first P50 / P95 | Baseline full P50 | Candidate full P50 |
|---|---:|---:|---:|---:|---:|
| Fast procedure | 4 | 7.927 / 9.541 | 4.096 / 4.307 | 7.927 | 4.096 |
| Thinking procedure | 4 | 12.895 / 15.158 | 7.469 / 8.653 | 13.010 | 7.577 |
| Fast non-procedure | 8 | 3.207 / 4.022 | 3.241 / 7.236 | 3.207 | 3.241 |
| Thinking non-procedure | 8 | 5.646 / 5.790 | 5.555 / 6.173 | 5.752 | 5.659 |
| All questions | 24 | 5.646 / 13.102 | 4.480 / 8.653 | — | — |

完整流程等待有明显下降；整体 P50/P95 也下降。但 Fast 非流程 P95 恶化，其中候选首请求为 9.106 秒，原因未经单独归因，不能宣称所有分位数都改善。当前结论是有限流程质量通过、调用不增，允许进入独立新留出；不是无条件默认启用。

## Fresh Holdout Freeze

在被改流程 8/8 确认之后，独立创建并冻结 `validation/holdout-v1.json`：中文馆内档案调阅、英文音频字幕审批，各两份全新资料，包含新状态分支、交接/审批条件和不同记录结构，附少量无关信息。它们没有进入已完成的设计、提示或实现。题目、完整语义判据与来源映射已离线固定，只有 query 和 corpus 经正常资料入口送入模型。初次冻结说明沿用了非流程 16/16 的宽松评分，现已仅更正该元数据为严格 15/16 并记录勘误；corpus/cases/query/判据不变，正在运行的留出输入不受影响。

两题 × Fast/Thinking × 三轮，每侧 12 答，对照 false/true。代码、prompt、温度与阈值保持冻结；不得据这些答案调当前候选。结果若需要改动，原题转为开发，另建新留出。当前默认仍 false。

本 reviewer 未读 critic、未调用模型或改业务代码。已核对所有候选全文和原始请求；冻结题 JSON 已解析校验，来源均存在。
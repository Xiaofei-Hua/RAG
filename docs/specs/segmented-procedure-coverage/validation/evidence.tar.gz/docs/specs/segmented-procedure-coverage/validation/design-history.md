# Design — Current v6 (Deterministic Selection Experiment)

## Reproduced Failure and Hypothesis
基线为main f7984fe。旧v5h_scanner_procedure已公开，退为开发回归。原始HTTP输入证实两种模式的4个候选生成均包含Prepare the designated reference sheet和keep failed-check records，且max_tokens=2048、reasoning=none；错误不是检索丢句或上下文截断。候选3/4只有一个答案块；提示同时要求首段回答所有问题、后续仅必要时简洁解释，鼓励把长流程压成概述。
假设：在原conditions→answer结构内，解除流程首段必须包含全部步骤的压力，明确后段覆盖具体动作、触发/先决条件和所问目的，能减少遗漏；不再输出额外内部计划或事实摘要。此为待真实模型检验的因果假设，输入包含事实不证明模型必然正确使用。

## Research and Transfer
从[Lei Wang个人主页](https://demoleiwang.github.io/HomePage/)追踪[Plan-and-Solve论文](https://aclanthology.org/2023.acl-long.147/)及[作者实现](https://github.com/AGI-Edgerunners/Plan-and-Solve-Prompting)。该工作把多步任务的遗漏与任务分解联系起来；原实验主要是GPT-3推理题，不能直接外推本地9B的RAG操作说明。
本项目只迁移“按问题所要求的阶段组织最终答案”的思路，不引入该实现的推理输出/最终答案提取流程，不开启隐藏思考、不增加模型调用。最小实验比较同证据/采样/预算下的旧与新prompt。JSON约束仍只能保证结构和来源编号，不能作为语义覆盖证明。

## Minimal Strategy
仅修改general profile的segmented_generate_system，保留公共schema、生成路径与分流函数：
1. 非流程问答保持首段直接回答所问。流程问答首段概括主要操作规则，conditions仍承载会改变结论的全部适用/起算/失败/未知边界，检查后合成首段。
2. 后续answer按用户所问阶段与资料中的操作顺序分段，写全资料支持的准备动作、执行动作、记录项目、失败分支及所问目的；每个动作的先决/触发条件与动作一起写清。不能只解释“用于追溯”而漏掉需要记录的项目，也不能合并不同阶段的起算事件。
3. 用户要求流程时不能把后续答案降为可选简短解释；条件可为清晰性随步骤重述，不引入首段没有的新限制。未提供的步骤/数值/规则明确未知，不从领域常识补足。
不硬编码扫描器、型号、37小时、资料名或开发题答案；不增加流程分类器或字段。先做prompt最小修复；只有实测不足才修订设计，不预先建设语义检查平台。

## Architecture, State and Failure
输入kept证据→同一次conditions/answer生成→既有ParagraphParser→同一Guardrail检查→JSON/SSE/history。无shared_state/REST/schema/持久化变化；无新增模型和缓存。Prompt仍由DomainProfile派生。比较/rewrite继续原完整schema。空资料、invalid ID、length与检查失败继续None/degraded/未完成，不额外生成。跨段发布及取消均复用已测试实现。
安全边界不变，资料指令不可执行；不允许用原文拼接补救漏步，避免绕开PII和用户语言。回滚只恢复该prompt；默认开关仍false直到质量验收。若未来提高默认，需单列公开配置影响、更新CHANGELOG与部署文档。

## Validation and Budget
- 确定性红绿：新prompt golden及真实请求绑定，已有多段解析/检查失败契约；进程内真实Graph+HTTP mock证明两模式流程多段正文、引用、done/历史一致且最终生成一次。不会把mock输出称为真实语义证明。
- 机制实验：旧v5扫描器+另一个中文流程开发题，各3轮交替旧分段/修复分段（每侧6），同模型/输入/参数；检查每个操作与起算事件，记录首块/全篇耗时和实际HTTP数。至少记录原始模型输出与输出检查后的正文。
- 最终API：旧4个开发题+2个流程题，两模式各2轮；对照当前默认完整生成和修复分段，报告所有槽位、两模式P50/P95、整题质量与调用数。已有比较回退不冒称分段加速。
- 候选固定后独立reviewer冻结2个新流程题（中英各一，分支/计时/记录不同结构），两模式各3轮，与完整生成配对；不能用新留出调当前prompt。任何调参后需另冻新题。
- 无新增实质步骤/条件/引用退步、开发复现修复、无新增调用是质量门槛；首段中位数有收益可支持启用，不要求每个分位数全面更优。首段允许把具体步骤留到后续，必须先给主要规则及会改变执行结论的限制；完整答案仍须覆盖所有所问动作。
- 预算保持2048 tokens，流程答案会比遗漏版更长；如因长度截断，不能以更快计收益。实验规模有界，不持续为单个措辞差异重跑。最终全量单元/E2E/perf、相关既有UI检查与独立全文评审后交付。

## v2 — Complete Local Steps, Not the Whole Procedure in the Lead
v1真实三轮每侧6答均协议完成，准备/失败记录明显恢复，但仍有已复现退步：英文R1先记录pass/fail再检查；R1/R3把失败复查合格泛化为重置周期；英文R2漏掉两个所问目的。中文三轮conditions为空，首段少关键操作规则；英文R3却把动作/用途堆为12个conditions，首段8.495s。观察证实动作阶段混合与条件分配不稳定；把全流程所有限制搬到首段的要求可能加剧概括压力，这是待验证的因果假设；继续追加首段覆盖清单会增加延迟和概括压力。
修订首段契约并显式记录，不能把旧判据下的失败改写为成功：流程首段给主要操作规则和通用适用范围，明确后续按阶段展开。每个已发布操作段必须包含它自己的先决/触发条件、动作、结果处理及所问目的；后续阶段的规则可在对应阶段首次给出，但不得推翻或缩限前段已作出的承诺。首段只是逐步回答的开头，不宣称整套操作说明已完整；完整状态继续以最终done为准。非流程问答仍直接回答问题。
conditions只放跨阶段通用的版本、适用环境、范围/未知边界，不再集中所有未来步骤的起算与失败动作。answer按所问阶段写完整用户答案，每个阶段把准备→检查/执行→得到结果后的记录/处置的顺序写清；不能在检查前记录检查结果。计数/周期/重置必须绑定资料明确指定的事件，不能把某一分支的规则推广到其他分支。资料支持的每个所问动作和目的仍必须覆盖，不能以“只给概览”通过全文质量。
无需新增分类器、schema或输出检查器：仍是同次conditions→answer、同一发布检查、同一预算。v1所有失败保留。先复用同2个开发流程×3轮旧/新机制对照；若未解决动作覆盖或因果错误，停止推进默认资格并依据具体失败另修设计，不能降低全文质量。
离线审阅同时报告旧“全局首段完整”判据与新“首段主要规则+每段局部完整”判据，避免将评价定义变化冒称质量提升；核心修复收益以完整答案正确覆盖为准。实际API与新留出按这个先冻结的v2契约审阅，不把关键字或格式当语义。第一段只有环境/价格而没有主要操作规则仍不合格。

## v3 — Bind Each Final Step to Fine-Grained Source Clauses
v2仍未合格：英文R1/R3把普通复查通过泛化为重置；中文R1漏准备与记录，R3漏周期350触发；还出现段落只引用另一份文档的问题。停止叠加纯提示清单，先用实验适配器验证下一最小机制，未通过前不扩展生产解析器。
依据[Attribute First, then Generate论文](https://aclanthology.org/2024.acl-long.182/)及[作者实现](https://github.com/lovodkin93/attribute-first-then-generate)，先选择细粒度支持信息再生成正文可作为降低自由概括的假设。原工作有多阶段/迭代生成；本项目只迁移每段先绑定支持片段的顺序，同一次调用内完成，不移植其多调用管线、不声称论文已证明本地效果。
实验把完整kept正文按句子/原换行加连续条款ID，保持全部原文、来源和原顺序，条款仍处于同一完整文档上下文与不可信资料边界；编号只用于定位，不是语义独立证明。每个conditions/answer对象字段顺序改为support_ids→text，support_ids枚举实际条款编号；先选直接支持该段的条款，再写最终用户答案。涉及指代的句子必须同时选择说明指代事件的条款；不单独拿“该次通过”推广到别的事件。source_ids从所选条款所属文档派生，防止支持来自文档A却输出文档B。原正文仍经同一输出检查。
不生成整篇计划/第二份摘要，不以原文附录补齐指标；最终text才是用户答案。引用条款被选中、ID覆盖或JSON合法均不能证明动作/用途覆盖，更不能代替全文人工评审。程序仅验证枚举与映射，不自动赋语义完整分。后段仍是v2每段自身完整的操作单元。
先在tests/integration临时适配器中比较主干旧分段prompt（实验显式开启，实际默认仍完整生成）与v3，每侧2流程×3轮，参数/kept证据/一次生成/2048预算保持；保存完整响应、support_ids与实际用户正文。若完整质量合格，再单独审阅最小生产接线设计与golden/API红绿；非流程和比较路径保持原合格实现，不把失败v2提示推广到全体请求。v1/v2失败及旧首段判据保留，默认false。

## v4 — Compose the Procedure from Selected Source Wording
v3候选全文0/6通过：实际已选到正确条款，仍在改写中漏掉动作/用途，并把换件的重置扩写到普通复查。对本复现，进一步强迫support_ids并不能修复自由改写。下一最小实验把最终生成任务收窄为选择和排序，而不是再次自由概括规则。v1–v3全部保留为失败，不进生产。
仅在实验适配器中使用同一完整资料、同样预算/参数/一次调用：模型返回answer数组，每段为title（只描述阶段，不写数值或新操作）与clause_ids；最终正文是所选条款的原文，按模型选择顺序组成清楚的阶段段落并附原来源引用。不存在另写的概括正文、附录补齐或第二次生成。重复选择只在同段去重，跨段有必要的条件重述可以保留。每段仍经过既有CheckedParagraphs与最终stop检查，引用不经过模型改写。
条款编号保持完整原文及原顺序。含指代词的句子（英文that/this/these/those/it/its，中文该/此/其/上述/本次）并回相邻前句，以保留“that check”前面的触发事件。此为有限的上下文保持策略，不宣称完整指代消解；独立审阅仍须检查标题/排序是否歪曲事件。模型可选择无关/漏选/错序，ID合法仍不作为语义合格。不能自动把所有kept条款塞到答案，必须由问题相关选择构成答案本身。
实验样本以同语言资料与问题为限；跨语言的原文拼装不符合语言要求，未来生产接线必须在生成前回到原完整路径，不能调用后再翻译。与v3相同的两个开发流程三轮配对；另外给两份资料加入明确无关的附件颜色/包装库存句，验证不会为了覆盖而照抄全部输入。完整答案要求不变：准备、执行、记录、异常、所问用途齐全，引用与触发关系正确且回答可用。首段主要规则仍须满足；不能因引用原文而降低语义或可读性门槛。
若最小实验通过，再另审生产接线；来源映射须来自结构化kept evidence，不能解析不可信正文假标题。原文每句被最终选择只减少自由生成成本，不保证完整性；只有真实API与新留出后才有默认资格。当前默认false。回滚移除实验适配器即可，未引入生产协议或状态变更。

## Production Integration — Complete Selection Before Publication
独立critic/defender均判定v4完整答案6/6合格，旧分段1/6；未见漏具体动作/目的、复位泛化、错误来源或无关包装内容。首段v2最低规则6/6，旧全局首段0/6；每一个中间段并非脱离全文后都自带全部失败/记录规则。为不削弱发布契约，流程路径不逐段提前发布：先等待同次紧凑选择JSON完整stop，组成完整操作说明，经现有输出检查一次后整体发布。无第二次调用，schema/模型参数仍同机制实验。此取舍增加相对v4早发首段的等待，但最终与当前默认完整生成做API质量/耗时对照，而不是把不完整发布算收益。
新增小模块core/procedure_generation.py负责ProcedureParagraph/ProcedureAnswer、同来源条款上下文合并、问题相关选择请求与原文引用合成。只在现有LOCAL_RAG_SEGMENTED显式开启、bounded资格、未comparison/rewrite，且问题明确要求流程/步骤/如何操作时进入；同语种中文或英文资料。混合/跨语言、缺结构化kept evidence、来源映射不全或选择支持范围外时在模型调用前回到原完整GroundedAnswer，不能生成后加一次翻译或修复。保守语言识别不声称通用语言检测。
Fast三入口及Generate sync/async把已有kept evidence放入本次generation inputs；没有新shared_state键、持久化或REST字段。来源编号从真实evidence.source与inputs.sources映射，允许多个chunk同源，禁止从正文标题猜来源。完整原始context中的history继续保留：仅用结构化evidence渲染得到的完整证据块进行一次替换；块不存在则回到原完整路径。不删除其余上下文。
local_rag_generation的单次请求/渲染选择支持procedure；stream_answer对此路径复用同一生成链，等完整结果后用CheckedParagraphs一次发布。原非流程分段解析器、比较/rewrite、取消、队列busy与None/degraded契约不变；非法ID、非stop、检查失败均固定不可用/未完成，无原文旁路、无第二次生成。新增prompt仍来自general profile。失败v2 prompt恢复主干版本，避免未合格提示影响其他问题。
确定性红绿覆盖：原文不丢失败记录/用途；指代合并不跨源；同源多chunk引用映射；无关条款未选择不出现；不合法ID/length/检查失败不发布、confidence不可用不为0；只1次模型请求；中文/英文/跨语回退；实际sync/async/SSE API正文/引用/done/保存一致。流程完整选择schema与prompt golden固定在tests/fixtures。真实API用六开发题×两模式×两轮，对照当前默认完整生成；候选固定后新独立中英留出各三轮。默认仍false，只有全部证据后作是否扩大默认的决定。

## Review Corrections
代码独立评审复现：bare如何/How do/How can会误把解释问题当操作流程；任意拉丁字母当英文及任意单汉字当中文会把法语/明显混合正文原样输出。收窄到明确步骤/流程/操作顺序/逐步/how to/steps/procedure/workflow/walkthrough/sequence信号，非流程仍保持原路径。语言边界采用保守的中文正文/英文功能词及明显外语或混合文本排除，不引入语言模型/依赖；不确定时在第一次调用前回原完整生成。仅扩展这两类已复现回归，不构建通用语言识别器。开发API题和生成输入不受此资格修正影响，实际选择算法/prompt保持v4。

## v5 — Explicit Negative Selection and Qualified Mixed-Evidence Admission
API真实对照发现：Fast 4次流程因第三份极低相关异语资料而回原生成；Thinking 4次选择正文动作全部保留，但2次多选包装/库存。非流程原分段另外2次附无关文档。v4/API失败保留，暂不冻结留出，默认false。
调研[Sentence Transformers官方CrossEncoder接口](https://www.sbert.net/docs/package_reference/cross_encoder/model.html)及本地5.4.1：单标签predict默认Sigmoid，现有rerank_score又被当logit转Sigmoid，实际.001/.98变成.500/.727；不能把后者当已校准概率。条款相关性诊断见clause-relevance-profile.json：中文包装.633/库存.552高于必需价格.489，无法分离，所以否决条款分数阈值方案，不新增此批计算。
下一最小实验仅改结构化选择：omitted_clause_ids先列与当前问题无关、无需交付的编号，再conditions=[]和answer（原title/clause_ids）。最终所有编号须恰好被归入省略或答案之一，交集/漏分类视为无效完成，不把未分类原文追加到答案。跨答案段允许必要重述，仍只一次生成和完整stop后检查；这只证明分类结构完整，不证明相关性或步骤完整。相同2题×原/逆来源顺序×3轮，v4/v5配对，每侧12条；同输入、参数、预算与输出检查。必须人工确认未误省略准备/记录/目的/边界，也未保留干扰，位置变化不是新的留出。
文档级资格独立实现并验证：Reranker仅在模型实际默认激活类型为torch.nn.modules.activation.Sigmoid时声明输出概率量纲（兼容新activation_fn/旧default_activation_function，无推理参数改动或新增前向），metadata增加rerank_output_space="probability"，仅本次流程资格据此解释原rerank_score，保留原数值和所有既有消费者；不用已被全局消费的rerank_prob/rerank_probability字段。概率缺失、非法或模型不可用为None/原降级，不能推断成0。仅当同语种至少一份已重排资料概率≥0.9，且其他语种资料均已重排、概率≤0.01时，才将这些已知低相关异语资料保留为未编号背景，不作为可选原文条款；高相关或缺分异语继续在生成前回完整路径。所有kept原文仍在模型上下文中，sources/共享kept不改，不按语言丢失证据，也不把无编号背景冒充可引用条款。该门控仅用于本流程路径，低相关同语种条款仍由同次显式负选择处理。
先完成机制验证，合格再接线v5并跑实际API两模式对照；原非流程分段不继续调提示，默认资格不能被单独流程修复冒充。修正概率契约的回归应覆盖局部门控读取真实Sigmoid值、不误用二次转换分数、模型失败/未知分数None、既有检索与API矩阵。新留出在最终候选固定后再冻结；若整个分段开关仍有非流程实质退步，保持false并在文档单独报告已修复的流程范围。

## v6 — Lower Variance for Selection, Not More Instructions
v5结构仅1/12完成；省略项多次包含用户明确询问的未知价格/户外边界，还出现交集或漏分类。即使去掉结构门禁也会有语义退步，停止此候选，负选择不接生产。指代原文编排v4主机制保留；文档门控定向23项已绿，尚需实际API确认。
最后一个有界选择实验只改v4条款选择温度为0，保留原prompt、schema、top_p=.8、2048、none和一次调用；普通完整/非流程生成参数不变。原因：任务已变为在有限依据中选择与排序，输出不需要创造性措辞；降低采样随机性可能减少偶发选入相邻无关条款，不能把温度0当质量证明。仍以2题×原/逆来源顺序×3轮，v4温度.7与0配对；语义全答/无关内容及全篇首见时间分别记录。保留v4/v5全部失败，不用未知价格缺失改写成相关性成功。通过才接线此参数并冻结新留出；不继续针对单个开发词汇堆排除规则。

## Final Qualification Scope
整体开关不再把旧非流程分段与流程修复捆绑。若v6通过，LOCAL_RAG_SEGMENTED=true仅使明确流程问题进入原文条款选择（通过既有bounded、比较/rewrite排除、语言/资料资格）；非流程问题保持当前默认的完整GroundedAnswer，避免把已观察到的无关扩写退步引入默认。不新增开关、不扩大模型资格、不改变API字段。流程完整选择温度0；其他生成继续.7。该路由收窄和可能的默认更新属于显式开关语义变更，需CHANGELOG [breaking]、README/API/部署说明；false仍是完整生成回滚。
先以flag=true新有限范围完成六开发题两模式两轮真实API；与flag=false默认对照，各题分别判完整质量与调用，不能用总通过数抵消新退步。固定代码后冻结新的两题留出（三轮、两模式），验证准备/分支/失败记录/用途/未知边界/相关性；任何新提示修改须重冻题。只有有限范围无新增实质退步且完整首见时间有收益，才能将代码和示例默认改为true；否则仍false。三轮温度0是重复运行，不虚称独立随机样本。

## Remove the Reproduced Low-Relevance Background
最终API仍有Fast中文2次漏追溯用途，其他6流程及16非流程完整。实际HTTP对照证明：API index6与v6机制index7除messages外全部字段相同；messages唯一差异是API额外保留的无编号R7英文低相关背景。条款10在输入但两次未选；同温度0、同schema/prompt的两份相关资料在机制三轮均完整。故修正已观察到的背景干扰，不再改提示或参数，也不采用额外核验。
原‘保留低相关foreign为背景’的设计撤销。复用既定强同语≥.9、所有异语已重排且明确概率≤.01的门控，将这些极低相关候选从生成上下文实际移除；有高分/缺分异语时保留整个原集合并回完整生成，不能部分丢掉可能有用依据。没有新增评分或模型调用。
Fast三个入口在prepare_evidence预算之前调用纯函数select_procedure_evidence，返回值建立本次kept_documents/context/sources；Generate的同一个_prepare_generation_evidence在已有所有者边界调用该函数，再prepare_evidence，将实际保留集合写到generation_evidence/retrieved_contexts/sources。仅LOCAL_RAG_SEGMENTED开启且segmented_enabled资格通过时预选，非流程、比较/rewrite与false完全不变。原始retrieval_evidence及retrieval diagnostics保留原召回事实，不由generate篡改。
选择器无有效资格就原样返回；评分None不当0；至少一份强同语保证非空。直接generation_chain的局部prepare也保持相同预选，历史只替换原完整证据块、其余不动。source_id始终映射真实源名，不借用显示截断文本。确定性回归新增‘低相关异语从实际prompt与API来源同时排除’（Fast/Thinking、JSON/SSE），高分/缺分仍原路径；再用同一开发协议重测候选，当前false基线行为与所有请求参数未变可复用原24条记录。通过后立即冻结新留出，不据留出改prompt。

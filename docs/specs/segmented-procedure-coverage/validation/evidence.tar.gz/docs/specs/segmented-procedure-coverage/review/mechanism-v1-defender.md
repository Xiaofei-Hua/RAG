# Mechanism Defender Review — v1

**Date**: 2026-11-11
**Protocol**: `validation/mechanism.json`
**Evidence**: `data/eval/procedure-mechanism-v1/{results.jsonl,model-http.jsonl,prompts.json}`
**Method**: 独立逐条阅读全部12条已检查正文与对应原始流式JSON，未读 critic，未新增实验，未制作新留出。
**Decision**: 候选v1未通过机制质量门槛；不能冻结候选或默认启用。旧准备/记录动作覆盖有所改善，但首段规则和全文用途/时序仍不稳定。

## Raw Evidence

- 12次回答均为一次实际 generation HTTP，均以 stop 结束；另有一次预热 control 调用。没有截断、检索未回答或新增核验调用可解释本次错误。
- 两侧使用同一程序提供的题目、证据顺序、2048/none/0.7/0.8；评审元数据未注入模型。此为直接生成机制实验，不等同完整API两模式验收。
- 候选中文3轮的原始 conditions 都为空。英文R2也为空，但其单块答案确实携带了主要操作边界，不能把 conditions 为空或只有一块直接判作语义失败。
- 英文R3 conditions 有12项，混入初检目的、周期用途、记录动作等细节。JSON结构合法没有避免信息分配不稳定，也没有保证动作语义正确。

## Per-Slot Review

`Row` 是 `results.jsonl` 的1起始行号。通过/失败根据语义而非段数；同一首段错误不会因为后段补齐而被冲销。

| Row | Case / Round / Variant | First body | Full answer | Evidence and rationale |
|---|---|---|---|---|
| 1 | EN / R1 / old | Fail | Fail | 将失败后的复查通过扩展为重置37小时；全文缺检查日期、通过/失败结果、保留失败记录与追溯目的。 |
| 2 | EN / R1 / candidate | Fail | Fail | 首段要求在初检前记录日期和pass/fail结果，结果应在检查后产生；将随后任一检查通过及失败复查通过泛化成重置周期。全文未解释旧头结果不能资格替代新头。 |
| 3 | ZH / R1 / old | Partial | Fail | 首段完整描述替换后350张起算，但没有清楚把350张绑定周期复查触发；全文有准备/记录，但未解释旧托盘合格不能替代新托盘。 |
| 4 | ZH / R1 / candidate | Fail | Fail | 首段只有环境和未知价格，缺初检合格后投入、350张/排除项、换托盘条件和失败处理。全文写“记录…合格结果”，未要求记录不合格结果；保留不合格样张不能替代记录失败结果。 |
| 5 | EN / R2 / candidate | Pass | Fail | 单块已写准备参考纸、序号/日期/结果、保留失败记录与主要起算/失败边界；但未解释周期检查验证参考结果，也未解释旧头结果不能资格替代新头。不是因单块而失败。 |
| 6 | EN / R2 / old | Fail | Fail | 失败复查通过后重置周期；全文漏准备指定参考纸和周期检查验证参考结果的用途。 |
| 7 | ZH / R2 / candidate | Fail | Acceptable with note | 首段仍只有环境和价格。全文基本列齐准备、记录、初检/周期/替换/失败动作及目的；记录条目写在周期段，其他检查的记录适用性不够显式。本次不将该歧义另设阻断，首段缺失已足够判整题失败。 |
| 8 | ZH / R2 / old | Pass | Pass | 主规则、350张及排除项、替换起算、失败停机、准备/记录和资格/追溯目的齐全；“建立或确认定位基准”可接受为检查目的概括，不因同义表述扣分。 |
| 9 | EN / R3 / old | Pass | Fail | 首段主要操作与限制齐全；全文漏日期/结果/失败记录以及初检、周期和记录目的。 |
| 10 | EN / R3 / candidate | Fail | Fail | 具体动作与用途总体齐，但conditions和后段均明确把失败复查通过当作重新起算37小时；原资料只明确初次及换头检查通过的起算事件。 |
| 11 | ZH / R3 / old | Pass | Fail | 主要规则齐；全文没有指定编号定位纸、机台/托盘编号、日期/样张编号/结果记录，也缺初始基准与追溯目的。 |
| 12 | ZH / R3 / candidate | Fail | Fail | 首段缺换托盘后的重新合格/重新起算和失败停机；全文漏初检建立基准及记录追溯目的，用“确认定位基准未因更换而改变”替代旧托盘记录不能资格替代新托盘的明确解释。 |

整题同时满足首段与全文：旧侧1/6，候选0/6。此为小样本开发观察，不是总体成功率估计；足以拒绝本候选的“已合格”结论。

## Findings

### DM-01 — High: First-body operating conditions lost

- **Location**: 候选 Row 4、7、12；原始模型记录 generation 索引5、8、13。
- **Symptom**: 中文前两轮首段只有使用环境/未知价格，第三轮仍漏替换和失败边界；这些信息直到后段出现。
- **Impact**: 用户先拿到的不是所要求的主要操作规则和完整影响执行的条件，违反 REQ-601。中文较低首段延迟不能当作合格收益。
- **Root cause**: 在本次可见输出中，模型把“首段概括主要规则”执行成环境简介，并直接输出空conditions；schema允许空数组且不作语义覆盖验证。不是parser丢弃已生成条件。
- **Recommendation**: 最小修订应明确首段的操作决策职责与conditions的适用/触发/失败边界，避免把全部“按阶段展开”的要求解释为关键条件也可后置。保持原调用与schema，先验证新假设，不预建审查平台。
- **Verification**: 同两开发题的下一轮有界实验逐条检查真实首段；保留本轮失败证据。
- **Status**: open / accepted for candidate revision。

### DM-02 — High: Action timing and counter events remain wrong

- **Location**: 候选 Row 2、10；对应英文资料第1份的初检、换头起算与失败处理句。
- **Symptom**: R1让用户检查前记录pass/fail结果；R1/R3把失败后通过的新检查等同于重置37小时。
- **Impact**: 操作顺序错误，并将不同阶段的计时规则合并。后一错误也见旧侧，故不能称新增回归；但本次要求显式修复该类混淆，仍未达到设计目标。
- **Root cause**: 模型仍压缩相近的“检查通过”事件；仅写“动作与条件配对”未稳定保留事件所属阶段。资料没有说失败复查通过一定重置计数。
- **Recommendation**: 把“准备/检查/结果记录”的时序和“条件只适用于资料明确绑定的动作阶段”作为下一候选的明确职责；不得用题目专有名词或答案常数硬编码。
- **Verification**: 检查首次投入、周期复查、失败恢复、部件更换分别对应的动作与起算；不能仅看37/350存在。
- **Status**: open / accepted for candidate revision。

### DM-03 — Medium: Requested purposes still omitted

- **Location**: 候选 Row 2、5、12。
- **Symptom**: 英文R2漏周期验证参考结果和旧头资格不能传递给新头；中文R3漏初始基准和记录追溯目的。
- **Impact**: 准备/失败记录动作改善不等于用户多问全部得到回答。特别是Row 5不是原动作缺陷原样复发，但仍不能按既定整题标准通过。
- **Root cause**: 输出阶段分配并未形成对每个所问阶段“动作+所问用途”的稳定覆盖；单一“解释作用”措辞不足以证明遵从。
- **Recommendation**: 下一最小候选按用户明确要求逐阶段给动作及相应目的，并继续允许缺失资料如实说明未知。
- **Verification**: 人工读完整答案；不能放宽为只看准备材料/保留失败记录两项。
- **Status**: open / accepted for candidate revision。

## Timing and Cost

| Case | Old first P50 | Candidate first P50 | Old full P50 | Candidate full P50 |
|---|---:|---:|---:|---:|
| English | 4.394 s | 5.181 s | 4.429 s | 7.753 s |
| Chinese | 3.300 s | 1.440 s | 4.093 s | 4.262 s |

每格仅3次。中文首段变快同时漏关键操作边界，不能作为质量合格的加速证据；英文候选第一/三轮长conditions带来明显首段与全篇成本。候选每答仍一次实际生成，没有新增模型调用。

## Metadata Correction

`validation/mechanism.json` 的 `policy.rounds` 仍为2，但 probe 明确循环3轮、结果也确为12条。应把归档元数据改为3，并将“Default legacy”文字明确为分段默认false、现有完整bounded生成不变。此为实验描述修正，不要求重跑。

## Next Boundary

先修订设计中的已复现问题再做有限prompt候选；本轮失败必须保留。候选尚未固定，不创建新留出。没有借此提出额外模型调用、事实校验服务、schema扩张或默认门禁变更。
# Critic Review — Procedure Mechanism v1

**Review date**: 2026-11-11  
**Review mode**: 完整 critic，真实生成质量与性能对照。  
**Inputs**: `validation/mechanism.json`、`data/eval/procedure-mechanism-v1/{results,model-http}.jsonl`、`prompts.json`，以及当前最小 diff。  
**Independence**: 未读取 defender 报告；未运行或要求新增实验。

## Decision

**v1 未达到流程质量验收，默认必须保持 false；暂不进入最终 API 或新留出资格验证。** 三条中文候选的首段都把关键执行限制留到后面，英文仍有动作时序错误或所问用途遗漏。12/12 的 stop 与单次生成仅证明协议与调用契约成立。

- Critical: 2
- High: 0
- Medium: 0
- Low: 0
- 最小实现本身与设计一致；失败发生于真实模型语义输出，不能用已有 39 个确定性测试通过来关闭。

## Implementation Review

当前业务 diff 仅在 `data/profiles/general.yaml:33-35` 把两条压缩限制替换为三条流程覆盖要求；没有改变 schema、解析器、模型参数、比较/rewrite 分流或默认值。新增 golden 绑定实际请求的 system prompt；两模式、JSON/SSE、stop/length 的 API 参数化继续验证多段正文、PII、历史与单次最终生成。`validation/red.log` 的 9 failed/30 passed 到 `green.log` 的 39 passed 是真实的提示契约红绿，不是语义修复证明。未发现额外实现阻断。

## Execution Facts

- 每题三轮、旧/新各六答，顺序交替；12 个正式 generation HTTP，加一次预热 control。每答只有一次正式生成。
- 每个题目的六次 human 输入完全相同，均为原问题与正常证据；旧/新仅 system prompt 不同。12 次参数均为 2048/none/0.7/0.8，均 stop。
- candidate 英文三轮的 conditions/answer 数为 7/4、0/1、12/4；中文三轮为 0/4、0/5、0/3。中文关键限制后到已存在于原始 JSON，不是检查器删改；英文 R1 的错误时序同样来自模型 JSON。
- 来源名称与编号匹配，未见本轮新增错误引用。没有因 length 截断而伪装完整的样本；这不使语义缺漏变成通过。

## Per-slot Review

首段只要求主要决策及全部关键边界，具体动作允许在后续展开；全文按既定 manual_required 审动作、顺序、所问目的。`Fail` 不因措辞或段数本身触发。

| Case | Round | Variant | First body | Full answer | Evidence |
|---|---:|---|---|---|---|
| Scanner | 1 | baseline | Fail | Fail | 换头后的通过/重新起算关系不明确；全文缺日期、pass/fail 与失败记录及追溯说明。 |
| Scanner | 1 | candidate | Fail | Fail | 首段要求在检查前记录 pass/fail 结果；全文未解释旧头的结果不能替代新头资格。 |
| Printer | 1 | baseline | Fail | Fail | 350 张只与换托盘后重新累计相连，普通周期复查触发未明确；缺旧托盘记录不能替代新托盘的说明。 |
| Printer | 1 | candidate | Fail | Fail | 首段只有环境与未知价；后文只要求记录合格结果，保留不合格样张不能替代记录不合格结果。 |
| Scanner | 2 | candidate | Pass | Fail | 准备材料和失败记录已补回；仍缺周期校验的目的、旧头记录不具新头资格的理由。单段本身不是失败原因。 |
| Scanner | 2 | baseline | Fail | Fail | 缺准备指定参考纸；换头后重新起算只被失败分支的起算描述替代；缺周期检查用途。 |
| Printer | 2 | candidate | Fail | Fail | 首段只有环境与未知价；全文把日期/样张/结果记录明确限为“周期复查记录”，未覆盖初次检查的记录。其他主要动作与目的已覆盖。 |
| Printer | 2 | baseline | Pass | Pass | 主要限制在首段；通用检查后记录与各阶段动作、建立/确认基准、换托盘资格及追溯完整。 |
| Scanner | 3 | baseline | Pass | Fail | 首段决策完整；全文缺日期/结果/失败记录以及多项所问目的。 |
| Scanner | 3 | candidate | Fail | Fail | 各阶段动作与目的覆盖齐全，但把普通失败复查合格也泛化为重新起算 37 小时；资料只明确初检起算及换头重置。该新增规则已在首段，不能以覆盖齐全抵消；12 条 conditions 也使首段很长。 |
| Printer | 3 | baseline | Pass | Fail | 全文缺准备纸、机台/托盘编号及检查后具体记录项目和追溯作用。 |
| Printer | 3 | candidate | Fail | Fail | 首段未交代换托盘检查/重置和失败处理；全文缺初始建立基准、保存记录追溯来源的目的，换托盘用途被改写为确认基准未改变。 |

独立严格判读：旧首段 3/6、全文 1/6；新首段 1/6、全文 0/6。英文 R3 最初按动作与用途覆盖记为通过，复核原始规则后更正：普通失败后的重置规则没有资料支持，必须与“覆盖齐全”分开判断，不能保留成功计数。中文 R2 的完整记录适用范围问题即使按宽松解读接受，首段仍明确失败，不改变本轮拒绝资格的结论。不能以全篇后来补充条件使已发布的不完整首段合格。

## Findings

### F-01 — 所问阶段仍遗漏，且结果记录被放到结果产生之前

**issue (blocking, must-fix)**

- **id**: F-01
- **severity**: Critical。符合 critic §2 Critical(a)：目标“可执行完整流程”在修复候选中仍可复现；英文 R1 还出现影响执行顺序的新错误。触及 core §3 生成热路径。
- **location**: `data/profiles/general.yaml:33-35`；`data/eval/procedure-mechanism-v1/results.jsonl:2`、`:5`、`:12`；REQ-601。
- **symptom**: 英文 R1 明确写“record ... pass/fail result before conducting the initial ... check”；R2 补回动作但不解释周期检查用途及新头资格；英文 R1/R3 把普通失败后的通过复查也当作周期重新起算点，超出资料明确的初检/换头事件；中文 R3 未说明首次建立基准及记录追溯目的。均为完整 stop 输出。
- **impact**: 用户无法按正确时序执行，并未获得所要求的完整解释；准备/记录缺漏目标尚未稳定关闭。更多段落不能替代完整阶段覆盖。
- **root_cause**: v1 的“覆盖准备/执行/记录/目的”仍是宽泛枚举；没有有效区分动作的先决信息与动作产出的结果，也未使每个所问阶段的目的保持对应。
- **recommendation**: 在 `design.md` 的最小策略中据已复现结果修订：保持同一 schema/单调用，用最终答案逐阶段组织动作、先决条件、产生的结果/记录与所问目的；明确结果产生后才记录结果，不能把各阶段目的合并成一项泛化用途；起算/重置只绑定资料明确的触发事件，不能推广到其他分支。只改通用 prompt，不硬编码题目或新增核验平台。
- **verification**: 原协议的三轮对照中逐槽人工检查动作顺序、记录覆盖及每个所问阶段的目的；保留 raw JSON 与发布正文。golden 只证明新契约被装载，不能作为关闭本项的语义证据。
- **status**: open

### F-02 — 规则概括退化成环境说明，关键执行条件推迟发布

**issue (blocking, must-fix)**

- **id**: F-02
- **severity**: Critical。符合 critic §2 Critical(a)/(b)：目标要求首段关键条件完整，候选在三条中文输出中均不成立，且相对旧中文 R2/R3 新增首段质量退步。
- **location**: `data/profiles/general.yaml:32-35`；`data/eval/procedure-mechanism-v1/results.jsonl:4`、`:7`、`:12`；REQ-601、REQ-604。
- **symptom**: 中文 R1/R2 的 conditions=[]，answer[0] 只有 19–26℃室内/无结露与未知价格；初检通过、350 张计数及排除项、换托盘通过/重置、失败停机全部在后段。R3 虽补初检/计数，换托盘与失败条件仍后到。
- **impact**: 首次发布不含操作决策完整边界；1.3–2.0 秒的提前正文不能作为合格首段收益。英文 R3 反向把 12 条事实/用途都塞入 conditions，说明字段职责仍不稳定。
- **root_cause**: “首段概括主要规则”没有清晰区分操作决策与环境简介；现有 conditions 指令未被实际遵循，并允许模型把关键分支留到后续。
- **recommendation**: 修订通用 prompt 的字段职责：资料存在适用、开始/重置、失败/恢复及未知边界时，把这些决策条件先完整写入 conditions；首个 answer 给可执行的总规则，而不只环境简介。conditions 不承担具体准备动作、记录清单或纯用途，后续展开阶段细节。保持字段与发布机制不变。
- **verification**: 原开发题逐槽分别评首段和全文；关键限制后到即首段失败，即使全文补齐也不追认首段有效。核对原始 conditions/首段与发布正文，不能用 token 时间本身判通过。
- **status**: open

## Timing and Cost

原始首段 P50：旧 3.366s → 新 2.844s；全文 P50：旧 4.261s → 新 4.323s。该首段差值混入三条中文不完整首段，**不能作为合格性能收益**。英文 R3 虽覆盖全部动作，仍有无依据的重置规则；首段 8.495s、全文 11.695s，对应旧为 3.206s/3.242s，但旧全文本身也不合格；不能把缺失版当同质量性能基线。

单次生成和既定预算约束满足。当前证据支持“v1 没有稳定解决流程质量”，不支持默认启用。最小下一步是按这两项已复现输出修订原 prompt 设计，保持现有有界验证计划，不扩展分类器、模型调用或评分服务。

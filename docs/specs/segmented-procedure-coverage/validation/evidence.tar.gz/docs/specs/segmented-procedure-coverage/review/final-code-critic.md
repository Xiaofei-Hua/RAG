# Critic Review — Final Procedure-only Code

**Review date**: 2026-11-11  
**Scope**: 全部 7 个 tracked 文件差异、未跟踪的 `core/procedure_generation.py`、`tests/unit/test_procedure_generation.py`、流程 golden；相关实际调用入口与现有分数消费者。  
**Independence**: 未读取 defender 报告，未运行模型或重跑整个测试矩阵，未修改业务/测试代码。读取既有红绿日志并执行 `git diff --check`，通过。

## Decision

- New Critical: 0
- New High: 0
- New Medium: 0
- New Low: 0
- **未发现阻断真实 API 验证的实现问题。当前代码符合已批准的流程专用范围；默认仍 false。**

F-07/F-08 的实现修复与永久回归满足关闭条件。F-09 的文档门控代码已实现并有直接正负例验证；但 F-09 原记录包含“实际 Fast 流程目标缺陷仍未解决”，其完整关闭须待本次 api-final 的真实 Fast 输出，不能单凭门控布尔值或 61 项测试代替效果闭环。

## Routing and Parameters

**praise (non-blocking)**：`segmented_enabled` 现在同时要求显式开关、bounded、无 rewrite、明确流程且非比较。`generation_chain.prepare` 在该条件下尝试结构化流程准备，并无论准备是否成功都关闭普通分段分支；所以正常入口不会因流程资格失败而落到旧 SegmentedAnswer。

实际调用只有以下两类：

| Input | Request | Sampling |
|---|---|---|
| 明确流程、通过资料/语言/映射资格、flag=true | ProcedureAnswer + 原文条款选择 prompt | temperature=0、top_p=0.8、2048、none |
| 普通非流程、比较、rewrite、资格不符或 flag=false | 原 GroundedAnswer + 原 bounded prompt | temperature=0.7、top_p=0.8、2048、none |

温度绑定由 `core/local_rag_generation.py:101-105` 的实际 procedure 对象决定，不由用户问题含某词直接决定。准备返回 None 时 schema、prompt 与温度一起回原完整模式。同步与异步共享同一个 prepare/render，未出现两套参数规则。

检查所有业务调用入口后，只有 Fast 和 Generate 调用 `stream_answer`，二者都先使用上述 `segmented_enabled`。旧普通分段解析器和直接单元测试仍保留，但新的运行入口不再为普通非流程启用它；无需为本次扩大为删除旧实现的重构。

## Evidence Gate and Score Semantics

`Reranker.rerank` 原 predict 调用及参数未改，返回 score 仍原样写 `rerank_score`，排序和已有 retrieval_score 保持。只在已加载模型的实际激活类型为 `torch.nn.modules.activation.Sigmoid` 时加 `rerank_output_space="probability"`；兼容新 activation_fn 和旧 default_activation_function。未知类型不标概率，既有 stale marker 在成功重排时移除。

未新增 rerank_prob/rerank_probability，未改变激活函数或新增 forward。代码检索确认 marker 仅由 reranker 写入、procedure_generation 读取；evidence、corrective、grade 等已有消费者继续原逻辑。此实现没有借流程资格修复顺带调整全局相关性分数。

`prepare_procedure:84-103` 仅把已重排且有该 marker 的有限 [0,1] 原分数作为本次门控信号。至少一份同语种 ≥0.9、所有异语项均 ≤0.01 才允许背景处理。缺失/非法/未知空间/未应用重排返回 None；不会填成 0。强异语或没有强同语支持仍回完整生成。

低相关异语原文仍存在请求 context，仅不获条款编号；source 列表和共享 kept 未修改。只替换原结构化证据块一次，历史与其他上下文保留。映射缺失仍回完整路径。条款 source_id 来自真实 inputs.sources，不从不可信正文猜来源；同源多 chunk 可正确映射。

## Completion and Failure

流程仍为一次生成，完整 stop 后严格解析全部 ID，再合成全篇。`stream_answer` 仅一次调用 CheckedParagraphs 发布全文；末段非法、length 或检查失败时没有已发布的操作前缀，也没有第二次调用补救。正文经过原输出检查/PII；Fast 与 Generate 保留原完成状态、checked receipt、保存与历史路径。

busy 单独透传，取消不会被普通 Exception 分支改写成成功；不可用保持 None/degraded。未新增共享状态键、持久化路径、跨请求可变状态或 REST 字段。v5 omitted 字段没有进入生产。

## Regression Evidence

已核对 `final-scope-red.log`：**9 failed / 32 passed**，随后 `final-scope-green.log`：**61 passed**。文档门控单独记录为 red **2 failed / 4 passed / 17 deselected** → green **23 passed**。这些是实现契约证据，真实语义证据另行评审。

| Boundary | Permanent evidence | Review |
|---|---|---|
| F-07 普通解释误入 | 三个解释问题的实际请求断言 GroundedAnswer | 与当前范围一致；此前已独立运行通过，修复仍保留。 |
| F-08 混合/其他语言 | 两个实际单次 GroundedAnswer 回归，中文正向事件用例 | 不以一个汉字接受整段英文；合法中文型号仍支持。 |
| F-09 文档资格 | 弱异语+强同语准入；高异语、None、未知 marker、无强依据回退 | 原背景仍在 context，只有真实相关两来源可选；待真实 Fast 质量闭环。 |
| 重排 marker | mock 原值 0.98/0.001 保持，真实类型才标 marker，无全局概率字段 | 直接验证本次分数量纲契约。 |
| 请求/原文 golden | sync/async、prompt、temperature 0、完整原文与引用、有效 ID 枚举 | 不是把 mock 当语义通过；固定生产格式及参数。 |
| 完整发布 | stop/length/非法末 ID/检查异常；一次检查、一次生成 | 失败无原文前缀，状态正确。 |
| API 行为 | Fast/Thinking × JSON/SSE × stop/length × 非流程/流程，PII、done/保存/历史一致 | 包含非流程回 GroundedAnswer 的红绿变化。 |

## Remaining Qualification

无需为本次再增泛化防御或重排平台。继续当前已批准 api-final：尤其核对真实 marker 随 kept 传到 Fast、实际请求进入 ProcedureAnswer、步骤/用途/未知边界完整，以及非流程恢复原完整路径后有无配对退步。其后才评新留出和默认值。

F-07/F-08 最终修复提交编号由 tracking 补记；F-09 的代码部分已验证，真实 API 部分暂待结果。公开开关语义文档与 CHANGELOG `[breaking]` 按已批准最终范围补齐，不由本次代码准入代替交付要求。

# Critic Review — Procedure-only Qualification Scope

**Review date**: 2026-11-11  
**Target**: `design.md` 的 Final Qualification Scope、最新 REQ-602/604，以及 v6 独立全文结果。  
**Independence**: 未读取 defender 报告，未调用真实模型。

## Decision

- Critical: 0
- High: 0
- Medium: 0
- Low: 0
- **可编码最小路由收窄与选择温度接线，无设计阻断；本次不批准修改默认值。**

`LOCAL_RAG_SEGMENTED=true` 仅使明确操作流程、满足 bounded 与现有资格的请求进入原文选择，温度 0；普通非流程、比较、rewrite、资料或语言资格不符均使用原完整 GroundedAnswer，温度 0.7。false 完整回滚。不增加 flag、在线调用、API 字段或共享状态。

## Assessment

**praise (non-blocking)**：该收窄直接处理已复现的 F-11：普通分段在正确首段后追加无关资料。恢复这些请求当前默认完整路径，保留已经验证的流程选择，是明确控制功能范围；没有修改原非流程 prompt、隐藏旧失败或用流程总通过数抵消配对退步。

v6 候选严格完整质量 12/12、对照 6/12，支持把温度 0 用于有限选择任务；参数变化只绑定实际 ProcedureAnswer 请求。语言门控不合格而回退时也须恢复原完整生成参数，不让原文选择温度扩散到 fallback 或普通问答。既有一次完整检查发布、PII、引用、取消和 None/degraded 契约继续有效。

开关语义收窄是公开配置行为变化，设计已明确 CHANGELOG `[breaking]` 与 README/API/部署说明，范围定义充分。无需为此新增平行开关或清理旧普通分段实现；只保证新的运行入口不再启用它。

## Verification and Default Decision

定向红绿核对真正发出的 schema/参数：合格中英文明确流程为 ProcedureAnswer/0；非流程、比较、rewrite、不合格语言/资料及 flag=false 为 GroundedAnswer/0.7。Fast/Thinking 与同步/异步、JSON/SSE 都保持一次最终生成与最终正文一致；不能只测资格布尔值。

随后以 true 的新有限范围对照 false，重新跑六开发题两模式两轮。分别报告每个配对的完整质量、实际路由、调用和第一份完整正文时间；旧 API 失败保留原记录。候选固定后冻结中英文新流程、两模式三轮，不将开发来源逆序当留出。任何新 prompt 调整均按既定协议重新冻结题目。

只有该有限范围无新增实质退步、调用不增加且完整首见时间有收益，才可讨论默认 true；否则仍 false。即使后续准入默认，结论也仅适用于明确且合格的流程原文编排，不包括旧普通非流程分段。

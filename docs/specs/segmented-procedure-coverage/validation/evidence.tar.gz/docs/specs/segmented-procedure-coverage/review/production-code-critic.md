# Critic Review — Production Code

**Review date**: 2026-11-11  
**Review target**: 当前tracked diff、`core/procedure_generation.py`、`tests/unit/test_procedure_generation.py`、流程golden与API参数化。  
**Independence**: 未读取defender报告，未运行真实模型，未修改业务或测试代码；只执行无模型的资格/渲染复现和`git diff --check`。

## Decision

- Critical: 0
- High: 2
- Medium: 0
- Low: 0
- **完整发布主路径符合设计，但两项已复现资格放宽需在交付前修正。** 不需要重写机制或新增模型；最小范围是收窄流程识别、拒绝明显混合正文，并固化回归。

默认仍false。现有开发流程的正确正文机制没有因这两项边界问题被否定，但当前实现不能宣称非流程行为与混合语言回退契约已经保持。

## Confirmed Correctness

**praise (non-blocking)**：流程stream分支等待同一`generation_chain.ainvoke`完成，`render_procedure`先要求stop、验证全部选择，再一次调用`CheckedParagraphs.append`发布全文。最后一个ID非法或length不会留下已发布的操作前缀，输出检查失败也只返回固定不可用文案，没有第二次生成。

Fast三个入口和Generate sync/async均加入已有kept evidence。来源来自`evidence.source`到inputs.sources的真实映射，允许同源多chunk；条款合并只在每个证据项内部发生，没有跨来源拼接。证据块替换保留其他context与历史。非流程原prompt恢复主干，比较/rewrite仍由原segmented_enabled排除。

失败不新增shared_state键，原generation_outcome与None/degraded路径保留；过程性选择结果只是本次输入和返回值，没有请求状态写入单例。原文仍经过原输出检查和PII处理。

## Findings

### F-07 — 宽泛疑问词把普通解释问题切换到流程原文编排

**issue (blocking, must-fix)**

- **id**: F-07
- **severity**: High。critic §2的边界路径未闭合；生成热路径资格与已批准“明确流程请求、非流程保持原实现”的范围不一致。
- **location**: `core/procedure_generation.py:9-12`、`:29-30`；`core/local_rag_generation.py:generation_chain.prepare`。
- **symptom**: 无模型调用即复现：`procedural_question("如何理解缓存一致性？")`与`procedural_question("How do cache replicas remain consistent?")`均True；提供同语言解释材料后prepare_procedure均返回选择请求。两题询问概念/机制，不要求操作步骤。
- **impact**: LOCAL_RAG_SEGMENTED开启时，普通解释问题不再使用原合格分段提示，而进入仅选原文条款的格式；这是已声明保留的非流程行为被改变，不是只影响实验中的两道流程题。
- **root_cause**: 裸“如何/怎样/怎么”与“how do/how should/how can”被当作足够的流程证据。
- **recommendation**: 在该正则中保留明确流程/步骤/操作顺序/逐步/实际walkthrough等表达，收窄裸疑问词；无需引入模型分类器或广泛意图平台。使上述两个解释问题不进入新机制，并保持原六开发题中明确流程请求的准入。
- **verification**: 在`tests/unit/test_procedure_generation.py`固化这两个负例及明确中文/英文流程正例；用mock实际请求验证负例不含ProcedureAnswer选择schema、明确流程仍单调用。无需调用真实模型复现此问题。
- **status**: open

### F-08 — 含少量中文的英文正文被当作同语种中文资料

**issue (blocking, must-fix)**

- **id**: F-08
- **severity**: High。critic §2的适用边界未闭合，已实际生成不符合请求语言的原文主体；生产设计明确要求混合/跨语在调用前回完整生成。
- **location**: `core/procedure_generation.py:33-36`、`:44-52`。
- **symptom**: 中文问题“请按步骤说明如何检查设备。”配正文“检查资料：Before operation, check the reference sheet. Record the date and result.”时，prepare_procedure返回非None。用合法选择直接render后，最终正文为上述英文主体，证明门控未回退；无需模型即可复现。
- **impact**: 中文用户收到英文操作原文，失去原完整生成按问题语言回答的能力。仅出现一个中文标记就通过中文资格，与“保守同语种”不符。
- **root_cause**: `_language`以是否存在任一汉字优先决定zh，不识别明显中英混合段落。
- **recommendation**: 对明确混合正文或无法确定同语种的情形返回None，从而在模型调用前使用原完整路径；保持对中文中的L4/R7等普通型号的支持。只修这个已复现边界，不需增加通用语言识别服务或新模型。
- **verification**: 为该混合正文增加真实request mock回归，断言选择前回GroundedAnswer且仅调用一次；同时补正向中文资料用例，避免修正后把合法中文流程全部回退。现有跨语负例只覆盖全英文资料+中文问题，没有覆盖该混合情形。
- **status**: open

## Reproduction Record

在已同步环境以`uv run --frozen --no-sync python`直接调用纯资格函数与render_procedure，没有调用LLM。输出为：

```text
conceptual_zh procedural_question=True procedure_prepared=True
how_works_en procedural_question=True procedure_prepared=True
mixed_source procedural_question=True procedure_prepared=True
composed= **检查步骤**
检查资料：Before operation, check the reference sheet. Record the date and result.[manual.txt]
```

两项复现均使用正常结构化evidence和由render_untrusted_evidence生成的context，无假标题或恶意输入。

## Tests and Limits

已核对现有红17 failed/32 passed→绿49 passed日志。golden对实际prompt、完整原文、enum、单调用与固定参数有意义；API同时覆盖Fast/Thinking、JSON/SSE、stop/length与PII、正文/done/保存/历史一致。`git diff --check`通过。

这些检查支持完整发布主路径，不覆盖上述两项资格问题。修正后定向补相应正负例即可；无需扩大实验数量或重新探索v4机制。后续真实默认API对照和新留出仍须按已定计划评全文质量、实际路由、调用数与完整正文时延。

## Eligibility Re-review — 2026-11-11

F-07、F-08 的代码修正与永久回归已独立验证，可从实现阻断项关闭；修复提交编号由最终 tracking 补记。本次没有读取 defender 报告或调用真实模型。

| Finding | Fix | Independent verification | Permanent regression |
|---|---|---|---|
| F-07 | `_PROCEDURE` 删除裸“如何/怎样/怎么”及 how do/how can 等，保留明确步骤、流程、how to、walkthrough。 | 三个普通解释问题均返回 False；明确中文步骤和英文 how to 均 True。 | `test_explanations_keep_the_existing_generation_route` 三个参数；实际 mock 请求使用原 CitedParagraph，非 ProcedureAnswer。 |
| F-08 | `_language` 对明显混合正文、非中英文或不能确定英文返回 None，保留中文型号。 | 已复现的中文标题加英文正文和法语均返回 None；中文 L4 与完整英文正例分别为 zh/en。 | `test_other_or_mixed_language_uses_buffered_generation` 两个参数验证生成前回 GroundedAnswer 且仅一次调用；`test_chinese_procedure_keeps_event_boundaries` 保留正向流程。 |

独立命令：`PYTHON_DOTENV_DISABLED=1 DOMAIN_PROFILE=general uv run --frozen --no-sync python -m pytest tests/unit/test_procedure_generation.py -q -k 'explanations or other_or_mixed or chinese_procedure'`，结果 **6 passed, 11 deselected in 2.44s**。另已核对 `routing-red.log` 的 5 failed/1 passed、`routing-green-final.log` 的 55 passed。

F-07 原复现中的“如何理解缓存一致性？”需要精确说明：它证明旧纯资格函数宽泛，但已有比较路由会匹配“一致”，不能单靠该句证明实际 generation 进入流程。因此永久中文负例改为“如何理解这个结果？”，独立实际请求回归通过；两个英文负例继续保留。此修正不影响原缺陷的根因或其他复现。

本次关闭只覆盖资格问题；真实 API 质量另见 `api-development-critic.md`，不由这 6 项单元测试代替。

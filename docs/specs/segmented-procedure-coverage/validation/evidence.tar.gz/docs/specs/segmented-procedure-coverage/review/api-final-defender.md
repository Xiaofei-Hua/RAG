# Final API Defender Review

**Date**: 2026-11-11  
**Protocol**: `validation/api-development.json`，六题 × Fast/Thinking × 两轮。  
**Evidence**: `data/eval/procedure-api-final-{baseline,candidate}/{results.jsonl,model-http.jsonl}`，各 24 答。下文行号为对应 results.jsonl 的 1-based 行号。  
**Method**: 独立逐配对审全文、来源支持、真实请求与事件；未读 critic、未调用模型、未改代码。

## Decision

**本轮仍未达到冻结新留出的质量前提，默认保持 false。** 候选流程 6/8 合格，非流程 16/16；基线流程 1/8，非流程 16/16。候选有明确的动作/记录覆盖与延迟收益，但两条 Fast 中文流程仍漏用户所问的记录追溯目的，不能因基线也失败而豁免。

暂不创建 `validation/holdout-v1.json`。完整路由与成本契约已实际成立，剩余失败发生在单次选择本身，不是检索、解析、发布或非流程旧分段。

## Procedure Pairs

| Row | Round / Mode / Case | Baseline full | Candidate full | Actual observation |
|---|---|---|---|---|
| 5 | R1 / Fast / scanner | Fail | Pass | 基线漏参考纸/序号准备、结果/失败记录、周期与追溯用途，且未完整交代换头的新周期。候选全部保留，未知户外/费用也有，复位只绑定换头通过。 |
| 6 | R1 / Fast / printer | Fail | Fail | 基线漏检查后记录/失败样张等及追溯用途。候选恢复具体动作、结果/失败样张记录和初始/周期/换件用途，但遗漏记录用于追溯偏移来源的目的。 |
| 11 | R1 / Thinking / scanner | Fail | Pass | 基线明确写检查前记录 pass/fail，失败停机句只引检查记录来源且漏追溯用途。候选原文事件、动作、用途和引用完整。 |
| 12 | R1 / Thinking / printer | Fail | Pass | 基线有准备、检查和结果记录，却漏记录追溯目的。候选通用检查记录段明确包含它。 |
| 17 | R2 / Fast / scanner | Fail | Pass | 基线漏准备、全部结果记录及多个所问用途。候选与 R1 对应流程相同，完整覆盖。 |
| 18 | R2 / Fast / printer | Fail | Fail | 基线虽恢复更多记录仍漏追溯用途；候选与行 6 完全相同，仍漏这一目的。 |
| 23 | R2 / Thinking / scanner | Fail | Pass | 基线恢复记录/追溯和换件目的，却没有说明周期检查用来验证仍在记录参考结果内。候选全部用途齐全。 |
| 24 | R2 / Thinking / printer | Pass | Pass | 基线完整正文含所有动作、记录及追溯用途，重复不单独失败；候选完整且事件引用清楚。 |

候选四种 mode/case 正文在两轮各自相同。没有包装颜色或库存离题内容，但这不是通过的充分条件。候选行 6/18 没有缺少“机台/托盘/样张”等词，真正遗漏的是这些记录为何有用，不能由字段齐全代替用户要求的目的说明。

## Proven Failure Location

候选行 6/18 的真实生成输入都含：

> [条款10] 保存机台、托盘与样张记录便于追溯偏移来源。

两轮原始 JSON 的答案选择依次为 `[2,5]`、`[2,7,9]`、`[3,8,9]`、`[3,7,9]`、`[2,3]`、`[4]`、`[5,11]`，没有条款 10。完成状态是 stop，2048 预算未截断。答案正文也没有其他等价的追溯目的解释。

因此这是**有依据可选但模型未选**的完整性失败；不是缺失输入、source_id 映射错误或检查后被删除。Thinking 同题选择了该用途，不能用它抵消 Fast 的失败。温度 0 使本次遗漏稳定重现，并不能保证完整选择。

## Routing and Publication

- 候选 8 条流程全部实际发送 ProcedureParagraph / conditions+answer，temperature=0；16 条非流程全部发送原 GroundedAnswer / basis+conditions+conclusion，temperature=0.7。基线全部为 GroundedAnswer / 0.7。
- Fast 中文保留第三份英文背景，其原 rerank_score 为 0.0038072040770202875；强同语言两份为约 0.994/0.977。旧显示 score 仍约 0.501，局部门控没有误用它；实际选择请求证明门控已生效。完整背景与全部可选中文条款仍在输入。
- 两侧每条都 stop、完整一次正文 token 发布。候选流程的全文检查前没有提前正文，未使用旧非流程多段扩写；token、done 的完整结果一致。
- 候选内部首段都有主要操作规则与范围：英文给失败保持停机直至纠因/复查合格，中文给首次合格才打印及初始起算；旧“一个书面首段给全部阶段条件”仍未满足，不能翻案。首次公开正文是全篇，不等于每个内部标题段独立完备。
- 英文 Fast 的记录说明在同一初始检查段中先于许可条件，未写“检查前记录通过/失败结果”；与基线明确的 before the initial check 指令不同。原准备 before check、通过后扫描和事件起算关系保持。中文通用记录虽放在周期段，但原句仍是所有检查后的合格或不合格记录，没有排他限定。本轮实际失败是用途漏选，不另因非排他标题或重复泛化失败。

## Non-procedure Pairs

以下每个行号的两侧全文均合格，16/16 → 16/16，没有以总数抵消配对退步。

| Case | R1 Fast / Thinking rows | R2 Fast / Thinking rows | Whole-answer assessment |
|---|---|---|---|
| Battery comparison | 1 / 7 | 13 / 19 | 9 小时与 600 分钟等价转换正确；给出所记录芦序更长，保留 8 W/5 W 差异，未外推同负载。 |
| Zero measurement | 2 / 8 | 14 / 20 | 10 分钟条件、0 ms=0 s 与已完成测量均明确，零未误作缺测，引用对应两份计时器记录。 |
| Calibration | 3 / 9 | 15 / 21 | 120 日历日、正常连续使用、首次投入确认和换探头后校准完成日起算均正确，未混淆出厂/收货/入库。 |
| Missing price / warranty | 4 / 10 | 16 / 22 | 价格未提供、交付日起 18 月保修和英文回答正确，没有把 42 mm 当价格。 |

旧 API 发现的计时器问题附水质计/扫描器资料的退步没有在本次有限路由出现。普通完整生成参数和 schema 已恢复，不能把这 16 答的自然采样措辞变化称为新流程选择收益。

## Calls and Timing

两侧各 60 条实际 HTTP。每个 Fast 请求 1 次最终生成；每个 Thinking 请求 3 次原控制调用 + 1 次最终生成。全部 48 答最终生成一次、none/top_p=0.8/2048，无额外重试、补写或翻译。

下表单位秒，P95 为小样本线性插值；完整首见必须结合上面的失败说明解读。

| Subset | n/side | Baseline first P50 / P95 | Candidate first P50 / P95 | Baseline full P50 | Candidate full P50 |
|---|---:|---:|---:|---:|---:|
| Fast procedure | 4 | 7.927 / 9.541 | 3.893 / 4.015 | 7.927 | 3.894 |
| Thinking procedure | 4 | 12.895 / 15.158 | 7.410 / 8.585 | 13.010 | 7.512 |
| Fast non-procedure | 8 | 3.207 / 4.022 | 3.122 / 3.896 | 3.207 | 3.122 |
| Thinking non-procedure | 8 | 5.646 / 5.790 | 5.551 / 5.854 | 5.752 | 5.658 |

这些数据说明有限选择路径减少了完整答复等待，但 Fast 中两个失败答不能被计成“质量合格的加速答”。本轮不满足“流程合格后冻结新留出”的条件。保留实际失败和默认 false，未创建或暴露新留出题。

## Strict Comparison Scoring Correction

后续复核明确沿用原 manual_required 的显式记录排序口径。该报告基线行 1 仅并列芦序 10 小时、赤砚 9 小时，没有直接给出所问记录排序，严格应判失败。因此冻结基线非流程由初版 16/16 更正为 15/16，总体由 17/24 更正为 16/24。此报告的 api-final-candidate 比较题均有明确记录排序，候选 22/24 与 Fast 中文两条用途遗漏结论不变。未改任何模型输出或评价题。

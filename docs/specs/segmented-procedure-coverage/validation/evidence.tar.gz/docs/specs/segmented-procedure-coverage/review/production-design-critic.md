# Critic Review — Complete Selection Before Publication

**Review date**: 2026-11-11  
**Review target**: `design.md` 的 Production Integration、已对齐的 REQ-601、现有 Fast/Generate/生成链/证据渲染入口。  
**Independence**: 独立依据现有实现和v4实际输出评审，未读取 defender 报告。

## Decision

- Critical: 0
- High: 0
- Medium: 0
- Low: 0
- **可开始既定红绿测试和最小生产接线实现；无必须先修订项。** 默认继续false，实际默认API对照与新留出仍是待完成的验收。

本准入批准的是“小范围流程选择与完整发布”实现，不是为v1–v3失败提示扩大生效范围，也不是默认资格通过。

## Core Assessment

**praise (non-blocking)**：等待同次选择JSON完整stop，组成完整操作说明并检查后整体发布，直接处理v4中“全文6/6正确，但任意中间段独立完整未被证明”的差别。它以确定的发布单元解决组织契约，不要求模型再次改写或为每段重复全部通用规则。

该方案保留v4已经验证的正文机制，并放弃提前发布一个尚未包含整套说明的前缀。新的首个正文时间必然包括全部选择和检查；最终性能必须与实际默认完整生成比较，不能继续引用v4早发首段的1.486s作为接线后的时延。

## Existing-path Compatibility

| Boundary | Review |
|---|---|
| Fast sync/async/stream | 三入口均已持有token budget后实际kept文档，可直接把结构化evidence传入本次inputs；无新增共享状态需求。 |
| Generate sync/async | `prepared`已有evidence/context/sources，现有generation_evidence状态无需扩展；本次输入增加结构化信息不改变shared_state所有权。 |
| History | 当前prepared.context先放完整证据块，再附加历史；只替换由同一structured evidence渲染出的完整块可保留历史。不能重建context时漏掉历史，找不到块时生成前回退。 |
| Source mapping | 真实source到inputs.sources的映射适配现有按来源去重/多chunk场景；正文中的假标题不参与映射，引用仍由程序添加。 |
| Model budget | 一次请求、原2048/none/0.7/0.8保持。只用现有模型选择结构，不增加翻译、补写或在线核验。 |
| Output checks | 非流式沿现有最终检查，流式流程分支等待全文后经CheckedParagraphs一次发布，并复用checked receipt避免after-hook重复改写。没有原文绕开检查的旁路。 |
| Failure | 已调用后非法ID、非stop、渲染/检查失败均为不可用或未完成；不能再次调用原生成补救。未调用前的资格不符才回原完整schema。 |
| Confidence/state | 原None/degraded和generation_outcome传播保持；协议成功仍不能自动变成语义评分。 |
| Non-procedure behavior | 恢复主干非流程prompt，保留比较/rewrite完整路径与现有普通分段解析器，避免把失败v2提示推广到其他问题。 |

## Eligibility and Scope

流程入口被既有LOCAL_RAG_SEGMENTED、bounded资格、非比较/非rewrite和明确流程请求共同限制。语言或来源无法支持原文编排时，在调用前返回原完整生成，有效避免同一次请求先选择、后翻译/修复形成额外调用。

保守中英文识别是本次有限路由，不是通用语言服务。新留出与API需要报告实际走到流程编排、普通分段、完整回退和检索终态的槽位，不能把回退结果算作新机制覆盖。规则命中自身不保证语义完整，最终正文仍须独立审阅。

## Validation Review

设计矩阵覆盖改动直接涉及的边界，范围合适：

- 先固定完整选择schema/prompt golden，验证实际请求绑定与一次调用；保留真实失败记录、用途与事件关系的回归样本。
- 结构化映射检查同源多chunk、跨源指代不合并、跨语与缺映射生成前回退；不需要扩大为新的数据完整性平台。
- stop/length、非法ID、输出检查失败均不能发布未检查原文；不可用信号仍为None/degraded。
- sync/async/SSE端到端核对实际正文、引用、done和保存正文相同，并保留现有取消、busy与比较/rewrite契约。
- 六开发题两模式两轮，与实际默认完整生成对照；候选固定后再用新中英留出三轮评完整质量与首个完整正文时间。当前机制实验不代替这些验收。

## Findings and Rollback

没有新增需阻断编码的设计发现。回滚保留LOCAL_RAG_SEGMENTED=false或撤回新流程接线即可；无新增持久化、REST字段或shared_state键。若后续实施选择扩大路由、改变语言回退或默认值，应按最终差异复审，当前准入不预先覆盖这些变化。

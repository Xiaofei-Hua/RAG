# Low-Relevance Background Removal Defender Review

**Date**: 2026-11-11  
**Reviewed**: `design.md` 的 `Remove the Reproduced Low-Relevance Background`、更新后的 REQ-602，以及两份实际 HTTP 输入。  
**Decision**: **准许最小证据预选修正及候选开发重测；默认仍 false，新留出仍须等待候选实际通过。**

## Evidence

独立比较 `procedure-api-final-candidate/model-http.jsonl` 的 index 6 与 `procedure-mechanism-v6/model-http.jsonl` 的 index 7：除 messages 外全部请求字段相同；system message 相同；human message 唯一差异为 API 多了一整份未编号的 R7 英文运行规则背景。其余中文条款、编号、schema、模型、温度 0、top_p=0.8、2048 和 none 相同。

API 两轮缺失的追溯用途仍在中文条款 10 中，而两份相关资料单独进入 v6 机制时三轮均选择了该用途。这个受控输入差异足以支持针对背景干扰的最小修正假设；并不自动证明删除后一定通过，仍需实际重测。不是再次按开发答案添加提示或参数补丁。

## Revised Contract

之前批准的“低相关 foreign 作为未编号背景保留”被明确撤销，REQ-602 已同步说明排除已测极低相关异语候选后的实际 kept；这是显式设计修订，没有静默把原证据保留承诺改义。

仅复用既定资格：开关开启、已有 bounded/明确流程/比较与 rewrite 排除成立，至少一个同语言已重排且明确概率 ≥0.9，所有异语言项均已重排、量纲明确且 ≤0.01。没有新增打分或模型调用，不修改原 prompt/schema/温度。

无资格、缺分、未知量纲、高相关异语言或缺强同语依据时，返回整个原集合并使用原完整生成；不能先删除部分低分项，再因另一项不合格而带着被裁过的集合回退。None 不能被当作低相关 0。

## Data-flow Assessment

Fast 三入口和 Generate 在既有 preparation 所有者边界、prepare_evidence 预算之前统一预选，实际留下的集合同时建立 context、kept_documents/generation_evidence、retrieved_contexts 和 sources。后续生成、引用、输出检查和 API 展示看到同一个实际保留集合，避免只从 prompt 删文本却还把它报告为本次生成依据。

原 retrieval_evidence 与 retrieval diagnostics 仍记录原召回事实，不由生成路径覆盖。保留项原文和 metadata 不改，不引入新的跨节点状态键。直接 generation_chain 使用同一预选逻辑，历史只替换原完整证据块，其他上下文保持；来源始终由结构化映射得到。

预算前预选是合理位置：已经判定不供本流程使用的异语尾部不应再占据生成证据预算。这个选择仍须限于已审资格，不能扩大成一般低分删除或同语言条款阈值过滤。

## Verification Scope

直接回归应证明实际低分 foreign 从生成 prompt 与对外 generation sources 同时消失，相关同语原文及历史保留；Fast/Thinking、JSON/SSE 的同一路径生效。另验证高分或缺分 foreign 保留整个原集合、完整 schema 与温度 0.7，false/非流程/比较/rewrite 不受预选影响。无需新增额外核验模型或更宽阈值平台。

只要这些入口保持 flag=false 的原行为不变，可以复用已冻结的 false 基线 24 答作为同开发协议对照；候选 24 答必须重跑，并继续逐项审具体动作、用途、引用、相关性和调用数。不能只检查条款 10 回来了就判整个候选通过。若修改超出上述受控路径，原基线复用资格需重新说明。

本评审未改代码、未调用模型、未读 critic 报告，未创建或暴露新留出题。候选开发合格后才冻结新题，之后不据留出调提示。
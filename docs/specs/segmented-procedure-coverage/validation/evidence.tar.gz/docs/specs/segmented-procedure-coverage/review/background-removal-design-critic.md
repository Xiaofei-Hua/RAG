# Critic Review — Remove Measured Irrelevant Background

**Review date**: 2026-11-11  
**Target**: `design.md` 最新 Remove the Reproduced Low-Relevance Background、更新后的 REQ-602。  
**Independence**: 未读取 defender 报告，未运行模型，未修改业务代码；独立比较已记录的实际请求。

## Decision

- Critical: 0
- High: 0
- Medium: 0
- Low: 0
- **允许编码这项最小上下文修复，并重测开发候选；无设计阻断。默认继续 false，F-12 尚未关闭。**

## Reproduced Input Difference

独立核对 `procedure-api-final-candidate/model-http.jsonl` index 6 与 `procedure-mechanism-v6/model-http.jsonl` index 7：所有非 messages 字段相同，system 内容相同；human 中唯一差异为 API 多了一整份未编号的 R7 英文运行规程背景。L4 的条款编号、正文、用户问题与 schema 均相同。

两资料机制样本包含记录追溯用途，而有此背景的 Fast API 两轮稳定漏选。该对照支持背景干扰这一可检验因果假设；并不单靠“请求差异只一处”就宣布修复已成功。去除后的真实候选全文结果才决定 F-12 能否关闭。

**praise (non-blocking)**：修复改的是已复现的无关生成输入，没有再修改提示、采样、条款语义或检查标准，也没有增加评分、核验或生成调用。它比针对条款 10 硬编码、补附录或再增分类字段更小，符合针对真实问题的范围。

## Selection and State Boundary

门槛沿用已批准的局部概率契约：同语种至少一份已重排、真实概率 ≥0.9；所有异语项均有有效概率且 ≤0.01。只有整个条件成立才移除这些极低相关异语项；任一异语高相关、缺分或量纲未知时返回原集合，走原完整生成，不部分删掉可能有用的依据。None 不作 0。

Fast 三个入口在 prepare_evidence 预算前使用同一纯选择函数；Generate 在既有 `_prepare_generation_evidence` 所有者边界使用它。随后由实际选择集合建立本次 context、kept、sources、generation_evidence 与 retrieved_contexts。设计已明确保留原始 retrieval_evidence 和检索 diagnostics，避免把生成选择伪装成检索没有召回。

筛选必须返回本次集合而不原地修改检索状态。source_id 继续以真实源名映射；来源面板和输出检查所见资料与实际生成保留集同步。直接 generation_chain 的局部准备也使用相同选择；历史只替换原完整证据块，其他上下文保持。该契约撤销了旧“低相关异语仍作为背景保留”的设计及对应测试预期，不应并存两种规则。

开关 false、非流程、比较、rewrite 或不满足资格均保持原输入和完整 GroundedAnswer/0.7；合格流程仍 ProcedureAnswer/0、2048、none、top_p0.8、一次完整 stop 后检查发布。不新增 shared_state 键、公共 API 字段、模型调用或全局评分行为。

## Validation and Baseline Reuse

已定回归覆盖改动直接触及的边界，范围足够：

- 低相关异语同时从实际模型 prompt、实际 kept 及 API 来源排除；Fast/Thinking 与 JSON/SSE 同步。
- 原始检索证据保留，历史保留，真实来源映射与输出检查依据正确。
- 高相关异语、缺分、未知 marker 与不满足强同语条件保留原集合、原完整路径；false 与非流程输入不变。
- 生成次数、温度绑定、完整发布、PII 与 None/degraded 保持。

false 基线所有行为及请求参数未改，可复用原 24 条记录；无需为记录格式或一致性另建实验。新候选仍按六题、两模式、两轮逐配对审全文，保留本次与历史所有失败，不用总分或时延抵消缺用途。复用基线的时延比较仍属于分批开发统计，应注明这一限制。

仅在候选完整语义合格后固定实现并冻结新留出；F-12 的具体复核是 L4 两轮 Fast 必须实际说明记录用于追溯偏移来源，同时保持准备、失败样张、其他用途、计数触发、未知边界和无关排除。没有降低质量门槛。

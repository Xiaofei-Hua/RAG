# Final Code Defender Review

**Date**: 2026-11-11  
**Object**: 最终 tracked diff、`core/procedure_generation.py`、流程单元/golden、两模式 API 回归及已有红绿日志。  
**Method**: 独立源码与测试证据复核，未读 critic、未改业务代码、未调用模型或创建留出。  
**Decision**: **没有发现本次最终实现的新增 Critical/High 阻断，可继续正在执行的实际 API 验收。** 当前默认仍 false；此结论不代替真实 API、新留出、完整矩阵和公开配置文档。

## Scope and Sampling

`core/segmented_generation.py:32` 的统一资格入口现在同时要求开关、bounded、rewrite_count=0、明确流程信号以及非比较。Fast 的 sync/async/SSE 和 Thinking 入口调用这一资格或统一 generation_chain，普通解释/记录问题不会继续进入旧分段 prompt。

`core/local_rag_generation.py:120` 准备阶段只有上述资格满足才尝试 procedure；一旦尝试，`segmented=False`，所以语言/映射/上下文等资格失败时直接选原 GroundedAnswer。没有先生成再追加补救调用。`build_generation_request` 只有有效 procedure 分支绑定温度 0，其余为 0.7；top_p=0.8、2048 和 none 保持。旧 SegmentedAnswer/parser 仍供直接内部回归使用，但生产入口已无非流程选择资格。

同步与异步共享准备和渲染逻辑，没有只改流式而漏普通 JSON 的分叉。比较/rewrite 保持既有完整路径；false 同样完整回滚。

## Complete Publication and Source Composition

`core/procedure_generation.py` 要求 finish_reason=stop、完整严格 schema 与有效条款 ID 后才渲染；v5 的 omitted 字段没有进入生产。每段正文来自最终选择的原文，source_ids 从真实条款归属派生，重复来源映射到真实来源名；不从资料正文假标题提取来源。

同一 evidence 项内的指代句和前句保持在同一条款，未跨来源合并。生成前只替换完整结构化 evidence 渲染块，其他 context/history 保留；块、来源或证据缺失则回原完整路径。原文背景与同语种编号条款共同处于原不可信资料边界。

`core/segmented_generation.py:155` 等完整生成链返回，才把全文交给 CheckedParagraphs 一次并发布一个正文事件。非 stop、非法 ID 或检查失败时无原文前缀泄漏，只给固定不可用且 generation_complete=false；ModelBusyError 沿用既有处理，不追加调用。最终 API 测试同时核对 token/done/会话保存/历史元数据和 PII 处理，没有用原文拼接绕过检查。

## Relevance Output Contract

`core/retrieval/reranker.py:214` 只读取模型实际默认激活类型，兼容新 activation_fn 和旧 default_activation_function；只有已知 `torch.nn.modules.activation.Sigmoid` 才添加 `rerank_output_space="probability"`。predict 调用参数、调用次数、排序和原 rerank_score 均没有改变。未知类型移除旧标记；模型失败仍使用原 rerank_applied=false 降级。

全业务源码中，该标记仅由 reranker 写、procedure 读。没有加入会被 evidence/grade 或 corrective/authority 自动消费的 `rerank_prob` / `rerank_probability`。因此本次没有顺带改变既有双 Sigmoid 消费者的全局阈值或检索纠正路径；旧量纲问题保留为已知范围外行为，新流程资格不再误用其约 0.500 的转换值。

流程门控只在 rerank_applied=true、量纲标记明确且原数值是有限 [0,1] 概率时使用分数。None、非法值或未知量纲不解释成 0。存在同语种 ≥0.9 的强证据，且所有异语言项均可确认 ≤0.01 时，后者才保留为未编号背景；高分或缺分异语直接回原完整生成。背景原文、来源和共享 kept 均未删除，模型也不能将未编号背景伪装为可选条款。

Fast 的 Documents→evidence→kept Documents→generation evidence 转换保留 metadata，Thinking 的 prepared evidence 也保留标记。真实 API 仍须确认实际评分/输入下 Fast 资格确实进入、且选择后的答案没有丢所问依据；代码结构合理并不代替这一验证。

## Tests and Evidence

- `validation/final-scope-red.log`：9 failed / 32 passed，失败对应温度绑定、解释问题仍走旧分段、普通记录 API 输出 schema。
- `validation/final-scope-green.log`：61 passed。
- 独立门控 `document-gate-red.log` 保留 2 failed / 4 passed / 17 deselected，`document-gate-green.log` 为 23 passed。
- 新流程单元通过实际 mock HTTP 请求核对完整 system prompt、ProcedureParagraph schema、动态 ID 枚举、temperature=0、2048/none/top_p 和单次调用；既有 bounded 单元仍断言完整生成温度 0.7。
- 资格回归涵盖解释问题、法语/明显混合正文、缺来源/证据/块、同源多 chunk、history 保留、指代事件保持，以及强同语言+低分 foreign、缺量纲/缺分/高分 foreign 回退。reranker 回归确认原数值不变、不写两个既有概率字段、未知激活不标记。
- 流程 golden 固定选择结构及最终原文引用答案，并排除未选择的包装/库存；它证明接线与渲染，不证明真实模型会正确选择。v6 真实质量结论另见 `mechanism-v6-defender.md`。
- E2E 覆盖 Fast/Thinking、JSON/SSE、stop/length、流程/非流程，保存正文与历史一致，真实请求最终生成一次；原文中的电话仍经既有输出检查清理。

本 reviewer 未重复运行已通过的同组测试，依据实际日志及断言逐项复核；没有用更多测试数量作为机制收益。交付前仍应按仓库要求完成全量矩阵，不能用本次 61 项替代。

## Data and Remaining Delivery Work

当前 diff 没有删改 v1–v5、旧 API 的失败数据，相关结果和 HTTP 日志仍在独立目录；新 API 使用 final 目录，不覆盖已报告失败。新 prompt 仅新增 general profile 的 procedure prompt，旧非流程 prompt 与已有完整生成 prompt 没被再次调优。未新增持久化或 shared_state 键。

PCD-01/02 的修复保持成立；正式 tracking closed 仍由最终修复提交及永久回归引用闭环。公开开关语义收窄的 [breaking] CHANGELOG、README/API/部署说明及任务清单尚属交付待办，在默认决策后统一完成，不因等待这部分文档暂停当前 API 验证。

当前候选可保持冻结；只有实际 API 质量准入后才创建新的两道中英流程留出。未提前生成或暴露留出题。
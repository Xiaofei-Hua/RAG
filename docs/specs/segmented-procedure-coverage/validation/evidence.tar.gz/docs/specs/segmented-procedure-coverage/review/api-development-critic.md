# Critic Review — API Development Comparison

**Review date**: 2026-11-11  
**Scope**: `procedure-api-dev-baseline/results.jsonl` 与 `procedure-api-dev-candidate/results.jsonl` 全部 24 配对、对应 `model-http.jsonl`、`validation/api-development.json`。  
**Independence**: 逐条阅读全部 48 份答案；未读取 defender 报告，未调用真实模型，未修改业务或测试代码。仅重新执行 6 项密封路由回归。

## Decision

- 当前候选 **不满足默认启用或进入新留出的质量条件**；继续 `LOCAL_RAG_SEGMENTED=false`。
- 流程核心语义完整性：baseline **1/8**，candidate **4/8**。计入已冻结的无关资料排除要求后，完整质量分别为 **1/8、2/8**。
- 其余 16 题，双方所问核心事实均 **16/16**；计入引用支持和无关追加内容，baseline **15/16**，candidate **14/16**。候选出现两条完整可用性退步，不能只报告问题中的数值都答对。
- 每侧 **60 次模型请求 = 24 次最终生成 + 36 次既有控制调用**。每个答案仅一次最终生成；Fast 每题总计 1 次，Thinking 每题总计 4 次。未增加生成调用。
- F-07/F-08 已独立复核修复；详见 `production-code-critic.md` 末尾。新增发现：Critical 1、High 2。

**praise (non-blocking)**：实际进入 ProcedureAnswer 的 4 条 Thinking 答案，全部保留具体准备、检查、结果记录、失败记录、检查目的、计数排除项、首次与换件复位触发、未知范围和真实引用。未再发生 v1–v3 中把普通失败复查泛化为换件复位的错误。重复原文和标题没有在这些样本中推翻原文显式条件，不以重复或措辞差异判失败。

## Procedure Results

“核心完整”要求全部所问动作、目的、事件关系、范围、未知信息、语言及支持引用；“严格完整”再加入协议明确要求排除包装颜色和库存。表中的行号是两侧 `results.jsonl` 相同配对位置。

| Line | Round / Mode / Case | Baseline | Candidate actual route | Candidate | Exact evidence |
|---|---|---|---|---|---|
| 5 | R1 Fast / R7 | Fail | GroundedAnswer fallback | Fail | 两侧均漏指定参考纸、序列号、结果日期与失败记录等。候选另写 fresh interval after replacement **or failure correction**，错误扩大复位触发。 |
| 6 | R1 Fast / L4 | Fail | GroundedAnswer fallback | Fail | 准备编号有写，但两侧均漏检查后日期/样张编号/失败样张保留、记录追溯用途等；候选并未因 stop 而修复这些动作。 |
| 11 | R1 Thinking / R7 | Fail | ProcedureAnswer | Core pass; strict fail | 基线把 fresh interval 放在普通失败复查后，且缺周期检查/记录追溯目的。候选动作、目的完整，但最后“Service Charge and Packaging”加入 blue cartons 与 92 boxes。 |
| 12 | R1 Thinking / L4 | Pass | ProcedureAnswer | Pass | 两侧涵盖准备编号、失败样张、用途及规则；基线“保留在当批记录中以便追溯”与已列机台/托盘/样张记录合读，接受为有意义的追溯说明，不要求逐字复述。候选排除包装干扰。 |
| 17 | R2 Fast / R7 | Fail | GroundedAnswer fallback | Fail | 两侧漏具体准备与检查后记录/保留失败记录、追溯用途；候选首个总结明确把 fresh 37-hour interval 放到任意失败纠正复查之后。 |
| 18 | R2 Fast / L4 | Fail | GroundedAnswer fallback | Fail | 两侧漏检查后的具体字段、保留失败样张和记录追溯用途。候选初始/周期目的与旧托盘不可代替的若干段还仅引用运行规程，实际文字依据在检查记录。 |
| 23 | R2 Thinking / R7 | Fail | ProcedureAnswer | Pass | 基线漏检查后 pass/fail/保留失败记录和记录追溯用途。候选完整、触发关系正确、排除干扰；重复不构成语义错误。 |
| 24 | R2 Thinking / L4 | Fail | ProcedureAnswer | Core pass; strict fail | 基线没有解释记录追溯偏移来源的用途。候选覆盖全部动作和目的，但“特殊事项说明”加入蓝色包装盒和 92 只库存。 |

Fast 的 4 个候选不是新机制的失败选择，而是**没有进入选择机制**。实际 kept evidence 中，R7 两份英文主要证据后还有 L4 中文检查记录；L4 两份中文主要证据后还有 R7 英文运行规程。`prepare_procedure` 的任一资料不同语种即回退规则因而使用 GroundedAnswer。该回退符合已批准语言保守约束，但真实 Fast 用户的原始遗漏问题仍未解决，不能将 4 条回退计入机制有效覆盖。

Thinking 的 4 条选择均使用实际来源映射；英文换头事件与 “that check” 保持同一条款。包装干扰为模型明确选中独立 ID，非程序自动追加：candidate HTTP index 26 选入条款 13、14；index 60 选入条款 12、13。

## Other Cases

P 表示所问事实、必要限制和引用均通过且无无关追加；F 表示完整质量失败。比较题用 9 小时=540 分钟与 600 分钟比较也可通过，不强求统一成小时这一种表达。

| Line | Round / Mode / Case | Baseline | Candidate | Assessment |
|---|---|---|---|---|
| 1 | R1 Fast / ih2_06 | P | P | 9h/8W、10h/5W；记录较长与同负载不可外推都保留。 |
| 2 | R1 Fast / dev_zero | F | P | 基线核心结论正确，但独立“零不是缺测”段仅引 L4 检查记录，来源不支持。候选引用两份计时记录。 |
| 3 | R1 Fast / dev_calibration | P | P | 正常连续使用、120 日历日、两个起算事件均正确。 |
| 4 | R1 Fast / dev_missing | P | F | 候选首段价格未知和交付起 18 个月正确；后续追加映棠计时偏差与澄晖校准全文，与所问 Caldra 无关。 |
| 7 | R1 Thinking / ih2_06 | P | P | 数值、不同负载限制与双来源正确。 |
| 8 | R1 Thinking / dev_zero | P | P | 零值等价且不是缺测。 |
| 9 | R1 Thinking / dev_calibration | P | P | 全文正确；候选首次发布只有周期和正常使用条件，两个起算事件在后两次发布。 |
| 10 | R1 Thinking / dev_missing | P | P | 未虚构价格，18 个月从交付起算。 |
| 13 | R2 Fast / ih2_06 | P | P | 数值比较与不可外推限制正确。 |
| 14 | R2 Fast / dev_zero | P | P | 零值、单位与基准条件正确。 |
| 15 | R2 Fast / dev_calibration | P | F | 候选完整回答校准后又追加 R7 操作规程和映棠计时测试；相关正文正确但完整交付受无关内容污染。 |
| 16 | R2 Fast / dev_missing | P | P | 价格未知与保修起点正确。 |
| 19 | R2 Thinking / ih2_06 | P | P | 统一单位关系、负载与引用正确。 |
| 20 | R2 Thinking / dev_zero | P | P | 已测得零与缺测区分正确。 |
| 21 | R2 Thinking / dev_calibration | P | P | 使用条件、两个起点、换件先校准保留。 |
| 22 | R2 Thinking / dev_missing | P | P | 价格未知和交付起 18 个月保留。 |

候选 8 条比较/零值题仍用 GroundedAnswer；8 条校准/缺价题用既有 SegmentedAnswer。两项无关追加发生在原普通分段路径，并非 ProcedureAnswer；这说明同时切换整个 LOCAL_RAG_SEGMENTED 开关的候选不能主张非流程完整质量无退步，但不要求本次扩展为旧 prompt 调优项目。

## Publication and First Body

生产设计已将流程发布单元改为完整选择后一次发布。因此按实际 API token 事件评审，不能把视觉标题下面一小段误当作已经独立发布的流程承诺。

- 两侧所有流程答案均只有 **1 个 token 事件**，该事件内容与最终答案相同；候选 4 条 ProcedureAnswer 均在完整 stop 后一次交付。没有不完整流程前缀泄露。
- 所以流程的首个已发布正文语义质量与全文相同：候选核心 **4/8**、严格 **2/8**；“一次完整发布”本身 **8/8**，两种计数不能互换。
- 仅作排版观察，4 条真正选择答案的视觉首节均包含主要运行规则和通用适用范围（**4/4**），不是仅列环境；视觉首节独自包含所有后续条件的旧标准为 **0/4**。旧机制实验首段失败不因此翻案；当前完整发布保证来自发布单元改变。
- 非流程候选有 3 条分成 3 次 token 发布：R1 Fast 缺价、R1 Thinking 校准、R2 Fast 校准。前后两条首次已正确回答所问，后续添无关内容；R1 Thinking 校准首次仅给 120 日历日和使用条件，尚未回答两个起算点。其余 13 条候选非流程为一次发布。故首个正文覆盖全部所问核心事实为 **15/16**，全文核心为 **16/16**。
- 全部 48 条 HTTP 状态为 200，最终生成均 stop、done 均 complete；这些协议状态不证明上述失败的语义质量通过。

## Calls and Latency

原始模型日志按每行 `model_start < index <= model_end` 配对核对，不以 UI 标注或 schema 合法代替实际调用。所有 48 次最终生成使用 qwen3.5:9b、2048 tokens、reasoning none、temperature 0.7、top_p 0.8。每侧 24 次生成且无修复重试；全部模型调用分别都是 60 次。候选部分流式请求没有 usage，不能把已有 16 条 usage 与基线 24 条合计直接比较总 token 成本。

| Group | N per side | First body P50 baseline → candidate | Request completion P50 baseline → candidate |
|---|---:|---:|---:|
| Procedure / Fast | 4 | 8.012s → 8.301s | 8.012s → 8.302s |
| Procedure / Thinking | 4 | 11.091s → 7.481s | 11.204s → 7.595s |
| Other / Fast | 8 | 3.410s → 2.411s | 3.411s → 2.956s |
| Other / Thinking | 8 | 5.912s → 4.887s | 6.019s → 5.617s |

这是小规模开发重复的描述统计，baseline/candidate 分批运行，不能当成严格交错配对性能结论。Thinking 流程约提前 3.61s 交付完整正文的现象有价值，但当前严格质量只过 2/4，不能用这项速度代替质量准入。

## Findings

### F-09 — 真实 Fast 流程全部因异语低相关资料回退，目标遗漏仍可复现

**issue (blocking, must-fix for qualification)**

- **id**: F-09
- **severity**: Critical。critic §2(a)：真实默认 API 的目标长流程遗漏在候选仍可复现，4/4 Fast 流程失败。
- **location**: `core/procedure_generation.py:73-82`；candidate results lines 5、6、17、18；模型请求 indices 5、6、35、36。
- **symptom**: 明确中英文流程都带有高相关同语种两份证据和一份低相关异语尾项；任一异语即回 GroundedAnswer，继续漏具体动作、失败记录和目的。
- **impact**: 生成热路径未改善 Fast 用户的目标问题；把 fallback 算作机制已覆盖会误报收益。
- **root_cause**: 语言资格对全部 kept 文档一票否决，未区分已存在重排信号显著低相关的尾项；回退本身执行正确。
- **recommendation**: 先以本批实际 kept 和已有有效重排信号做最小文档筛选实验，再做语言资格；不得仅按语言删除高相关材料，不把 None 当低分，也不得为默认启用忽略这 4 个失败。若无法验证，维持 false 并明确未闭合。
- **verification**: 保留真实第三份异语低相关材料；确认选入主证据后实际 schema 命中与完整语义改善，同时以高相关异语/无分数样本验证仍回完整路径。无需新分类平台。
- **status**: open

### F-10 — 选择机制仍会发布已冻结的无关包装条款

**issue (blocking, must-fix for qualification)**

- **id**: F-10
- **severity**: High。critic §2(a) 的选择边界未闭合，生成热路径实际输入含正常无关资料时会扩大答案；没有把轻微冗余冒称错误操作或全部动作失败。
- **location**: candidate results lines 11、24；HTTP indices 26、60；`core/procedure_generation.py:121-135`。
- **symptom**: 在完整正确流程后，模型主动选择 blue/蓝色与 92 盒库存条款，程序按合法 ID 原样发布。
- **impact**: 已冻结的干扰排除质量条件失败；当前完整原文编排不能保证只呈现与问题有关的流程内容。
- **root_cause**: 合法来源和原文忠实不等于相关性；选择仍由一次自由决策决定。
- **recommendation**: 不放宽判据或用 ID 覆盖率抵消此失败。若探索已有 cross-encoder，只先对保护指代后的条款组进行一次批量离线实验，确认必需动作/目的/未知信息与干扰有可分离的分数，再决定是否加入流程局部过滤；没有可分离证据则继续 false。
- **verification**: 本两条具体答案中的全部必需动作和目的保持，包装两句排除；同时分别报告全文语义覆盖和干扰排除，不只报告选中 ID。
- **status**: open

### F-11 — 同开关下旧普通分段存在两条完整交付退步

**issue (blocking for enabling the shared flag)**

- **id**: F-11
- **severity**: High。critic §2(a)：共用开关开启后非流程常见输入的相关性边界失败，真实 16 配对出现 2 条新增无关追加。
- **location**: candidate results lines 4、15；HTTP indices 4、33 的 SegmentedAnswer；既有普通分段路径。
- **symptom**: 正确首段之后，分别附加其他设备的计时测试/校准或 R7 流程，基线对应答案没有这些内容。
- **impact**: 开启候选后非流程完整可用性下降；首段正确、来源存在和 stop 不能证明全文无退步。
- **root_cause**: 本候选同时启用旧普通分段；该路径在多份 kept 文档时继续生成与问题无关的后段。
- **recommendation**: 保持默认 false；不要为本次扩展旧 prompt 调优。若以后要只启用已合格流程，需要在既定设计中明确限定生效范围并验证原非流程实际请求保持，而非直接开启共享开关后忽略该退步。
- **verification**: 保留这两条真实多资料请求作为非流程回归，核对全文无无关后段；首次发布和全篇分开评审。
- **status**: open for shared-flag enablement; mitigated by default false

## Minimal Follow-up Boundary

已有文档级 `rerank_score` 的排序信息值得复用，但不能把字段注释当分数语义：`Reranker.rerank` 的 `predict` 没有显式设激活，`document_to_evidence` 又对该值执行 sigmoid。本批约 0.001 与 0.98 变成约 0.500 与 0.727，不能直接把后一组当相关概率或随意反推阈值。先确认本地实际模型/库的输出空间；缺失、不可用或异量纲不参与低分剔除。

条款打分的主要风险是把短的失败记录、用途、价格未知或不计数句当作低相关再次删掉。若继续实验，输入至少保留来源标题和同源指代组，先展示全体必需条款与包装干扰的分数分布；没有稳定分离就不应采用 top-k 或阈值硬删。这一建议只针对已复现的质量问题，不要求扩展全局重排、共享状态或新的在线生成调用。

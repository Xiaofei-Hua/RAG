# Critic Review — Procedure Mechanism v2

**Review date**: 2026-11-11  
**Evidence**: `data/eval/procedure-mechanism-v2/{results,model-http}.jsonl`、`prompts.json`、原开发协议及 v2 设计。  
**Independence**: 未读取 defender 报告；未运行真实模型，未新增实验。

## Decision

**v2 未合格；不进入 API/新留出，默认保持 false。** 改首段契约后主要规则和范围更稳定，但全文仍遗漏动作或周期触发，并把只属于特定阶段的重置规则推广到其他阶段。还出现编号合法、对应文档却不支持该段部分主张的具体引用错误。

12/12 均 stop；12 次正式生成，每答一次，另有一次预热 control。该轮没有增加调用，不能因此把语义失败判成功。

## Per-slot Review

旧首段指完整全局条件；新首段指主要操作规则、通用范围和适当引用。全文仍要求具体动作、所问目的、正确触发事件及完整引用支持。首段概述允许后续阶段展开，不能用这个变化豁免全文。

| Case | Round | Variant | Old lead | v2 lead | Full answer | Main issue |
|---|---:|---|---|---|---|---|
| Scanner | 1 | baseline | Fail | Fail | Fail | 未给干燥室内/16–28℃范围；缺准备与记录，错误泛化失败后重置。 |
| Scanner | 1 | candidate | Fail | Fail | Fail | 初始用途的来源引用不全；缺保留失败记录，普通周期复查被赋予重新起算规则，第二段失败停机只引检查记录。 |
| Printer | 1 | baseline | Pass | Pass | Fail | 缺检查后日期、样张编号与合格/不合格结果的具体记录。 |
| Printer | 1 | candidate | Fail | Pass | Fail | 没有指定编号定位纸、机台/托盘编号准备和检查后记录项目；只说保存信息追溯，初始建立基准目的也未写出。 |
| Scanner | 2 | candidate | Fail | Pass | Pass | 准备、结果记录、失败保留、三个阶段目的与起算/重置分别覆盖；未把普通失败处理改写为重置。 |
| Scanner | 2 | baseline | Pass | Pass | Fail | 缺指定参考纸准备、保留失败记录、周期检查用途与新头资格理由。 |
| Printer | 2 | candidate | Fail | Fail | Fail | 首段准备/编号来自检查记录却只引运行规程；全文未说明首次检查建立定位基准。 |
| Printer | 2 | baseline | Pass | Pass | Fail | 操作与记录基本完整，但未解释首次检查建立定位基准。 |
| Scanner | 3 | baseline | Pass | Pass | Fail | 缺指定参考纸准备、保留失败记录和周期/换头的所问目的。 |
| Scanner | 3 | candidate | Fail | Pass | Fail | 普通周期检查失败后复查通过，被明确写成重新起算37小时；资料仅明确初检起算和换头重置。 |
| Printer | 3 | baseline | Pass | Pass | Fail | 缺检查日期记录及旧托盘结果不能代替新托盘资格的说明。 |
| Printer | 3 | candidate | Fail | Pass | Fail | 周期复查段没有350张正式标签的触发，只在换托盘重置处写350；只写合格结果，未交代记录追溯目的。 |

按完整协议严格判读：旧首段 5/6、全文 0/6；候选旧首段 0/6、新首段综合 4/6、全文 1/6。候选六个首段的主要规则/范围正文都较 v1 稳定，但其中两段引用不完整，不能直接报告“新首段6/6”。局部操作段整体仍不能通过，普通复查重置错误是句子层面的实质错误，不能被后文正确的换头重置抵消。

## Findings

### F-03 — 自由概括仍漏掉准备、记录、触发点并泛化重置

**issue (blocking, must-fix)**

- **id**: F-03
- **severity**: Critical，critic §2(a)：目标流程缺漏仍可复现；v1 的 F-01 不能关闭。涉及生成热路径。
- **location**: `data/eval/procedure-mechanism-v2/results.jsonl:2`、`:4`、`:10`、`:12`；REQ-601。
- **symptom**: 中文 R1 没有具体准备/记录项目；R3 漏普通周期350张触发；英文 R1/R3 将复查通过泛化为重置。新 prompt 已明示禁止这些行为，输出仍不遵循。
- **impact**: 用户仍得不到可直接按证据执行的完整流程。只把条款分到三个段落不保证事实覆盖和正确因果。
- **root_cause**: 当前仍让模型在完整多文档内自由选取和压缩事实；更长的通用要求没有把每个最终段落绑定到具体支持条款。
- **recommendation**: 停止继续叠加清单。按 v3 的实验范围，只尝试同次生成中先选句级支持条款、再写对应最终段落；保留完整上下文和指代触发事件；若仍失败，不把结构/编号完备解释成语义完备。
- **verification**: 沿用现有两题三轮有界对照，审实际最终正文的准备、记录、周期触发、每阶段用途和重置事件；保留每段支持编号供定位，但正文才决定通过。
- **status**: open

### F-04 — 文档引用合法但没有覆盖段落全部主张

**issue (blocking, must-fix)**

- **id**: F-04
- **severity**: High，critic §2：热路径的来源支持契约在真实输出中失效；不是假想风险或非法编号问题。
- **location**: `data/eval/procedure-mechanism-v2/results.jsonl:2` 第二操作段、`:7` 首段；`data/profiles/general.yaml` 的自由 source_ids 选择。
- **symptom**: 英文 R1 的段落引用只有检查记录，但包含仅见于运行规则的失败停机/改正/复查；中文 R2 的准备纸及机台/托盘编号只存在检查记录，却只引运行规程。相同文档标题存在、编号合法不能支持这些主张。
- **impact**: 用户沿当前引用查不到完整依据；在线结构校验不能发现该语义归因错误。
- **root_cause**: 正文生成与文档级 source_ids 选择缺少更细粒度对应，模型把相邻段的来源错误合并/遗漏。
- **recommendation**: 在限定实验中，让每段先绑定实际条款 support_ids，引用文档由这些条款归属派生；继续人工核对正文是否被所选条款真正支持。不得把派生文档列表本身当成功修复。
- **verification**: 针对上述两个实际段落审支持条款与正文；检查失败处理是否绑定运行规则，准备/记录是否绑定检查记录。实际错误绑定仍必须计失败。
- **status**: open

## Timing

原始首段 P50：旧 2.940s → 新 2.364s；全文 P50：旧 3.375s → 新 4.402s。首段定义已更改且候选多数全文不合格，这不是可交付性能收益；必须同时保留旧首段判据，不能用新定义给旧失败翻案。

## Mechanism Recommendation

优先采用 v3 已提出的**每个最终段落先绑定句级来源，再写该段**。它比全篇计划、每来源一份摘要再二次整合更小，也不会把全部证据重复写入输出预算。当前最有依据的预期收益是减少错误归因和跨阶段因果混用；步骤遗漏是否改善仍是待检验假设。

不建议强制全部来源句都出现在答案中：kept 可能包含无关材料，这会将错误从遗漏变成无关信息和预算耗尽。也不建议程序直接拼接未覆盖原句补齐；那会替换用户要求的自然流程、可能破坏时序，并冒充模型已完成整题。若为诊断记录编号覆盖，它只能说明模型声明了支持关系，不能证明正文实现了对应事实。

## Research Basis and Limits

从 [Aviv Slobodkin 的公开主页](https://github.com/lovodkin93) 追踪 [Attribute First, then Generate 论文](https://aclanthology.org/2024.acl-long.182/) 与 [作者实现](https://github.com/lovodkin93/attribute-first-then-generate)。论文把来源选择、句子规划和逐句生成分解；官方实现明确提供三阶段与两阶段管线。此处只借鉴“先局部绑定支持，再写正文”的顺序，不移植其多次调用，也不声称论文证明了本地9B单次调用的效果。上述是本项目据来源提出的迁移假设。

[ALCE](https://aclanthology.org/2023.emnlp-main.398/) 分开评答案正确性和引用质量，支持本轮继续把“编号合法”“引用支持”“整题覆盖”分开报告；单独增加引用粒度并不构成完整答案质量证明。

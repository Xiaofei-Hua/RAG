# Mechanism v6 Defender Review

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-mechanism-v6/{results.jsonl,model-http.jsonl}`，2 题 × 2 来源顺序 × 3 轮，温度 0.7 / 0 各 12 答。  
**Method**: 独立阅读全部不同完整正文，并核对每轮对应文本、来源事实、标题与选择顺序；未读 critic，未调用模型，未修改业务代码或创建留出。

## Decision

**v6 候选通过本轮有限机制检查，可做最小参数/路由接线并进入真实 API。** 候选完整内容与 v2 首段合格 12/12。温度 0.7 对照完整内容合格 6/12，合并 v2 首段后为 5/12。两侧均结构完成 12/12；结构成功不是这一区别的依据。

候选实际上是四种输入排列各重复三次，四组内正文完全相同；不宣称十二个独立随机样本或已经证明新领域泛化。此次总体完整首见中位数略升，故不是温度 0 本身的加速证明；后续要与当前默认完整生成作实际 API 对照。

## Pair Review

行号为 results.jsonl 的 1-based 行号。Full 指事实、动作、目的、记录、适用关系、引用和相关性；Lead 单独按 v2 主要运行规则与通用范围判断。

| Round / Case / Order | .7 Row | .7 Full / Lead | 0 Row | 0 Full / Lead | Actual reason |
|---|---:|---|---:|---|---|
| R1 / scanner / original | 1 | Pass / Pass | 2 | Pass / Pass | 两侧准备、日期/结果/失败记录、四类用途与事件起算完整。 |
| R1 / scanner / reversed | 3 | Fail / Pass | 4 | Pass / Pass | .7 没有回答所问服务费未知；0 明确保留。 |
| R1 / printer / original | 5 | Pass / Pass | 6 | Pass / Pass | 规则、全部准备/记录、周期/换件/失败及用途齐全。 |
| R1 / printer / reversed | 7 | Fail / Pass | 8 | Pass / Pass | .7 漏价格未知；0 保留价格和户外未知边界。 |
| R2 / scanner / original | 10 | Fail / Pass | 9 | Pass / Pass | .7 加入蓝色纸箱和 92 箱库存；0 未引入离题条款。 |
| R2 / scanner / reversed | 12 | Pass / Fail | 11 | Pass / Pass | .7 全文内容齐，但书面首段只有环境；0 首段另给失败保持停机至纠正并通过的主规则。 |
| R2 / printer / original | 14 | Pass / Pass | 13 | Pass / Pass | 两侧完整；重复没有改变换托盘起算条件。 |
| R2 / printer / reversed | 16 | Fail / Pass | 15 | Pass / Pass | .7 虽有结果记录，漏机台/托盘/样张用于追溯偏移来源的所问目的；0 有。 |
| R3 / scanner / original | 17 | Pass / Pass | 18 | Pass / Pass | 两侧换头的 fresh interval 均仍绑定更换检查通过，未推广到普通失败复查。 |
| R3 / scanner / reversed | 19 | Fail / Fail | 20 | Pass / Pass | .7 漏服务费未知且首段仅环境；0 两者满足。 |
| R3 / printer / original | 21 | Pass / Pass | 22 | Pass / Pass | .7 准备段后置但原文明确“检查前”，没有反向操作指令；0 全文同样齐全。 |
| R3 / printer / reversed | 23 | Fail / Pass | 24 | Pass / Pass | .7 漏记录追溯用途；0 保留。 |

## Candidate Semantic Assessment

英文两种顺序均保留：指定参考纸和序号准备；日期/通过或失败结果、保留失败记录；初始安装参考、周期验证、旧头结果不能使新头合格、追溯历史四类用途。初始通过起算与换头检查通过后 fresh interval 分别明示；37 小时仅 active scanning，standby 排除；普通失败只要求停机、纠因和通过复查，没有被改成重置触发。干燥室内 16–28℃、户外/潮湿未提供规则和费用未提供都在。引用分别落到真实规则/记录来源。

中文两种顺序均保留：指定编号定位纸、机台/托盘编号；日期、样张编号、合格或不合格结果、保留失败样张；初始定位、周期偏移确认、旧托盘不能替代新托盘检查、追溯偏移四类用途。350 张周期触发、测试/作废不计、初次合格起算与换托盘后的重新起算各自完整；失败停印、排因、复查通过恢复，没有普通失败自动清零。19–26℃无结露室内及未知户外/价格边界完整，引用支持对应原文。

没有把条款编号覆盖当语义结论。还单独审阅了以下可读性风险：

- 英文逆序的记录说明在 `Starting Ordinary Scanning` 段之前。它在 `Initial Setup and Reference Check` 中描述检查及其记录，没有写“检查前记录通过/失败结果”；准备原句明确 before the check，普通扫描许可仍以初检通过为前提。它与 v1 的明确 `record ... pass/fail result before conducting ... check` 不同。说明性段落可更紧凑，但本轮不足以判成反向操作指令。
- 英文 `Failure Handling` 中重复换头句，仍以 `After replacing` 为前提；标题未把更换变成普通失败的强制动作，也未把其复位规则无条件推广。
- 中文逆序把记录句放在“不合格处理”标题下，但原文明确要求记录“合格或不合格结果”，并非只在失败时记录。准备句同样保持“检查前”，后续复查沿用所述检查。无排他词或实际缩限，不因标题/重复单独失败。

这些结论基于完整说明一次发布后整体阅读；不声称每个内部段落脱离全文也独立完备。

## Publication and Cost

实际 HTTP 有 24 个 generation 加 1 个独立预热 control。每答只有一次最终生成，全部 stop。每对请求除 temperature 外其余字段相同；top_p=0.8、2048、none，输入与 schema 均保持，负选择没有混入。无截断、补写、二次翻译或失败时间充当收益。

每答完整选择后首次发布；全篇首见时间如下，P95 为小样本线性插值，单位秒。

| Subset | n/side | .7 P50 / P95 | 0 P50 / P95 |
|---|---:|---:|---:|
| All | 12 | 3.656 / 4.299 | 3.763 / 3.970 |
| English | 6 | 3.689 / 4.451 | 3.683 / 3.789 |
| Chinese | 6 | 3.620 / 4.020 | 3.882 / 3.999 |

候选全篇 P50 比 .7 增加约 0.107 秒；不能称本机制轮已经加速。收益在于这四种已公开输入排列的完整质量改善，且无新增调用；生产性能必须以实际默认完整生成作基线。

候选 v2 内部首段 12/12，旧“一个书面首段给所有阶段条件”仍为 0/12；对照旧首段也为 0/12。历史 v1–v5/API 失败均保留。默认继续 false，下一步为有限路由真实 API，再固定候选和独立新留出。
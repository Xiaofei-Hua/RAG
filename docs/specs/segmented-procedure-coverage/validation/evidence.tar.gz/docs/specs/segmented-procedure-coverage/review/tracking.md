# Review Tracking

## Disposition
独立critic/defender并行评审覆盖编码前设计、每次机制修订、最终代码、开发及新留出。默认关闭交付获准；默认启用未通过。完整历史报告与逐答记录在validation/evidence.tar.gz内保留，旧失败不改判。

| ID | Severity | Requirement | Fix commit | Verification | Permanent regression | Status |
|---|---|---|---|---|---|---|
| D-01 / F-01,03,05 | High / Critical | REQ-601 | pending integration commit | 开发流程8/8、新留出核心步骤/条件/记录/用途12/12 | test_complete_selection_preserves_steps_and_request_contract; test_annotation_preserves_event_context_sources_and_history; test_segmented_api_persists_completion | awaiting commit linkage |
| F-02 | Critical | REQ-601/602 | pending integration commit | 所有开发/留出首个实际正文事件等于完整全文；不再提前交付局部流程 | test_procedure_publication_is_complete_checked_and_single_call | awaiting commit linkage |
| F-04,06 | High | REQ-601/602 | pending integration commit | 实际来源映射、引用条款原文与全文检查，开发/留出引用有效 | test_annotation_preserves_event_context_sources_and_history; test_segmented_api_persists_completion | awaiting commit linkage |
| F-07,08,11 | High | REQ-602 | pending integration commit | 解释/跨语/普通题回原完整；16/16普通实际请求与基线相同 | test_explanations_keep_the_existing_generation_route; test_other_or_mixed_language_uses_buffered_generation | awaiting commit linkage |
| F-09,12 | Critical | REQ-601/602 | pending integration commit | 两模式开发流程8/8，两个Fast用途复现已恢复，实际来源去噪一致 | test_only_measured_weak_foreign_evidence_is_removed; test_segmented_api_persists_completion[procedure_with_noise] | awaiting commit linkage |
| F-10,13 | High | REQ-604 | default false retained | 开发包装误选已恢复；新留出中文相关性/视觉首节失败仍未修复，禁止默认启用 | test_segmented_api_persists_completion; existing default-off routing tests | defended-with-alternative — false隔离，非缺陷修复 |

## Delivery
Stage 1新增纯机制与纯函数契约，Stage 2接线及文档，均默认false。最终working tree矩阵1313 passed/6 skipped、coverage75%；两阶段实际提交矩阵和GitHub test/e2e-ui/check结果待回填。所有Critical须在合并Stage 2前补实际修复提交；不以本表pending项声明已完成交付。

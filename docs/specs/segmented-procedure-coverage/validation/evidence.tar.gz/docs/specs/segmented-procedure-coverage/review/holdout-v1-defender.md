# Independent Holdout Review — Defender

**Date**: 2026-11-11  
**Object**: frozen `validation/holdout-v1.json`; `validation/procedure-api-holdout-{baseline,candidate}/{results.jsonl,model-http.jsonl,batch.json}`. Row numbers below are one-based JSONL lines.  
**Independence**: 逐条阅读两侧 24 答及实际请求/响应；未读取 critic 报告，未调用模型，未修改代码、题目、提示或判据。

## Decision

**候选不能默认启用。** 全部动作、条件和记录步骤覆盖由基线 5/12 改善到候选 12/12，所问用途由 4/12 改善到 12/12；但候选中文六答都带入绿色墙钟和 18 本年鉴，并把开始阅览的主规则延后到第三节。严格完整题合格率仅 **6/12**，基线为 **1/12**。R3 Fast 中文构成真实配对退步，不能用总分和提速抵消。`LOCAL_RAG_SEGMENTED=false` 必须保留；本轮停止针对留出的迭代。

两模式、三轮候选各题正文完全相同，实测 12 答只有两个不同正文。结果证明这两个冻结输入上的行为，不能冒称 12 个独立题目或独立随机样本。

## Frozen Criteria and Counts

全文检查包括全部准备动作、状态分支、放行与关闭条件、记录字段、失败记录、所问用途、未知边界、引用和实际执行顺序。仅字段、关键词、ID 或合法 schema 都不算完整语义证明。无实质影响的重复不自动判失败。

| Dimension | Baseline | Candidate | Interpretation |
|---|---:|---:|---|
| 全部动作/条件/记录字段与追加步骤 | 5/12 | 12/12 | 不含用途、相关性与书面首节；不能称整题通过 |
| 所问用途完整 | 4/12 | 12/12 | 编号对应、交付边界、状态追溯；或脚本/全程播放/独立审批/版本历史目的 |
| 无无关内容 | 11/12 | 6/12 | 基线第 10 行有银色公告板；候选全部中文含墙钟/年鉴 |
| v2 书面开头有主要规则和通用范围 | 10/12 | 6/12 | 忽略标题，检查第一实际正文段/首节，不把整条 token 当成书面首段 |
| 相关主张有真实来源支持 | 12/12 | 12/12 | 有依据但不相关的装饰事实仍导致相关性失败 |
| 完整 stop 后首次整体发布 | 12/12 | 12/12 | 每答一个正文 token 事件；不能替代内容质量 |
| 严格整题通过 | **1/12** | **6/12** | 每条冻结要求与 v2 契约均须满足 |

旧“一个书面首段包含全部阶段条件”口径另报：基线仅第 4、5、7、9 行满足，4/12；候选 0/12。该旧口径不是本轮替换 v2 的新门槛，也不翻案既有机制失败。v2 允许后续局部规则随对应阶段首次给出，仍要求开头有主规则和适用范围。

## Pairwise Whole-Answer Review

`Core` 是全部动作、条件和记录字段/追加步骤；`Purpose` 是全部所问用途。候选英文六答 Core/Purpose/v2/相关性均通过；候选中文六答 Core/Purpose 通过、v2/相关性失败。以下缺陷均在读完全文后确认，后段已补足的项目不判遗漏。

| Row | Round / mode / case | Baseline Core / Purpose / strict | Candidate strict | Baseline missing content or other finding |
|---:|---|---|---|---|
| 1 | R1 Fast / archive | Pass / Fail / Fail | Fail | 编号关联字段齐，但未解释编号用于对应一次完整调阅；可见开头为范围，主要阅览规则到第 3 项。 |
| 2 | R1 Fast / caption | Fail / Fail / Fail | Pass | 漏仅修改标题拼写不使审批失效的例外；漏 transcript identifier、全部草稿链接及四项所问目的。 |
| 3 | R1 Thinking / archive | Fail / Fail / Fail | Fail | 漏后续复核结论追加到同一编号；漏编号对应完整调阅和交接确认交付边界的目的。 |
| 4 | R1 Thinking / caption | Fail / Pass / Fail | Pass | 全文没有 transcript identifier 及保留每个草稿链接的动作；保留退稿及其原因的目的不能替代字段/链接要求。 |
| 5 | R2 Fast / archive | Pass / Fail / Fail | Fail | 全部动作/记录齐；漏编号对应完整调阅、交接确认交付边界两项用途。 |
| 6 | R2 Fast / caption | Pass / Fail / Fail | Pass | 记录及分支齐；漏防止使用旧脚本、整段播放查相邻 cue 间遗漏、独立审核分离编写与发布决策三项目的。 |
| 7 | R2 Thinking / archive | Fail / Fail / Fail | Fail | 漏编号关联申请档号/阅览证号/计划日期；漏编号对应和交付边界用途。不能把泛称申请信息当作完整关联记录。 |
| 8 | R2 Thinking / caption | Fail / Pass / Fail | Pass | 没说明缺少/不匹配输入时标 blocked 并请求修正；退回循环没有明确重做完整播放；漏标题拼写例外。 |
| 9 | R3 Fast / archive | Pass / Pass / **Pass** | **Fail** | 全部要求在首段和后文得到补足，无装饰事实；候选增加无关内容，是实际配对退步。 |
| 10 | R3 Fast / caption | Pass / Fail / Fail | Pass | 漏旧脚本/相邻 cue 遗漏/独立决策目的；加入银色公告板及未被询问的节假日边界。后段补足音频变更与标题拼写例外，不误判该两项遗漏。 |
| 11 | R3 Thinking / archive | Fail / Fail / Fail | Fail | 漏在库且无冻结时建立编号并安排取卷；漏编号关联字段及对应完整调阅目的；首个正文段只有范围。 |
| 12 | R3 Thinking / caption | Fail / Pass / Fail | Pass | 漏 transcript identifier 及保留所有草稿链接；后段明确匹配确认后才开始，全文未把请求修正等同解锁。 |

严格配对：6 条 Fail→Pass、5 条 Fail→Fail、1 条 Pass→Fail、0 条 Pass→Pass。六条中文的核心覆盖改善不消除其相关性失败。

## Candidate Semantic Findings

### H-D01 — Irrelevant selection in every Chinese answer

候选 `results.jsonl:1,3,5,7,9,11` 首节明文写“阅览室的墙钟外框是绿色”“资料室今年订了18本地方年鉴”。两句有真实来源，仍与调阅办理无关，且冻结要求明确排除。源条款选择只保证被选文字有依据，不保证选得相关。R3 Fast 基线第 9 行已合格，候选因此退步。

中文其余全文覆盖申请准备、在库/候补/退回三个分支、重新核对、交接后阅览、归还一致才关闭、异常保持未结和复核追加；编号、核对、交接、归还、异常记录字段以及三个目的均齐。没有把复核转交写成关闭，没有把提交申请写成可阅览。因此准确结论是核心遗漏得到修复、整题质量未过，不能把六答概括为完全不可执行或完全合格。

### H-D02 — Main operating rule appears after the opening section

同六答的“适用范围与通用规则”只有适用范围、节假日未知及无关装饰信息；共同清点并签名后才能阅览到第三节“交接与阅览开始”才出现。违反用户先交代主规则和冻结 v2 书面开头契约。此处是可见组织顺序问题，不是提前发布不完整操作前缀：实际第一次正文事件已包含完整全文。

### English acceptance and repetition boundary

英文六答开头包含 prerecorded English / indoor exhibitions 范围、live/translated 排除与同音频/字幕版本经独立 reviewer 批准才能发布。随后完整保留输入缺失或不匹配的阻塞/确认、针对该版本起稿、全程逐 cue 检查、失败保持编辑、退回保留原因并重做完整播放和新版本审批、音频变更后重新起稿/检查/审批，以及仅改工作标题拼写不使既有审批失效的例外。

草稿/退稿链接、transcript identifier、每次播放字段/明确 pass、审核日期/版本对/退回原因及四项目的均齐；live-caption 无规则和审核时限未知明确，未选 silver frame。准备到送审的大原文块在几个阶段中重复，来自保留指代的条款合并。它增加阅读负担，但未改变触发条件、缩限通用记录或允许未审批发布，因此按冻结规则不单独判失败。

## Actual Inputs, Sources, Calls and Publication

逐行配对的 query、case、mode、round 均一致，离线评审字段 `manual_required`、`whole_question_criteria` 等未进入实际生成 messages。两侧同题均有全部两份必要资料。Fast 基线额外保留一份极低相关异语资料：中文约 .001624、英文约 .000108；候选按已冻结资格移除该份，实际 prompt/kept/API sources 同步，保留两份必要资料。Thinking 两侧原本均为两份必要资料。完整请求变化属于冻结机制本身，不能称两侧 messages 完全相同。

每侧 30 次真实 HTTP 模型请求：12 次最终生成和 18 次 Thinking 控制调用。Fast 每答 1 次，Thinking 每答 4 次（3 control + 1 generation）。没有增加翻译、核验、重试或第二次生成。

基线 12 答实际为 `GroundedAnswer`、temperature .7；候选 12 答为 `ProcedureAnswer`、temperature 0。两侧 top_p .8、2048、reasoning_effort none 保持；全部 finish_reason=stop、每答一个正文 token 事件、done.generation_complete=true。候选先等完整选择，再由所选原文及来源组成正文，经过既有检查整体发布；英文字数较长不能当成生成 token 成本。输出完成标志只表示协议完成。

## Latency and Generation Cost

单位秒，P95 为样本线性插值；每种模式每侧仅 6 答，不作总体显著性结论。`first_body_s` 是第一次实际完整正文发布，不是模型首 token。

| Mode | Baseline first P50 / P95 | Candidate first P50 / P95 | Baseline total P50 / P95 | Candidate total P50 / P95 |
|---|---:|---:|---:|---:|
| All | 12.9245 / 17.7125 | 5.4527 / 8.4083 | 12.9703 / 17.7832 | 5.5076 / 8.5257 |
| Fast | 11.2568 / 18.2952 | 4.0488 / 4.7173 | 11.2571 / 18.2954 | 4.0491 / 4.7175 |
| Thinking | 15.2615 / 15.6221 | 7.1185 / 8.6897 | 15.3681 / 15.7599 | 7.2352 / 8.8044 |

完整首见总体中位数减少 57.81%；总耗时中位数减少 57.54%。12 次生成 completion tokens 从 13,172 降为 3,504（减少 73.40%），生成服务时间均值约 11.789→3.928 秒。整批耗时约 161.752→68.571 秒；两批顺序运行、各模式没有并发负载比较。上述提速可信地反映这批实验，却不能抵消中文六答的质量缺陷。

## Disposition

未默认启用、明确记录限制并保留 false 回滚，是当前已落地的替代隔离措施，不是对 H-D01/H-D02 的语义修复。允许默认关闭的代码按既定两个可独立测试阶段交付；每阶段提交/测试/CI/追踪仍由主任务补齐。无需针对这次失败扩建分类平台、增加模型或继续堆提示；若未来修改行为，本留出即成为开发资料，不能再次冒充全新留出。
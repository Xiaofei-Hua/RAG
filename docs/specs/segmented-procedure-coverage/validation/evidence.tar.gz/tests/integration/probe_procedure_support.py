"""Experiment with support-first final paragraphs, using the production publisher."""
import asyncio
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
os.environ.update(PYTHON_DOTENV_DISABLED="1", LOCAL_RAG_POLICY="bounded", LLM_MODEL="qwen3.5:9b", OPENAI_BASE_URL="http://127.0.0.1:11434/v1", OPENAI_API_KEY="ollama", DOMAIN_PROFILE="general", LOCAL_LLM_SCHEDULER="fair", LOCAL_RAG_SEGMENTED="true", EMBEDDING_PROVIDER="api")
import yaml
from pydantic import BaseModel,ConfigDict,Field
from langchain_core.prompts import ChatPromptTemplate
from run_bounded_api_probe import capture_model
from core import segmented_generation as seg
from core.local_rag_generation import CitedParagraph
from core.retrieval.evidence import render_untrusted_evidence
from core.prompts.domain_profile import get_active_profile
from agent.guardrails.manager import GuardrailManager
from models.llm_models import get_llm

class SupportedParagraph(BaseModel):
    model_config=ConfigDict(extra="forbid",strict=True)
    support_ids:list[int]=Field(min_length=1)
    text:str=Field(min_length=1)
class SupportedAnswer(BaseModel):
    model_config=ConfigDict(extra="forbid",strict=True)
    conditions:list[SupportedParagraph]
    answer:list[SupportedParagraph]=Field(min_length=1)

def annotate(case,protocol):
    evidence=[];source_map={};units=[]
    for source_id,name in enumerate(case["sources"],1):
        sentences=re.split(r"(?<=[。！？])|(?<=[.!?])\s+(?=[A-Z])|\n+",protocol["corpus"][name])
        lines=[]
        for sentence in sentences:
            if not sentence.strip():continue
            uid=len(units)+1;source_map[uid]=source_id
            units.append({"id":uid,"source_id":source_id,"text":sentence})
            lines.append(f"[条款{uid}] {sentence}")
        evidence.append({"source":name,"title":"","content":"\n".join(lines)})
    return render_untrusted_evidence(evidence),source_map,units

async def main():
    protocol=json.loads(Path(sys.argv[1]).read_text());out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=False)
    prompt=(ROOT/"docs/specs/segmented-procedure-coverage/validation/v3-prompt.txt").read_text()
    os.chdir(out);count=capture_model(out/"model-http.jsonl");profile=get_active_profile()
    original_prompt=profile.prompts["segmented_generate_system"]
    baseline=yaml.safe_load(subprocess.check_output(["git","show","f7984fe:data/profiles/general.yaml"],cwd=ROOT))["prompts"]["segmented_generate_system"]
    originals=(seg.CitedParagraph,seg.SegmentedAnswer,seg.request_model)
    model=get_llm();model.cache=False;checker=GuardrailManager().check_output
    async with asyncio.timeout(60):await model.ainvoke("请只输出就绪。",max_tokens=16,reasoning_effort="none",extra_body={"max_tokens":16})
    try:
        for repeat in range(1,4):
            for case in protocol["cases"]:
                annotated,source_map,units=annotate(case,protocol)
                for variant in (["baseline","candidate"] if repeat%2 else ["candidate","baseline"]):
                    seg.CitedParagraph,seg.SegmentedAnswer,seg.request_model=originals
                    profile.prompts["segmented_generate_system"]=baseline
                    contexts=[protocol["corpus"][name] for name in case["sources"]]
                    context=render_untrusted_evidence([{"source":name,"title":"","content":text} for name,text in zip(case["sources"],contexts)])
                    if variant=="candidate":
                        class Converter:
                            @classmethod
                            def model_validate(cls,value):
                                p=SupportedParagraph.model_validate(value)
                                ids=list(dict.fromkeys(source_map[i] for i in p.support_ids))
                                return CitedParagraph(text=p.text,source_ids=ids)
                        def request_model(llm,sources):
                            schema=SupportedAnswer.model_json_schema()
                            schema["$defs"]["SupportedParagraph"]["properties"]["support_ids"]["items"]["enum"]=list(source_map)
                            configured=llm.bind(reasoning_effort="none",temperature=0.7,top_p=0.8,max_tokens=2048,extra_body={"max_tokens":2048},response_format={"type":"json_schema","json_schema":{"name":"rag_answer","strict":True,"schema":schema}})
                            return ChatPromptTemplate.from_messages([("system",prompt),("human",profile.prompts["generate_human"])])|configured
                        seg.CitedParagraph,seg.SegmentedAnswer,seg.request_model=Converter,SupportedAnswer,request_model
                        context=annotated
                    inputs={"question":case["query"],"sources":case["sources"],"context":context}
                    row={"round":repeat,"case_id":case["id"],"variant":variant,"first_body_s":None,"events":[],"units":units if variant=="candidate" else None}
                    before=count[0];started=time.perf_counter()
                    try:
                        async with asyncio.timeout(45):
                            async for event in seg.stream_answer(model,inputs,checker,contexts):
                                row["events"].append(event)
                                if event["type"]=="token" and row["first_body_s"] is None:row["first_body_s"]=time.perf_counter()-started
                                if event["type"]=="done":row.update(answer=event["full_response"],outcome=event["generation_outcome"])
                    except Exception as exc:row["error"]=type(exc).__name__
                    row.update(elapsed_s=time.perf_counter()-started,model_calls=count[0]-before)
                    with (out/"results.jsonl").open("a") as f:f.write(json.dumps(row,ensure_ascii=False)+"\n")
                    print(json.dumps({k:v for k,v in row.items() if k not in {"events","answer","units"}},ensure_ascii=False),flush=True)
    finally:
        profile.prompts["segmented_generate_system"]=original_prompt
        seg.CitedParagraph,seg.SegmentedAnswer,seg.request_model=originals

asyncio.run(main())

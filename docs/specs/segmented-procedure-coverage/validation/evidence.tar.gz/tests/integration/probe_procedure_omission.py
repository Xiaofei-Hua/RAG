"""Compare one-call explicit omission with the complete selection baseline."""
import asyncio
import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
os.environ.update(PYTHON_DOTENV_DISABLED="1", LOCAL_RAG_POLICY="bounded", LLM_MODEL="qwen3.5:9b", OPENAI_BASE_URL="http://127.0.0.1:11434/v1", OPENAI_API_KEY="ollama", DOMAIN_PROFILE="general", LOCAL_LLM_SCHEDULER="fair", LOCAL_RAG_SEGMENTED="true", EMBEDDING_PROVIDER="api")
from pydantic import BaseModel, ConfigDict, Field
from langchain_core.messages import AIMessage
from langchain_core.prompts import ChatPromptTemplate
from run_bounded_api_probe import capture_model
from core.procedure_generation import ProcedureParagraph, ProcedureAnswer, prepare_procedure, render_procedure
from core.retrieval.evidence import render_untrusted_evidence
from core.segmented_generation import CheckedParagraphs, generation_outcome
from core.prompts.domain_profile import get_active_profile
from agent.guardrails.manager import GuardrailManager
from models.llm_models import get_llm

class OmissionAnswer(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    omitted_clause_ids: list[int]
    conditions: list[ProcedureParagraph] = Field(max_length=0)
    answer: list[ProcedureParagraph] = Field(min_length=1)

async def main():
    protocol=json.loads(Path(sys.argv[1]).read_text()); out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=False)
    prompts={v:(ROOT/f"docs/specs/segmented-procedure-coverage/validation/v{n}-prompt.txt").read_text() for v,n in [("baseline",4),("candidate",5)]}
    os.chdir(out);count=capture_model(out/"model-http.jsonl");profile=get_active_profile()
    model=get_llm();model.cache=False;checker=GuardrailManager().check_output
    async with asyncio.timeout(60):await model.ainvoke("请只输出就绪。",max_tokens=16,reasoning_effort="none",extra_body={"max_tokens":16})
    for repeat in range(1,4):
        for case in protocol["cases"]:
            for order in ["original","reversed"]:
                sources=case["sources"] if order=="original" else list(reversed(case["sources"]))
                contexts=[protocol["corpus"][name] for name in sources]
                evidence=[{"source":name,"title":"","content":text} for name,text in zip(sources,contexts)]
                inputs={"question":case["query"],"sources":sources,"evidence":evidence,"context":render_untrusted_evidence(evidence)}
                prepared=prepare_procedure(inputs);assert prepared
                allowed=set(range(1,len(prepared["units"])+1))
                inputs["context"]=prepared["context"]
                for variant in (["baseline","candidate"] if repeat%2 else ["candidate","baseline"]):
                    schema=(ProcedureAnswer if variant=="baseline" else OmissionAnswer).model_json_schema()
                    schema["$defs"]["ProcedureParagraph"]["properties"]["clause_ids"]["items"]["enum"]=sorted(allowed)
                    if variant=="candidate":schema["properties"]["omitted_clause_ids"]["items"]["enum"]=sorted(allowed)
                    configured=model.bind(reasoning_effort="none",temperature=.7,top_p=.8,max_tokens=2048,extra_body={"max_tokens":2048},response_format={"type":"json_schema","json_schema":{"name":"rag_answer","strict":True,"schema":schema}})
                    chain=ChatPromptTemplate.from_messages([("system",prompts[variant]),("human",profile.prompts["generate_human"])])|configured
                    row={"round":repeat,"case_id":case["id"],"evidence_order":order,"variant":variant,"units":prepared["units"],"first_body_s":None}
                    before=count[0];start=time.perf_counter()
                    try:
                        async with asyncio.timeout(45):
                            message=await chain.ainvoke(inputs)
                        row["selection"]=json.loads(message.content)
                        if variant=="candidate":
                            answer=OmissionAnswer.model_validate_json(message.content)
                            omitted=set(answer.omitted_clause_ids);selected={i for p in answer.answer for i in p.clause_ids}
                            if omitted & selected or omitted | selected != allowed:raise ValueError("incomplete_or_overlapping_classification")
                            message=AIMessage(content=answer.model_dump_json(exclude={"omitted_clause_ids"}),response_metadata=message.response_metadata)
                        rendered=render_procedure(message,sources,prepared)
                        publisher=CheckedParagraphs(checker,sources,contexts);publisher.append(rendered)
                        row.update(answer=publisher.text,first_body_s=time.perf_counter()-start,outcome=generation_outcome())
                    except Exception as exc:
                        row.update(error=str(exc),outcome=generation_outcome(False,type(exc).__name__))
                    row.update(elapsed_s=time.perf_counter()-start,model_calls=count[0]-before)
                    with (out/"results.jsonl").open("a") as f:f.write(json.dumps(row,ensure_ascii=False)+"\n")
                    print(json.dumps({k:v for k,v in row.items() if k not in {"answer","selection","units"}},ensure_ascii=False),flush=True)

asyncio.run(main())

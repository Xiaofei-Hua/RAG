"""Compare old and repaired prompts using identical evidence and one model call."""
import asyncio
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
os.environ.update(PYTHON_DOTENV_DISABLED="1", LOCAL_RAG_POLICY="bounded", LLM_MODEL="qwen3.5:9b", OPENAI_BASE_URL="http://127.0.0.1:11434/v1", OPENAI_API_KEY="ollama", DOMAIN_PROFILE="general", LOCAL_LLM_SCHEDULER="fair", LOCAL_RAG_SEGMENTED="true", EMBEDDING_PROVIDER="api")
import yaml
from run_bounded_api_probe import capture_model
from core.segmented_generation import stream_answer
from core.retrieval.evidence import render_untrusted_evidence
from core.prompts.domain_profile import get_active_profile
from agent.guardrails.manager import GuardrailManager
from models.llm_models import get_llm

async def main():
    protocol = json.loads(Path(sys.argv[1]).read_text())
    out = Path(sys.argv[2]).resolve(); out.mkdir(parents=True, exist_ok=False)
    os.chdir(out)
    count = capture_model(out / "model-http.jsonl")
    profile = get_active_profile()
    candidate = profile.prompts["segmented_generate_system"]
    baseline = yaml.safe_load(subprocess.check_output(["git", "show", "f7984fe:data/profiles/general.yaml"], cwd=ROOT)) ["prompts"]["segmented_generate_system"]
    (out / "prompts.json").write_text(json.dumps({"baseline":baseline,"candidate":candidate}, ensure_ascii=False, indent=2))
    model = get_llm(); model.cache = False
    async with asyncio.timeout(60):
        await model.ainvoke("请只输出就绪。", max_tokens=16, reasoning_effort="none", extra_body={"max_tokens":16})
    checker = GuardrailManager().check_output
    try:
        for repeat in range(1,4):
            for case in protocol["cases"]:
                variants = ["baseline", "candidate"] if repeat % 2 else ["candidate", "baseline"]
                for variant in variants:
                    profile.prompts["segmented_generate_system"] = baseline if variant=="baseline" else candidate
                    contexts = [protocol["corpus"][name] for name in case["sources"]]
                    inputs = {"question":case["query"], "sources":case["sources"], "context":render_untrusted_evidence([{"source":name,"content":text,"title":""} for name,text in zip(case["sources"],contexts)])}
                    started=time.perf_counter(); before=count[0]
                    row={"round":repeat,"case_id":case["id"],"variant":variant,"events":[],"first_body_s":None}
                    try:
                        async with asyncio.timeout(45):
                            async for event in stream_answer(model,inputs,checker,contexts):
                                row["events"].append(event)
                                if event["type"]=="token" and row["first_body_s"] is None: row["first_body_s"]=time.perf_counter()-started
                                if event["type"]=="done": row.update(answer=event["full_response"],outcome=event["generation_outcome"])
                    except Exception as exc: row["error"]=type(exc).__name__
                    row.update(elapsed_s=time.perf_counter()-started,model_calls=count[0]-before)
                    with (out/"results.jsonl").open("a") as f: f.write(json.dumps(row,ensure_ascii=False)+"\n")
                    print(json.dumps({k:v for k,v in row.items() if k not in {"events","answer"}},ensure_ascii=False),flush=True)
    finally:
        profile.prompts["segmented_generate_system"] = candidate

asyncio.run(main())

# Candidate Freeze v13

UTC: 2026-11-11T13:03:25.232795+00:00
Base: 9b79b006a89620ec58b4d46538913f20bfc5e54e, branch fix/procedure-relevance-order, reviewed working-tree candidate.
Snapshot: candidate-v13-code.tar.gz (code, prompt, model/flag boundary, golden and regression tests).

Four Chinese development procedures, two source orders and two rounds: independent strict16/16; production replay16/16. Real API same11 exposed cases/20 documents, both modes twice: Chinese16/16 vs baseline2/16, two independent reviewers approve new-holdout qualification. All final calls single generation. Controls are unchanged and reported separately.

The model, schema, prompt, all eligibility/renderer/constraint rules are frozen before writing any new holdout. Default remainsfalse. No tuning from fresh outputs; failure invalidates qualification and makes those cases development. Only after passed qualification may the default flag change with separate regression/default smoke. Documents may record observed results without changing behavior.

New holdout: independent author creates three new Chinese procedural cases in new domains, including requested unknowns, at least one unasked unknown and same-entity irrelevant content. Source/query/rubric only, no model calls by author. Full frozen eligibility preflight before any real model; only query/corpus enter production, no expected-answer metadata. False baseline vs true frozen candidate, Fast and Thinking three rounds each. Actual route/calls must be inspected; rewritten full generation remains control, never credited to clauses. Original protocol/corrections/failures retained.

# Rejected v18 Probe

The mixed-clause priority prompt left the ceramic permission in the second section in both modes. The experiment was stopped after observing this target failure; retain all completed rows and any interrupted wire request. Not a complete 40-answer evaluation and not eligible for production. No protocol or production change.

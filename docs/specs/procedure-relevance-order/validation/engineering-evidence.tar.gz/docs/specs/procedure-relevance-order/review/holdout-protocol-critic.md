# Holdout Protocol Critic Review

**Date**: 2026-11-11  
**Target**: `validation/holdout-v9.json`，revision=`procedure-relevance-holdout-v9-r3-routing-preflight`；候选先前已在`freeze-v9.md`及代码归档冻结。独立只审protocol与既有路由，未读新模型输出或defender评测结论，模型调用0。

## Decision

**r3无剩余实验阻塞，可启动正式v2目录的既定false/true、Fast/Thinking各三轮对照。** 每侧3题×2模式×3轮=18答。默认false、候选算法冻结、原语义判据保持；早期中断运行保留但不计验收。

## Protocol Assessment

- **praise (non-blocking)**: 两中文、一英文均为冻结后新写的不同流程。活动室覆盖改期等候位置/只改电话例外、门卡错误和新增损坏未结；木玩具覆盖通知不等于交付、代领授权、整份附件重新确认及保管边界；联赛覆盖双方确认/所有异议解决、开赛前后离场分支及撤回修订。这些具体依赖不同于已暴露四开发题，不只是换实体名。
- **praise (non-blocking)**: 每题判据均由所问事项及资料支持：首节主要许可与范围，全文动作/分支/记录/用途/未知，相关引用与排除同实体装饰事实。没有加入“所有细则都在首节”、首句、首节长度或额外关键词得分要求。英文主要放行句保持自然描述，没有为规范词前置策略改写资料。
- 各资料中的未规定事项、记录用途及装饰事实均区分明确；正文没有答案类别、应选ID或评审元数据。corpus六来源和全部case字段（除query）与原始预检版逐项一致，所有修正只作用于问题中明确请求的表达。
- 输入隔离已核验现有`tests/integration/run_bounded_api_probe.py:94`及`:116`：corpus通过正常资料上传，聊天请求只带query/session/mode；manual_required、lead_rubric、strict_rubric、coverage、freeze及其他评审元数据不送入生成。sources用于正常文档命名和离线审查，不注入参考答案。

## Routing Preflight and Timing

预检初版时，木玩具和联赛问题未包含现有显式流程识别表达。补明自然“办理流程”/“step-by-step procedure”后，完整路由还发现活动室题干“不一致”中的“一致”触发旧比较回退；只将该题干等义改为“房号有误”。原资料中的“不一致”、处理规则和所有rubric保持，生产比较规则也未改。

初次模型baseline在预检完成前已启动，是本次预检时序遗漏。按主Agent记录，已停止早期运行，未阅读新模型正文，原目录保留并排除验收；修正没有使用生成表现作反馈。原protocol和中间版分别保留为`holdout-v9-preflight.json`、`holdout-v9-preflight-r2.json`。不把未改路径结果计入候选收益。

独立以已冻结本地9B/general/bounded、segmented=true、rewrite_count=0及每题资料离线调用实际`procedural_question`、`segmented_enabled`、`prepare_procedure`：

| Case | Explicit procedure | Full segmented gate | Evidence eligible | Language |
|---|---|---|---|---|
| Room handover | P | P | P | zh |
| Toy pickup | P | P | P | zh |
| League results | P | P | P | en |

三题完整资格均通过。实际API的检索与生成仍按正式运行实测，不用离线资格代替语义评审。

## Finding F-15 — Initial Holdouts Did Not Exercise the Frozen Candidate Route

- **Label**: issue (blocking, must-fix), now resolved by preflight correction
- **id**: F-15
- **severity**: High；critic §2的边界/验证缺口，初版问题实际触发既有回退，无法检验所称候选收益。
- **location**: 原`holdout-v9.json`三题query；`core/segmented_generation.py:23`及`:32`；REQ-704。
- **symptom**: 木玩具/联赛缺显式流程提示；活动室虽为流程题，但“一致”触发比较回退。原始三题均不能作为候选路径覆盖证据。
- **impact**: true/false会比较未改完整生成，造成错误实验归因；不代表生产路由本轮引入故障。
- **root_cause**: 新题作者未在启动前完成全部冻结资格预检，只凭问题语义认定流程入口。
- **recommendation**: 正式运行前仅自然明确题干，并避开无意比较措辞；保留原版本与中断记录，禁止改候选算法、资料事实或判据。
- **verification**: r3三题实际完整路由与证据准备均通过，原corpus及query以外case字段不变；0模型调用、未读新输出。
- **status**: verified-by-test-holdout-routing-preflight

# Mechanism v7 Critic Review

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v7-pilot/{results,model-http}.jsonl`。独立只读，未读defender、未调用模型；冻结rubric不变。

## Decision

**严格2/4，当前候选不补至16、不接生产。** 档案两种来源顺序全部通过；字幕实际首节的独立资格已保留且无干扰，但两答全文仍缺三项用户要求的用途。

| Slot | Case/order | Full | Lead | Relevant | Citation | Strict | First body s | Tokens |
|---:|---|---|---|---|---|---|---:|---:|
| 1 | Archive/original | P | P | P | P | P | 6.242 | 556 |
| 2 | Archive/reversed | P | P | P | P | P | 6.367 | 577 |
| 3 | Caption/original | F | P | P | P | F | 6.531 | 579 |
| 4 | Caption/reversed | F | P | P | P | F | 6.539 | 596 |

四次真实HTTP均generation、一次调用、stop，结果complete。档案的交接许可、三分支、编号关联及各阶段记录用途、两个未知项完整。字幕准备、阻塞确认、完整回放、审核返回、版本对批准、音频变更/标题例外、记录字段与未知项均保留；失败范围是下述用途，不扩写成这些动作也丢失。

字幕两序都未选择“转录稿匹配避免过期稿”和“完整回放发现相邻提示间遗漏”的原文，以及“独立审核分离编写和发布决定”的目的句（原序条款9/10，反序5/6）。原文中只有相关动作，不足以替代冻结manual_required明确要求的作用说明。

角色资格回指修复使实际首节带入独立审核与同版本批准，两答首节按原标准通过；较长首节和重复不新设失败条件。整体只能说明该边界修复解决此首节样本，不能视为完整生成机制已合格。

## Finding F-13

- **Label**: issue (blocking, must-fix)
- **id**: F-13
- **severity**: High；真实所问用途遗漏，违反REQ-701/704完整性契约。
- **location**: 槽3/4；字幕冻结manual_required用途项。
- **symptom**: 两答都有动作和记录，却都缺上述三项用途。
- **impact**: 用户要求解释各检查/审核作用仍未满足，首节正确不能抵消。
- **root_cause**: 合并资格依赖能保留许可条件，但没有保证选择全部所问目的条款。
- **recommendation**: 保留失败，不以首节成功接受当前候选；继续已批准的最小隔离实验。
- **verification**: 同冻结判据恢复三用途，同时保持首节、相关性、引用与其余完整流程。
- **status**: open

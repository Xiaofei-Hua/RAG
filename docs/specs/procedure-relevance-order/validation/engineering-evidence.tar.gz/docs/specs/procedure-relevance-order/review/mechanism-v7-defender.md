# Mechanism v7 Pilot Independent Review — Defender

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v7-pilot/{results,model-http}.jsonl`; one-based rows.  
**Independence**: 完整审读四答及真实选择/响应，未读 critic、未调用模型、未改判据或创建留出。

## Decision

**v7 严格 2/4，不补跑至 16 答，不接生产。** 档案两序完整通过；字幕两序实际首节已有独立审核资格、同版本审批及范围，但全文均漏三项所问用途。首节、相关性、引用各 4/4，全文完整性 2/4。

| Row | Case / order | Complete | Lead | Relevant / cited | Strict | Body time (s) | Completion tokens |
|---:|---|:---:|:---:|:---:|:---:|---:|---:|
| 1 | 档案 / original | P | P | P / P | P | 6.2418 | 556 |
| 2 | 档案 / reversed | P | P | P / P | P | 6.3669 | 577 |
| 3 | 字幕 / original | F | P | P / P | F | 6.5314 | 579 |
| 4 | 字幕 / reversed | F | P | P / P | F | 6.5388 | 596 |

## Findings and Verified Gains

**V7-D01 — High, accepted/open: 字幕三项用途仍缺失。** 第 3/4 答全文没有脚本匹配用于避免过时脚本、全程播放用于发现相邻 cue 间遗漏、独立审核用于分离编写与发布决策。明确写出对应动作不等于解释所问目的。合并后原序缺条款 9/10，逆序缺 5/6；退稿历史用途已保留，不能代替其他三项。

相对 v3 flow_rule，字幕 original 原来全文用途齐全，本轮是新增的完整性维度退步；reversed 的这三项目的则延续旧失败。不能把两者一概写成“旧失败未变化”，也不能用首节已修复抵消新增遗漏。

字幕首节现在实际包含 reviewer who did not edit it 与该 reviewer 对同音频/字幕版本审批，范围也齐全；角色回指合并的局部收益成立。全文仍保留阻塞到匹配确认、全程播放及失败/返修、独立版本审批、音频变更重启和仅标题拼写例外、identifier/全部草稿链接、播放/review字段、退稿用途、live/时限未知。没有银框。首节及后段的原文重复不单独判失败。

档案两答均保留首节交接许可与范围、全部申请分支/修正核对、关闭及异常规则、编号和各类记录/用途、复核追加与两项未知，没有墙钟或年鉴。逆序的交接操作已在开头主规则中明确，不因后文交接段仅列记录而误判全文遗漏。

## Calls and Disposition

四答均真实单次最终生成、stop，完整渲染检查后 complete；合计 **2,308 completion tokens**、**4,092 prompt tokens**。没有截断或二次生成，不能把用途缺失解释为预算耗尽。表中时间是直接生成适配器的完整正文可用时间，不是 API 全链路性能。

保留角色回指修复的有限收益与两序用途失败，默认 false。下一隔离实验可以检验接口输出契约的可见性，但 v7 当前没有通过四答准入，也不能据此创建新留出。

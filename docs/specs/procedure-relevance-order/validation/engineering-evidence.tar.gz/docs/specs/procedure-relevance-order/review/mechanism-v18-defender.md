# Defender Note — v18 Mechanism Failure

**Date:** 2026-11-12  
**Evidence:** `data/eval/procedure-relevance-mechanism-v18/{results,model-http}.jsonl`。

**否决v18接线，默认仍false，F-16仍open。** 实际落盘为37条已完成结果和37条已完成wire；第38次在途由主任务终止，没有第38份完成答案，不能写成40答完成或通过。

独立核对陶艺两模式两轮，results第1/2/21/22行的原混合条款3仍为step，实际首节仍只有标题与范围，主要开放条件在第二节。优先级提示没有修复已复现目标。37个已完成请求各最终生成一次；本简报只裁决这四份直接失败，不虚构其余33份的整体语义通过数。

当前general生产prompt仍为v17的“混合条款选最主要类别”，没有采用v18优先级句。保留全部已完成请求/结果和终止事实；后续v19使用v17原prompt，不将v18的设计准入误写为实验证明。

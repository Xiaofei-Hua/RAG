# Defender Review — v12 Chinese Pilot

**Date:** 2026-11-11  
**Evidence:** `data/eval/procedure-relevance-mechanism-v12-pilot/{results,model-http}.jsonl`，逐行编号；沿用四个中文开发题冻结判据。独立审读 8 答，未读 critic、未调用模型、未改生产代码。

## Decision

**严格 7/8，候选仍不合格，停止扩大；默认继续 false。** 中文边界本身合理，但活动室反序丢失用户明确询问的两项未知，不能以其余七答或首节通过抵消，也不能进一步删去活动室业务题。

## Per-slot Assessment

C=全文动作/条件/分支/记录用途/所问未知；L=实际首节主要规则与范围；R=相关性；S=严格整题。八答引用均支持实际展示原文，均一次调用、stop/complete。首节较长和必要重复不单独失败。

| Row | Case / order | C | L | R | S |
|---:|---|:---:|:---:|:---:|:---:|
| 1 | L4 / original | P | P | P | P |
| 2 | L4 / reversed | P | P | P | P |
| 3 | Archive / original | P | P | P | P |
| 4 | Archive / reversed | P | P | P | P |
| 5 | Room / original | P | P | P | P |
| 6 | Room / reversed | F | P | P | F |
| 7 | Toy / original | P | P | P | P |
| 8 | Toy / reversed | P | P | P | P |

## Blocking Finding

**High, accepted/open — Explicitly requested unknowns omitted.** 第 6 槽的 unit 6“说明没有列出取消预约的费用”和 unit 15“办法未说明夜间活动如何申请”都生成 `answers=未询问, role=omit`，可见正文完全没有两项信息边界。问题末句明确询问夜间申请与取消费用，冻结 manual_required 同样要求保留，故属于全文语义遗漏。不能用“夜间不适用”的范围句替代“资料没有给出夜间申请方式”，费用也没有任何等义回答。

机制原因是短关联本身判断错误，程序忠实没有恢复 omit；不是来源引用错误或结构缺槽。该答的入场实际许可、办理分支、完整记录及用途都保留，故不夸大其他失败。其余七槽以及全部八槽的首节、装饰排除确有收益，但不足以证明中文整体资格成立。

## Calls and Cost

实际八次最终调用，没有额外验证或重试。HTTP 中的 system prompt 与 v10 linked 原文相同，none、temperature=0、top_p=.8、2048 保持；所有原始 JSON 与保存 selection 一致，实际均先 answers 后 role。按真实结果报告输出和完整首见，不把格式正确当作语义合格。

输入合计 **8,712 token**，输出 **3,843 token**；完整首见 P50/P95 为 **5.047/6.202 秒**（线性分位数）。这是本轮八槽观察值，不是稳定性能承诺。

**Next:** 按已批准 v12 停止条件保留失败，不扩大第二轮、接生产或继续缩业务范围；新的机制需另作设计。英文失败与未改完整生成边界继续如实保留。

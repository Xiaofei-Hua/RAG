# Mechanism v15 Critic Review

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v15/{results,model-http}.jsonl`，同七题两模式的 14 槽；对照 v14 及各 original_directory / original_index 的 v13 最终生成。独立审读，未读 defender、未调用模型或修改生产。

## Decision

**严格 12/14，不能进入生产接线，default false。** v14 的 13/14 降至 12/14：拼布 Thinking 未问费用仍在，Archive Thinking 新丢失所问记录关联和用途。其余 12 槽通过，昆虫两模式均正确省略队徽。生产接线评审的“14 全通过”前提未成立，本次不批准该条件方案实施。

全文 13/14、首节 14/14、相关性 13/14、所问未知 14/14、未问未知省略 13/14、引用 14/14。标题省略、段落位置及无害重复未扣分。

| Case | Fast slot / strict | Thinking slot / strict | Actual limitation |
|---|---|---|---|
| L4 | 1 / P | 5 / P | 无；正文与已审 v14 相同 |
| Archive | 2 / P | 6 / F | Thinking 丢失编号关联字段及用途 |
| Room | 3 / P | 7 / P | 无；正文与已审 v14 相同 |
| Toy | 4 / P | 8 / P | 只省略标题，业务事实/首节完整 |
| Greenhouse | 9 / P | 12 / P | 无；正文与已审 v14 相同 |
| Patchwork | 10 / P | 13 / F | Thinking 仍带入未问义卖报名费 |
| Insect | 11 / P | 14 / P | 所问未知与实际条款对齐，队徽/聚餐未知省略 |

## Blocking Evidence

**F-17 remains open — Critical, issue (blocking)**：用户所问与条款的语义对应仍不可靠。依据 critic §2(a)，目标相关性缺陷仍复现；本轮还出现完整性退步，不新增假设性门槛。

- **location / symptom**：results 第 13 行，实际键 `15:本记录没有提供义卖摊位的` 被标为 `answers=遗失纸样补领费用, role=limit`，正文确实加入未问的义卖摊位报名费用。与 v14 相同失败，通用关系句没有纠正它。
- **additional observed regression**：第 6 行实际键 `10:每个调阅编号关联申请档号` 被标为 `answers=未询问, role=omit`；全文丢失“每个调阅编号关联申请档号、阅览证号和计划日期，用于对应一次完整调阅”。用户明确问每阶段记录及用途，后文没有等义补回；同输入 v14 保留该条。
- **impact**：一槽无关信息未消除，另一原合格槽出现所问内容遗漏；不是仅辅助 answers 措辞不佳。
- **root_cause**：新增对象/动作/属性提示仍未保证实际关系匹配，并将支持所问流程的关联记录判为未问。
- **recommendation**：停止此候选接线，保留失败原始输入/选择/正文；生产仍 v13/default false，不按费项或档案字段打补丁。
- **verification / status**：同输入真实 14 答验证未通过；F-17 保持 open。后续若换方案，沿既定完整语义标准验证，不改本次评分。

## Calls and Comparable Cost

14 份新 wire 与 v14 仅系统提示的已批准关系说明不同，schema/语义键、用户检索全文、参数均一致。全部实际键齐全，14 次 HTTP 全为 generation、每答一次、全部 stop，无额外模型或重试。

以下仅比较最终 model-http 的 `end - start`，不使用旧 API first_body：

| Version | n | Generation P50/P95 s | Mean input / output tokens |
|---|---:|---:|---:|
| v13 stored controls | 14 | 5.428 / 7.361 | 1294.00 / 541.57 |
| v14 | 14 | 7.475 / 10.451 | 1317.00 / 714.36 |
| v15 | 14 | 8.012 / 10.929 | 1370.00 / 714.64 |

P95 线性插值，留存批与新批不是随机交替；成本如实列出。否决原因是实际质量失败，不是要求各项耗时全面更优。

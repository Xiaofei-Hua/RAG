# Design

## Diagnosis and Research
本轮仅解决中文流程的无关内容与首节错序。9B自由选择ID或同时概括/组织全文，会遗漏操作条件或把同实体装饰当作记录。固定逐条分类改善覆盖，但单一lead类别不能稳定识别自然许可；短问题关联又曾把“未规定”误当“未询问”。这些均有真实失败，不以结构合法代替质量。
从[Kyosuke Nishida](https://www.knishida.info/publications/)的[QFE](https://aclanthology.org/P19-1225/)及[Chain-of-Note](https://aclanthology.org/2024.emnlp-main.813/)借鉴问题驱动选择；从[Silei Xu](https://github.com/sileix)的[Chain-of-Draft](https://arxiv.org/html/2502.18600v2)借鉴短中间标注。训练/任务前提不同，论文不是本地9B效果保证。长标识、复杂排序、可见schema、自由首节等均经最小实验否决，完整设计/失败/原始请求保留在验证归档。

## Strategy and Hypotheses
v13在一次JSON中对每个实际条款先写短answers（用户问题点），再写role：main_rule/scope/step/record/limit/omit。固定槽位避免列表提前结束；问题关联帮助区分业务字段与载体样式。用户问了而资料未规定时仍属limit，不是未询问。H1是覆盖与相关性改善，H2是把呈现顺序交给程序以减少输出成本；短标注本身不证明语义正确。
程序仅把main_rule/scope映射为首节，把已选step中的通用明确规范表达前置；不恢复omit、不移动record/limit、不推导许可。各组按原序完整展示原文，每条一次，附真实来源。规范词沿用v9，未按失败题扩词：必须/须/不得/不能/禁止/仅/只有/才能/方可/不允许及原英文规范词。规则可能出现在较长首节，不以无害重复或首节长度独立判失败。
answers严格1..48字符，只用于同次生成，不展示、不做语义打分或程序改判。例如answers为未询问而role=limit，仍按role展示；有效性由实际正文验收。不会生成第二份自由摘要、在线judge或纠错调用。

## Architecture and State
core/procedure_generation.py拥有严格ProcedureClause/ProcedureAnswer、实际ID动态schema与渲染；general.yaml为唯一prompt来源。core/local_rag_generation.py复用原最终请求；参数none/temperature=0/top_p=.8/2048、context4096不变。
_eligible_evidence共同边界仅接受中文目标，prepare及select都遵守：英文不提前删证据，原context和完整schema保留。资格仍限本地loopback合格9B/general、明确流程、非比较、rewrite_count=0、同语种资料；混合/跨语/其它资格不足回原完整生成。已有实际reranker概率条件可去除极弱异语资料；缺失分数None不当0。
完整stop→原文组合→现有引用/PII检查一次→全文发布。Fast同步/异步/JSON/SSE与Thinking保持统一入口，首个正文事件为完整已检查答案。没有新的shared_state键、依赖、持久化、REST字段；generation_evidence与实际来源集合一致，原检索状态不由生成改写。

## Failure and Invariants
缺/多槽位、非法role或answers、无首节、非stop、引用/输出检查失败，沿用不可用与confidence=None，不追加生成；取消/排队契约不变。资料为不可信引用，仍忽略其中指令。没有新增安全边界。固定槽位与来源合法不保证相关性/首节正确，新鲜语义评测是默认资格依据。

## Budget and Experiments
分类/渲染O(n)，没有新LLM、embedding或reranker调用。核心指标为全文/首节/相关性/引用、完整首见P50/P95、调用与输出tokens。v13四中文开发题×两来源顺序×两轮16/16通过；重复不是16个独立题。普通比较及英文完整路径独立列为控制，不用中文收益掩盖未改路径失败。
临时机制批准后接线：新golden/资格/固定槽位/隐藏短标注/原文与首节/None/JSON-SSE回归，红23失败/42通过→绿65通过；生产对16份选择离线重放一致，零模型调用。真实API协议为11个已暴露题（4中文流程+3英文流程+4普通控制）、20份资料、两模式各两轮。
API开发通过后冻结候选，独立创作全新中文留出并先完成全资格离线预检，再运行两模式各三轮。留出含所问未知与未问未知，防止无差别保留。只给系统query/corpus，判据离线；实际请求确认路由，rewrite完整路径不冒充候选路径。若失败退为开发，不改本批后再称新留出。

## Rollout and Migration
当前默认false；只有适用中文开发/API/新留出无实质退步且不增加调用、耗时可接受，才改默认true并做真实默认冒烟。显式false并重启回原完整生成；fair调度不受影响。英文实验未合格，继续当前默认完整生成，不宣称英文首节问题已修复。
[breaking, conditional] 默认启用时，LOCAL_RAG_SEGMENTED仅覆盖上述合格中文流程；旧显式试用的英文流程也回原完整生成。模型、远程API、比较或改写不扩大资格。README/API/部署示例同步范围、结果、限制及回滚。最终单元+进程内E2E+perf/coverage和GitHub必需检查、独立评审闭环后合并main。

## v14 — Semantic Clause Keys
冻结v13新留出严格15/18，全文/首节/已问未知/未问未知排除/引用均18/18；三次昆虫Fast把独立的队徽条款保留。原始请求中处理时限是条款9、队徽为条款14，而模型把14的answers写为处理时限、role=limit。Thinking同题正确；Fast多带一份其它流程记录，暴露了编号与内容对齐失效。此批已暴露，降为开发，默认false，保留全部失败。
H：数字ID只约束槽位完整，不能给下一次分类提供当前条款的语义锚点。将固定schema的每个键改成‘编号:原文前12字符’，模型先输出被约束的短原文片段再生成原有answers/role。前缀取原文而非模型摘要；编号保证唯一，程序据完整实际键映射原条款，拒绝增删/改键，不按输出位置配对。分句/指代、原文、来源、类别、规范词、预算与全部路由不改，也不增加调用或按实体/队徽/时限硬编码。
研究依据为早期已调研GENRE/SEAL的可读标识，而非质量保证。早期v4是自由长标识列表并在英文重复；本次仅中文、12字符固定required map，不引入自由数组或自由排序。新增输出成本O(12n)字符；实际测P50/P95及tokens，不能仅以结构合法断言对齐正确。短前缀可能相同或只显示开头，仍依原全文分类；唯一编号与真实语义验收保留。
最小实验直接复用已存真实API最终请求，覆盖全部7个已暴露中文题的Fast/Thinking实际检索上下文（含触发错位的第三来源），每题每模式取首轮，14答，不重新运行检索或追加baseline模型。原v13请求/回答作同输入对照。仅把schema键替换为上述实际键，系统提示说明标识含编号与原文开头；其余内容与参数保持，渲染适配回原完整条款。先独立评审后临时实现，失败不扩大；成功才接线红绿、多轮API并重新冻结/创建真正新留出。

## v15 — Match the Requested Relation
v14最小实验修复昆虫Fast的编号错位，但裁片Thinking新增“义卖摊位报名费用”，把它标为用户所问的补领费用；严格13/14，不能进入生产。两个费用并非同一问题，现有短answers要求具体事项，却未明确对象与动作关系一致；这是已复现的语义相关性缺陷，不按实体删资料，也不修改评分。
v15仅在v14的limit规则后加一句通用约束：“判断相关性时，用户所问与条款描述必须对应同一对象、动作及其属性；不能仅因共享一个泛称就把另一事项当成回答。未知事项也要逐项对应，属于另一对象或动作的未知不能补充到当前问题中。”不举测试中的费项、队徽或实体例子，不改schema/键/类别/分组/预算。假设短可读键解决条款定位、关系一致约束解决同类属性混淆；这只是可验证假设，不承诺模型完美。
先独立评审，随后临时复用v14同14个请求，只替换这一句；原v13/v14原始回答作控制，全部7个中文题/两模式均测，避免只测新失败。失败仍不接线、不默认启用；通过才按原计划红绿、生产实际API多轮、冻结后真正新留出。性能以同输入最终generation时长及tokens比较，首见仍须API另测。

### Conditional Production Wiring
只有v15同14答独立语义评审通过才接线：新增私有_clause_key(unit)返回id:原文前12字符，schema与render均使用该实际键，集合检查拒绝改前缀/缺多键，映射不依赖输出顺序。general.yaml使用冻结relation-key-prompt.txt，其它v13逻辑不变。先更新真实Toy golden与坏key/固定槽位回归，另永久保存两个相关性失败的已修复真实选择/正文golden，红→绿后接线；保留None降级、单调用、原文和英文原路径测试。
真实API重跑全部7中文题两模式各两轮：api-development-v15-a保持v13的20份语料但仅选4个改动中文题，b保持已失败v13留出的原6语料/3题。query/corpus/rubric均不变；对照已存同环境完整生成baseline相应两轮，不重复未改英文/普通的模型调用。实际wire确认最终输入、调用数和route，不能把14答直接生成计时当API首见。通过后冻结，再由独立作者创作全新留出并预检。默认仍false，未改路径既有28/28相同请求与回归测试保留。

## v16 — Classify the Actual Clause
v15同输入14答只通过12：义卖费用仍误选，且档案Thinking新增整条记录关联字段/用途遗漏。仅加关系提示无效，停止累积指令。数字键、截断前缀及模型自写answers都使当前分类依赖不完整或模型编造的问题关联；full原文→有限角色是更直接的分类任务。
v16临时假设：固定schema键为“id:完整原文”，值直接为main_rule/scope/step/record/limit/omit枚举，不生成answers或第二份摘要。模型在每次类别判断前已被约束输出真实完整条款，而非短前缀/自写关联。仍固定required、唯一id、禁止额外键，按完整键映射原文，原分句/指代/规范前置/源引用保持。Prompt保留v14所有类别含义与原文完整性，但移除短answers及相关字段指令；明确键含完整原文，只输出类别，不加v15失败的新句。无实体规则/词表、无新模型调用，输出预算仍2048、context4096、temperature0。
代价是逐条回显全部证据字符，但省去每条answers对象与说明；复杂度O(全部条款字符)，可能更慢或触发length，不能以结构正确代替结果。先对同14个真实输入做临时试验，记录实际tokens/length/同口径generation时长；任何语义退步或截断均不接线。若候选成功，生产前再根据真实最长输入决定是否需要可解释的长度资格回退；此刻不引入预算新开关或扩大资格。研究借鉴仍是GENRE/SEAL的语义标识与问题驱动抽取，迁移效果只由实验决定。

### Conditional v16 Wiring
仅当14答独立语义评审通过后：ProcedureAnswer.clauses改为dict[str,ClauseRole]，移除ProcedureClause；私有_clause_key(unit)=id:完整原文，由schema的required/properties与render共同使用，值为同六类enum。完整键集合必须精确匹配实际条款，既有排序/规范前置/原文/引用与单调用降级不变。general.yaml用冻结full-key-prompt；不加长度开关，14答真实预算结果不足以推出所有长输入都适用，最终仍诚实报告覆盖范围。
先更新真实Toy golden、缺多键/同id错正文/非法role/无lead/非stop/检查失败回归；原文key不可按序号或返回位置模糊映射。两个最新已复现语义失效保留实际成功分类、原文与正文golden，永久离线回放；不把mock测试当模型语义保证。PII E2E中的源文和对应固定键同时注入相同电话，保留实际输出检查断言。API沿用上面的a/b两协议和既有完整生成baseline，两模式各两轮；冻结后独立创作全新留出，仍defaultfalse。

## v17 — Preserve Completion Conditions in the Lead
v16完整性/相关性/所问未知/未问未知排除/引用14/14，首节12/14；Toy两模式将完整真实交付条款标为step，程序只识别“才能”等形式，未识别“……完成才交出……”的完成条件结构。无需再改prompt/schema或追加模型推理。
v17只在既有_CONSTRAINT中增加通用完成条件“完成才”，仍仅前置已被选中的step；不会恢复omit、不改record/limit，不改写条件或推断许可。该结构不限题中实体或交付动作；它与已覆盖的“才能”同属操作先决条件。避免使用单个“才”误命中“人才/刚才”等词，也不扩充其它未复现表达。
先独立设计评审，随后临时离线对v16全部14份真实selection以新规则回放，零模型调用；两Toy真正交付条件须进入首节，其余正文条款集合/来源/完整性不变。永久回归覆盖不同操作的“核对与登记完成才启动”、omit同句不恢复，以及“刚才/人才”普通步骤不无故前置。通过后按Conditional v16 Wiring接线（本小规则包含在内），红绿、全部7中文真实API两轮及冻结后新留出。默认继续false，不把离线回放当新模型或新留出成绩。

# Mechanism v1 Critic Review

**Date**: 2026-11-11  
**Inputs**: frozen development-v1 in `docs/specs/procedure-relevance-order/validation/development.json`; raw `data/eval/procedure-relevance-mechanism-v1/{results,model-http,prompts}.jsonl/json`.  
**Independence**: 独立阅读完整正文、原始选择、来源及HTTP记录；未读取 defender，未调用模型。两轮同一题/顺序/变体的正文完全相同，合并审读24组，并保留48槽状态。

## Decision

**本轮没有最小合格候选；不能接生产或默认启用。** `anchored` 在全文覆盖和排除无关句上优于 `lead`，但中文档案4/4首节仍缺“共同清点签名完成交接才能阅览”。字幕4/4首节缺冻结判据要求的独立审核条件，原顺序旧选择有该条件，形成首节退步。标题或addresses写“关键规则”不能替代实际原文规则。

`lead` 除首节未修复外，还丢了档案编号/核对记录和英文用途；R7原来源顺序新增包装/库存干扰。不能因更快而选择它。`anchored` 可保留为下轮机制研究的证据，不是已合格上线方案。当前默认false保持，新留出不应消耗在已失败候选上。

## Rubric and Aggregate

P=通过，F=失败。完整指全文动作、条件、分支、记录字段/用途及所问未知项；首节按已冻结lead_rubric，独立于全文；相关指无明确无关事实；引用指原文与实际来源支持。整题四维全部通过。无害重复、原文仍带事件限定的跨节重复不判失败；不把“每节必须再重复全部通用条件”添加为新门禁。程序success/stop不是语义通过。

| Variant | Full | Lead | Relevant | Citation | Strict | First body P50 s | P95 s | Mean output tokens | Actual calls |
|---|---|---|---|---|---|---:|---:|---:|---:|
| baseline | 14/16 | 10/16 | 12/16 | 16/16 | 10/16 | 3.728 | 4.385 | 293.9 | 16 |
| lead | 8/16 | 8/16 | 14/16 | 16/16 | 6/16 | 2.942 | 3.152 | 242.5 | 16 |
| anchored | 16/16 | 8/16 | 16/16 | 16/16 | 8/16 | 3.726 | 4.266 | 332.0 | 16 |

48个已记录HTTP请求均为一次generation、finish_reason=stop，每个实验槽1次；不存在为了补足语义追加调用。P95使用样本排序线性插值。本轮是已暴露的4题×2来源顺序×2轮适配器实验，非当前默认false完整生成的API性能对照；不能据此声称线上完整首见收益。重复轮输出相同只说明本条件下可重复，不构成新的独立内容样本。

旧“所有条件均入首节”口径单独保留：R7/L4每变体均0/8；本轮按冻结的新首节判据R7/L4每变体8/8。不回改旧报告，也不把旧口径混入本次整题分母。

## Evidence Notes

| Code | Reproduced observation |
|---|---|
| A1 | Archive全部变体/顺序的首节都没有共同清点、双方签名完成交接后才能阅览；该许可仅在后续交接节。首节存在申请/查询/安排取卷不等于阅览许可。 |
| A2 | lead Archive两顺序均缺“每个调阅编号关联档号、阅览证号、计划日期及完整调阅用途”，并缺初核、候补转可取、修正重核的经办人/时间/结果及保留失败记录不覆盖。两项都不在其他正文中。 |
| A3 | baseline Archive首节仍含绿色墙钟和18本地方年鉴。新两变体移除了这两句，但不代表首节或全文同时通过。 |
| C1 | Caption除baseline原顺序外，首节均未交代审核者独立于编辑者。lead反顺序还把同一版本对批准才发布的许可整个后置；其余C1槽虽有版本许可，仍缺独立性。冻结lead_rubric明确要求“经独立审核批准”。 |
| C2 | lead Caption原顺序全文缺“独立审核将编写决定与发布决定分开”的所问用途。仅写交给未参与编辑的审核者是动作，不是该用途说明。 |
| C3 | lead Caption反顺序全文进一步缺转录稿匹配避免过期稿、完整回放发现相邻提示间遗漏、独立审核分离编写/发布决定三项用途。 |
| C4 | baseline Caption反顺序全文未保留job card中的转录稿标识及所有草稿链接（包括被拒稿）。其余回放、退回、音频变化、标题拼写例外与未知期限仍有。 |
| R1 | lead R7原顺序“Document Limitations”把“Packaging cartons are blue”和“Warehouse packaging inventory is 92 boxes”与所问服务费未知一同展示；这两句不回答流程问题。 |

`anchored` 全文16/16覆盖：包括档案三分支和关闭条件、事件记录用途、节假日/期限未知；包括字幕阻塞后确认、完整回放、退回循环、版本对批准、音频变化与纯标题拼写例外、记录字段及各项用途。其失败是首节许可条件后置，不能以全文完整抵消。

R7/L4的初检与更换事件起算、37有效小时/350正式标签及排除项、失败恢复、环境/价格未知均仍可从全文明确恢复；重复的更换条款保留事件限定，未写成普通复查一律重置。来源支持正确的无关句仍判相关性失败，引用维度不掩盖它。

## Blocking Findings

### F-03 — Explicit Lead and Addresses Do Not Close the Lead Failure

- **Label**: issue (blocking, must-fix)
- **id**: F-03
- **severity**: Critical；critic §2(a)，目标BUG在候选下真实复现。
- **location**: 本报告A1/C1；原始结果槽14/16/37/42及20/22/43/48；design v1 H1/H2、REQ-702/705。
- **symptom**: anchored档案4/4缺首节阅览许可；字幕4/4缺首节独立性。lead也没有闭合。
- **impact**: 用户必须继续读后节才能获得明确要求优先交代的准入/发布规则；更换JSON字段没有解决目标。
- **root_cause**: 结构强制了首节位置，但锚点/标题仍允许用主题、准备事项、未知信息代替实际许可谓词。
- **recommendation**: 不将v1接入默认；下一版设计围绕“首要问题对应的实际许可/禁止条件如何被选入首节”修订最小机制，不靠标题存在、ID合法或增加一次验证模型补救。
- **verification**: 下一候选沿用本轮完整判据，档案两顺序多轮实际首节必须含交接许可，字幕必须含独立审核与同版本批准；同时保留全文与相关性。
- **status**: open

### F-04 — Lead-only Introduces Required-content Omissions

- **Label**: issue (blocking, must-fix)
- **id**: F-04
- **severity**: High；真实边界/效果回归，违反REQ-701/704的完整动作与用途契约，不能接受为默认路径。
- **location**: 本报告A2/C2/C3/R1；结果槽13/18/19/24及对应第二轮。
- **symptom**: lead在档案和字幕共8槽丢必需内容，并在R7原顺序2槽引入包装库存。
- **impact**: 更短、更快的输出未满足所问记录与用途；相对旧选择产生实质退步。
- **root_cause**: 更短结构没有持续维持问题全部事项的选择覆盖；简单lead提示同时不能可靠排除同来源干扰。
- **recommendation**: 否决lead作为本轮较小候选；保留完整失败，不按中位数速度或局部相关性收益豁免。
- **verification**: 若后续保留此路线，A2/C2/C3必需项必须逐答恢复且R1消失，首节仍独立验收。
- **status**: open

## Slot Review

O=原来源顺序，R=反来源顺序；Slot与results.jsonl行号及HTTP index一致。所有槽引用P、实际调用1；表中仍保留各槽四维状态。两轮相同正文使用相同语义判定。

| Slot | Round | Case | Order | Variant | Full | Lead | Relevant | Citation | Strict | First body s | Output tokens | Notes |
|---:|---:|---|---|---|---|---|---|---|---|---:|---:|---|
| 01 | 1 | R7 | O | lead | P | P | F | P | F | 3.151 | 255 | R1 |
| 02 | 1 | R7 | O | anchored | P | P | P | P | P | 3.825 | 324 | — |
| 03 | 1 | R7 | O | baseline | P | P | P | P | P | 3.822 | 301 | — |
| 04 | 1 | R7 | R | anchored | P | P | P | P | P | 3.956 | 343 | — |
| 05 | 1 | R7 | R | baseline | P | P | P | P | P | 3.753 | 300 | — |
| 06 | 1 | R7 | R | lead | P | P | P | P | P | 2.875 | 240 | — |
| 07 | 1 | L4 | O | lead | P | P | P | P | P | 3.157 | 268 | — |
| 08 | 1 | L4 | O | anchored | P | P | P | P | P | 3.834 | 332 | — |
| 09 | 1 | L4 | O | baseline | P | P | P | P | P | 4.034 | 339 | — |
| 10 | 1 | L4 | R | anchored | P | P | P | P | P | 3.656 | 312 | — |
| 11 | 1 | L4 | R | baseline | P | P | P | P | P | 3.909 | 323 | — |
| 12 | 1 | L4 | R | lead | P | P | P | P | P | 3.012 | 251 | — |
| 13 | 1 | Archive | O | lead | F | F | P | P | F | 2.499 | 202 | A1,A2 |
| 14 | 1 | Archive | O | anchored | P | F | P | P | F | 4.353 | 382 | A1 |
| 15 | 1 | Archive | O | baseline | P | F | F | P | F | 3.251 | 236 | A1,A3 |
| 16 | 1 | Archive | R | anchored | P | F | P | P | F | 3.847 | 331 | A1 |
| 17 | 1 | Archive | R | baseline | P | F | F | P | F | 3.251 | 260 | A1,A3 |
| 18 | 1 | Archive | R | lead | F | F | P | P | F | 2.654 | 210 | A1,A2 |
| 19 | 1 | Caption | O | lead | F | F | P | P | F | 3.018 | 250 | C1,C2 |
| 20 | 1 | Caption | O | anchored | P | F | P | P | F | 3.659 | 316 | C1 |
| 21 | 1 | Caption | O | baseline | P | P | P | P | P | 4.504 | 348 | — |
| 22 | 1 | Caption | R | anchored | P | F | P | P | F | 3.603 | 316 | C1 |
| 23 | 1 | Caption | R | baseline | F | F | P | P | F | 3.332 | 244 | C1,C4 |
| 24 | 1 | Caption | R | lead | F | F | P | P | F | 3.074 | 264 | C1,C3 |
| 25 | 2 | R7 | O | anchored | P | P | P | P | P | 3.623 | 324 | — |
| 26 | 2 | R7 | O | baseline | P | P | P | P | P | 3.704 | 301 | — |
| 27 | 2 | R7 | O | lead | P | P | F | P | F | 2.955 | 255 | R1 |
| 28 | 2 | R7 | R | baseline | P | P | P | P | P | 3.615 | 300 | — |
| 29 | 2 | R7 | R | lead | P | P | P | P | P | 2.788 | 240 | — |
| 30 | 2 | R7 | R | anchored | P | P | P | P | P | 3.827 | 343 | — |
| 31 | 2 | L4 | O | anchored | P | P | P | P | P | 3.707 | 332 | — |
| 32 | 2 | L4 | O | baseline | P | P | P | P | P | 3.917 | 339 | — |
| 33 | 2 | L4 | O | lead | P | P | P | P | P | 3.065 | 268 | — |
| 34 | 2 | L4 | R | baseline | P | P | P | P | P | 3.797 | 323 | — |
| 35 | 2 | L4 | R | lead | P | P | P | P | P | 2.889 | 251 | — |
| 36 | 2 | L4 | R | anchored | P | P | P | P | P | 3.548 | 312 | — |
| 37 | 2 | Archive | O | anchored | P | F | P | P | F | 4.238 | 382 | A1 |
| 38 | 2 | Archive | O | baseline | P | F | F | P | F | 3.151 | 236 | A1,A3 |
| 39 | 2 | Archive | O | lead | F | F | P | P | F | 2.446 | 202 | A1,A2 |
| 40 | 2 | Archive | R | baseline | P | F | F | P | F | 3.184 | 260 | A1,A3 |
| 41 | 2 | Archive | R | lead | F | F | P | P | F | 2.510 | 210 | A1,A2 |
| 42 | 2 | Archive | R | anchored | P | F | P | P | F | 3.746 | 331 | A1 |
| 43 | 2 | Caption | O | anchored | P | F | P | P | F | 3.600 | 316 | C1 |
| 44 | 2 | Caption | O | baseline | P | P | P | P | P | 4.346 | 348 | — |
| 45 | 2 | Caption | O | lead | F | F | P | P | F | 2.929 | 250 | C1,C2 |
| 46 | 2 | Caption | R | baseline | F | F | P | P | F | 3.327 | 244 | C1,C4 |
| 47 | 2 | Caption | R | lead | F | F | P | P | F | 3.031 | 264 | C1,C3 |
| 48 | 2 | Caption | R | anchored | P | F | P | P | F | 3.566 | 316 | C1 |

# Defender Review — v17 Fresh Holdout

**Date:** 2026-11-12  
**Evidence:** `data/eval/procedure-relevance-holdout-v17-{baseline,candidate}/{results,model-http}.jsonl`；`validation/holdout-v17.json`；`validation/freeze-v17.md`；`validation/runtime-resume-v17.json`。  
**Independence:** 本评审者没有参与本批题目创作、没有调用模型或修改协议/生产代码；本节独立结论形成并归档前未读新 critic 结论。

## Decision

**候选严格通过12/18，不具备默认启用资格。陶艺题两模式各三轮的六答均把台面开放依据留在第二节，而同槽基线六答首节均已给出该依据。这是 REQ-702 目标缺陷仍可复现，且在被改路径出现实质顺序退步。保持默认 false；本批留出暴露后转开发，不能修改候选后将其重称为全新留出。**

候选全文动作/分支/记录用途、相关性、所问未知、未问未知排除及引用均18/18通过；首节仅12/18。完整生成基线严格2/18通过（离线包 R1/R3 Thinking）；严格总数提高不能抵消陶艺六槽的首节退步。没有因长首节、正常标题、无害重复或等义表达扣分，也没有增设题外或全系统完美门槛。

## Per-slot Semantic Review

行号分别指两侧 `results.jsonl` 相同槽。P/F是实际正文语义裁决，不是结构解析分数。候选每题首轮完整审读，后续逐槽读取实际正文与选择；同题六份最终正文完全相同，逐槽选择和来源核对仍单独完成。

| Row | Round / Mode | Case | Baseline strict | Baseline lead | Candidate strict | Candidate lead |
|---|---|---|---|---|---|---|
| 1 | R1 Fast | 陶艺 | F | P | F | F |
| 2 | R1 Fast | 离线包 | F | P | P | P |
| 3 | R1 Fast | 月表 | F | P | P | P |
| 4 | R1 Thinking | 陶艺 | F | P | F | F |
| 5 | R1 Thinking | 离线包 | P | P | P | P |
| 6 | R1 Thinking | 月表 | F | P | P | P |
| 7 | R2 Fast | 陶艺 | F | P | F | F |
| 8 | R2 Fast | 离线包 | F | P | P | P |
| 9 | R2 Fast | 月表 | F | P | P | P |
| 10 | R2 Thinking | 陶艺 | F | P | F | F |
| 11 | R2 Thinking | 离线包 | F | P | P | P |
| 12 | R2 Thinking | 月表 | F | P | P | P |
| 13 | R3 Fast | 陶艺 | F | P | F | F |
| 14 | R3 Fast | 离线包 | F | P | P | P |
| 15 | R3 Fast | 月表 | F | F | P | P |
| 16 | R3 Thinking | 陶艺 | F | P | F | F |
| 17 | R3 Thinking | 离线包 | P | P | P | P |
| 18 | R3 Thinking | 月表 | F | P | P | P |

候选其余五项（全文、相关性、已问未知、未问未知排除、引用）每槽全部 P。

### Baseline Reasons

- 陶艺 row1/4/10/16漏送展起始登记/拍照/按图摆放的完整操作；row4还漏入馆记录与待处理/不覆盖要求，row16漏开放单关联用途。row7没有按图摆放，且混入雨量月表修订记录；row10加入浅灰地毯和课程报名费未知；row13推断资料未规定的作者简介改字记录，并漏开放单关联用途。六槽实际首节仍均包含主要开放许可，不能因全文失败就抹去这项基线能力。
- 离线包 row2/8/11/14没有完整交代收集文件和起始登记/建清单操作；row5/17的全文则涵盖这些操作、全部分支、记录字段/用途、未知和引用，予以通过。它们虽没有再重复“压缩完成不等于许可”这句否定，但已明确本版独立签名与全部页面可达等必要条件，按冻结的等义语义标准不额外判失败。
- 月表六槽均有准备、逐日记录或所问例外遗漏。row3/6/9/12缺有原始页的“未观测”仍可复核说明，row15也缺该说明及完整逐日记录，且首节没有固定雨量筒/人工日读数的适用范围。row18保留了未观测可复核说明，但缺起始整理与逐日记录，补页/修订/姓名记录段误引流程文档而非记录要求。

## Actual Selection and Target Failure

### DH17-01 — Main permission remains below the lead

- **id:** DH17-01
- **severity:** Critical，依 `docs/specs/prompts/critic.md:28` 的“目标 BUG 在方案下仍可复现”；本次另有同槽基线首节通过→候选失败的直接退步证据。
- **location:** `core/procedure_generation.py:155`、`:190`；candidate `results.jsonl:1`、`:4`、`:7`、`:10`、`:13`、`:16`；candidate `model-http.jsonl:1`、`:7`、`:16`、`:22`、`:31`、`:37`；`requirements.md:8`。
- **symptom:** 六份陶艺回答首节只有流程标题、馆内桌面已烧成作品范围和记录标题；“该台全部作品有当前摆位检查记录，且策展员确认底座稳固、通道可通行”在明确的第二节“操作步骤”中。首节没有任何等义的主要开放条件，不是标题/长度争议。
- **impact:** 用户指定先看范围与开放依据的顺序没有兑现；全文完整、来源正确和更快均不能抵消。
- **root_cause:** 实际完整key第3条把初始登记、开放依据、松动处置和重新检查合为一个unit。`_REFERENCE` 对句内“该”匹配使这些句子被并到前句；模型六次都将该混合unit标为 step，两个资料标题反而标为 main_rule。当前规范词前置不匹配该unit，因而保留在第二节。完整key保证对应无错位，但不能保证混合unit的语义角色正确。
- **recommendation:** 当前保持默认 false 并保留失败；针对 `core/procedure_generation.py:155` 的混合unit和 `:190` 的首节安排修订设计，确保已选主要许可进入首节、原文上下文与单调用不变。应先以真实选择固定回归再检验新方案，不以临时实体词表或事后改rubric宣告修复。
- **verification:** 本批陶艺六个原始选择/正文和两模式基线已直接复现；后续修复必须有永久单元/进程内E2E红绿证据、旧开发全题不退步及冻结后的另一个独立新留出。本报告没有新调用或替代本批数据。
- **status:** accepted，未修复、仍open。独立编号DH17-01经交叉核验与critic既有F-16为同一发现，总tracking沿用F-16，不新增重复编号。

### Preserved Capabilities

陶艺六答完整保留登记/拍照/按图摆放、全台许可、松动暂停、底座/摆位复检与新签认、简介改字例外、撤展核对/双方签名/磕痕待核实，以及记录关联和用途。保险与寄回费用未知保留，地毯、课程费用未知和Fast额外召回的月表资料全部 omit；因此该发现只指首节顺序，不伪称相关性或事实覆盖也失败。

离线包六答将当前修订号、非制包人签名、全部页面可达和清单相符的下载依据放在首节；全包重试、内容改版、文字例外、漏页撤下/新包/旧条目，以及全部记录用途均保留。设备空间与旧链接天数未知保留，交换会/讲座日期和额外月表资料 omit。

月表六答首节保留每日原始页号、另一复核员逐日签记和无待查行。零与未观测区别、未观测仍可复核、缺原页待查/禁邻日填补、修订留旧/重签与姓名例外，连同记录字段和用途均在正文。补报截止与纸页年限未知保留，书柜/摄影展截止和额外离线包资料 omit。

## Actual Wire and Publication

两侧均为18个测量请求，分别45次HTTP＝18最终 generation＋27原控制调用。Fast每答总1次，Thinking每答总4次，所有槽最终生成均一次。全部 generation 为 stop，HTTP200，generation_complete=true；各36份正文的token拼接、done与隔离session持久化内容一致。

候选18份实际schema均是完整原文key→六类enum，实际key集完整，没有 answers 字段，也没有回退到完整生成冒充候选。实际system prompt全部为冻结 `full-key-prompt.txt`。两侧同槽query及来源顺序一致，实际来源全文与冻结corpus一致；Fast额外召回第三份其他流程资料，候选均正确排除。正常入口只提交query/corpus，所读最终请求中没有本题lead/strict/manual rubric。

候选none/temperature0/top_p0.8/2048，基线none/temperature0.7/top_p0.8/2048；没有为减少时间改预算或增加判断调用。运行恢复记录为同一0.24.0-format-backport、Qwen3.5:9b Q4_K_M、4096上下文与全GPU加载。启动前空prompt的load响应无题目答案，不计测量generation。

## Timing and Cost

| Mode | Baseline first-body P50/P95 (s) | Candidate first-body P50/P95 (s) | Baseline generation HTTP P50/P95 (s) | Candidate generation HTTP P50/P95 (s) |
|---|---:|---:|---:|---:|
| Fast (9/side) | 12.286 / 13.408 | 9.448 / 9.633 | 12.162 / 13.293 | 9.258 / 9.457 |
| Thinking (9/side) | 14.676 / 17.310 | 9.790 / 9.907 | 11.546 / 13.862 | 6.542 / 6.709 |
| All (18/side) | 13.312 / 16.943 | 9.492 / 9.906 | 11.840 / 13.563 | 7.745 / 9.434 |

首正文是完整已检查回答，不是状态事件；HTTP耗时独立按最终generation end-start计算。最终生成输入总tokens17613→21591，输出19258→12327（均值1069.89→684.83），显示完整key回显/分类方案的输入成本和输出节省。没有截断。

## Boundary and Next Gate

三题是冻结后独立创作的三个新问题；每题两模式三轮不是18个独立新题。顺序运行baseline后candidate，非随机交替，延迟结论限于同机本批观测。程序/测试通过不替代此次真实首节失败；本报告不要求无关英文/普通路径完美，也不追加安全/完整性假想门禁。

当前不得改默认true或把本任务标为达成。应据实际混合unit问题继续最小设计/实验，保留原失败与已通过能力，后续另行冻结和独立新留出；默认真实冒烟及既定最终检查只能在质量门禁通过后推进。

## Critic Adjudication — After Independent Review

独立报告已落盘后才读取`holdout-v17-critic.md`。其唯一Critical F-16与本报告独立DH17-01一致；沿用既有F-16追踪，不能因重命名或总分改善关闭。

| Finding | Severity | Decision | Evidence / Design revision |
|---|---|---|---|
| F-16 | Critical | accepted，仍open | candidate `results.jsonl:1,4,7,10,13,16`和`model-http.jsonl:1,7,16,22,31,37`；`design.md:30`新增v18实验方向，尚未构成修复证据 |

### F-16 Five-step Decision

1. **事实核验：真。** 自己独立审读的六份陶艺正文首节仅标题/范围，核心许可在第二节；对应wire的条款3均step，见上述实际行。资料标题标为main_rule不能替代真实许可。critic并未把长首节或无害重复误当失败。
2. **可触发：已经发生。** 正常Fast/Thinking两模式各三轮、完整stop和输出检查后实际发布，均非手工构造的不可达状态；同槽baseline首节六份全通过。没有事实错误或不可达反证可据以拒绝。
3. **成本与影响：必须接受。** 这是明确目标维度的实质退步。针对混合unit分类优先级的单句实验成本低，但其效果未知；不能以模型成本节省换取接受该退步。
4. **范围：直接在内。** REQ-702明确要求首节实际呈现主要规则/范围，REQ-704/705规定实质退步阻止默认；不是应转单的历史问题或题外要求。
5. **替代：没有已落地的等价修复。** 保持false只是正确的发布门禁，不等于修好了该首节。v18明确混合unit优先级是合理待验证路线，已另作设计准入评审；实验、永久回归和新留出尚未完成，故不能标defended-with-alternative或closed。

critic的18槽裁决、基线2/18、候选12/18以及实际调用/耗时与本独立核验一致。没有其他Critical/High需要额外裁决，也没有范围外问题需转单。

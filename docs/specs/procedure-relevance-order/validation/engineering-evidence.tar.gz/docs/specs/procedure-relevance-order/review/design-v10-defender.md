# Defender Review — v10 Semantic Roles and Short Question Links

**Date:** 2026-11-11  
**Scope:** `design.md` v10、`validation/roles-prompt.txt`、`validation/linked-prompt.txt`；独立审查，未读 critic，未改生产代码、未调用模型。

## Decision

**可以开始已暴露木玩具/联赛两题 × 两来源顺序 × 三变体共 12 答的临时实验；无 Critical/High 设计阻断。** 此许可不等于生产接线、默认启用或效果合格。v9 新留出失败及逐槽证据已另存 `holdout-v9-defender.md`，默认继续 false。

## Rationale

显式区分 `main_rule` 与 `scope`，直接针对 v9 把范围或准备当首要许可的真实失败；将 `record` 解释为实际业务字段和所问用途，直接针对表单装饰进入正文的真实相关性退步。说明保留用户询问样式时的相关性，没有引入实体、颜色黑名单或扩充规范词表。

两份精确 prompt 的语义定义相同；`roles` 只输出类别，`linked` 只增加每槽先短 `answers` 再 `role`，可以观察问题关联的边际效果和成本。若效果相同，优先较小的 `roles`。每个实际条款仍固定占槽，原文及来源完整保留；短关联不展示，也不作为事实正确或语义通过的证据。

从 [Silei Xu 主页](https://github.com/sileix)追踪的 [Chain-of-Draft 论文](https://arxiv.org/html/2502.18600v2)及[官方实现](https://github.com/sileix/chain-of-draft)支持尝试简短中间表达的研究方向；其算术、常识及符号任务结果不能证明本地 9B 条款分类有效。本轮对照是必要的迁移验证。

## Existing Conditions

- 保持一次最终调用、none/0/.8/2048、4096 context；不加重试、后置语义判断或新模型调用。
- 依原冻结判据独立评首节、全文完整性、相关性、引用；schema 合法或 `answers` 合理不能替代用户正文通过。
- 保存真实输出、结束原因、token 和耗时；观察实际 `answers`→`role` 顺序，避免仅凭 schema 声称条件生成生效。48 字符上限本身不证明满足提示中的短字数预算，按实际成本报告，不新增验收门禁。
- 12 答只是开发 pilot；合格后仍需全部 7 个已暴露开发题两来源顺序两轮、接线前独立评审及红绿，再冻结并另建真正新留出。

## Limits

类别更清楚仍可能被条款首句或混合语义支配；短关联也可能增加输出而不改善选择。v1 的段落关联、v6 的复杂分类均未证明有效，因此本次只准最小对照，不预先认定新字段有效。没有新增范围外问题或防御性门禁。

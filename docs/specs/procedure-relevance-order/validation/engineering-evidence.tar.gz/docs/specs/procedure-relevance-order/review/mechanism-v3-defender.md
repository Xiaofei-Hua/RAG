# Mechanism v3 Independent Review — Defender

**Date**: 2026-11-11  
**Inputs**: frozen `validation/development.json`; `data/eval/procedure-relevance-mechanism-v3/{protocol,prompts}.json` and `{results,model-http}.jsonl`; corresponding v1 anchored and v2 rule_lead controls. References use one-based JSONL rows.  
**Independence**: 未读 critic；完整审读首轮 16 个不同正文及 selection，第二轮逐槽正文完全重复后继承同一语义裁定。核对全部 32 次实际模型 JSON 顺序、请求参数、来源、单调用与成本。未调用模型、修改判据/业务代码或创建新留出。

## Decision

**v3 没有最小合格候选。** `flow_rule` 严格通过 12/16，恢复了 R7 周期复查与档案记录，仍有字幕首节独立审核条件缺失、字幕 reversed 三项目的遗漏。`flow_anchored` 严格通过 10/16，首节全部达到冻结要求，却新增 R7 两种顺序的无关包装/库存，并在档案 reversed 漏编号关联字段及用途。

实际 32 次模型 JSON 都是 answer→lead，用户正文也确实是 lead→answer，实验已落实生成和展示顺序的分离。该改变带来部分收益，尚未同时解决完整性、首节与相关性；不批准生产接线、默认启用或新留出。

## Frozen Quality Totals

Complete=全文动作/条件/分支/记录/用途/所问未知齐全；Lead=第一实际正文节符合冻结 rubric；Relevant=没有无关事实；Cited=实际主张有来源；Strict=四项同时通过。字段、标题、quote 不单独计语义通过。没有增加首节长度或“必须第一句就是许可”等门槛。

| Variant | Complete | Lead | Relevant | Cited | Strict |
|---|---:|---:|---:|---:|---:|
| v1 anchored | 16/16 | 8/16 | 16/16 | 16/16 | 8/16 |
| v3 flow_anchored | 14/16 | 16/16 | 12/16 | 16/16 | **10/16** |
| v2 rule_lead | 10/16 | 12/16 | 16/16 | 16/16 | 8/16 |
| v3 flow_rule | 14/16 | 12/16 | 16/16 | 16/16 | **12/16** |

flow_anchored 对 v1 anchored 的严格配对：4 条 Pass→Pass、4 条 Pass→Fail（R7 两顺序）、6 条 Fail→Pass（档案 original、字幕两顺序）、2 条 Fail→Fail（档案 reversed）。档案 reversed 的全文遗漏是隐藏在 Fail→Fail 中的新增维度退步。

flow_rule 对 v2 rule_lead：8 条 Pass→Pass、0 条 Pass→Fail、4 条 Fail→Pass（R7 reversed、档案 original）、4 条 Fail→Fail（字幕两顺序）。这支持其局部改进，不把尚失败的字幕题排除后称全部合格。

旧“首节含全部操作条件及所问未知”的诊断口径另报：flow_anchored 10/16（L4 reversed、档案和字幕两顺序），flow_rule 0/16。此处只查条件/未知，不能替代记录用途完整性；不作为本轮新增准入标准，也不改写旧失败。

## Findings

### M3-D01 — Flow-anchored introduces irrelevant R7 content

- **Severity**: Medium; **Status**: accepted, open; 按冻结 strict 仍为实质失败。
- **Location**: `results.jsonl:2,3,17,20`。
- **Symptom / impact**: 全文的 Additional Information / Document Limitations 带入蓝色包装盒及 92 箱库存，不回答室外规则或服务价格。四个对应的 v1 anchored 槽原先都没有这些事实，是真实配对退步。
- **Root cause**: 实际地址甚至写入 packaging，随后选择装饰条款；不是原文拼装或引用出错。先生成 answer 没有自动保持题目相关性。
- **Recommendation / verification**: 不因首节合格或核心步骤完整而略去偏题；原顺序实际选 12/13/14，逆序选 6/7/8，全部对应价格未知加两个无关事实。flow_rule 同槽不含它们，但另一变体的正确不能补救当前候选。

### M3-D02 — Flow-anchored loses archive linkage records

- **Severity**: High; **Status**: accepted, open。
- **Location**: `results.jsonl:11,28`。
- **Symptom**: 全文缺调阅编号关联申请档号、阅览证号、计划日期及“对应一次完整调阅”的用途；可见首节很长仍没这些内容。
- **Impact**: 用户明确要求各阶段记录及用途；其他核对、交接、归还记录齐全不能替代编号关联字段。v1 anchored 同槽全文原本齐全。
- **Root cause**: answer 与最终 lead 都没有选择关联条款 2，重排字段没有恢复这条选择。
- **Recommendation / verification**: 保留该完整性退步；已检查首节及所有后段，没有补回。不能根据长首节或其他记录齐全判整题通过。

### M3-D03 — Flow-rule retains caption lead and purpose failures

- **Severity**: High; **Status**: accepted, open。
- **Location**: 首节缺陷 `results.jsonl:13,16,30,31`；额外全文遗漏 `:16,31`。
- **Symptom**: 两种顺序首节都有范围与同版本审批，但没有独立审核条件；reversed 全文另缺脚本匹配避免旧稿、全程播放检查相邻 cue 遗漏、独立审核分离编写与发布决策三项目的。
- **Impact**: 后续出现 reviewer who did not edit it 不能代替冻结的首节要求；已有操作动作不能代替用户询问的用途。original 的全文完整仍因首节失败不通过。
- **Root cause**: 最后生成的 quote/IDs 仍复用最初 Scope and Release Rule 的不完整许可集合。reversed 后续用途选择只有退稿历史用途，未选剩余三项目的。
- **Recommendation / verification**: 首节必须按实际语义继续判失败。original rule IDs `[1,3]`，reversed `[10,12]`，都没有独立审核角色/目的；reversed 全文未选用途条款 5、6。不因 JSON 已按新顺序生成而关闭失败。

## Whole-Answer Review and Accepted Boundaries

flow_rule 的 R7 两顺序都保留初检通过才运行、正确初始起算、每 37 活动扫描小时复查/排除待机、换头检查通过后的独立新周期、失败暂停到排因重检通过、准备/结果/失败记录及各项目的、室外和价格未知。可见首节有范围与失败停机规则，按既定 R7 rubric 合格；不因隐藏 quote 没摘停机句而否定实际已显示的正确条款。

L4 两个变体两顺序均保留温度/无结露范围、初次样张许可/起算、350 正式标签和不计项、换托盘重检与起算、失败恢复、全部准备/记录/用途及未知。flow_anchored reversed 首节非常长，规则在同一首节稍后出现，仍满足冻结首节判据；重复或长段不单独判失败。

flow_rule 档案两顺序均完整：主规则与范围在首节，后续申请三分支、修正重核、交接放行、归还一致关闭/异常保持未结、全部编号/核对/交接/归还/异常字段、三项用途、两项未知齐全。reversed 的交接操作已经在开头的主规则段明确；后文交接记录段没有重写操作，不据此误判全文缺交接。flow_anchored original 全文同样完整，reversed 缺项见 M3-D02。

flow_anchored 字幕两顺序的可见首节含独立 reviewer、同版本审批、范围以及所问流程条件，按冻结标准通过。全文也包含阻塞到匹配确认、全程播放/返修、新版本审核、音频变更后重启与标题拼写例外、identifier/全部草稿链接、播放/review字段、全部四项用途及两项未知。首节虽然几乎复述全文且有重复，未形成错误许可或无关事实，因此不凭简洁偏好扣分。

flow_rule 字幕 original 全文同样齐全；reversed 保留了 v2 曾缺的 identifier/全部草稿链接，但三项目的仍缺。两变体字幕均无银色公告板，档案均无墙钟/年鉴；全部实际选句和事实引用都能对应真实来源。

## Per-Slot Status

P/F 为人工语义裁定；C=Complete，L=Lead，R=Relevant，S=Strict。所有 32 槽 Cited=Pass。第二轮逐槽正文与对应首轮完全相同，仍单独列出。

| Row | Round | Case / order | Variant | C | L | R | S |
|---:|---:|---|---|:---:|:---:|:---:|:---:|
| 1 | 1 | R7 / original | flow_rule | P | P | P | P |
| 2 | 1 | R7 / original | flow_anchored | P | P | F | F |
| 3 | 1 | R7 / reversed | flow_anchored | P | P | F | F |
| 4 | 1 | R7 / reversed | flow_rule | P | P | P | P |
| 5 | 1 | L4 / original | flow_rule | P | P | P | P |
| 6 | 1 | L4 / original | flow_anchored | P | P | P | P |
| 7 | 1 | L4 / reversed | flow_anchored | P | P | P | P |
| 8 | 1 | L4 / reversed | flow_rule | P | P | P | P |
| 9 | 1 | 档案 / original | flow_rule | P | P | P | P |
| 10 | 1 | 档案 / original | flow_anchored | P | P | P | P |
| 11 | 1 | 档案 / reversed | flow_anchored | F | P | P | F |
| 12 | 1 | 档案 / reversed | flow_rule | P | P | P | P |
| 13 | 1 | 字幕 / original | flow_rule | P | F | P | F |
| 14 | 1 | 字幕 / original | flow_anchored | P | P | P | P |
| 15 | 1 | 字幕 / reversed | flow_anchored | P | P | P | P |
| 16 | 1 | 字幕 / reversed | flow_rule | F | F | P | F |
| 17 | 2 | R7 / original | flow_anchored | P | P | F | F |
| 18 | 2 | R7 / original | flow_rule | P | P | P | P |
| 19 | 2 | R7 / reversed | flow_rule | P | P | P | P |
| 20 | 2 | R7 / reversed | flow_anchored | P | P | F | F |
| 21 | 2 | L4 / original | flow_anchored | P | P | P | P |
| 22 | 2 | L4 / original | flow_rule | P | P | P | P |
| 23 | 2 | L4 / reversed | flow_rule | P | P | P | P |
| 24 | 2 | L4 / reversed | flow_anchored | P | P | P | P |
| 25 | 2 | 档案 / original | flow_anchored | P | P | P | P |
| 26 | 2 | 档案 / original | flow_rule | P | P | P | P |
| 27 | 2 | 档案 / reversed | flow_rule | P | P | P | P |
| 28 | 2 | 档案 / reversed | flow_anchored | F | P | P | F |
| 29 | 2 | 字幕 / original | flow_anchored | P | P | P | P |
| 30 | 2 | 字幕 / original | flow_rule | P | F | P | F |
| 31 | 2 | 字幕 / reversed | flow_rule | F | F | P | F |
| 32 | 2 | 字幕 / reversed | flow_anchored | P | P | P | P |

## Actual Order, Calls and Cost

全部 32 个实际模型响应的顶层 JSON 顺序均为 `answer, lead`，展示首节来自最后生成的 lead，之后才是 answer。两个变体实际提示各只比相应旧提示新增设计规定的生成顺序说明，所有对应槽的 human message 与旧对照一致，问题/资料/来源顺序/条款映射未变化。

每答一次真实最终生成，共 32 次，无额外控制、核验、重试或二次生成。实际参数均为 qwen3.5:9b、temperature 0、top_p .8、none、2048；全部 stop，完整原文渲染检查后 complete。协议正确不替代语义通过。

| Variant | Complete body P50 / P95 (s) | Total P50 / P95 (s) | Completion tokens total / mean | Mean prompt tokens | Calls |
|---|---:|---:|---:|---:|---:|
| v1 anchored | 3.7264 / 4.2664 | 3.7264 / 4.2664 | 5,312 / 332.000 | 900.75 | 16 |
| v3 flow_anchored | 4.8545 / 5.1767 | 4.8545 / 5.1767 | 6,676 / 417.250 | 950.75 | 16 |
| v2 rule_lead | 4.6775 / 6.2402 | 4.6775 / 6.2402 | 7,254 / 453.375 | 908.75 | 16 |
| v3 flow_rule | 5.1362 / 6.3339 | 5.1362 / 6.3339 | 7,748 / 484.250 | 958.75 | 16 |

字段数量没有增加，但实际输出并未等长：flow_anchored 比 v1 anchored 多 85.25 completion tokens/答；flow_rule 比 v2 rule_lead 多 30.875 tokens/答。完整首见中位数也分别上升约 1.1281 秒、0.4586 秒。旧对照来自不同批次，不能将时间差解释为严格时序交替的因果估计；此处也不含正常 API 检索/Thinking 控制，不是相对当前 false 完整生成的性能结论。

每变体只有八种已暴露输入配置及两个重复轮次、八个不同正文。局部变好和重复稳定都不等于独立新题可靠性。

## Disposition

生成/展示顺序分离的执行契约成立，flow_rule 的 R7 与档案全文收益成立；但两个候选都有冻结标准下的剩余实质失败，不能选择其中任何一个为“最小合格版本”。保持当前生产实现和默认 false，保存本轮原始输出与逐槽结果，等待有不同依据的后续机制再验证，不通过改判据或按已知题目挑变体取得表面通过。

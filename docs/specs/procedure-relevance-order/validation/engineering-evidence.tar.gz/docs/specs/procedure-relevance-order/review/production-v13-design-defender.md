# Defender Review — v13 Production Wiring Design

**Date:** 2026-11-11  
**Scope:** `design.md` 的 Production Wiring for v13、当前 `core/procedure_generation.py` / `core/local_rag_generation.py` 入口、v13 八答实测；独立评审，未读 critic、未调用模型或改生产代码。

## Decision

**无 Critical/High 设计阻断，可进入保持默认 false 的红绿接线实施。** v13 开发 pilot 独立严格 8/8，见 `mechanism-v13-defender.md`。这是实现与继续验证许可，默认 true 及合并验收尚未获准。

## Mechanism and Boundary

`ProcedureClause` 只增加已测的短 answers 与六类 role，动态实际 ID schema 保持逐条必填；原文 renderer 只读取 role，将 main_rule/scope 映射 lead，并保持现有 step 规范词前置。answers 不展示、不作事实证明、不驱动二次判定，符合实际 pilot：L4 反序存在 answers 写“未询问”但 limit 正确保留未知的情况。没有引入自由自然语言首节或生成 source_ids 数组。

中文资格应放在共同 `_eligible_evidence` 边界，而不是只拦 `prepare_procedure`。当前 `select_procedure_evidence` 直接调用该函数（`core/procedure_generation.py:121`），prepare 也调用同一函数（:129）；因此共同边界可以避免英文在回退完整生成前已删改资料。`generation_chain` 在 procedure 不可用时保持原 inputs 并构建 GroundedAnswer（`core/local_rag_generation.py:116`），配合英文 select 返回原 evidence，才保留原 context、schema 和 .7 温度。

保留既有目标语言选择、强同语种概率证据和极弱异语过滤契约，不扩大语言识别或比较/rewrite 路由。未知分数 None 不作 0。中文边界符合用户确认的需求；英文历史失败与当前完整生成事实继续明示，不能宣传为全语言修复。

## Required Existing Validation

- 先用实际中文选择/原文建立 golden，并验证短关联不泄漏、原文与真实引用、main_rule/scope 映射、既有规范词只移动 step、record/limit/omit 不被恢复或搬移；红后再实现。
- 英文回退同时覆盖 prepare 与 select，不预删极弱异语证据，实际请求保持原 schema、.7 温度、context 和一次生成。中文固定槽位与非法输出、非 stop 等沿用现有不可用/None，不增加模型调用。
- Fast/Thinking 的 JSON/SSE 完整发布及取消/排队契约保持；测试中不以格式合法代替质量。general.yaml 使用已测 prompt 全文，继续作为唯一运行时事实源。
- 接线后对已存选择离线重放核对实际行为，随后第二轮及至少两轮真实 API 对照；候选冻结后再独立创建中文新留出。通过前 default=false，显式 false 回滚不变。

这些检查直接覆盖本次 schema/语言资格/输出的变化；不新增泛化防御门禁。单次 pilot 对开发题有效尚不足以关闭默认启用的质量条件。

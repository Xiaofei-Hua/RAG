# Mechanism v13 Critic Review

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v13-pilot/{results,model-http}.jsonl`，按冻结开发rubric独立逐答审读8槽、原文选择及实际HTTP。未读defender、未调用模型。

## Decision

**本轮中文开发严格8/8，可以接线默认关闭的生产候选并继续既定验证；不能默认启用。** 全文、首节、相关性、引用及所问未知各8/8。八槽只是四个已暴露中文题的一轮两序结果，不是新留出或稳定性证明。

| Slot | Case | Order | Full | Lead | Relevant | Citation | Asked unknowns | Strict |
|---:|---|---|---|---|---|---|---|---|
| 1 | L4 | original | P | P | P | P | P | P |
| 2 | L4 | reversed | P | P | P | P | P | P |
| 3 | Archive | original | P | P | P | P | P | P |
| 4 | Archive | reversed | P | P | P | P | P | P |
| 5 | Room | original | P | P | P | P | P | P |
| 6 | Room | reversed | P | P | P | P | P | P |
| 7 | Toy | original | P | P | P | P | P | P |
| 8 | Toy | reversed | P | P | P | P | P | P |

L4两序保留环境、初检起算、350正式标签及排除计数、换托盘重检重启、失败恢复、准备与记录用途。档案两序首节含共同清点签名完成交接才可阅览；候补/退回/重核、归还异常未结、各阶段记录及用途完整。活动室两序含现场清点损坏记录/双方签名/本场次门卡入场门槛、改期与电话例外、错门卡重核、新损坏未结及记录用途。木玩具两序含三项交付许可、通知非交付、代领、附件整单重确认、地址例外、全部记录用途。包装/库存/墙钟/年鉴/橙页眉/蓝点均未进入正文。

已对照v12活动室反序原记录：取消费用及夜间申请两个单位原为`answers=未询问, role=omit`，本轮改为对应所问事项与limit，正文恢复两项未知。其它题的所问未知也完整。L4反序两个未知的answers仍写“未询问”，但role=limit并正确展示原文；这表明辅助标注不等于语义证明，不能据它覆盖实际正文结论，也不应增设辅助文字一致性门禁。

首节可以包含相关规则、用途及必要重复，不另加首句含全部规则或长度门槛。legacy全部条件首节标准单列：L4两序首节均未含失败处理及全部未知，仍不满足旧标准；当前冻结的主要规则/范围首节标准通过。

## Calls and Cost

8条HTTP均为generation，每答1次、stop且complete；原始JSON与保存的选择一致。none、temperature=0、top_p=.8、2048保持，平均输出447 tokens，完整首见P50/P95为4.795/5.193秒（P95线性插值），无补答或验证模型调用。

**praise (non-blocking)**：通用“未问≠未规定”澄清在该轮恢复实际遗漏，同时保住首节、全部业务细节及装饰排除。尚未验证未被询问的未知干扰、真实生产接线、多轮或新题；这些按既定后续计划完成，不把8/8外推为全部中文流程有效。

## Round 2 and Production Replay

后续独立核验`data/eval/procedure-relevance-mechanism-v13-round2/{results,model-http}.jsonl`：8槽均有单次generation、stop/complete，选择与实际正文逐槽等同首轮已审正文，因此沿用语义审读而保留每槽状态。

| Round 2 slot | Case / order | Full / Lead / Relevant / Citation / Unknown | Strict |
|---:|---|---|---|
| 1 | L4 / original | P / P / P / P / P | P |
| 2 | L4 / reversed | P / P / P / P / P | P |
| 3 | Archive / original | P / P / P / P / P | P |
| 4 | Archive / reversed | P / P / P / P / P | P |
| 5 | Room / original | P / P / P / P / P | P |
| 6 | Room / reversed | P / P / P / P / P | P |
| 7 | Toy / original | P / P / P / P / P | P |
| 8 | Toy / reversed | P / P / P / P / P | P |

两轮严格16/16，16条实际HTTP均为单次最终生成；第二轮P50/P95为4.784/5.189秒、平均447输出tokens；合并16槽为4.792/5.256秒、平均447输出tokens。仍是四个已暴露题的两轮两序，不能外推新题表现。

critic另行用当前生产`prepare_procedure/procedure_schema/render_procedure`对两轮16份选择做离线重放：原文单位及最终正文16/16一致，生产prompt与实测提示相同，schema约束与实验等价（仅生产多title注释），零HTTP/模型调用。该检查证明本批生产接线保留了已测机制；不替代真实API或新留出验收，默认false保持。

# Design v1

## Diagnosis and Research
基线main 9b79b00。旧留出中文六次实际选择首节[1,8,16,17]：范围/节假日未知/墙钟/年鉴；用户要求的交接签名后才阅览在第三节。资料与来源没有缺失，程序如实渲染；错误来自裸ID选择与自由首节分配。上一轮已否决穷举omitted_clause_ids（丢所问未知信息、结构失败）和条款阈值筛选（必需句分数低于干扰），本轮不重走两条路线。
从[Kyosuke Nishida主页](https://www.knishida.info/publications/)追踪[QFE论文](https://aclanthology.org/P19-1225/)及论文实现/消融说明：按问题顺序选择并关注剩余需求有助于防止过量证据，原方法需要专门训练，不能直接当成本项目效果。参考[Chain-of-Note论文及附录实现提示](https://aclanthology.org/2024.emnlp-main.813/)的先明确资料与问题关系思路；不移植逐文档长笔记、训练或无依据时调用内在知识。这里只检验‘同次输出中先给简短问题锚点再选依据’这一迁移假设。

## Minimal Candidate
只修改流程选择的schema/prompt/渲染：ProcedureAnswer从conditions=[]+answer改为lead+answer，lead和后续条目均是{addresses,title,clause_ids}，addresses在IDs前是用户问题中的简短具体事项，作为本段选择的条件；title只标阶段。lead优先满足用户指定首要问题，必须合并主要操作许可/禁止规则与通用范围；不能用未知信息段替代主要规则。answer按用户所问顺序组织具体步骤，动作/前提/失败分支/记录/用途仍全部覆盖。
每条入选依据须回答addresses所指事项；同主题但不回答事项的条款不入选。所问未知信息仍相关，不能为相关性省略。addresses仅用于同次条件生成，不展示给用户、不作为语义正确证明，不增加一个核验模型或完整计划。渲染顺序确定为lead然后answer；所选原文仍按真实来源引用、全文stop后一次输出检查发布。原文切分/指代合并/证据资格不变，保留已解决的事件起算关系。
假设H1：显式lead降低首节任务被后续步骤吸收的概率；H2：短问题锚点降低裸IDs把邻近无关句混入答案的概率。任何字段只提供结构诱导，不声称硬保证语义相关性。不能硬编码设备、档案、墙钟、年鉴或开发条款编号；不采用词黑名单或输出后删句。

## Architecture and Contracts
core/procedure_generation.py变更内部结构和渲染，core/local_rag_generation.py继续枚举实际条款ID。profile唯一来源，golden同步。Fast/Generate入参与shared_state不变，无新增状态、持久化、外部API字段或依赖。comparison/rewrite/非流程/跨语继续原完整生成；LOCAL_RAG_SEGMENTED目前false。程序只验证schema/ID/stop，不能把它们作为语义分。空lead/非法ID/length/输出检查失败仍既有不可用、confidence=None；无追加生成或原文旁路。队列/取消/PII/不可信资料边界保持。
同一9B/context4096、temperature0/top_p.8/none/max2048，新增短addresses可能增加约100–300输出token，必须实测；仍应比完整自由生成短。主要收益指标：严格整题/首节通过、无关内容率、实际模型调用数、完整首见P50/P95及输出token。相对旧选择允许有限耗时成本换质量，但不能新增模型调用；相对当前false完整生成须保留完整首见中位数收益，不要求每个分位数全面更优。

## Experiment and Tests
编码前独立并行critic/defender批准最小实验。先在tests/integration的临时适配器比较旧选择与新结构：4个已暴露流程（R7/L4/档案/字幕），两种来源顺序各2轮，共16答/侧；同证据/运行时/采样/预算，交替执行。同一轮加入lead-only消融（同4题/来源顺序/轮次），与lead+addresses使用同等任务指令，仅移除addresses字段及对应说明，三变体各16答共48答。若lead-only达到相同完整/首节质量，则选更小方案；不凭仅目标题成功直接推广。若新结构未修复目标，记录完整失败、依据实际行为修订设计，不直接接线默认。
机制合格再接生产，确定性红→绿覆盖首节渲染顺序、addresses不泄露、实际ID/来源、全文发布、None/失败与单调用；golden不预制真实语义评分。真实API：4个开发流程+原4个普通题，两模式×两轮，候选true对照当前默认false完整生成；复用旧选择机制作为消融，不能混淆两种基线。
候选冻结后由独立评审者新建2个中文+1个英文流程，含不同分支/审批规则、所问未知边界与同实体无关句，两模式各3轮；不能用留出调当前候选。逐答人工审查完整动作/条件/目的、首节规则、相关性和引用；严格整题要求上述全部通过。首节不得只有主题/适用环境，必须实际回答用户指定的首要规则；全文正确不能抵消首节后置。无害重复/措辞差异不单独判退步；明确无关事实或任何所问动作/用途/条件遗漏属于实质失败。普通未改路径的随机波动如实记载，不重调无关prompt追求逐答全胜。开发/留出被改路径出现新的实质退步就不启用默认。
最终单元+进程内E2E+perf/coverage；无前端代码改动，沿用GitHub必需UI检查。默认启用前加显式false回滚回归与默认真实冒烟，不盲目重复全部模型对照。所有实验原始请求/响应、时间与独立评审归档，旧失败不可覆盖。

## Rollout and Rollback
[breaking, conditional] 仅在最终独立评审确认合格后，把LOCAL_RAG_SEGMENTED代码/示例默认改true；已有显式false保留。资格仍合格本地general/9B/明确流程，其他路径不扩展。通过false并重启恢复原完整生成；单应用worker/fair调度保持。文档同步说明单次生成、完整发布、真实收益、样本局限和回滚。内部JSON字段不属于REST，但公开配置默认变更须CHANGELOG标记。没有新增安全边界；无法保证任意自然语言问题都正确，不将小样本写成普遍保证。

## v2 — Bind the Lead to a Concrete Rule Before Selecting IDs
v1三变体48答全部stop且单调用，但无合格候选。addresses版去掉无关内容、保留全文事项；档案首节仍缺交接许可，字幕首节缺独立审核条件。lead-only还漏记录和用途，故不接生产。首节addresses只列要回答的问题，没有形成实际规则，继续泛泛要求‘首节要完整’不足以解决ID分配。
下一有界实验保留addresses后续段，lead拆为{rule_quote,rule_clause_ids,scope_clause_ids,title}：先摘出直接回答用户指定主要操作/许可规则的完整原句（可取多句以涵盖决定许可的角色/先决条件），再选择支持这条规则的IDs，最后选择通用范围IDs。rule_quote在ID之前作为同次解码的语义依据；不写思考过程，不再让未知事项替代主要规则。用户可见首节仍只由对应IDs的原文组成（rule后scope），quote不作为独立正文或额外可信来源，不输出自由改写结论。
这是H1的具体化：把抽象问题标签变为可定位的实际许可语句，消除‘标题提到了但正文没回答’；仍非形式化语义保证。正文的所有步骤/条件/记录/用途和所问未知保留addresses版，不改变分句、来源资格、温度/预算/none或输出检查。没有增加模型调用、后置删句、题目专用词或ID规则。quote只增加少量同次输出token，其成本必须报告。
先执行同4开发题×2来源顺序×2轮的16答候选，复用v1同输入/同运行时的anchored16答作失败对照（分批时间不冒称严格时序配对）。四题首节及全文仍用已冻结rubric，不因新结构放宽。若修复则接线前独立评审；真实API仍另做对当前false的成对对照。v1所有失败原样归档，默认false。

## v3 — Generate the Complete Procedure Before Its Lead
v2修复了档案首节许可，却又漏编号关联/周期检查等全文事项；字幕仍缺首节审核独立性，故不接生产。待检验的共同原因是让小模型在尚未组织全部步骤时先决定复杂首节，首节任务可能挤掉后续事项。当前完整生成GroundedAnswer已有basis→conditions→conclusion的生成顺序、conclusion先展示的实现（core/local_rag_generation.py）；流程同样已等待全文，没必要让模型最先写可见首节。
下一最小实验仅把同次schema生成顺序调整为answer→lead，先完整选择操作/记录/用途/未知，再从这些已经处理的条件中选择首节，实际展示仍lead→answer。不增加中间计划、调用或必填输出字段；实际token仍需测量，不从正文后置猜测规则。对v1 anchored和v2 rule_lead各做一个answer-first变体，其余输入/字段/语义要求不变；提示只补一句生成先answer后lead、可见顺序不变。每变体4题×2来源顺序×2轮各16，选择满足全部判据的最小版本；引用/首节/全文还是冻结rubric。先运行机制，不能凭字段顺序推断成功。

## v4 — Semantic Clause Handles Instead of Bare Numbers
v3 flow_rule严格12/16、flow_anchored10/16，仍不接生产。资料只换来源顺序就出现不同用途/记录遗漏，提示编号映射负担可能影响选择；这仍是待验证解释，不声称仅由编号导致。
依规范重新调研：[Nicola De Cao主页](https://nicola-decao.github.io/)→[GENRE论文](https://arxiv.org/abs/2010.00904)与[官方实现](https://github.com/facebookresearch/GENRE)，以及[SEAL论文](https://arxiv.org/abs/2204.10628)/[官方实现](https://github.com/facebookresearch/SEAL)。这些工作通过可读名称/原文子串作受约束标识，而非要求模型预测无语义标签；有专门训练与检索任务差异，不直接证明本9B效果。不引入其训练、索引或模型，仅迁移可读标识的解码思路。
保持v3 flow_rule所有任务字段/answer先lead后/温度/预算/检查，只把选择值从裸int改为枚举的原文短标识：中文取条款前36字符，英文取前12个空白分词，末尾附稳定本次编号以消歧（标识以原文开头，编号在尾）。完整原文仍在同一资料上下文；短标识仅定位，不替代或截断事实。上下文与schema用同一标识，精确字典映射回实际条款后继续原渲染，禁止从模型返回的任意文本猜映射。不同来源或相同前缀仍可唯一区分。
v4只改表示，不改条款/来源/评分、不加actor规则、黑名单或后置相关性过滤。非枚举标识仍既有无效ID降级；复杂度O(条款数)，无新增模型/embedding/reranker调用。额外标识输出token可能较多，记录prompt/completion、时间及截断；预算仍2048，不能以length当完成。先4题×2来源顺序×2轮16答，对照保留的v3 flow_rule16答；判据不变，默认false。只有真实效果支持再谈生产接线。

## v5 — Decide Once for Every Clause
v4的长字符串enum退化为同一标识重复直至2048截断，提前停止并保留实际完成/中断记录；不提高token预算补救。v1–v3仍在让模型自由列出“选中了什么”，schema不能迫使它考虑未提及的记录/用途。下一假设是将开放抽取改为固定槽位分类：输入条款不变，每个实际条款必须且只输出一个类别，避免提前结束清单使条款无声消失。完整槽位只保证逐条作决定，不证明语义分类正确；仍按冻结人工rubric验收。
同次JSON为{clauses: {"1": "lead|step|record|limit|omit", ...}}。实际每个ID均是required property，additionalProperties=false，值用同一小enum；按原文次序生成各槽位。lead表示直接回答用户首要规则/适用范围，以及决定这条规则的执行者资格和先决条件，不能只有主题或环境。step为操作动作/分支；record为记录字段和用户所问用途；limit为所问未规定事项；omit仅用于不回答问题的内容。混合条款只选一个最主要类别，整个原文保留，绝不拆掉后半条件。
渲染按lead→step→record→limit，各组保持资料原序；条款原文逐条引用，固定中英小节名，不再生成自由标题、问题锚点、rule_quote或重复lead选择。每条最多出现一次，所有类别非事实正文。空lead或全omit走既有不可用，不追加模型调用。现有分句、指代合并、资格筛选、none/temp0/top_p.8/2048、完整stop+一次检查不变。无新增外部依赖/状态键/评分/持久化，复杂度O(n)。跨资料步骤顺序仍可能失败，是本实验必须观察的算法风险，不能仅凭齐全就算合格。
先运行档案与字幕各两种来源顺序各1次（4答），直接检查反复出现的许可、独立审核及记录用途问题；若未改善则停止此路线，不盲目重复。若合格再补全四开发题×两种来源顺序×两轮至16答。比较v3已存flow_rule；语义标准不改、默认false。减少重复字段预计降低生成token，实际记录调用数、完成性、token和首见；API/新留出仍需独立验证。此设计沿用前述QFE/CoN的问题驱动选择启发，采用工程上的固定分类槽位替代自由选取；不声称借鉴论文已证明9B有效。

## v6 — Complete Classification, Explicit Lead, and Antecedent Closure
v5四答都完整保留相关条款、排除干扰且约1.8–2.2秒，但首节仍把lead误当范围段；字幕反序还将退回审核放在准备之前。停止补跑。v3已有有效的“正文处理后摘实际规则再选ID”组件，v5已有逐条不遗漏组件，下一实验组合这两个已测组件，分别解决覆盖与排序，避免继续用一个类别兼任两个职责。
clauses每个实际ID仍required，值改为{section: step|record|limit|omit, order: 1..N}；先逐条分类并给同组操作序号，组内按order排序、并列按原序。之后生成v3 RuleLead原字段（rule_quote、rule_clause_ids、scope_clause_ids、title），先实际规则后范围。正文按step→record→limit展示所有非omit条款，lead单独前置，允许有意义重复；不从未考虑条款中自动猜补，不用输出后语义判断。重复lead选择代价约100–250 token，仍2048/一次调用。顺序值只决定呈现，不新增事实。
另一个已复现边界错误：字幕“the reviewer”引用前条“a reviewer who did not edit it”，现有_REFERENCE只保留it/that等指代却漏此种明确角色资格回指。扩展最小分句规则：仅当前一组原文含“a/an + 1–3词名词短语 + who/which/that”且当前句含“the + 同短语”时合并同来源原文，保持资格与放行条件不可拆。这不是为reviewer硬编码，不能跨来源、不改原文、不以source标题猜身份。合并可能扩大lead，按既有无害重复标准审查；原文中的无关信息不能因合并获豁免。增加英文角色资格回指golden正反例与中文现有边界回归。
先同v5四答pilot，冻结判据不改。只有四答通过再补至四开发题两序两轮16答；之后生产设计/测试/API与新留出。所有旧失败保留，默认false。核心复杂度仍O(n log n)，schema只是逐条决定+展示计划，不是语义正确证明。

## v7 — Isolate the Reproduced Clause-Boundary Fix
v6四答中三答分类退化为全部step并混入干扰；额外order/schema复杂度没有得到收益，不接生产。角色回指合并本身使两份字幕首节都保留独立资格，但与分类改动混合，不能归因整体成功。下一实验回到v3 flow_rule的完全相同prompt/schema/字段顺序，仅保留v6已设计的同源明确角色回指合并，隔离这个已复现的输入边界修复。先同档案/字幕两序四答；如果全文/首节通过再补全16。若仍失败才继续算法修改，不把复杂分类框架带入生产。默认false、所有判据/单调用/预算不变。

## v8 — Make the Output Contract Visible to the Model
v7四答首节均完整且去掉干扰，但两份字幕仍遗漏所问的三项用途，不能接线。继续复核推理接口发现：当前schema仅放在response_format约束解码，消息里只说“符合schema”，并没有给模型完整schema。[Ollama官方structured outputs文档](https://docs.ollama.com/capabilities/structured-outputs)建议同时把schema作为字符串放入提示以帮助模型理解输出；这只是可检验的接口用法差异，不证明其为全部遗漏根因。
下一隔离实验保持v7原有prompt/schema/分句/预算，只将实际生成的紧凑JSON schema追加到system消息，作为模型可读输出契约；用SystemMessage载入以免JSON大括号被当成模板变量。schema同一对象生成，不另存副本/不新建核验，不增加调用。实际条款数已通过enum约束，新增输入token可能增加prefill，仍4096上下文及2048输出，记录用量与终态。先既定四答pilot；合格再补全16，不扩大分类框架或加用途关键词规则。默认false。

## v9 — Classify Relevance Once, Promote Explicit Operating Constraints
v8仍遗漏字幕三项用途，且档案反序把申请当阅览许可；不采用schema注入。已有最稳定的小组件是v5逐条简单分类：全部相关内容保留、无关内容排除、约2秒。让9B同时设计首节/排序反复降低语义质量，下一方案把职责缩小：模型只做已测的逐条分类，程序决定显式操作约束在首节展示。
保持v5原prompt/schema/分句/温度/预算完全不变，非omit才可展示。可见首节包含模型标lead的条款，再加入step中有显式规范性表达的条款，按资料原序；其余step、record、limit依次展示，已移入lead的条款不在后面重复。规范性信号限定为通用中英文许可/义务/禁止表达：必须/须/不得/不能/禁止/仅/只有/才能/方可/不允许，以及whole-word must/shall/only/before/until/unless/required/requires/allowed/permitted/prohibited/cannot、may not/can not/do not。不匹配实体、题目、条款号或具体目的动词，不改变来源相关性判断，不截句/改写事实/推导新许可。分类为limit/record的条款不因词命中被抢到首节；omit绝不因规则词恢复。
这是一种有边界的呈现策略：首节展示相关操作约束，后续展示剩余操作/记录/未知；不声称词法信号覆盖所有自然语言规则。可能使首节变长，沿用既定语义判据，不以长度本身失败；如首节实际仍漏主规则或正文顺序不可执行，实测即否决。保留完整前提和原引用；无新事实、调用、判分/验证器。固定标题仍用v5中英标题，首节改为‘规则与适用范围/Rules and scope’。合并角色回指、长schema、自由quote/addresses/order字段都不进入本候选。
先对已保存v5四答分类做确定性重放，检查渲染语义是否满足原判据（不冒称新增真实模型答数）；通过后用相同v5生成器+新渲染跑四开发题两序两轮16答。再按原计划生产API/新留出，不新增审批门禁。策略只控制选中事实的展示位置，效果仍以实际中文/英文新题决定，默认false直到合格。

## Conditional v9 Production Integration
若v9机制16答通过，生产只接入本候选：ProcedureAnswer.clauses为严格str→五类别映射；request schema以实际条款ID建立required properties并禁止额外键；render再次核对真实键集合，再按v9通用规范词前置已选step，分四组原文引用。缺键/额外键/非法类别/规范条款前置后仍无lead/非stop沿用现有不可用+None，不增调用。prepare仍保持原分句/指代/证据资格，仅在内部准备结果携带实际证据语言，固定小节标题跟随证据语言（已验证与所需输出语言一致）。没有shared_state新键、API新增字段或持久化。
唯一prompt来源更新general.yaml为v5已实测原提示；不注入schema文本、不加入新的语义说明改变解码。ProcedureParagraph旧自由标题/ID列表结构由内部分类schema取代，不是REST字段。普通比较/rewrite/非流程/跨语资格不足继续原完整生成；默认仍false。
先更新golden并写缺失/额外槽位、非法类别、omit不复活、record/limit不误前置、首节实际原文及固定标题回归，运行单元和Fast/Thinking JSON/SSE进程内E2E记录红。实现后跑相同定向矩阵绿；真实API按既定8开发题两模式两轮对照false/true，不因未改路径随机差异改prompt。冻结本实现后才由独立评审创建3道新留出，三轮两模式对照。通过才把配置默认改true并记录breaking迁移/显式false回滚、默认实际模型冒烟；未通过保持false继续定位。

接线修正：limit显示标题固定为“条件与边界 / Conditions and boundaries”，容纳已观察到的已知失败条件与未知范围混合条款；不变更分类、prompt或模型输入。R7反序混合条款加入golden，保留两类原文，不能将已知停机条件解释成未知。


# Subsequent Design Record

# Design

## Diagnosis and Research
已复现的瓶颈是9B同时负责选择、组织首节和自由编排时漏掉相关条款或带入同主题无关事实；扩大提示/排序字段会增加成本且不稳定。需求是保留完整动作、条件、记录和用途，并让主要操作规则先出现，最终生成仍只调用一次。
从[Kyosuke Nishida主页](https://www.knishida.info/publications/)追踪[QFE](https://aclanthology.org/P19-1225/)，参考[Chain-of-Note](https://aclanthology.org/2024.emnlp-main.813/)的问题驱动选择；从[Nicola De Cao主页](https://nicola-decao.github.io/)追踪[GENRE](https://github.com/facebookresearch/GENRE)和[SEAL](https://github.com/facebookresearch/SEAL)的可读标识，另核验[Ollama可见schema建议](https://docs.ollama.com/capabilities/structured-outputs)。这些方法的训练/任务前提不能直接迁移为9B效果。长标识、自由规则引用、复杂排序与schema注入都未同时通过完整性和首节要求，完整设计迭代及失败原样归档，不进入生产。

## Strategy and Hypothesis
采用v9：模型在同一次JSON中为每个实际条款填写一个固定类别lead/step/record/limit/omit；不能自由结束选择清单而无声遗漏未处理条款。程序完整展示非omit原文，按规则、剩余操作、记录、条件分组。step内的显式许可/义务/禁止条款前置到lead，各组保持来源原序，每条只出现一次。
前置信号仅为通用中英表达：必须/须/不得/不能/禁止/仅/只有/才能/方可/不允许，whole-word must/shall/only/before/until/unless/required/requires/allowed/permitted/prohibited/cannot及may/can/do not。它们只改变已选原文的位置，不恢复omit，不抢record/limit、不推导新许可、不依赖实体/题目/数字。首节可能较长；词法信号不保证覆盖所有表达，必须以真实效果验收。
H1：逐条固定分类降低遗漏和无关内容率；H2：把确定的呈现顺序交给程序，减少自由首节选择错误与输出token。结构完整不代表语义分类正确。保持原分句/指代规则；实验性的角色回指扩展、自由标题/addresses/quote、长标识及排序字段全部舍弃。

## Architecture and State
core/procedure_generation.py拥有分类schema与渲染；core/local_rag_generation.py仍使用同一个最终请求。ProcedureAnswer.clauses为严格str→五类别映射，实际ID建立required properties，禁止额外键，渲染核对实际键集合。固定中英标题跟随已通过同语种资格的证据语言；limit标题为“条件与边界”，不把混合的已知失败规则误称全部未知。
完整stop→原文组合→现有引用/PII检查一次→整体发布。Fast sync/async/SSE和Thinking Generate都走既有入口；shared_state没有新增键，generation_evidence及实际来源集合契约不变。没有新依赖/持久化/REST字段。普通比较、非流程、改写及跨语或资格不足保持原完整生成。

## Failure and Invariants
缺/多槽位、非法类别、前置后仍无lead、非stop、引用/输出检查失败都沿用既有不可用+confidence=None，绝不报告0分，不追加生成。模型原生未标lead但操作约束可前置时仍可完成。omit不会因规范词复活，记录和边界不会因规范词被移走。没有新增安全边界，资料仍为不可信引用，保留原输出检查与取消/排队契约。

## Budget and Evidence
维持4096 context、none、temperature=0、top_p=.8、2048最终输出；不改变完整生成的.7温度。分类与渲染O(n)，无新模型/embedding/reranker调用。核心指标为严格质量、首节、相关性、完整首见P50/P95、实际调用及输出token。
四开发流程两来源顺序两轮：v9严格16/16，首见P50/P95=1.771/2.078s；旧选择10/16、P50=3.728s。真实API开发每侧8题×2模式×2轮，改动流程4/16→16/16；Fast首见P50 9.748→1.938s，Thinking 11.740→4.997s。Fast总1调用、Thinking总4调用（3次原控制+1次生成），两侧相同。普通未改路径15/16→13/16，候选三次比较未明示大小关系，完整生成请求未变；如实记录，不修改无关prompt追逐随机全胜。详见results及独立评审。

## Validation and Rollout
先写golden/固定槽位/前置与降级/JSON-SSE回归再实现，红22失败/34通过→绿56通过。生产对16份既有选择离线重放与机制一致，仅修正中性标题；不计新增真实答数。后端最终单元+进程内E2E+perf/coverage；无前端改动，GitHub必需UI检查继续执行。
候选已在validation/freeze-v9.md及代码归档中冻结，随后由独立评审者创建2中文+1英文全新留出，两模式各3轮比较当前false与true。只将corpus/query送系统，人工判据离线；全文/首节分开评，保留记录用途、条件和所问未知，不用关键词或无害重复判退步。不能据留出调本候选。通过后做默认实际模型冒烟及显式false回滚回归；此前默认false。
[breaking, conditional] 新留出确认适用流程无实质退步后，LOCAL_RAG_SEGMENTED默认改true，代码与示例/README/API/运维文档同步；已有显式false保留。设置false并重启恢复旧完整生成，fair队列不受影响。仅合格本地9B/general且明确同语种流程生效，不宣称任意语言或模型普遍合格。全部失败/协议/请求响应/评审/命令日志归档；最终Critical/High闭环后合并main。

留出预检修正：原问题有非显式流程和“一致”比较触发，早期运行停止且未读取新正文，不计验收。仅等义明确三题请求，资料/判据/算法保持；r1/r2原协议保留。完整资格离线预检通过，新增六个零模型路由回归固化既有边界，正式验收只用v2结果目录。

## v10 — Semantic Roles and Short Question Links
v9正式新留出失败：候选严格6/18；实际clauses路径15答中，木玩具6答首节缺真正交付条件并带入表单装饰，联赛Fast3答首节缺发布许可；联赛Thinking3答发生原rewrite并走完整生成，不计v9路径。默认继续false。三题已暴露，加入开发，不再称新留出；不得补两个题目词或按同题调后声称留出通过。
核心解释：lead容易被当作资料开头/概述，record容易被当作与表单有关的任何属性；仅依赖规范词不能覆盖自然许可表达。下一最小实验将类别直接表达语义：main_rule（直接回答用户首要操作规则或许可条件）、scope（适用范围）、step、record（实际填写/保存的业务信息和所问用途）、limit、omit。明确‘记录载体/场所的样式属性’本身不等于用户要求保存的业务字段；用户明确问样式时仍相关，不建立颜色/实体黑名单。现有规范词表不扩词；main_rule/scope直接进入首节，step仍按原已选约束前置。全部原文/来源和完整发布保持。
从[Silei Xu公开主页](https://github.com/sileix)追踪[Chain-of-Draft论文](https://arxiv.org/html/2502.18600v2)及[官方实现](https://github.com/sileix/chain-of-draft)。其短中间草稿在部分算术/常识/符号任务减少输出，论文亦指出复杂/小模型情形的限制；不直接当成本9B抽取有效，也不引入多次调用或长隐藏思考。结合此前CoN的问题关联思路，只检验很短的关联标注能否改善逐条判定。
对照两个候选：roles仅改变上述语义类别/说明；linked在每个固定槽位先生成answers（该条实际回答的用户问题点，至多12中文字/5英语词，schema最长48字符），再生成role。没有被问到写‘未询问’，不能用‘记录/步骤’泛主题代替。answers是同次条件生成，不展示、不当作真实性证明、不作语义评分；不复述原文、不要求长推理。其余输入/字段决策说明完全相同，隔离短标注边际成本；若roles效果相同则选更小方案。none/0/.8/2048、4096与一次最终调用不变。
先用已暴露木玩具/联赛两题×两来源顺序×1轮，对照当前v9与roles/linked共12答。仍按已冻结首节/全文/相关/引用判据；如果候选通过，再在全部7开发题两来源顺序两轮确认，不靠新题反复微调提示。任何实现接线前仍需独立评审/红绿；之后重新冻结，再创建真正全新的留出。当前生产v9只是默认关闭的候选，不先合并或默认启用。

## v11 — Classify Evidence, Then Write the Lead
v10最小12答未通过：roles保留业务完整性并排除装饰，但首节仍漏自然许可；linked只修木玩具，联赛反序还漏所问异议期限，增加输出却无稳定收益。原因不只是类别命名：同一原文组可能含准备动作与实际许可，强行给整组单一首节角色可能被开头支配（解释性假设，尚未隔离证实）。继续增加角色、词表或长解释没有证据支持。
利用已有两项分工优势提出v11：基线有直接概括真实许可的成功答案，但两份独立评审对基线首节范围存在分歧，不采用17/18作为确定结论；v9原文组合实际路径全文15/15通过。同一次JSON依次生成clauses与lead：clauses按step/record/limit/omit逐条固定分类（保持v10对业务记录与载体样式的区别）；lead使用既有CitedParagraph格式自然语言直接回答用户所要求的主要操作规则和适用范围，真实source_ids限定在本次证据集合。原文分类先完成，再生成首节，借助同一调用的已输出选择；最终显示顺序为lead在前、完整原文细节随后。
step包含相关规则、范围、操作、条件与分支；record仅相关业务字段/用途；limit所问未知；omit无关。主要规则不再承担‘一个整组应属于哪个首节类别’决策，也不依赖规范词正则前置。全部非omit条款完整展示（即便lead已概括），各组内保留原序，引用保持原来源。首节可有必要重复；不以重复自动判失败。标题为规则与适用范围/操作依据与步骤/记录与用途/条件与边界及英文对应。lead须覆盖实际许可的并列条件和角色资格，不能用准备、申请或通知代替；仅据原文，不扩展许可。没有生成整篇自由摘要、辅助解释或第二模型。
lead允许正常自然语言改述，因此没有‘所有正文均逐字原文’的证明；其依据与事实支持需真实独立语义验收，引用合法不代表语义正确。复用CitedParagraph与现有输出检查，不新增在线judge/校验调用。schema限实际source_id，完整stop、缺/多条款、非法类别、无效/缺lead仍按现有不可用None，不额外回退调用。旧的规范词前置全部移除，不把未标主规则问题转成范围扩大。
先在7个已暴露开发题两顺序各一轮（14答）验证v11；对照原v9/v10存档，不重复已知失败模型调用。若全文/相关性/首节有实质失败，停止扩大；若通过，再完成第二轮、多轮API与新冻结留出。none、temperature=0、top_p=.8、2048和4096不变，一次最终生成；目标完整首见仍优于当前默认完整生成。临时probe准入和生产接线分别独立评审，默认false不动。

## v12 — Qualify the Requested Chinese Scope
v11 14答严格仅5/14；source_ids重复导致两答length，另有档案首节错把申请当阅览许可、装饰回流。保留失败，不扩大自然首节实验、不接线。不采用增加源数组限制来掩盖仍然存在的语义失败。
重新对齐本轮用户明确目标‘中文回答混入无关内容和首节顺序’：不以英文试验失败无限推迟中文修复。候选回到v10 linked原始提示/schema（未改文字），仅检验是否可对中文资格成立；若成立，默认只覆盖中文明确流程，同语种英文继续原完整生成（当前默认行为），不将英文失败隐去或称已解决。语言是可维护的场景边界，不按题目、实体、来源或语法词设白名单。
先仅用现有4个中文开发题（L4、档案、活动室、木玩具）两来源顺序各1轮共8答，v10 linked不改规则、不增调用。若全文/首节/相关性有实质失败则此候选仍否决，不通过继续缩到某些业务题或实体来绕过；若8答通过，再第二轮与真实API，并冻结新的中文资格边界后由独立评审者创作全新中文留出。英文对照作为未改路径控制，实测输出请求仍为原完整生成。
只有上述中文完整开发及新留出都通过，才考虑默认true；eligible evidence需中文（源/问同语种，已有低概率跨语言过滤契约保留），其它语言回到完整生成。显式false回滚。这个范围变化、英文失败与中文收益须在README/API/部署说明明示，不宣称所有流程语言普遍改善。临时8答试验先评审；生产边界接线另审。

## v13 — Distinguish Unasked from Unspecified
v12中文8答严格7/8，首节与装饰排除8/8；活动室反序误把用户明确所问而资料未规定的两项写成‘未询问’并omit。没有继续缩掉任何题，默认false；失败不扩大第二轮。新的假设是短标注‘该条实际回答的问题点’混淆了‘资料没有答案’与‘用户没有问’，需要明确二者语义，而非添加实体/颜色或未知语句匹配规则。
v13仅对原linked提示作一项通用澄清：问题点按用户确实问了什么识别，资料明确未给出该事项时，问题点仍保留、role=limit，绝不把未规定误写成未询问。schema与answers字段名、角色、范围、程序原文渲染、规范词前置、模型所有参数保持v12。没有任何按关键词恢复omit的运行时启发式，也不把所有未知无差别加入答案。
先重做4个中文开发题×2来源顺序×1轮8答，与存档v12按同一冻结rubric比较。保留所有8题/原判据，不因只差1题降低验收标准；若改好且没有新退步再第二轮/API及新的独立中文留出。新留出必须含未被询问的未知说明，区分真正覆盖所问与无差别保留未知。未改英文完整路径仍作为控制。独立评审后才临时实现，生产不开默认。

## Production Wiring for v13 (Default False Until Holdout)
若独立实测评审认可v13，生产仅接线已测机制：ProcedureClause严格包含answers（1..48字符）和role（main_rule/scope/step/record/limit/omit）；ProcedureAnswer逐条固定动态键，每条schema同样先answers后role。answers只是同次生成的短问题关联，不对用户展示、不作事实证明、不驱动程序改判；例如answers写未询问但role=limit仍依role展示原文，程序不追加语义推断。
渲染把main_rule/scope映射既有lead；step现有规范词前置保持不变，record/limit不挪、omit不恢复。任何非omit原文保留，真实引用、一次完整检查、stop发布、None和取消/排队契约沿用；没有自由自然语言lead、source_ids生成数组或新的模型请求。general.yaml替换为已测linked-unknown-prompt全文，唯一prompt事实源。
资格在_eligible_evidence的共同边界仅接受中文目标语言，因此prepare与select_procedure_evidence都对英文回退原输入；不能只阻止prepare却先删改英文生成证据。跨语言或中英混合、普通比较、rewrite及无明确流程都继续原完整生成。英文路由回归同时断言原schema/temperature=.7/原context/单调用及不预删弱异语证据。中文保留实际reranker概率去除极弱异语资料的既有资格，未知分数None不当0。
先更新中文真实输出golden和固定槽位/短标注/原文排序/中文资格/英文不改证据/Fast-Thinking JSON-SSE/失败None回归跑红；再接线跑绿。原英文golden仅作旧历史，不作为当前候选可用证明；新golden从实际中文原文与选择存档产生，人工检查原文和引用。随后生产对现有选择离线重放、至少两轮真实API，与当前false完整生成对照。候选冻结后才由独立评审新建留出；只在中文质量无实质退步且单调用和耗时可接受时启用默认。显式false保持原生成。

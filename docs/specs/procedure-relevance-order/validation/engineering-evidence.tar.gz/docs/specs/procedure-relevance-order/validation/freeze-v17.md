# Candidate Freeze v17

UTC: 2026-11-11T14:06:51.293535+00:00

基线origin/main=9b79b006a89620ec58b4d46538913f20bfc5e54e，候选fix/procedure-relevance-order。代码见candidate-v17-code.tar.gz；生产prompt精确为full-key-prompt.txt，完整原文key→六类enum，加完成才仅前置已选step。默认仍false。

冻结前开发7题/两模式/两轮共28答均通过；真实正文与独立已审回放一致。Fast P50/P95 10.776/15.521→8.732/9.936秒；Thinking14.744/16.858→9.510/10.807秒。70 HTTP=28最终生成+42原控制，无新增调用。红28失败42通过→绿70通过，代码独立评审无新增C/H。

下一步由独立defender在本冻结后创作全新3题/6份资料，不复用已暴露题及rubric；实际模型前由critic完成完整资格预检。两模式各3轮，当前false完整生成对照与true候选；期间不改prompt/schema/渲染/查询/语料/rubric。若失败留存且转开发，不称新留出通过。默认启用仍须留出无实质退步、真实默认冒烟及最终测试/评审。

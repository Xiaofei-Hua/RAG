# Mechanism v8 Critic Review

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v8-pilot/{results,model-http}.jsonl`。独立只读，未读defender、未调用模型，冻结rubric不变。

## Decision

**严格1/4，不采用当前schema提示注入候选，不接生产。** 两份字幕仍漏三用途，档案反序新增首节错选申请事项；原序档案完整通过。

| Slot | Case/order | Full | Lead | Relevant | Citation | Strict | First body s | Prompt/output tokens |
|---:|---|---|---|---|---|---|---:|---:|
| 1 | Archive/original | P | P | P | P | P | 5.427 | 1450/473 |
| 2 | Archive/reversed | P | F | P | P | F | 4.385 | 1450/388 |
| 3 | Caption/original | F | P | P | P | F | 5.102 | 1384/446 |
| 4 | Caption/reversed | F | P | P | P | F | 5.888 | 1384/541 |

四次均单次generation、stop、complete。相对v7同题，输入多412个档案tokens或376个字幕tokens，结构原本已合法；本批不能据格式成功推断语义收益，跨批时间不当作严格配对性能结论。

档案反序首节标题是“开始阅览的主要规则”，正文只摘填写调阅单/出示证件及范围，真正清点签名后才能阅览在后节。精确问题是首节未给许可；不夸大成正文明确宣称“申请后即可阅览”。全文记录/用途/未知仍完整。

字幕两序均保留独立资格和同版本批准于首节，全文的动作、记录字段、版本例外与未知项仍有；但转录稿匹配避免过期稿、完整回放发现相邻提示间遗漏、独立审核分离编写与发布决定三用途再次未选。F-13未闭合。

## Finding F-14

- **Label**: issue (blocking, must-fix)
- **id**: F-14
- **severity**: Critical；critic §2(a)，已修复的档案首节目标在当前候选再次复现。
- **location**: 槽2首节；REQ-702/704/705。
- **symptom**: rule_quote及rule IDs选择申请准备，未选择交接许可。
- **impact**: 首节未回答用户指定首要规则，v7同输入曾通过。
- **root_cause**: schema可见仅改变选择行为，没有形成首要问题与实际许可的可靠关联。
- **recommendation**: 不采用当前候选，保留原结果与字幕用途失败；不把官方用法建议写成项目效果证明。
- **verification**: 后续候选继续原四维逐答判据，首节与全文必须同时通过。
- **status**: open

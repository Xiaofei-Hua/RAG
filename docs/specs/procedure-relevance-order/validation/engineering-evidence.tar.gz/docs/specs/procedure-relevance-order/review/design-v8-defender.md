# Design v8 Independent Review — Defender

**Date**: 2026-11-11  
**Object**: `design.md` section v8; v7 actual results; Ollama structured-output documentation.  
**Independence**: 未读 critic、未调用模型、未生产编码或创建留出。

## Decision

**准许保持 v7 其余行为不变的四答隔离 pilot；无新增 Critical/High 实验设计阻塞。** [Ollama 官方文档](https://docs.ollama.com/capabilities/structured-outputs)明确建议在解码 schema 之外，也把该 schema 以字符串加入提示；同页说明 OpenAI-compatible 接口支持 `response_format`。这是有直接接口文档依据的最小用法实验，不需要改变选择算法或增加模型。

现有发送消息只提“符合 schema”，实际结构在 response_format；这支持检查消息内明确输出契约的影响，但不证明服务端内部如何处理 schema，更不证明它是三项目的遗漏的根因。官方建议也不等于本地 Qwen3.5:9b 的质量保证。

## Existing Boundaries

- 追加的是本次实际使用的同一 schema 对象的紧凑 JSON，保持 v7 字段、枚举、生成/展示顺序和语义要求；不另外加用途例子、题目关键词或正确答案。
- 作为静态 SystemMessage 内容加入，避免大括号被模板解释；只有这段契约可见性是变量，原 query/原文/来源顺序与回指合并不变。
- 原 4096 context、2048 output、none/温度 0/top_p .8、单调用和完整 stop 后原检查保持。schema 字符串增加输入成本，记录真实 prompt/completion tokens、完整首见、终态；不缩掉证据或扩大预算来掩盖其成本。
- 四答仍严格检查首节、全文动作/条件/记录/用途/未知、相关性与引用，尤其保留 v7 两份字幕的三项用途缺失。合法结构和协议完成不代替语义。

仅四答全部通过后才按原流程补齐 16；否则保存结果后停止补跑。默认 false，生产/API 对照及冻结后新留出仍未获本次许可。

# Design v9 Independent Review — Defender

**Date**: 2026-11-11  
**Object**: latest frozen `design.md` v9, including before / 须 / requires / do not; v5 saved classifications and frozen rubric.  
**Independence**: 未读 critic、未调用模型、未生产编码或创建留出。

## Decision

**准许先对已保存 v5 四答做确定性重放；无新增 Critical/High 实验设计阻塞。** 重放通过原语义判据后，可按既定设计执行四开发题 × 两来源顺序 × 两轮的 16 答真实验证。当前不批准生产接线或默认启用。

v5 已在四个输入上保留全部所问事实并正确 omit 装饰内容，但首节选择失败。v9 保持其模型分类，程序只决定已选择 step 中显式操作约束的展示位置，既不恢复被 omit 的事实，也不新推导许可。该职责分离可以用现成结果低成本检验，不需要新的模型或复杂分类/排序字段。

## Accepted Boundaries

- 冻结的是通用规范表达，不含实体、条款号、具体数值或用途动词；英文按 whole-word/已定多词表达匹配。匹配只表示“把这条完整原文移到首节”，不输出“因此允许”等推理结论。
- 原 lead 保留，只有非 omit 的 step 可因匹配上移；record/limit 不被抢入首节，omit 永不恢复。相关性仍由模型分类负责，词法策略不冒充语义筛选器。
- 被移入首节的整条原文只展示一次，前提、否定、分支与来源不截断。语义完整时，不因其没有在后文再重复而失败；首节变长也不自动失败。
- 原先字幕 reversed 的 review/return 与 preparation 顺序必须继续读实际重放正文判断。若操作前提仍无法按用户要求理解，或实际首节缺独立资格/主许可，仍按原判据失败；单纯命中词不算通过。
- v5 prompt/schema/原分句和预算保持，角色回指合并、schema 注入、自由 quote/addresses/order 不混入本候选。确定性重放不计新增真实模型样本、调用或生成 token。

## Evidence Limits

通用规范词不能覆盖全部自然语言许可，也不能补救模型把必需条款分类为 omit/record/limit 的错误。当前设计明确承认这一有限范围，并以真实全文、首节和新题效果决定是否合格，足以支持最小实验，不需另设泛化词表覆盖门禁。

重放四答仅验证这个渲染策略对已有分类的结果，不能替代后续 16 答真实模型、生产 API 或冻结后的新留出。所有旧失败保留，默认 false；不因重放零额外模型成本而提前声称整条生成机制可靠。

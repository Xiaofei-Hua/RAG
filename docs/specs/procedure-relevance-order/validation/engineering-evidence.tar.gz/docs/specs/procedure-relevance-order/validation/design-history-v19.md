# Design

## Problem and Research
只解决合格中文流程回答的无关内容与首节主规则后置。真实失败显示：数字ID或短前缀会对应错条款，模型自写问题关联会把另一事项当成回答；增加说明又造成所问记录遗漏。结构合法不能证明语义正确。
从[Kyosuke Nishida](https://www.knishida.info/publications/)的[QFE](https://aclanthology.org/P19-1225/)借鉴问题驱动抽取，从[Nicola De Cao](https://nicola-decao.github.io/)的[GENRE](https://arxiv.org/abs/2010.00904)及[SEAL](https://arxiv.org/abs/2204.10628)借鉴可读证据标识。训练/任务不同，论文不保证本地9B效果；短中间标注等失败路线与完整设计修订均保留于验证归档。

## Algorithm and Hypotheses
v17在一次JSON中对每个实际条款输出类别：main_rule/scope/step/record/limit/omit。固定键为“编号:完整原文”，值直接为有限类别，不再生成自写问题说明或自由摘要。H1：完整原文在当前分类前出现，比数字/截断前缀加自写关联更易对应真实事项。实际实验支持整个组合，不单独归因某一个字段。
程序把main_rule/scope映射为首节；只把已选step中通用明确规范表达前置，不恢复omit、不移动record/limit、不推导许可。原规范词保留，唯一补充为已复现的完成条件“完成才”，与既有“才能”同类，不使用单个“才”或实体/动作词表。各组保持资料原序，每条一次，完整原文和真实来源保留。H2：把顺序交给程序，减少模型同时概括/选取/排序的负担。
完整键的集合精确等于实际条款键；不按返回顺序、编号子串或近似原文配对。该约束只保证对应，分类本身仍可能错，因此须实际正文评测。首节长度、无害重复和措辞差异不单独判失败。

## Architecture and State
core/procedure_generation.py拥有ProcedureAnswer（dict[str,ClauseRole]）、动态schema及渲染；_clause_key是schema/render共同的完整键来源。general.yaml为唯一prompt来源，core/local_rag_generation.py复用原最终生成请求。参数none/temperature0/top_p.8/2048、context4096不变；原完整生成控制保持.7。
共同语言资格仅接受中文目标，select与prepare一致；英文原context不提前删证据。仍限合格本地loopback9B/general、明确流程、非比较、rewrite_count=0、同语种资料；其它问题回原完整生成。既有实测reranker概率可排除极弱异语资料，缺失None不当0。
完整stop→按原文组合→既有引用/PII检查一次→全文发布。Fast同步/异步/JSON/SSE和Thinking共用入口，首个正文事件是完整已检查回答。无新增shared_state键、REST字段、依赖或持久化，generation_evidence对应实际生成来源，原检索状态不由生成改写。

## Failure and Security
缺多键、错正文键、非法类别、无首节、非stop、引用/输出检查失败沿用不可用、confidence=None，不追加模型调用；取消/排队不变。资料仍是不可信引用，忽略其中指令；PII检查后才可发布。没有新增安全边界，不扩展假设性防御工作。

## Budget and Validation
分类/渲染O(全部条款字符)，完整原文键增加回显成本，但去掉了每条自写关联；不增加LLM、embedding或reranker调用，不扩大2048预算。真实机制14答最大879输出tokens，无截断；这不是任意长输入保证。核心指标为全文/首节/相关性/引用与未知处理、完整首见P50/P95、输出tokens和调用数，不要求每题每个分位数全面更优。
v16真实14答全文/相关性通过而两Toy首节失败；v17纯程序修复零模型回放14/14，只改变这两答顺序。生产红28失败42通过→绿70通过，精确回放14/14；永久golden覆盖完整真实选择、错位/未问费用与完成条件，单元+进程内E2E覆盖None降级、一次生成、原文、JSON/SSE/保存、PII和英文原路。未涉及前端；最终后端矩阵/coverage及GitHub必要UI检查仍执行。
实际API七中文题、两模式、两轮28答通过：a保留原20份语料/4题，b保留已暴露6语料/3题；对照已存同环境完整生成baseline对应槽，query/corpus/rubric未变。普通/英文已有28/28相同最终请求及回归测试，不重复未改路径的模型调用。结果与成本见results。
候选冻结后才由独立作者创作全新3题/6语料，先做segmented_enabled/select/prepare完整资格预检，再运行两模式各三轮的baseline/candidate。未知与未问未知均包含；评分仅离线。暴露/失败题转开发，保留原始失败，不修完再称为新留出。模型重复采样不当独立新题。

## Rollout and Migration
当前默认false；只有适用开发和新留出无实质退步、无新增调用且成本可接受，才改默认true并做真实默认冒烟。显式false并重启回原完整生成；fair调度不受影响。英文实验未合格，继续当前完整生成，不宣称英文首节已修。
[breaking, conditional] 默认启用仅覆盖上述合格中文流程；旧显式试用的英文流程也回完整生成。模型/远程API/比较/改写不扩大资格。README/API/部署示例同步范围、限制、结果及回滚。独立critic/defender与tracking闭环、最终矩阵和GitHub检查后合并main。

## v18 — Mixed-Clause Priority
v17新留出严格12/18，陶艺两模式各三轮均首节缺许可；全文/相关性/未知/引用18/18。实际条款3因内句“该台”等指代合并了登记、开放许可、松动与复检，被模型按占主体的步骤归step。冻结prompt却要求“混合条款选最主要类别”，与关键许可必须在首节的展示契约不一致。该留出已暴露，退为开发，默认false。
v18先修这个直接矛盾：仅把上述一句改为显式优先级“包含主要操作许可→main_rule，否则含适用范围→scope，其余才按主要类别”，确切提示见priority-key-prompt.txt。分句/指代组合、完整原文key、六类、规范词、2048预算及所有路由不变，不再补实体或新的规范词，也不生成新摘要/调用。保留整条上下文，避免为了排序拆散原有事件条件。假设单标签的主类别决策必须服从用户的主要规则先行要求，而非按句数多数表决；模型能否遵守仍须实测。
独立评审后，临时复用v17已有全部10个暴露中文题的两模式真实最终请求（20个不同上下文），唯一改动为该句。各两轮共40答，旧v17对应实际请求/答作控制；完整性、首节、无关/已问及未问未知、引用仍逐答评，不调语料/rubric。计时只比同口径最终generation wire，不冒充API首见。成功后最小prompt接线与真实golden红绿，不重复未改检索/编排的全开发API；最终冻结后独立新留出仍走真实API、两模式三轮两侧对照，满足完整链路及首见验收。此调整只减少已验证不变部分的重复执行，不放宽质量标准。

## v19 — Sentence-Internal References
v18已完成37答后因陶艺两模式两轮仍同样失败而停止，进程终止日志保留（无第38条完成wire），不能报40答完成。提高混合类别优先级并未解决；生产不采用此prompt。更底层复现为_REFERENCE.search(sentence)把任何位置的“该/其”等都当跨句指代，将“一个台面…该台…”本句内指代也回连前面的登记步骤，随后再次吞并松动和复检，放大了分类单元。
参考[LlamaIndex官方Sentence Window](https://developers.llamaindex.ai/python/examples/node_postprocessor/metadatareplacementdemo/)把细粒度选择单元与周边上下文区分的思路；其原方案是检索/窗口替换，本项目只借鉴粒度，不加索引、embedding或模型。
v19仅把原分组合并触发从search改为match：句首明显指代继续连同前句，句中出现指代不自动吞并前句。所有原句、来源与相邻上下文仍在同一次请求里，完整原文key/六类、v17原prompt、完成条件前置及预算/route不变。它不是完整指代解析器；须验证减少合并未造成条件、范围或记录遗漏，不能把拆句结构当成语义正确。
独立评审后先对陶艺Fast/Thinking两个实际输入做临时最小试验：只重分条款及相应编号/schema，原文/问题/source不变。若仍失败即停止；若通过，再对全部10暴露中文题两模式20真实上下文各两轮做对照（先导两答不作为额外独立题）。通过才做一行生产修改和失败测试红绿；永久测试同时覆盖“该次…”句首回连和“一个台面…该台…”句内指代不回连，真实golden验证首节与原文覆盖。冻结后的全新API留出仍两侧各18，不把现陶艺修好后称新留出。

# Defender Review — v13 Chinese Pilot

**Date:** 2026-11-11  
**Evidence:** `data/eval/procedure-relevance-mechanism-v13-pilot/{results,model-http}.jsonl`，逐行编号；原四个中文开发题冻结判据。独立审读全部八答，未读 critic、未调用模型或改生产代码。

## Decision

**严格 8/8，通过本轮开发 pilot。** 活动室反序的夜间申请方式、取消费用未知已恢复，其他七槽没有新的完整性、首节、相关性或引用退步。可以继续保持默认 false 的接线红绿及后续验证；此结果不等于默认资格或新留出通过。

## Per-slot Assessment

C=完整动作/条件/分支/记录及用途；L=可见首节主许可和范围；R=相关性；U=所问未知；Q=事实来源与引用；S=严格整题。依实际语义审查，不因首节长度、无害重复或隐藏标签措辞判失败。

| Row | Case / order | C | L | R | U | Q | S |
|---:|---|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | L4 / original | P | P | P | P | P | P |
| 2 | L4 / reversed | P | P | P | P | P | P |
| 3 | Archive / original | P | P | P | P | P | P |
| 4 | Archive / reversed | P | P | P | P | P | P |
| 5 | Room / original | P | P | P | P | P | P |
| 6 | Room / reversed | P | P | P | P | P | P |
| 7 | Toy / original | P | P | P | P | P | P |
| 8 | Toy / reversed | P | P | P | P | P | P |

L4 两序保留初检合格起算、350 张计数排除、换托盘重检重计、失败暂停、全部记录及目的。档案两序首节均有共同清点签名后才能阅览，候补/退回/异常未结及记录历史没有遗漏。活动室两序均有现场清点记录、签名门卡后入场，等候/改期/只改电话/门卡错误/新增损坏及记录用途完整；反序两项所问未知均为 limit 并实际展示。木玩具两序首节有全部交付条件，代领、补齐重确认、仅改地址、五组记录用途及两项未知完整。所有装饰/包装/库存等无关事实均未展示。

第 2 槽 L4 反序对价格和室外规则的 answers 仍写“未询问”，但 role=limit、正文正确保留信息边界。这说明不能把短标注视作事实证明或程序改判依据；按既定原则仅依据实际正文判通过。第 6 槽把预约号关联用途放在 scope，仍是用户所问相关事实，首节实际许可也齐全，不以分组偏好额外判失败。

## Calls and Cost

八答全部 stop/complete、每答一次最终调用。HTTP system prompt 与 `linked-unknown-prompt.txt` 完全相同，none、temperature=0、top_p=.8、2048 保持；实际 JSON 都先 answers 后 role，原始输出与保存 selection 一致。

输入 **9,376 token**、输出 **3,576 token**；完整首见 P50/P95 **4.795/5.193 秒**（线性分位数）。v12 同八槽为输入 8,712、输出 3,843、P50/P95 5.047/6.202 秒；本轮提示增加输入，但没有增加调用或观察到输出成本上升。两组均为一次开发 pilot，不宣称稳定性能收益。

## Limits and Next Step

八槽都是已暴露开发题。仍需第二轮、真实 API 对照、生产候选冻结后独立中文新留出，并含未问且与操作无关的未知说明；不能据本轮断言未知选择普遍正确。英文维持原完整路径并验证其请求控制。默认启用门槛未完成。

## Round 2 and Production Replay

已独立审读 `data/eval/procedure-relevance-mechanism-v13-round2/{results,model-http}.jsonl` 的第二轮八答。逐槽与首轮语义一致，完整动作/条件/分支/记录用途、首节、相关性、未知和引用均通过，**两轮严格 16/16**。

| Case / order | Round 1 strict | Round 2 strict |
|---|:---:|:---:|
| L4 / original | P | P |
| L4 / reversed | P | P |
| Archive / original | P | P |
| Archive / reversed | P | P |
| Room / original | P | P |
| Room / reversed | P | P |
| Toy / original | P | P |
| Toy / reversed | P | P |

第二轮八答均一次最终调用、stop/complete，输入 9,376、输出 3,576 token；完整首见 P50/P95 **4.784/5.189 秒**。两轮合计 16 次最终调用、输入 18,752、输出 7,152 token。相同提示和 temperature=0 的重复成功不等于独立新题泛化证据。

另以当前生产 `prepare_procedure` / `procedure_schema` / `render_procedure` 做零模型独立重放：16/16 条款原文、真实 raw selection、渲染正文和运行时 prompt 与存档相符；schema 约束相同（生产 Pydantic 多出的 title 元数据不作约束差异）。新的中文 golden 的 response、expected_answer、system_prompt 均对应实际木玩具原序样本。重放不计新增真实答数。生产代码评审见 `code-v13-defender.md`；真实 API 和新冻结留出仍待完成，默认保持 false。

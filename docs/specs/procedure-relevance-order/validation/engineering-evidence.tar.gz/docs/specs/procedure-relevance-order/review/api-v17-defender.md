# Defender Review — v17 API Development

**Date:** 2026-11-11  
**Evidence:** `data/eval/procedure-relevance-api-v17-{a,b}/{results,model-http}.jsonl`；完整生成基线分别为已审 `procedure-relevance-api-v13-baseline` 和 `procedure-relevance-holdout-v13-baseline` 对应两轮。独立评审，无新模型调用、无生产改动、未读 critic。

## Decision

**a 16/16、b 12/12，合计28/28按原语义标准通过，可冻结进入真正新中文留出；默认启用仍待新留出与既定最终检查。** 所选完整生成基线严格2/28，两个通过槽都是档案Fast。该严格统计要求所有所问事项完整，不意味着其余基线答案全无价值。

候选全文动作/分支/记录用途、实际首节许可与范围、相关性、已问未知、未问未知排除及引用全部通过。Toy四答首节已含三项实际交付条件；照片队徽、裁片义卖未知均排除，档案编号关联/用途保留，没有新的实质退步。

## Per-slot Coverage

每题四槽依次 R1 Fast、R1 Thinking、R2 Fast、R2 Thinking；表中每个P/F对应一条实际答案。a/b来源不同，旧行号分别按上述两个基线目录解释。

| Case | Candidate results rows | Baseline results rows | Baseline strict | Candidate strict |
|---|---|---|---|---|
| L4 | a:1, a:5, a:9, a:13 | 6, 17, 28, 39 | F / F / F / F | P / P / P / P |
| 档案 | a:2, a:6, a:10, a:14 | 7, 18, 29, 40 | P / F / P / F | P / P / P / P |
| 活动室 | a:3, a:7, a:11, a:15 | 9, 20, 31, 42 | F / F / F / F | P / P / P / P |
| 木玩具 | a:4, a:8, a:12, a:16 | 10, 21, 32, 43 | F / F / F / F | P / P / P / P |
| 温室 | b:1, b:4, b:7, b:10 | 1, 4, 7, 10 | F / F / F / F | P / P / P / P |
| 裁片 | b:2, b:5, b:8, b:11 | 2, 5, 8, 11 | F / F / F / F | P / P / P / P |
| 照片 | b:3, b:6, b:9, b:12 | 3, 6, 9, 12 | F / F / F / F | P / P / P / P |

a首轮Fast四答已全文审读；后续各槽与已审对应正文或v16原文回放比对，除已批准Toy条件前置外无新语义变化。b十二答均等于已全文审读的相应v16正文。标题、首节长度、无害重复和相关事实组别调整没有额外扣分。既有所有细节判据不变。

## Actual Request and Publication

独立重新读取原始日志核验：a保持原20份语料、b保持原6份语料；各选中case的query/sources/manual_required/lead_rubric/strict_rubric完全未变。28个最终实际请求与已审v16同case/mode的请求完全相同，确实使用完整原文key→六类enum及冻结prompt；没有评分元数据进入请求。

每侧对应槽合计70 HTTP＝28最终generation＋42原Thinking控制。Fast每答总1次，Thinking每答总4次；各答最终generation均1次，没有为质量增加调用。候选28答全为HTTP200、stop、complete，SSE拼接/done/保存正文一致。没有把回退完整生成冒充候选通过。

未重复未改英文/普通的模型调用；原28个控制的请求一致性结论和现有回归继续适用，不将其旧失败隐藏，也不为本中文改动增设全系统全优条件。

## Comparable Timing and Tokens

这里是API对API首正文，并另外独立列出最终generation HTTP end-start；没有将直接实验生成耗时与旧API首见混算。

| Mode | Baseline first-body P50/P95 (s) | Candidate first-body P50/P95 (s) | Baseline generation HTTP P50/P95 (s) | Candidate generation HTTP P50/P95 (s) |
|---|---:|---:|---:|---:|
| fast | 10.776 / 15.521 | 8.732 / 9.936 | 10.593 / 15.264 | 8.503 / 9.716 |
| thinking | 14.744 / 16.858 | 9.510 / 10.807 | 10.585 / 13.441 | 6.125 / 6.327 |
| all | 12.832 / 16.891 | 9.343 / 10.779 | 10.585 / 14.785 | 6.296 / 9.679 |

最终generation输入26422→32116 tokens，输出28667→17844 tokens；各28次。完整原文key、去answers与展示规则是组合效果，不能将收益单独归因于某一项。数据为同机顺序矩阵观测，七个已暴露题的重复不等于28个独立题。

## Boundary

代码评审见 `production-v17-defender.md`。本报告仅确认开发API准入；当前七题均已暴露，不充当新留出。随后候选已按 `freeze-v17.md` 冻结，独立新协议 `holdout-v17.json` 已交完整离线预检，未利用该新协议模型结果调整候选。


# Review Tracking

## Design Gate
独立critic与defender均已确认可进入最小机制实验，不表示默认资格已过。设计按建议明确严格整题/首节/相关性判据，并用同等任务提示比较lead-only与addresses的边际贡献；不新增模型核验或假设防御门禁。

| Finding | Requirement | Decision | Fix | Verification / regression | Status |
|---|---|---|---|---|---|
| 旧F-13/H-D01,02 | REQ-701/702 | 本轮目标缺陷，保留默认false直到实测闭环 | pending | 机制/真实API/新留出全文与首节分别判定 | accepted-for-experiment |

# Defender Review — v15 Relation Constraint

**Date:** 2026-11-11  
**Evidence:** `data/eval/procedure-relevance-mechanism-v15/{results,model-http}.jsonl`；原七题 rubric、v13/v14 已审真实对照。独立核验全部 14 份 selection 与正文，未读 critic、未调用模型、未改生产。

## Decision

**v15 严格 12/14，不能接线；条件生产方案的准入前提未成立。** v13/v14 对应样本均 13/14。照片 Fast 修复保持，但裁片 Thinking 的无关费用仍在，档案 Thinking 新增所问记录关联与用途遗漏。

C（完整相关事实）13/14；L（首节）14/14；R（相关性）13/14；已问未知14/14；未问未知排除13/14；引用14/14。无新 Critical/High 安全、调用或降级发现；两项语义失败依原定条件阻止接线，生产仍 v13/default=false。

## Per-slot Results

| Case | Fast row / result | Thinking row / result |
|---|---|---|
| L4 | 1 / P | 5 / P |
| 档案 | 2 / P | 6 / F（遗漏） |
| 活动室 | 3 / P | 7 / P |
| 木玩具 | 4 / P | 8 / P |
| 温室 | 9 / P | 12 / P |
| 裁片 | 10 / P | 13 / F（无关未知） |
| 照片 | 11 / P | 14 / P |

实际正文与 v14 逐对比对：除木玩具两槽删去无害源标题及档案 Thinking 真正缺句外，其余相同。无害标题删除未扣分，hidden answers 更具体也不自动加分。首节、分支、未知与引用逐项沿用原语义判据。

## Actual Failures

- **第 6 答新增遗漏**：`results.jsonl:6`、`model-http.jsonl:6` 中 `10:每个调阅编号关联申请档号` 被判“未询问”→omit，整个“编号关联申请档号、阅览证号和计划日期，用于对应一次完整调阅”不再展示。用户明确问每阶段记录什么、为何保存，原 v13/v14 均保留。C=F，不能因其余记录仍在而算完整。
- **第 13 答旧错未修**：`results.jsonl:13`、`model-http.jsonl:13` 的 `15:本记录没有提供义卖摊位的` 仍被判 limit，answers 从“补领费用”变成“遗失纸样补领费用”；可见正文仍加入义卖摊位报名费未知。R/O=F；所问纸样补领费用与此不是同一事项。引用真实，故不误报幻觉或引用错误。

两项记 Medium 质量问题并接受事实；不存在新的假设防御工作项。该一句约束未取得预期净增，现结果不支持把它作为生产修复。

## Request and Cost Check

14 份实际 HTTP 请求除 system 中已审的这一句外，与 v14 完全相同；schema、键、user/context 与参数均未改。raw selection 与保存值对应，全部单次 generation、stop，共 14 次新调用，无额外重试。

下表只用最终 generation 的 HTTP end-start，未混用旧 API first_body：

| Mode | v14 HTTP P50 / P95 (s) | v15 HTTP P50 / P95 (s) | Input tokens | Output tokens |
|---|---:|---:|---:|---:|
| fast | 9.348 / 11.047 | 9.324 / 11.135 | 9999 → 10370 | 5824 → 5826 |
| thinking | 6.639 / 7.698 | 6.353 / 7.604 | 8439 → 8810 | 4177 → 4179 |
| all | 7.475 / 10.451 | 8.012 / 10.929 | 18438 → 19180 | 10001 → 10005 |

输出成本基本相同（10001→10005 tokens），输入增加742 tokens；本机顺序实验时间仅作观测，不据少量波动声称稳定性能收益。完整 API 时延尚未测试，本轮失败无需进入该阶段。

## Production Disposition

所提 key helper/schema/render 和冻结 prompt 的最小接线仍以 14 答语义通过为前提；本次未满足，因此不授权业务改动、更新默认或用新 golden 掩盖上述失败。原代码、预算、资格与已批准测试边界保持，不追加全系统门槛。


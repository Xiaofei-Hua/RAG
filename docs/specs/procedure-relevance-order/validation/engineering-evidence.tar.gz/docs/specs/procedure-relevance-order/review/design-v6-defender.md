# Design v6 Independent Review — Defender

**Date**: 2026-11-11  
**Object**: `design.md` section v6; v3/v5 actual results; `core/procedure_generation.py:14,122–132`.  
**Independence**: 未读 critic、未调用模型、未生产编码或创建留出。

## Decision

**准许同档案/字幕两顺序的四答 pilot；无新增 Critical/High 实验设计阻塞。** v5 已观察到完整内容和相关性收益，但同一类别兼任首节与正文分组没有满足首节；资料原序拼装也已实际损害反序字幕的组织顺序。固定分类 + 组内 order + 单独 RuleLead 分别承担这些职责，是范围明确的组合实验，不需要新模型或在线语义补救。

独立审核资格回指也有直接原文依据：同来源先出现 `a reviewer who did not edit it`，随后 `the reviewer` 执行审批。现有 `_REFERENCE` 保留 it/that 等词，却没有把这个明确名词回指与前置资格绑定。按设计仅匹配同来源相邻组中 a/an + 1–3 词短语 + who/which/that，当前句的 the + 同短语触发合并，属于针对已复现证据边界的最小闭合尝试；不硬编码 reviewer、不跨来源或改写原文。

## Conditions Already Within Scope

- 固定槽位仅保证每条输出 section/order；分类仍可能错，排序也可能全同或不合流程。按实际正文核验完整性与可执行顺序，不用槽位数量代替语义。
- RuleLead 继续按所选完整原文渲染。回指合并使许可条款带上相关执行者资格后，首节可能较长；按冻结无害重复规则审，不新增简洁或第一句顺序门槛。合并夹带无关事实仍不得豁免。
- 保持原已有效指代边界、来源映射与中文流程规则。设计已有英文角色回指正反例和中文边界回归，应检验同源匹配与非匹配边界；这不扩展成通用共指解析或身份推断任务。
- order 只调整同组展示，不能生成新的事实；lead 前置与正文重复允许，只要完整操作的前提和分支未被改变。渲染后不得自动猜补漏条款或追加模型。
- 原 2048/none/温度 0/top_p .8、一次最终生成、完整 stop 后原检查及失败契约保持。section/order 对象和 RuleLead 都增加实际输出成本，按原指标记录 token、完整首见及结束原因。

## Pilot Interpretation

组合 pilot 若四答均通过冻结首节、全文、相关性和引用标准，再按既定设计补全 16 答；否则归档失败后停止补跑。它只能证明该组合在本批的结果，不能把全部收益分别归因于排序、分类或回指合并。当前 false 保留，生产接线/真实 API/新留出仍在后续阶段。

# Design v21 Critic Review

**Date**: 2026-11-12  
**Scope**: 独立审读 design.md 的 v21、`validation/orthogonal-opening-prompt.txt`，与当前v19生产prompt逐段比较；未调用模型或修改生产。上轮失败见[机制v20](mechanism-v20-critic.md)。

## Decision

**准入广播两份原真实输入的最小先导；两答都通过才继续13题52答。** 新增Critical/High: 0；F-16仍open、默认false。尚未批准生产接线或默认启用。

修订确实保留v19六类完整说明，只调整格式并追加正交首节判断。role唯一控制保留/省略，false不再暗示omit；step可以同时为true，补上已复现的自然许可；record/limit仍完整后置，omit不会被标志复活。相对v20，这隔离了“保持哪些事实”与“把已选许可放到哪里”的渲染决策，不再为修位置而替换整套已验证的记录分类。

仅将布尔信号用于step，并与原规范词前置取并集，是本次已复现错误的最小范围。main_rule/scope及record/limit原行为、四节展示不变，不需要新子问题解析器或提前扩张其他类别。两维同次生成仍可能相互影响，原role并非因格式保留就保证预测不变；先导必须实际检查Fast来源2的所有记录和用途，而不能只看unit4变true。

## Representation and Validation

[JSON Schema官方数组说明](https://json-schema.org/understanding-json-schema/reference/array)支持按位置使用prefixItems分别约束tuple成员；配type=array、两项的minItems/maxItems，可表达第一项六类enum、第二项boolean。固定二元值没有额外复写完整键，也没有自由长度选择列表，适合当前少量结构成本的目标。

但标准可表达不代表当前format-backport引擎必然支持全部关键字。**直接在已计划的两次真实调用核对wire返回即可证伪**：格式被拒、元素/类型不符或生成不完整即先导失败；不另设兼容性门禁、不开展引擎开发、不增加一轮探针。实际输出tokens/耗时仍按none/0/.8/2048原预算记录，不能因为多一个布尔值就预先声称成本可忽略。

保留两份原输入全部来源：Fast第三份剧场记录、同文窗帘和未问比赛截止均在。首节实际许可与范围、全文所有动作/记录/用途、已问未知、无关内容排除和引用均沿原rubric。原准备登记若一并前置不单独失败；但不得预填正确role、恢复omit或把所有正文当首节。两答通过只支持扩展已批准的52答；之后仍需真实golden红绿、重新冻结和真正新留出。

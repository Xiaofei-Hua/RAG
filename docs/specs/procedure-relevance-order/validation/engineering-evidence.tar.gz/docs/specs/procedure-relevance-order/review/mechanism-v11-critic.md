# Mechanism v11 Critic Review

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v11-pilot/{results,model-http}.jsonl`，14槽实际正文、JSON选择和HTTP终态。独立使用冻结开发rubric，未读defender、未调用模型。

## Decision

**v11不合格，严格5/14，不扩大第二轮或接生产；默认false。** 自然语言lead修复了木玩具两序及联赛原序的实际许可，但档案两序仍把申请/取卷当作首要前提，缺共同清点签名的交接门槛；联赛反序首节缺排除范围。五个已完成回答仍带入装饰，另两答引用数组重复至length而不可用。F-16/F-17未闭环。

## Slot Review

Full/Lead/Relevant/Citation分别审；P/F为通过/失败，—表示无可发布正文，语义不可评，不记作0分。不可用槽不通过整题。

| Slot | Case | Order | Full | Lead | Relevant | Citation | Strict | Observation |
|---:|---|---|---|---|---|---|---|---|
| 1 | R7 | original | P | P | P | P | P | 规则、起算、换头、停机及未知完整。 |
| 2 | R7 | reversed | — | — | — | — | F | source_ids重复至2048 length，无正文发布。 |
| 3 | L4 | original | P | P | P | P | P | 首节许可及全文计数/换托盘/用途完整。 |
| 4 | L4 | reversed | P | P | P | P | P | 条款分组不同，所问内容均保留。 |
| 5 | Archive | original | P | F | P | P | F | 首节停在登记/核对/在库/取卷，缺交接清点签名。 |
| 6 | Archive | reversed | P | F | P | P | F | 同上；后文正确交接不能补首节。 |
| 7 | Caption | original | P | P | F | P | F | 首节含独立审核和同版本批准，正文带银色边框。 |
| 8 | Caption | reversed | P | P | F | P | F | 全部条款标record，带银色边框；首节仍给流程顺序。 |
| 9 | Room | original | P | P | P | P | P | 入场交接门槛、分支与记录用途完整。 |
| 10 | Room | reversed | — | — | — | — | F | source_ids重复至2048 length，无正文发布。 |
| 11 | Toy | original | P | P | F | P | F | 首节三项交付条件正确，正文带蓝点。 |
| 12 | Toy | reversed | P | P | F | P | F | 同上；范围虽分到limit，仍完整呈现。 |
| 13 | League | original | P | P | P | P | P | 首节范围排除及双方确认/异议解决许可完整。 |
| 14 | League | reversed | P | F | F | P | F | 首节只列肯定范围，无排除；正文带酒红横幅。 |

12个完成槽中Full 12/12、Lead 9/12、Relevant 7/12、Citation 12/12，严格5/12；其余2槽不可用，不能从分母隐藏。Caption首节的同版本批准与“reviewer who did not edit it”均在同一首节，不能另加第一句必须全含的要求。League反序首句为“apply to in-person, untimed rounds at the club”，无only或ranked/remote排除，按基线复核的同一语义标准失败。

legacy全部条件首节标准单列：R7原序通过，L4两序未包含全部复查计数/重启或未知边界，R7反序不可用；不回改旧失败记录。正文保留完整不等于首节合格；原文装饰被保留也不等于相关。

## Calls and Cost

14条HTTP均为generation、每答1次；12次stop，2次length，无额外补答调用。`results`的SDK异常槽usage为空，但原始HTTP明确各消耗2048输出tokens，不漏算成本。

| Scope | n | P50 / P95 elapsed s | Mean output tokens |
|---|---:|---:|---:|
| All attempts | 14 | 3.614 / 20.482 | 562.71 |
| Completed | 12 | 3.559 / 4.727 | 315.17 |

R7/Room反序约20.466/20.511秒，raw均已完成lead文字后在`source_ids`持续重复；本次schema只有实际ID enum和minItems=1，没有数组上限。其余完成槽也常输出8–16个重复ID，由既有渲染去重。限制引用列表大小属于已复现成本缺陷的最小修复，但即使解决截断，档案首节与装饰混入仍足以否决v11；不能只修数组后宣称质量合格。

**praise (non-blocking)**：自然语言首节能表达无需整组单标签承载的许可，完整原文保住所有完成槽的所问事实。这证明分工有部分价值；当前联合生成同时影响分类和引用解码，尚无稳定净收益，不支持继续扩大验证。

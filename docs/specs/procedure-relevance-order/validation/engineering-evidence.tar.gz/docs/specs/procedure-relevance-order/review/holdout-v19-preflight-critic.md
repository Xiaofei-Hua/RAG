# Holdout v19 Preflight Critic Review

**Date**: 2026-11-12  
**Target**: 冻结v19候选与 `validation/holdout-v19.json` r2。独立审协议并运行完整资格预检；未读新留出模型输出或defender评测结论，模型/网络调用0，未改候选或语义判据。

## Decision

**通过，可启动baseline false / candidate true各18答（三题×两模式×三轮）。新增Critical/High: 0。** 17:44:57 CST完成零模型复检并在正式题目生成前通知root；这里只批准实验准入，不批准默认。

候选冻结于09:33:05 UTC；新协议由独立作者于09:42:33 UTC创建。先前空prompt的done_reason=load只加载权重，不是新题生成。实际生成开始后，问题/资料/rubric及候选均保持冻结。

## Full Route and Evidence Eligibility

使用实际 `segmented_enabled`、`select_procedure_evidence`、`prepare_procedure`，配置general/bounded/本地qwen3.5:9b/loopback:11434/v1、rewrite_count=0。正常来源名与原文经 `render_untrusted_evidence` 包装；没有真实检索分数时保留同语种资料，没有虚构高分或把None当0。

| Case | Enabled | Selected | Prepared units | Source IDs | false side enabled |
|---|---|---:|---:|---|---|
| Spoken audio | true | 2/2 | 18 | 1,2 | false |
| Doubles assignment | true | 2/2 | 17 | 1,2 | false |
| Light cues | true | 2/2 | 17 | 1,2 | false |

另以全部六来源对三题分别运行完整select/prepare，均6/6、52条、真实1–6来源映射。正常API仍从全六份上传资料检索，case.sources不是强制过滤器。此处只证明资格与输入准备，不声称六来源的生成质量或token预算已经通过。结果存 `validation/holdout-v19-preflight-results.json`。

## Pre-generation Correction

r1灯光题query的“哪一版能作为执行单”实际命中既有比较启发式“哪一”，segmented_enabled=false；另外两题true。select/prepare本身不能代替这项入口检查。

在任何题目模型生成前，root保存 `holdout-v19-r1.json`，仅将该短语等义改为“成为执行单的条件”，并更新revision/status、记录 `holdout-v19-preflight-revision.md`。我逐字段复核：corpus、所有rubric、其它query与资料均未变，候选路由规则未改。r2三题完整资格全过；没有根据答案表现修改题意或简化要求。既有F-15所要求的完整预检在本轮实际发挥作用。

## Semantic Fairness

三题分别检验播单当前文件的整段试听/另一编辑签记及旧单更正通知，双人队签到/唯一归属/桌号与版次签字，排练提示的导演时机确认/全提示点试走/同版签收与未完交接。具体动作与状态依赖不同于已暴露题，不只是替换实体；主要许可保持自然表达，未按本次match修复重写语料或强塞新规范词。

所有必答项均来自用户所问及资料事实。首节只要求实际主要许可与一般范围；后续局部异常、记录字段与用途可在后文完整展开。长首节、正常标题及无害重复不单独失败，不新增题外竞赛/灯具规则或全系统全优门槛。

| Case | Asked unknowns | Unasked exclusions |
|---|---|---|
| Spoken audio | 单段时长上限、补录截止 | 窗帘、比赛投稿截止 |
| Doubles assignment | 迟到等候时长、补证费 | 会刊封面、讲座报名费 |
| Light cues | 同场重试上限、提示单电子版留存 | 折叠椅、纪念册保存期限 |

正常runner只上传corpus并提交query/session/mode，coverage/manual_required/rubric/freeze等评审信息保持离线。正式结果仍需逐答审实际全文、首节、相关性、所问/未问未知、引用及真实调用和API首见。

**praise (non-blocking)**: 同类未知词分别绑定不同事项，可检验实际问题关联；预检在生成前识别并修正非目标路由表达，完整保留语料与语义判据。

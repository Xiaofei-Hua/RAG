# Mechanism v5 Critic Review

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v5-pilot/{results,model-http}.jsonl`；冻结development rubric未改。未读defender、未调用模型。

## Decision

**pilot严格0/4，不补跑当前路线，不接生产。** 四答全部保留所问事实/记录/用途/未知，排除墙钟、年鉴和告示板等干扰，真实引用正确；但首节四答均未满足原规则。字幕反序另有步骤呈现倒序。

| Slot | Case/order | Coverage | Lead | Procedure order | Relevant/citation | First body s | Tokens |
|---:|---|---|---|---|---|---:|---:|
| 1 | Archive/original | P | F | P | P/P | 2.136 | 158 |
| 2 | Archive/reversed | P | F | P | P/P | 2.164 | 158 |
| 3 | Caption/original | P | F | P | P/P | 1.799 | 131 |
| 4 | Caption/reversed | P | F | F | P/P | 1.872 | 131 |

四次HTTP均generation、单调用、stop，结果complete。Coverage仅指所问内容覆盖；第4槽不因此被称为完整可执行的顺序说明。四答首轮不能当成16答稳定验证，也不把分批耗时当线上相对收益。

## Evidence

- 档案两答首节只给开放纸档/工作日馆内/不外借，清点签名后才能阅览在操作节。编号关联、各阶段记录用途及两个未知项本轮都保留。
- 字幕原序首节只有范围；反序首节**已有同一音频/字幕版本批准后才能发布**，不能概括为纯scope-only，但独立审核条件仍在后节。两个首节都不满足冻结条件。
- 字幕反序Procedure先显示“The reviewer records approve or return...”及退回重做，再显示“Before starting a caption draft...”准备/编辑，违背所问步骤顺序。原文事实未被改写，问题来自分组后保留跨资料原序。

## Findings

### F-10 — Fixed Slots Preserve Coverage but Not the Required Lead

- **Label**: issue (blocking, must-fix)
- **id**: F-10
- **severity**: Critical；critic §2(a)，首节目标在全部pilot回答复现。
- **location**: 槽1–4；REQ-702/705。
- **symptom**: lead分类没有实际收纳阅览许可或完整发布资格。
- **impact**: 用户指定首要规则仍被后置。
- **root_cause**: 单一类别把范围与操作/角色条款分开，完整逐条决定不保证首节语义。
- **recommendation**: 当前v5不接线；保留覆盖收益，重新设计首节责任。
- **verification**: 原rubric下实际首节含档案交接许可、字幕同版本批准与独立资格，并保全全文。
- **status**: open

### F-11 — Source Order Is Not Procedure Order

- **Label**: issue (blocking, must-fix)
- **id**: F-11
- **severity**: High；已复现来源顺序边界下的流程编排失效。
- **location**: 槽4的Procedure；字幕manual_required的准备/编辑/审核顺序契约。
- **symptom**: 审核退回先于起草准备展示。
- **impact**: 内容齐全但不能按所问步骤顺序阅读执行。
- **root_cause**: 同组条款按资料原序排列，资料顺序与操作先后无关。
- **recommendation**: 下一实验显式处理流程顺序，不能仅以类别齐全验收。
- **verification**: 反来源顺序仍先准备与编辑/检查，再审核及后续变更；事实条件和记录用途不丢。
- **status**: open

# Mechanism v6 Critic Review

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v6-pilot/{results,model-http}.jsonl`。独立只读，未读defender、未调用模型；冻结rubric不变。

## Decision

**严格0/4，当前组合不补跑、不接生产。** 四答所问内容均有覆盖、引用正确，但只有档案原序排除干扰；该答首节又缺阅览许可。其余三答所有分类都变成step，order直接等于原ID。

| Slot | Case/order | Coverage | Lead | Relevant | Citation | Strict | First body s | Tokens |
|---:|---|---|---|---|---|---|---:|---:|
| 1 | Archive/original | P | F | P | P | F | 5.843 | 507 |
| 2 | Archive/reversed | P | P | F | P | F | 8.038 | 732 |
| 3 | Caption/original | P | P | F | P | F | 5.161 | 451 |
| 4 | Caption/reversed | P | P | F | P | F | 4.794 | 413 |

四次HTTP均单次generation、stop，结果complete。Coverage不等同流程编排通过；字幕反序Procedure仍先列审核/退回与记录，再列准备/编辑，数字order没有修正资料顺序。

## Observations

- 档案原序lead只选范围条款1，清点签名后的阅览许可仍在后节。
- 档案反序把17条全部设step，墙钟/年鉴进入正文；字幕两序把13条全部设step，银色告示板边框进入正文。不是仅分类标签不好看，而是已展示明确无关事实。
- 字幕两序的实际首节均含未参与编辑的审核者及同版本批准规则，符合原首节判据。rule_quote本身仍可能只摘发布句，但选中的合并原文保住了资格。这是边界修复值得隔离验证的正向观察，不代表整套分类成功。
- 三答首节较长仍按冻结判据判P，没有新增长度或首句要求。所有旧失败保留。

## Finding F-12

- **Label**: issue (blocking, must-fix)
- **id**: F-12
- **severity**: Critical；critic §2(a)，相关性/首节目标仍实际复现。
- **location**: 槽1–4；REQ-701/702/705。
- **symptom**: 一答首节漏许可，另三答全step导致干扰被展示。
- **impact**: 无一答同时满足首节与相关性，不能作为合格候选。
- **root_cause**: 更复杂的section/order槽位在本模型样本中未形成有效分类；ID齐全与合法排序不足以保证语义。
- **recommendation**: 否决v6组合，保留角色回指的正向观察供已批准隔离实验验证。
- **verification**: 隔离实验仍按原四维判据，不以资格回指合并成功替代整答通过。
- **status**: open

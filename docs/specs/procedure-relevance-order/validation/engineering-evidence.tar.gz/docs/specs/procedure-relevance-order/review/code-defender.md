# Production Code Review — Defender

**Date**: 2026-11-11  
**Scope**: 当前 tracked diff：`core/procedure_generation.py`、`core/local_rag_generation.py`、`data/profiles/general.yaml`、流程 unit/API/golden。  
**Independence**: 未读 critic，未调用真实模型、改业务代码或创建留出。核验已存红绿日志，并独立用生产代码重放 v9 的 16 份选择。

## Decision

**未发现 Critical/High 或其他需要阻塞本次接线的代码问题。** 实现保持已批准 v9 的效果机制，支持继续既定真实 API 对照；默认仍 false，新留出与最终默认决策尚未完成。

## Implementation Review

- `core/procedure_generation.py:27`、`:32`：严格五类别映射与实际 ID 的 required properties 配合，缺键/额外键不会默默变成遗漏正文；没有自由标题或自由事实输出。`core/local_rag_generation.py:92` 直接使用此 schema，生成参数、同步/异步单调用未变。
- `core/procedure_generation.py:175`：先验证完整分类，再只对 step 中冻结的通用规范表达前置；record、limit 和 omit 不受词命中影响。无 lead 检查在前置后，符合实验。四组按原 units 顺序输出，每条只出现一次，来源来自实际 unit，全文原句没有截断、改写或补推理。扫描次数为常数倍 n，没有新排序/模型调用。
- `core/procedure_generation.py:165`、`:188`：语言取自已通过原资格过滤的证据；原资格过滤已对齐所需输出语言。固定中英标题正确，`条件与边界 / Conditions and boundaries` 容纳已知失败规则与未知事项混合条款，解决 V9-D01 的标题问题，不影响分类。
- `data/profiles/general.yaml:28`：接入的是 v5/v9 已测提示，没有加入角色回指合并、schema 文本或额外语义字段。普通比较、rewrite、非流程和跨语资格不足的完整生成路径未修改；`core/segmented_generation.py:36` 默认仍 false。
- 非 stop、非法类别/槽位、无可见 lead 在现有发布入口转不可用；`core/segmented_generation.py:144` 的完整生成/输出检查及异常终态仍承接这些失败，没有追加生成。已有 JSON/SSE 路径继续保存同一正文和完成性，失败 confidence 为 None，不作 0 分。

## Verification

已检查 `validation/red.log` 的 **22 failed / 34 passed** 与 `validation/green.log` 的 **56 passed**。定向矩阵对应 `tests/unit/test_procedure_generation.py`、`tests/e2e/test_segmented_api.py`；本评审未无理由重跑已绿矩阵。

`tests/unit/test_procedure_generation.py:30` 校验完整 golden、实际 schema/提示、预算及同步/异步单调用；`:103` 覆盖缺失/额外槽位、非法类别、无 lead、非 stop 与检查失败，只发布完整合格正文或不可用终态。`:304` 的中英文回归同时验证 step 前置、record/limit 不动、omit 不恢复、无重复、中性标题，以及没有原生 lead 仍可由前置形成首节。

`tests/e2e/test_segmented_api.py:13` 的 Fast/Thinking × JSON/SSE × 完成/截断 × 流程/含噪流程/普通路径矩阵复用新 golden；`:122` 新增实际首节许可/范围断言，`:129` 起验证保存/历史/完成性、一次最终生成和失败 None。这些测试验证接线和契约，不冒充模型语义评测。

另外通过 `uv run --frozen --no-sync python -c` 做零模型确定性重放：对 `data/eval/procedure-relevance-mechanism-v9` 的 16 份实际分类重新执行生产 `prepare_procedure`、`procedure_schema` 和 `render_procedure`。**16/16** 的 units、schema、system prompt 与实验一致，生产正文均等于实验正文仅将末节标题替换为已批准中性标题后的结果；无其他正文变化。此项直接确认适配器接线等价，不计新模型样本。

## Remaining Work

V9-D01 的呈现修正已有代码、回归与上述重放证据；最终 tracking 的提交闭环由主流程记录。分类可能遗漏/误分、词法前置不涵盖所有表达这些既知算法边界，仍由原定真实 API 多轮和冻结后新留出检验；本评审不增设泛化词表或异常门禁，不提前批准默认启用。

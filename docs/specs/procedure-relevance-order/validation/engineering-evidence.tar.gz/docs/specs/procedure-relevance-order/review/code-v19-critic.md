# Production v19 Critic Review

**Date**: 2026-11-12  
**Scope**: 冻结v17→v19生产差异、真实陶艺golden、单元/E2E红绿及生产回放记录。独立审读，未读defender结论、未调用模型，未无理由重跑已通过矩阵。

## Decision

**接线通过，新增Critical/High: 0；允许冻结后的独立新留出资格预检及真实API对照。默认仍false，F-16的最终闭环和默认资格等待新留出。**

- 生产唯一差异为 `core/procedure_generation.py:155` 的 `_REFERENCE.search(sentence)`→`.match(sentence)`；strip、分句、来源、完整键/schema、分类渲染与错误降级均未改。`local_rag_generation.py`、`segmented_generation.py`、`general.yaml`与v17相同，未混入失败v18提示或增加调用。当前相关文件与v19冻结归档一致。
- 新同步/异步测试用实际陶艺Thinking原文与真实selection，先断言许可独立单元，再通过正常generation_chain检查完整正文、实际首节许可、无关项省略、一次最终调用及真实schema完整键。不是只测regex布尔值，也未用人工改写selection制造通过。
- 新golden的units、sources、response与已独立通过的v19实际第2槽相同，期望正文是该真实答案去掉API层统一提示后的完整内容。旧昆虫/拼布两份fixture语义完全未变，文件较大diff来自JSON重排及新增陶艺案例。
- 既有 `test_chinese_procedure_keeps_event_boundaries` 明确覆盖“先检查样张。该次合格后开始计数。”仍合在同一条，搭配新句内指代不回连测试覆盖实际修改两侧。原非法结构/非stop/None、一次调用、英文原路、omit和PII/JSON/SSE/保存测试继续存在。
- 已审红绿日志：新同步/异步用例在旧分组下均因许可混入登记失败（2 failed），接线后完整定向单元+进程内E2E **72 passed**。生产回放记录为20个真实请求的units/context/schema与实验一致、40个正文回放一致、零模型调用；这证明接线，不能替代留出语义。

冻结时间为 `2026-11-12T09:33:05.038205+00:00`。下一步先对新题完整执行segmented_enabled/select/prepare，并以未修改语义判据做真实false/true各18答；最终测试矩阵/默认实际调用仍依原计划，不因本代码评审提前批准默认。

**praise (non-blocking)**: 已证实的句内回指错误以一行收敛修正，保留句首事件边界，并用真实许可/正文回归固定实际收益。

## Final Matrix Record

已审 `validation/v19-backend-matrix.log`：1336 passed、6 skipped、3项既有warnings，branch coverage75%。这里只核对既有运行证据，未重复执行。

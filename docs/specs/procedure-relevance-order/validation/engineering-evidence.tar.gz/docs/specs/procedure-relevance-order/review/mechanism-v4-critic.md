# Mechanism v4 Critic Review

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v4/{results,model-http}.jsonl`。独立只读核验，未读defender、未调用模型。

## Decision

**v4不合格，支持停止剩余实验，不进入生产。** 实际已落盘4答，不能写成3答或全部失败：R7两答length，L4两答stop。4次均为单次generation调用。

| Slot | Case/order | Finish | Completion tokens | Elapsed s | Visible result |
|---:|---|---|---:|---:|---|
| 1 | R7/original | length | 2048 | 20.611 | unavailable，generation_complete=false，first_body=null |
| 2 | R7/reversed | length | 2048 | 20.502 | unavailable，generation_complete=false，first_body=null |
| 3 | L4/original | stop | 846 | 9.384 | 完整发布；全文、首节、相关性、引用均通过冻结判据 |
| 4 | L4/reversed | stop | 908 | 9.889 | 完整发布；全文、首节、相关性、引用均通过冻结判据 |

R7的原始响应都停留在第一个段落的clause_ids数组，连续重复相同长标识，分别为带`[条款1]`或`[条款9]`的运行规程前缀，直至2048上限；没有完整lead或可发布正文。两答prompt均1152 tokens。失败被标为不可用，未把半JSON发布成完成答案；语义维度为不可评，不是0分。

L4两答保留首次许可、350正式标签/排除项、事件起算、更换与失败恢复、记录字段/用途及环境/价格未知，没有选入包装库存，原文引用正确。其通过不能抵消R7同样输入已由v3成功生成、v4却重复耗尽预算的退步。当前仅4个首轮槽，不宣称16答实验完成或估计总体成功率。

## Finding F-09

- **Label**: issue (blocking, must-fix)
- **id**: F-09
- **severity**: High；候选在正常流程输入下出现已复现生成失败，热路径生成组件适用critic §2下限；已有不可用降级保持，未见向外错误发布。
- **location**: 本批HTTP/result槽1/2；REQ-703/704/705。
- **symptom**: 两种来源顺序均重复同一长enum，2048 tokens耗尽，约20.5秒后无完整正文。
- **impact**: 相比既有短ID成功路径产生可用性和成本退步。
- **root_cause**: 实际解码陷于开放选择数组的长标识重复；本证据不证明所有可读标识或其他模型都有同样问题。
- **recommendation**: 否决本候选并保留原始失败；停止剩余12槽，维持默认false，不通过抬高预算掩盖重复。
- **verification**: 后续不同机制须在原输入和预算下真实完成，并通过冻结语义判据；此报告未执行后续实验。
- **status**: open

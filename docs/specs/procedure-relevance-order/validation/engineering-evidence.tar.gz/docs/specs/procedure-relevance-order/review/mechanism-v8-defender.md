# Mechanism v8 Pilot Independent Review — Defender

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v8-pilot/{results,model-http}.jsonl`; one-based rows.  
**Independence**: 完整审读四答和实际请求/响应，未读 critic、未调用模型、未改判据或创建留出。

## Decision

**v8 严格 1/4，不合格。** 档案 original 通过；reversed 首节把申请准备选成开始阅览的主要规则；字幕两序仍漏脚本匹配、全程播放、独立审核三项目的。全文完整性 2/4、首节 3/4、相关性/引用各 4/4。不能将 schema 可见性建议当成已解决语义遗漏的证据。

| Row | Case / order | Complete | Lead | Relevant / cited | Strict | Body time (s) | Completion tokens |
|---:|---|:---:|:---:|:---:|:---:|---:|---:|
| 1 | 档案 / original | P | P | P / P | P | 5.4269 | 473 |
| 2 | 档案 / reversed | P | F | P / P | F | 4.3849 | 388 |
| 3 | 字幕 / original | F | P | P / P | F | 5.1023 | 446 |
| 4 | 字幕 / reversed | F | P | P / P | F | 5.8883 | 541 |

**V8-D01 — High, accepted/open:** 第 2 答首节 rule ID 11 是填写调阅单/出示证件；交接清点签名后才能阅览的条款 15 仅在后续交接段。标题声称主要规则不补足正文。全文并未明示仅申请即可阅览，不夸大为不存在的错误许可，但首节确为相对 v7 的实质退步。

**V8-D02 — High, accepted/open:** 第 3/4 答仍缺匹配脚本避免旧稿、全程播放发现相邻 cue 遗漏、独立审核分离编写与发布三项目的。记录、动作与退稿历史用途保留，不能替代这三项。两答首节实际独立资格与同版本审批均在，不因隐藏 quote 省略角色而否定正确可见原文。

档案两序全文动作/分支、编号及核对/交接/归还/异常记录、三项用途和两项未知均齐；字幕除上述目的外的阻塞/返修/版本变更/拼写例外、identifier/全部草稿链接、记录和未知也齐。四答没有墙钟/年鉴/银框，无害重复不单独判失败。

## Actual Contract and Cost

四条真实 system message 均包含与 response_format 同一 schema 的紧凑 JSON 字符串，实验变量实际生效。每答一次生成、stop；参数均 qwen3.5:9b、temperature 0、top_p .8、none、2048。合计 **1,848 completion tokens**、**5,668 prompt tokens**；相对 v7 四答增加 1,576 prompt tokens，却未修复用途并新增首节退步。未追加调用或扩大预算。

停止 v8 补跑，保留全部证据与当前 false。仅说明本次 schema 注入没有达到任务效果，不否定其作为一般结构化输出用法的价值。

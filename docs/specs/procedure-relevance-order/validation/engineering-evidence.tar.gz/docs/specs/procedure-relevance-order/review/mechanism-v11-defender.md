# Defender Review — v11 Pilot

**Date:** 2026-11-11  
**Evidence:** `data/eval/procedure-relevance-mechanism-v11-pilot/{results,model-http}.jsonl`，逐行编号；7 个已暴露开发题冻结判据。独立审读全部 14 槽，未读 critic、未调用模型或改生产代码。

## Decision

**v11 不合格，严格 5/14，不扩大第二轮或接生产，默认继续 false。** 自然语言首节改善了木玩具和联赛的实际许可表达，但档案两序仍缺交接放行规则；原文选择在五槽带回装饰事实；另两槽因来源编号重复到 length 而不可用。

## Per-slot Assessment

C=全文动作/条件/记录用途/未知完整；L=首节主要许可与范围；R=相关性；S=严格整题。未发布正文记 N/A，不将不可用当作 0 分。12 个完整正文的来源均实际存在，原文引用支持对应事实；长首节、必要重复、等义改述不单独失败。

| Row | Case / order | C | L | R | S | Concrete result |
|---:|---|:---:|:---:|:---:|:---:|---|
| 1 | R7 / original | P | P | P | P | 主规则、范围、细节完整 |
| 2 | R7 / reversed | N/A | N/A | N/A | F | source_ids 重复至 2048 length，无正文 |
| 3 | L4 / original | P | P | P | P | 主规则、范围、细节完整 |
| 4 | L4 / reversed | P | P | P | P | 同上 |
| 5 | Archive / original | P | F | P | F | 首节缺共同清点签名后才阅览 |
| 6 | Archive / reversed | P | F | P | F | 同上 |
| 7 | Caption / original | P | P | F | F | 银色告示板框进入记录 |
| 8 | Caption / reversed | P | P | F | F | 同上 |
| 9 | Room / original | P | P | P | P | 入场许可、范围、细节完整 |
| 10 | Room / reversed | N/A | N/A | N/A | F | source_ids 重复至 2048 length，无正文 |
| 11 | Toy / original | P | P | F | F | 蓝色页脚圆点进入记录 |
| 12 | Toy / reversed | P | P | F | F | 同上 |
| 13 | Match / original | P | P | P | P | 发布许可、范围、细节完整 |
| 14 | Match / reversed | P | P | F | F | 酒红横幅进入记录 |

## Findings

- **High — actual lead omission, rows 5/6:** 首节用申请、证件核对、在库且无冻结、建立编号和安排取卷说明“开始阅览的前提”，缺少双方共同清点卷数并签名完成交接的实际放行条件。后文保留规则，故不误报全文丢失；首节仍未完成用户明确要求。
- **High — unrelated facts, rows 7/8/11/12/14:** 装饰条款被标 record 后完整显示。字幕反序和联赛反序出现整组全 record，说明 clauses 先生成并未稳定保持 v10 的相关性收益；合法引用不使装饰与用户办理问题相关。
- **High — unavailable answers, rows 2/10:** 原始响应在 lead.source_ids 循环输出真实编号，最终 length；两槽仅一次调用、无发布正文。该问题是实际生成失败，不能以去重后的部分 lead 或原文细节推定成功。其他已完成槽也有重复编号，渲染后去重且正文有支持，不因此另扣语义分。

字幕两答在同一个可见首节中既保留同音频/字幕版本批准，也说明 reviewer 未参与编辑，语义首节通过；不要求资格与批准必须紧邻或逐字匹配。联赛反序的 practice league 与 in-person、untimed、at the club 共同表达该实践联赛的范围，接受整体语义，不因没有再逐字写排除句另判首节失败；横幅是独立、明确的失败。

自然语言首节解决部分混合条款问题的收益成立，但没有达到完整稳定的首节与相关性要求。12 个可用答的相关原文细节都保留，首节 10/12 通过，相关性 7/12 通过；不能把这些条件统计当成 14 槽整体合格。

## Calls and Cost

实际 14 次最终调用，每槽一次；none、temperature=0、top_p=.8、2048 不变。12 个完整 JSON 的实际顺序均为 clauses→lead。HTTP usage 合计输入 **14,264**、输出 **7,878** token，包含两次失败各 2,048 token；没有把失败成本漏算。

12 个可用答完整首见 P50/P95 为 **3.559/4.727 秒**（线性分位数）；两次无正文失败耗时分别 **20.466/20.511 秒**，first_body_s 为 None，不能按 0 混入延迟分位。这里是一次开发 pilot 的观察值，不是稳定性能承诺。没有新模型验证调用，生产仍未修改。

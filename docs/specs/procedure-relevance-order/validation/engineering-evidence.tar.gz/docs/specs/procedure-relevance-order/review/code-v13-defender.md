# Defender Code Review — v13

**Date:** 2026-11-11  
**Scope:** 当前 tracked diff 六文件：`core/procedure_generation.py`、`core/local_rag_generation.py`、`data/profiles/general.yaml`、unit/API 测试及中文 golden。独立评审，未读 critic、未调用真实模型或修改生产代码。

## Decision

**未发现 Critical/High 代码阻断，可以继续保持 default=false 的真实 API 验证。** 两轮机制独立严格 16/16；当前实现与已测选择、原文和呈现语义一致。API 和冻结后新中文留出尚未完成，不批准默认启用或宣称交付验收完成。

## Algorithm and Behavior

`ProcedureClause`（`core/procedure_generation.py:27`）严格限制 answers 的长度与六类 role，动态 schema 为每个实际条款建立必填槽位。`render_procedure`（:174）核对真实键集合，只使用 role 决定呈现；main_rule/scope 归 lead，只有原先 step 的规范词条款前置，record/limit 不挪、omit 不恢复。它从原 units 按来源顺序组合一次完整原文，并从实际 source_id 生成引用，answers 不泄漏也不被当成语义校验依据。

`_eligible_evidence`（:92）在共同边界拒绝非中文目标语言；select（:125）和 prepare（:133）均受该边界约束，故英文回退前不会先删去弱异语证据。原概率来源判定、强同语种与极弱异语条件未变，None 不被当作 0。原分句与指代分组未改，中文 source/question 资格、比较、rewrite 和非明确流程边界继续沿用。

`build_generation_request`（`core/local_rag_generation.py:64`）只替换 procedure schema，仍用一次 invoke/ainvoke；不可用 procedure 使用原 inputs、GroundedAnswer 与 .7 温度。运行时 general.yaml 内容与批准并真实测试的 linked-unknown prompt 相同，没有第二份在线解释或额外生成。`LOCAL_RAG_SEGMENTED` 默认仍为 false，显式 false 路径保留。

## Verification

- 已检查归档红绿日志：`validation/v13-red.log` 为 **23 failed / 42 passed**，`v13-green.log` 为 **65 passed**。不重复全量测试；现有定向矩阵覆盖单元与进程内 Fast/Thinking、JSON/SSE。
- 新英文回归（`tests/unit/test_procedure_generation.py:413`）同时断言 select 返回原 evidence、完整 context、原 schema、.7 温度与单调用；不是只检查语言判断函数。
- 单元故障用例涵盖缺/多槽、非法 role、缺/过长 answers、无 lead、length 和输出检查失败，验证完整不可用发布与单调用。API 用例核对 token/done、保存正文与历史状态一致，非 stop 的 confidence 为 None，并保留真实输出检查和 PII 处理。
- 中文 golden 来自真实 v13 木玩具输出，已人工核对实际交付许可、范围、返工分支、记录用途和所问未知；没有把旧英文 golden 当作本候选可用证明。
- 我另用当前生产函数独立零模型重放两轮 16 份选择：条款原文、raw JSON、渲染正文、prompt 及 schema 约束均符合存档，中文 golden 也与实际样本一致。schema 对比只忽略 Pydantic 的 title 元数据，保留全部字段约束。重放不计新增模型评测。

## Remaining Evidence

第二轮机制全文/首节/相关性与首轮一致，但同一已暴露开发集的成功不证明中文泛化。真实 API 对照仍需核验中文改动路径、英文与普通题原请求控制、最终 generation 与既有 Thinking 控制调用的区别，以及首见和 token 成本。冻结后再独立创建含“未问未知”区分项的新中文留出；不扩大为语言/业务白名单调参，也不以检查数量替代质量结论。

本轮没有新增范围外问题或防御性门禁。批准机制中的规范词呈现限制和短关联偶有措辞错误仍是效果边界，实际正文与新留出负责验收。

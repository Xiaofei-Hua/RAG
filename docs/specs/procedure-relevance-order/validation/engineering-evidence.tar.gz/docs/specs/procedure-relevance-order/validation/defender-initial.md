# Independent Design Review — Defender

**Date**: 2026-11-11  
**Object**: `requirements.md`, `design.md` v1, `tasks.md`; current `core/procedure_generation.py`, `core/local_rag_generation.py`, general profile, existing tests, and previous procedure validation.  
**Independence**: 未读取本轮或旧轮 critic 报告；未调用真实模型、修改业务代码或创建新留出。本报告为并行独立设计评审，不伪装成对尚未读取的 critic findings 的逐条裁决。

## Decision

**允许进入 Design v1 的临时适配器最小机制实验；不据此批准生产接线或默认启用。** 现有失效是被模型选入的条款偏题及首节主规则后置；显式 `lead` 与先于 IDs 的短 `addresses` 分别针对这两个已复现问题。它们值得在一次生成、原预算和原资料资格内检验，尚无证据证明已有效。

未发现阻止该最小实验的 Critical/High 设计问题。已复核修订后的 v1:17、19：旧选择、lead-only、lead+addresses 各跑四个已暴露流程 × 两种来源顺序 × 两轮，每变体 16 答，共 48 答；两种新结构使用同等任务指令。失败就保留完整证据并修订假设。默认仍为 false，后续接线、冻结、新留出和最终默认决定继续受设计中的质量门槛约束。

## Verified Failure and Existing Mechanisms

1. 旧候选中文六答均选入墙钟和年鉴，且主规则在第三节。`docs/specs/segmented-procedure-coverage/validation/procedure-api-holdout-candidate/results.jsonl:1,3,5,7,9,11` 的实际正文具有相同缺陷。首个真实生成请求及原始响应见同目录 `model-http.jsonl:1`：首节 IDs 为 `[1,8,16,17]`，交接后阅览的条款 6 被留在第三节。源文和 ID 没缺失。
2. `core/procedure_generation.py:17` 的段落只有 `title` 与 `clause_ids`，`:23` 的答案只有空 `conditions` 与自由 `answer`；`:155` 依次原文渲染所有已选条款。当前没有题目锚点或独立首节位置。程序正确还原错误选择，给程序再加 ID 合法性检查不能修正该语义错误。
3. 现有 prompt 已写“先给主要运行规则”“跳过与问题无关的资料”（`data/profiles/general.yaml:31`）。因此本轮不能把重写同一句指令本身当作机制证据；应检验新增输出结构能否改变实际选择。
4. 旧完整生成也非稳定满分，但 R3 Fast 中文基线实际合格，见 `docs/specs/segmented-procedure-coverage/validation/procedure-api-holdout-baseline/results.jsonl:9`：所问流程、范围、主规则、记录用途与未知边界均出现，无装饰事实。该条真实配对退步必须保留，不能用旧候选的总覆盖改善抵消。
5. 现有同次调用与原文来源映射可复用：`core/local_rag_generation.py:91` 枚举实际条款 ID，`:102` 保持 2048/none/流程温度 0，`:134` 与 `:138` 各只执行一次最终生成；`core/procedure_generation.py:119` 绑定实际来源，`:150` 要求完整 stop。设计不需要新增生成、在线验证或失败后第二次生成。

## Review Table

| Item | Severity | Decision | Evidence and rationale | Design disposition |
|---|---|---|---|---|
| D-01 首节与相关性是两个真实问题 | High impact, already scoped | accepted | 上述真实请求/正文与渲染路径吻合；独立 lead 能约束可见位置，addresses 可能改变选择条件，但都不保证语义正确。 | v1:8–10 已明确假设及有限边界；允许实验，不宣称修复。 |
| D-02 schema/锚点不能代替语义验收 | High impact, already mitigated | defended-with-alternative | 原合法结构已产生偏题；再加字段不足以证明内容正确。v1:9、13、18–19 明确以正文审查与独立留出验收。 | 已落地于设计，无需新增在线语义评分或模型。 |
| D-03 两个结构因素需要区分收益 | Medium | accepted | v1:17 已将旧选择、lead-only、lead+addresses 放入同一完整矩阵，并规定质量相同优先较小方案。 | 设计已采纳；报告不得把组合收益全部归因于 addresses。 |
| D-04 新字段成本与重复样本 | Medium | accepted | v1:14 的约 100–300 token 是估算；旧温度 0 的六个中文正文相同，多轮不等于多道独立题。 | 实报 token、调用、分模式完整首见 P50/P95；不因合法 schema 或重复轮数声称普遍可靠。 |
| D-05 相关未知信息不能被一并删除 | High impact, already mitigated | defended-with-alternative | 已复现目标是去除无关事实，用户仍明确询问节假日和结案期限。v1:9 保留所问未知，v1:19 逐答审完整内容。 | 用相同完整语义标准审查，无需词黑名单、穷举 omitted IDs 或阈值过滤。 |

表中的 High 表示对应既有失效的影响，不是新发现尚待解决的 High 阻塞项。D-02/D-05 的替代是设计已明确的实验隔离、正文验收和默认 false；它们不等于运行时语义保证，也不能在实验失败后用作默认启用理由。

## Reasoning and Bounded Conditions

### D-01 / D-02

- **Fact**: 旧源文、真实 JSON 与可见全文均能重现偏题及后置。当前程序没有把正确选择变错，也没有缺失待选主规则。
- **Reachability**: 模型可能生成合法 `lead`，却仍选未知段替代主规则；也可能生成宽泛或偏题的 `addresses` 后继续选装饰条款。新 schema 并不使这两种情形不可达。
- **Cost and scope**: 临时适配器可以在不接生产、不新增调用的前提下验证真实收益；相比扩建在线检查或更换检索算法，范围与已证实故障相称。
- **Alternative**: 已定三变体四题换序配对、正文/首节分开审查及失败保留 false 足以判定是否继续。本阶段不需要建立额外质量服务。
- **Decision**: 允许最小实验；若可见首节仍没有用户要求的主规则和范围，或新增结构只是移动装饰事实、遗漏必需动作/条件/用途/未知项，目标未完成，不能接默认。

### D-05

- **Fact**: 旧中文问题明确询问两个未知边界。旧正文同时保留未知边界与无关事实，二者不能一起归为“背景”。
- **Reachability**: 用“主要流程”或“只选必要步骤”过度收窄 `addresses`，可能去掉目的、保留记录的理由或所问未知；被删内容也可能只在原文合并条款的一部分。
- **Cost and scope**: 在既定逐答全文审查中检查这些内容即可，不增加模型和门禁平台。
- **Alternative**: 以用户具体所问事项为选择条件，继续保留已有效的指代合并与原文映射；允许没有实质损害的重复，不要求全部输入句必选。
- **Decision**: 采用设计已有措施；不接受以相关性分提高、短答案或 ID 精简替代完整语义。

## Experiment Interpretation

- **Mechanism comparison**: 旧选择与新结构使用同资料、同采样和预算；来源换序必须同步重建 IDs 与来源映射。评审面向文字语义，不能复用固定正确编号。四题 × 两顺序 × 两轮是八种输入配置的重复，不是十六个新问题。
- **Ablation**: 三变体进入同一完整机制矩阵；若 lead-only 已达到同等完整/首节质量，就按 v1:17 选择较小方案。若保留组合结构，也只报告有限实验中观察到的差异，不把消融当普遍因果证明。
- **Acceptance**: 目标中文不再夹带无关内容，首节实际有主规则与范围，其他所问动作、条件、分支、记录、用途、未知边界及支持引用都保留。英文已合格行为和事件起算关系不得退步。无害重复不单独判失败。
- **Two baselines**: 机制阶段旧选择是结构消融基线；真实 API 阶段 false 的完整生成才是当前默认基线。报告需区分二者，不能把相对旧选择的进步写成相对默认已无退步。
- **Cost**: 维持一次最终生成，不把 Thinking 原有控制调用隐藏在总数外；同时报最终生成次数与全部实际模型请求。实测新增 token、完整首次正文时间及总耗时，不用模型首 token 替代完整首见。允许为质量承担有限增量，但仍须满足 v1:14 相对当前默认的中位数收益要求。
- **Freeze and holdout**: 旧留出已用于诊断，本轮只算开发。候选完成开发且冻结后再独立创建 2 中文 + 1 英文；不能拿新留出调整当前候选。出现被改路径新的实质退步，仍 false，不靠平均分或提速抵消。

## Research Boundary

独立核对的 [QFE 论文](https://aclanthology.org/P19-1225/)将问题关注与证据序列选择结合，包含训练模型；[Chain-of-Note](https://aclanthology.org/2024.emnlp-main.813/)利用逐资料笔记判断相关性并组织答案。它们支持研究方向的合理性，不证明本地 Qwen3.5:9b 在短 addresses 字段上已有同样收益。v1:5 将其表述为迁移假设是恰当的；不应引入论文中额外训练、长笔记或内在知识回退。

## Honest Limits and Next Step

本方案不能保证任意自然语言提问下的相关性或完整性；同实体的装饰事实也可能继续被选中。独立 lead 只能确定结构位置，不能确保其中事实正确。程序验证、golden、mock API 测试用于执行契约，不构成语义效果证据。

本轮只授权上述最小机制实验。待实验结果后，再判断是否进入既定生产红→绿接线；独立新留出暂不创建。无范围外 backlog 项，无新增防御性工作项。

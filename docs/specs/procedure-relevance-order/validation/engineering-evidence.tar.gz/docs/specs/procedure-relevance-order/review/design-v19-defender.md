# Defender Review — v19 Sentence-Internal References

**Date:** 2026-11-12  
**Scope:** `design.md:35`；`core/procedure_generation.py:15,155`；十题实际最终请求中的原始contexts。独立评审，未读取并行v19 critic；未调用模型或改生产。

## Decision

**允许先对陶艺Fast/Thinking两个实际输入作临时试验；二者完整语义和首节通过后，允许既定十题两模式各两轮开发对照。没有新增Critical/High准入阻塞。F-16仍open、默认false；结构修正本身不构成语义验收。**

## Factual Assessment

旧`_REFERENCE.search(sentence)`把句中任意“该/其”等都作跨句连接触发。陶艺真实句“一个台面获准开放的依据是该台全部作品有当前摆位检查记录…”本身已有“一个台面”的明确先行词，却被并入前一句登记，随后同样连入松动和复检。这正是v17/v18真实混合条款3，属于已复现缺陷。

`sentence.strip()`先于该判断，改为`match`会让此许可句独立；所有句子仍经同一循环按资料顺序进入units与annotated context，不删除原句、来源或相邻上下文。句首“该次…”等仍回连，符合现有保护真实承接语境的用途；该修改没有声称完成通用指代解析。

独立审读20个实际输入所含十题原文，变化还包括L4的“首次打印前…该次检查合格”、月表的“用于…其他站点”、照片记录的“原始观察及其授权”等句内匹配。它们可在现有完整上下文中独立作为分类单元；没有发现足以否决本临时实验的已发生反例。档案/活动室真实的句首“此流程…”仍保持回连。此审读只证明粒度变更对象合理，不预判模型能选全每个更细条款。

[官方Sentence Window示例](https://developers.llamaindex.ai/python/examples/node_postprocessor/metadatareplacementdemo/)确实区分单句检索单元和送给模型的周边窗口。设计仅借鉴“选择粒度与阅读上下文分离”的思路，明确不搬入其索引/embedding机制；该来源不证明本项目角色分类效果。

## Experiment Boundary

- 先导只使用两份真实陶艺输入，保留v17原prompt、原文、问题、来源与预算；只重分组合并单元、编号及对应schema。若主要开放条件仍不在首节即停止，不继续无收益40答。
- 先导成功后按原全部十题rubric审40答，特别保留初始步骤、复检/恢复条件、记录关联用途及已问/未问未知。分类单元变细可能改变角色选择；该影响属于本次已有语义验收，不能仅验首节。
- 更细条款增加key数量的实际tokens/耗时由该实验报告；保持2048和每答一次最终generation。直接实验只报最终generation时间，不冒充真实API首见。
- 成功后的一行生产修改须有失败测试红绿与真实golden，覆盖句首回连、句内不回连、实际首节和原文覆盖；既定冻结后的真正新API留出继续两侧各18答。旧陶艺修复后仍是开发证据。

## Findings and Boundary

没有新增具体Critical/High发现；不扩展实体词表、完整指代解析器、额外模型调用或题外门槛。v18的失败已简记于`mechanism-v18-defender.md`，其优先级提示不与本干预混合。待并行critic报告后再对具体发现按五步树裁决。

## Post-review Critic Adjudication

独立准入报告归档后读取`design-v19-critic.md`。其新增Critical/High为0，准入次序、原v17提示、原始上下文/派生schema、预算和真实新留出边界与本独立判断一致。其陶艺许可单独成第4条与当前分句/匹配规则相符；没有需要五步否决或修订的具体新finding。F-16仍按已归档五步裁决保持accepted/open，不能在试验前关闭。

# Mechanism v3 Critic Review

**Date**: 2026-11-11  
**Inputs**: unchanged `validation/development.json`; `data/eval/procedure-relevance-mechanism-v3/{results,model-http}.jsonl` and `prompts.json`.  
**Independence**: 未读defender、未调用模型。阅读16组完整正文/选择/来源；同题、同顺序、同变体两轮正文完全相同，保留32槽状态。

## Decision

**本轮仍没有最小合格候选，不可进入生产接线。**

- `flow_anchored`：首节16/16通过，但R7四答重新混入包装库存，档案反顺序两答漏编号关联，严格10/16。
- `flow_rule`：R7和档案全文遗漏恢复，严格12/16；字幕四答首节仍缺独立审核，反顺序两答还漏三项用途。
- 更改生成顺序确实执行，却没有同时闭合完整性、首节和相关性。不能按最高总分选择仍有实质失败的方案；默认false保持。

## Actual Intervention and Metrics

32个原始HTTP响应的顶层JSON顺序均为answer→lead，渲染实际仍lead→answer；32次均generation、单次调用、finish_reason=stop。不是仅从schema声明推断执行。参数仍Qwen3.5:9b、temperature0、top_p0.8、none、2048 token预算。

| Variant | Full | Lead | Relevant | Citation | Strict | First body P50 s | P95 s | Mean tokens |
|---|---|---|---|---|---|---:|---:|---:|
| v1 anchored | 16/16 | 8/16 | 16/16 | 16/16 | 8/16 | 3.726 | 4.266 | 332.00 |
| v2 rule_lead | 10/16 | 12/16 | 16/16 | 16/16 | 8/16 | 4.678 | 6.240 | 453.38 |
| v3 flow_anchored | 14/16 | 16/16 | 12/16 | 16/16 | 10/16 | 4.854 | 5.177 | 417.25 |
| v3 flow_rule | 14/16 | 12/16 | 16/16 | 16/16 | 12/16 | 5.136 | 6.334 | 484.25 |

前两批仅是同开发输入的已保存对照，时间非跨批交替配对收益；P95为样本线性插值。本批两个变体按实验交替执行。没有新增token门禁，也没有声称对当前false完整生成有性能收益。首节/全文的语义失败已足以拒绝接线。

## Unchanged Rubric

全文动作/条件/分支、记录字段与用途、所问未知均须保留；实际首节满足冻结lead_rubric；无明确无关事实且引用支持原文。四维联合为严格整题。没有新增“首句必须给全部规则”“首节长度上限”或“quote必须逐字等同所有IDs”标准。

特别是flow_anchored的L4反顺序、档案和字幕首节较长，且重复后续内容，但其中实际包含要求的规则和范围，均按原判据判首节P，不以篇幅或无害重复扣分。flow_rule的R7 quote仅摘范围/环境信息，实际IDs却含失败停机规则；按可见正文判首节P，quote不成为额外通过/失败门禁。

旧“全部关键条件入首节”口径单独报告R7/L4：flow_anchored为2/8（L4反顺序两答），flow_rule为0/8。不回改旧报告，也不混入当前分母。

## Evidence

| Code | Exact observation |
|---|---|
| R1 | flow_anchored的R7两种顺序四答均在末节展示蓝色包装箱和92箱库存。原顺序addresses还写“Unknown information (service charge, packaging)”，其中packaging并非用户所问。来自同一资料不构成相关性。 |
| A1 | flow_anchored档案反顺序两答缺“每个调阅编号关联申请档号、阅览证号和计划日期，用于对应一次完整调阅”，包括三个字段和用途；原始编号2未出现在任何正文。其他核对、交接、归还、异常记录与未知项仍在。 |
| C1 | flow_rule字幕两种顺序四答的quote及首节仅有范围和同音频/字幕版本审批后发布，没有独立审核角色条件。后节的“reviewer who did not edit it”不能抵消冻结首节要求；flow_anchored已把该句放在首节，故对应首节判P。 |
| C2 | flow_rule字幕反顺序两答缺转录稿匹配避免过期稿、完整回放发现相邻提示间遗漏、独立审核分离编写与发布三项用途，原始编号5/6未选。转录稿标识与全部草稿链接本轮已恢复，不能沿用v2把它们继续记成遗漏。 |

正向结果：flow_rule的R7两顺序均恢复普通37有效小时间隔，档案两顺序均保全编号关联及用途；档案首节包含清点签名后的阅览许可。两变体L4全部保留350正式标签、排除项、初始/更换事件起算、失败恢复、记录与未知事项。字幕所有答仍保留阻塞确认、全程回放、返工循环、版本批准、音频变更与标题拼写例外、未知规则/期限。上述正向结果不抵消C1/C2等失败。

## Findings

### F-07 — Generation Order Does Not Close Both Target Dimensions

- **Label**: issue (blocking, must-fix)
- **id**: F-07
- **severity**: Critical；critic §2(a)，同类目标问题仍在实际候选下复现。
- **location**: R1/C1；结果槽2/3/17/20及13/16/30/31；REQ-701/702/705。
- **symptom**: flow_anchored引入无关包装库存；flow_rule仍漏字幕首节审核者独立性。
- **impact**: 没有一个变体同时满足用户问题相关性与首要规则展示。
- **root_cause**: 调整生成顺序能改变选择，但没有约束问题锚点误扩展或跨条款许可角色条件遗漏。
- **recommendation**: 不按局部分数选择上线；保留失败，下一设计针对实际问题相关条款覆盖与许可依赖提出可验证机制。
- **verification**: 冻结判据下逐答同时满足全文/首节/相关性/引用，不能移除不利题目或更换首节标准。
- **status**: open

### F-08 — Full Coverage Remains Unstable Under Both Variants

- **Label**: issue (blocking, must-fix)
- **id**: F-08
- **severity**: High；真实来源顺序边界下的内容遗漏，违反REQ-701/704。
- **location**: A1/C2；结果槽11/28及16/31。
- **symptom**: flow_anchored档案漏编号关联；flow_rule字幕漏三项所问用途。
- **impact**: 同一题切换来源顺序仍产生实质不完整。
- **root_cause**: 先选择answer没有保证每个所问事项都会获得对应原文。
- **recommendation**: 返回机制设计，保留这些具体回归；不以首节修复或总分改善豁免。
- **verification**: 下一候选逐答恢复A1/C2并维持已有动作、条件、相关性及首节结果。
- **status**: open

## Slot Review

O=原来源顺序，R=反来源顺序；P/F=通过/失败。槽号对应本批results行号与HTTP index；每槽实际生成顺序answer→lead、调用1、stop。完全相同重复正文沿用相同语义结论。

| Slot | Round | Case | Order | Variant | Full | Lead | Relevant | Citation | Strict | First body s | Tokens | Notes |
|---:|---:|---|---|---|---|---|---|---|---|---:|---:|---|
| 01 | 1 | R7 | O | flow_rule | P | P | P | P | P | 5.094 | 452 | — |
| 02 | 1 | R7 | O | flow_anchored | P | P | F | P | F | 4.369 | 376 | R1 |
| 03 | 1 | R7 | R | flow_anchored | P | P | F | P | F | 4.380 | 380 | R1 |
| 04 | 1 | R7 | R | flow_rule | P | P | P | P | P | 4.959 | 445 | — |
| 05 | 1 | L4 | O | flow_rule | P | P | P | P | P | 5.557 | 508 | — |
| 06 | 1 | L4 | O | flow_anchored | P | P | P | P | P | 4.881 | 431 | — |
| 07 | 1 | L4 | R | flow_anchored | P | P | P | P | P | 5.047 | 448 | — |
| 08 | 1 | L4 | R | flow_rule | P | P | P | P | P | 5.018 | 449 | — |
| 09 | 1 | Archive | O | flow_rule | P | P | P | P | P | 6.149 | 556 | — |
| 10 | 1 | Archive | O | flow_anchored | P | P | P | P | P | 5.229 | 451 | — |
| 11 | 1 | Archive | R | flow_anchored | F | P | P | P | F | 5.038 | 439 | A1 |
| 12 | 1 | Archive | R | flow_rule | P | P | P | P | P | 6.330 | 577 | — |
| 13 | 1 | Caption | O | flow_rule | P | F | P | P | F | 4.836 | 427 | C1 |
| 14 | 1 | Caption | O | flow_anchored | P | P | P | P | P | 4.822 | 420 | — |
| 15 | 1 | Caption | R | flow_anchored | P | P | P | P | P | 4.566 | 393 | — |
| 16 | 1 | Caption | R | flow_rule | F | F | P | P | F | 5.178 | 460 | C1,C2 |
| 17 | 2 | R7 | O | flow_anchored | P | P | F | P | F | 4.351 | 376 | R1 |
| 18 | 2 | R7 | O | flow_rule | P | P | P | P | P | 5.036 | 452 | — |
| 19 | 2 | R7 | R | flow_rule | P | P | P | P | P | 5.009 | 445 | — |
| 20 | 2 | R7 | R | flow_anchored | P | P | F | P | F | 4.413 | 380 | R1 |
| 21 | 2 | L4 | O | flow_anchored | P | P | P | P | P | 4.920 | 431 | — |
| 22 | 2 | L4 | O | flow_rule | P | P | P | P | P | 5.558 | 508 | — |
| 23 | 2 | L4 | R | flow_rule | P | P | P | P | P | 4.996 | 449 | — |
| 24 | 2 | L4 | R | flow_anchored | P | P | P | P | P | 5.090 | 448 | — |
| 25 | 2 | Archive | O | flow_anchored | P | P | P | P | P | 5.159 | 451 | — |
| 26 | 2 | Archive | O | flow_rule | P | P | P | P | P | 6.150 | 556 | — |
| 27 | 2 | Archive | R | flow_rule | P | P | P | P | P | 6.346 | 577 | — |
| 28 | 2 | Archive | R | flow_anchored | F | P | P | P | F | 5.032 | 439 | A1 |
| 29 | 2 | Caption | O | flow_anchored | P | P | P | P | P | 4.828 | 420 | — |
| 30 | 2 | Caption | O | flow_rule | P | F | P | P | F | 4.850 | 427 | C1 |
| 31 | 2 | Caption | R | flow_rule | F | F | P | P | F | 5.200 | 460 | C1,C2 |
| 32 | 2 | Caption | R | flow_anchored | P | P | P | P | P | 4.539 | 393 | — |

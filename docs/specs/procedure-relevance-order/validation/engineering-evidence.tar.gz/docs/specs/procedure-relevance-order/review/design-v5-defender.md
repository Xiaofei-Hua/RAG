# Design v5 Independent Review — Defender

**Date**: 2026-11-11  
**Object**: `design.md` section v5, Decide Once for Every Clause; independently reviewed v1–v4 evidence.  
**Independence**: 未读 critic、未调用模型、未生产编码或创建留出。

## Decision

**准许先做档案与字幕各两种来源顺序、共 4 答的 pilot；无新增 Critical/High 实验设计阻塞。** 这将自由抽取清单改为逐条固定类别选择，直接检验未列条款能否保留，同时移除长字符串反复输出和多次自由标题/锚点的成本来源。它是与 v4 不同的选择机制，不能沿用 v4 失败或论文结果预判成功。

每个实际 ID 为 required property、类别为短 enum，能约束“每条有一个标签”，不能证明模型完整考虑了该条或标签语义正确。`omit` 仍可能误删必需用途/未知，`lead` 仍可能只选环境。设计已保持原冻结人工判据，因而不把结构保证误作质量保证。

## Bounded Conditions

| Point | Decision and rationale |
|---|---|
| 原文和来源 | 保持已有分句/指代合并与完整原文；一个混合条款只分一类，但整条渲染，不能因类别只取前半句。 |
| 单次生成 | 固定类别替代自由选择，仍 2048/none/温度 0/top_p .8；完整 stop 和一次原输出检查后发布，不为分类失败追加调用。 |
| 单次展示 | 每条最多展示一次可降低重复；只要全文语义、许可条件和可执行顺序完整，不因后续步骤组未再次重复首节条款而判失败。 |
| 分类与首节 | 非空 lead 不是合格证明；档案许可、字幕独立审核、全部记录/用途/未知和无关事实排除仍按冻结 rubric。 |
| 资料顺序 | lead→step→record→limit 的组装可能改变跨来源操作顺序；pilot 两种来源顺序直接观察该风险，按实际正文含义判断，不以字段齐全替代可执行性。 |
| 失败与成本 | 空 lead、全 omit、缺槽位/非法值、length 均如实记录既有不可用结果；没有完整正文时首见为 None，不伪造 0。调用、token 和完整首见照原指标实报。 |

## Pilot Decision

四答全部满足原首节、完整性、相关性和引用标准，才按设计补齐至四题 × 两来源顺序 × 两轮共 16 答；有未修复目标或新实质退步就先停止此路线并归档，不用大量重复对冲失败。该 pilot 仍只是开发题，不能作为独立留出或默认启用证据。

v4 实录已归档 `review/mechanism-v4-defender.md`：R7 两答长 enum 重复至 length，L4 两答 stop 且正文通过；不把后一事实抹去，也不为完成原 16 答补跑。v5 默认 false，生产接线、真实 API 对照与候选冻结后的新留出仍需后续独立判断。

# Design v8 Critic Review

**Date**: 2026-11-11  
**Target**: `design.md:56` 起的模型可见schema。未读defender、未运行模型、未改业务代码。

## Decision

**既定四答隔离实验无阻塞，可以执行；不准入生产。** 保持v7的事实输入、schema逻辑、分句、任务提示及运行参数，仅将实际schema紧凑字符串加入system，干预边界清楚。

已核验[Ollama官方Structured Outputs文档](https://docs.ollama.com/capabilities/structured-outputs)：官方建议在解码参数之外，也把schema字符串交给提示，以帮助模型理解所需输出；同页说明OpenAI兼容接口支持response_format。它支持本次接口用法实验，不证明三用途遗漏由schema不可见造成，也没有保证语义完整性。

## Notes

- **praise (non-blocking)**: 同一schema对象用于两处，避免维护两个契约；用SystemMessage载入，既有JSON括号不进入模板变量解析；不增加调用。
- **suggestion (non-blocking)**: v7四答结构已经合法，v8收益必须来自冻结语义判据的实际改善，不能把格式合法率当新效果。
- **suggestion (non-blocking)**: 新增输入token和prefill成本如实记录，仍保持4096上下文/2048输出预算及length不可用终态；不扩大组件或加入题目用途规则。

四答继续要求全文、实际首节、相关性与引用全部通过，特别保留字幕三用途回归。通过才补16答，F-13及此前未解决问题不因设计批准而关闭，默认false。

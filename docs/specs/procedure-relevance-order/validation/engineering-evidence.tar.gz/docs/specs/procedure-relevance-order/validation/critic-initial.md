# Critic Review — Procedure Relevance and Order

**Review target**: `design.md` v1（含运行前补充的判据与消融定义）
**Review mode**: 完整 critic；生成热路径，无新增安全边界，不扩展 STRIDE/FMEA。
**Review date**: 2026-11-11
**Independence**: 已读规范、设计、相关代码及旧留出原始结果；未读 defender，未调用真实模型，未改业务代码。

## Decision

- Critical: 0；High: 0；Medium: 0 open / 2 resolved；Low: 0。
- **可进入最小机制实验**。两项实验定义已在运行前补齐，无未解决设计阻断。
- 当前批准仅涵盖临时适配器及三变体配对实验；生产接线、默认启用必须等待真实结果、API 对照与新的独立留出。

`lead` 和先于 IDs 输出的 `addresses` 是合理的可检验假设，尚不是语义保证。未运行候选前，不以结构合法证明目标闭合，也不因缺少形式化保证否决小实验。

## Evidence

- 旧留出 `docs/specs/segmented-procedure-coverage/validation/procedure-api-holdout-candidate/results.jsonl` 的中文档案题 Fast/Thinking 各三轮，6/6 首节包含墙钟/年鉴，而用户要求先说明的“共同清点签名后才能阅览”在第三节。全文覆盖不能抵消首节失败。
- `core/procedure_generation.py:147` 起忠实渲染所选原文，`core/local_rag_generation.py:91` 起只约束可用 ID。缺陷源于选择/编排，v1 的修改位置匹配该机制。
- 同批英文字幕题首节已包含发布许可与范围；新候选必须保留英文分支、批准后变更、用途与未知项，不能只看中文目标题修复。
- 节假日办理和异常结案期限是中文用户明确询问的未知信息，不应随无关句一起删除。

## Resolved Findings

### F-01 — Freeze Semantic Acceptance Before Reading Candidate Outputs

- **Label**: suggestion (non-blocking, resolved)
- **id**: F-01
- **severity**: Medium；对应 critic §2 欠定义，属于冷路径实验判据，不是已证实热路径失效。
- **location**: `docs/specs/procedure-relevance-order/design.md:19`；REQ-701/702/704/705。
- **symptom**: 初稿“机制合格/实质退步”未明确定义，可能把全文覆盖或删除干扰单独当成整题通过。
- **impact**: 无法确定是否以遗漏所问条件/未知信息换取相关性改善。
- **root_cause**: 指标维度已有，整答合格判据未写清。
- **recommendation**: 运行前明确整题要求完整语义、首节、相关性及引用全部通过；无害重复与措辞不自动算退步。
- **verification**: 已复读 design:19；现已明确上述联合判据，首节必须实际给出用户指定首要规则，明确无关内容和所问动作/用途/条件遗漏属于实质失败。
- **status**: closed（设计修订已静态复核；无业务修复或模型测试结果可宣称）。

### F-02 — Isolate the Addresses Ablation

- **Label**: suggestion (non-blocking, resolved)
- **id**: F-02
- **severity**: Medium；对应 critic §2 实验定义不足，属于冷路径。
- **location**: `docs/specs/procedure-relevance-order/design.md:17`；H2。
- **symptom**: 初稿未定义 lead-only 保留哪些新提示要求，字段贡献可能与提示改写混杂。
- **impact**: 可能增加输出 token，却无法判断问题锚点是否有边际贡献。
- **root_cause**: 消融名称已有，其余条件尚未固定。
- **recommendation**: lead-only 与 lead+addresses 保持同等语义指令、输入及预算，仅去掉锚点字段/相应说明；同等效果优先较小方案。
- **verification**: 已复读 design:17；三变体同 4 题×2 来源顺序×2 轮，各16答，共48答；仅锚点字段/说明不同，质量相同时选较小方案已写入。
- **status**: closed（设计修订已静态复核）。

## Invariant Review

| Area | Assessment |
|---|---|
| Calls and budget | 一次最终生成，新增 token/时间须实测；Thinking 控制调用与最终生成分别记账。 |
| Degradation | 非法结构/ID、非 stop、输出检查失败保持不可用和 confidence=None；明确计划失败及单调用断言。 |
| State and publication | shared_state/messages/持久化无新增；完整 stop 后一次输出检查发布、取消契约保持。 |
| Prompt and regression | profile 单一来源、golden、单元+进程内 E2E 均已计划；真实质量不由 golden 代替。 |
| Baselines and scope | 旧选择用于机制对照；当前 false 完整生成用于生产收益对照，保留原配置。普通比较/改写/非流程不扩展。 |
| Holdout and rollback | 暴露样本退为开发；冻结后独立留出；未通过不启用默认，false 回滚与真实默认冒烟已计划。 |
| Performance | 完整首见 P50 收益与质量为主，P95如实报告；不要求每个分位数全面更优。 |
| Security | 无新增安全边界，既有不可信资料、PII 与输出检查保持，不扩大假设性防御工作。 |

## Positive Decisions

- **praise (non-blocking)**: 不把 schema、ID 或 addresses 合法性当成语义证明，旧失败与全部对照保留。
- **praise (non-blocking)**: 小实验先证伪，再生产接线；保护未知信息、记录目的和起算关系，不增加模型调用。

下一轮按完整请求、原始 JSON、实际可见正文和调用/时间记录独立逐答评审。当前不宣称新机制已修复缺陷或适合默认启用。

# Mechanism v2 Independent Review — Defender

**Date**: 2026-11-11  
**Inputs**: unchanged frozen `validation/development.json`; `data/eval/procedure-relevance-mechanism-v2/{protocol,prompts}.json` and `{results,model-http}.jsonl`; v1 anchored as the existing failure control. Row references are one-based JSONL rows.  
**Independence**: 未读 critic；完整审读首轮八个不同正文与实际 selection，第二轮逐槽正文完全相同，沿用对应语义裁定并保留逐槽结果。核对全部 16 次实际请求/响应、单调用和成本。未调用模型、修改题目/判据/业务代码或创建新留出。

## Decision

**v2 不能接入生产，也不能进入默认启用或新留出阶段。** 档案首节两种来源顺序都已实际包含交接许可，首节通过从 v1 anchored 的 8/16 提升到 12/16；但全文完整性从 16/16 降至 10/16，字幕首节依然缺独立审核条件。严格整题仍是 8/16，出现 R7 reversed 的 Pass→Fail，不能用档案 reversed 的改善抵消。

相关性与引用均保持 16/16，每答仍一次生成；这两项不关闭新遗漏或首节失败。继续 false，保留全部 v1/v2 证据。v2 证明“先摘规则”能在档案题改善首节选择，尚未证明可同时保持全文完整性。

## Frozen Criteria and Totals

Complete=全文动作、条件、分支、记录、用途和所问未知齐全；Lead=可见首节符合冻结 rubric；Relevant=不含无关事实；Cited=实际主张有来源；Strict=四项同时通过。标题、quote 和合法 IDs 不代替可见正文；无害重复不单独判失败。

| Variant | Complete | Lead | Relevant | Cited | Strict |
|---|---:|---:|---:|---:|---:|
| v1 anchored | 16/16 | 8/16 | 16/16 | 16/16 | **8/16** |
| v2 rule_lead | 10/16 | 12/16 | 16/16 | 16/16 | **8/16** |

按相同 round/case/order 严格配对：6 条 Pass→Pass、2 条 Pass→Fail、2 条 Fail→Pass、6 条 Fail→Fail。前者退步为 R7 reversed，改善为档案 reversed。档案 original 和字幕 reversed 虽旧严格题已经失败，v2 新增的全文遗漏仍是实质维度退步，不能隐藏在 Fail→Fail 内。

旧“首节包含全部条件/起算/失败/未知”的口径：v2 为 0/16（v1 anchored 同为 0/16），仅另报，不替代冻结新口径。

## Findings

### M2-D01 — New complete-answer omissions

- **Severity**: High; **Status**: accepted, open; 阻止生产准入。
- **Location**: `results.jsonl:2,10`（R7 reversed）；`:5,13`（档案 original）；`:8,16`（字幕 reversed）。
- **Symptom**: R7 全文没有“每累计 37 活动扫描小时复查”，只留下换头通过后新 37 小时周期；档案全文缺调阅编号关联档号/阅览证号/计划日期以及对应完整调阅的用途；字幕全文缺 transcript identifier、每份草稿链接，以及脚本匹配避免旧稿、全程播放发现相邻 cue 遗漏、独立审核分离编写与发布决策三项目的。
- **Impact**: 三类内容均为明确所问要求；换头周期不能替代普通周期复查，其他记录不能替代编号关联字段，已有独立审核动作不能替代所问用途。v1 anchored 同槽全文均齐全。
- **Root cause**: 新首节抽取改变了后续选择，实际 answer 未选必要条款；资料和条款映射仍在，renderer 没有丢弃已选文字。保留相同后续 schema 不代表后续选择行为保持不变。
- **Recommendation**: 不接生产，不在输出后补固定条款。后续候选必须同时保持全文和首节，按相同冻结判据重验这些实际遗漏。
- **Verification**: 已审全文后段：R7 reversed 没有选普通复查条款 11；档案 original 没有编号关联条款 10；字幕 reversed 没有条款 2（identifier/全部链接）、5（脚本/播放用途）、6（独立审核用途）。现有 37 数字、退稿用途或其他记录不能补足缺失语义。

### M2-D02 — Caption lead still omits reviewer independence

- **Severity**: High; **Status**: accepted, open; 延续 v1 的首节缺陷。
- **Location**: `results.jsonl:7,8,15,16`。
- **Symptom**: 首节给出预录英语室内展览范围、排除直播/翻译和同版本审批，但未给“独立审核”条件。后续 Preparation 中出现 reviewer who did not edit it，不能代替首节要求。
- **Impact**: 冻结 `lead_rubric` 要求同一音频/字幕版本经独立审核批准才可发布；首节版本对齐正确不等于许可规则全部齐全。
- **Root cause**: `rule_quote` 本身也只摘取范围与审批句，没涵盖角色资格；对应 rule IDs 如实渲染了这个不完整的规则集合。增加 quote 没有使角色条件自动被选中。
- **Recommendation**: 不依据 quote 字面“Publication is allowed”或非空 rule IDs 关闭 M-D01；继续以实际许可语义审查，无需另加在线模型或泛化匹配门禁。
- **Verification**: original 首节 rule IDs `[1,3]`、scope `[5]`；reversed rule IDs `[10,12]`、scope `[10]`。两者都没有独立审核角色或其目的原文，且实际首节确实缺该条件。

## Verified Improvements and Remaining Content

档案 original/reversed 首节实际包括范围、申请/核对分支及“共同清点卷数并签名，交接完成后才能阅览”，不是仅 quote 正确或标题声称正确。虽然首节较长且重复准备内容，按冻结规则不单独判失败。两顺序均无墙钟/年鉴；归还一致才关闭、异常保持未结并复核、后续复核结论追加、节假日和结案期限未知都保留。reversed 全文所有记录和三项目的齐全，严格通过；original 缺项如 M2-D01。

R7 original 完整保留范围、初检和换头许可、各自正确起算、37 小时复查/排除待机、失败停机、准备/结果/失败记录及各项目的、室外和价格未知，严格通过。reversed 除普通周期复查触发缺失外，换头的独立起算、失败规则和未知边界均在；没有把后段的换头 37 小时误算作已回答普通周期。

L4 两顺序均严格通过：温度/无结露范围和初次样张许可在首节；350 正式标签、测试/作废不计、初次及换托盘起算、失败暂停/排因重检、全部准备/记录/失败样张、所问用途和未知均完整。原文重复没有改变事件语义。

字幕 original 全文完整：阻塞到匹配确认、全程播放失败保持编辑、独立审核、返修全程播放并提交新版本、音频变更后重启、仅工作标题拼写例外、全部记录/用途/未知均齐，只是首节失败。reversed 还缺 M2-D01 内容。两顺序均没有银色公告板。

## Per-Slot Status

P/F 为人工语义裁定；C=Complete，L=Lead，R=Relevant，S=Strict。所有 16 槽 Cited=Pass。

| Row | Round | Case | Order | C | L | R | S |
|---:|---:|---|---|:---:|:---:|:---:|:---:|
| 1 | 1 | R7 | original | P | P | P | P |
| 2 | 1 | R7 | reversed | F | P | P | F |
| 3 | 1 | L4 | original | P | P | P | P |
| 4 | 1 | L4 | reversed | P | P | P | P |
| 5 | 1 | 档案 | original | F | P | P | F |
| 6 | 1 | 档案 | reversed | P | P | P | P |
| 7 | 1 | 字幕 | original | P | F | P | F |
| 8 | 1 | 字幕 | reversed | F | F | P | F |
| 9 | 2 | R7 | original | P | P | P | P |
| 10 | 2 | R7 | reversed | F | P | P | F |
| 11 | 2 | L4 | original | P | P | P | P |
| 12 | 2 | L4 | reversed | P | P | P | P |
| 13 | 2 | 档案 | original | F | P | P | F |
| 14 | 2 | 档案 | reversed | P | P | P | P |
| 15 | 2 | 字幕 | original | P | F | P | F |
| 16 | 2 | 字幕 | reversed | F | F | P | F |

## Actual Inputs, Calls and Cost

16 个实际 human message 均与 v1 anchored 对应槽一致；题目、同序证据和条款/来源映射未变化。实际 schema 的 lead 属性顺序为 `rule_quote → rule_clause_ids → scope_clause_ids → title`，后续仍为 `addresses → title → clause_ids`。可见正文是 IDs 原文及来源，隐藏 quote 未作为另一个正文段。

每答实际一次最终生成，共 16 次；全部 qwen3.5:9b、temperature 0、top_p .8、none、2048，全部 stop，渲染/原检查后 complete，无追加控制、核验或重试生成。协议完成只表示完整发布，不表示语义通过。

| Variant | Complete body P50 / P95 (s) | Total P50 / P95 (s) | Completion tokens total / mean | Mean prompt tokens | Calls |
|---|---:|---:|---:|---:|---:|
| v1 anchored | 3.7264 / 4.2664 | 3.7264 / 4.2664 | 5,312 / 332.000 | 900.75 | 16 |
| v2 rule_lead | 4.6775 / 6.2402 | 4.6775 / 6.2402 | 7,254 / 453.375 | 908.75 | 16 |

v2 新增 121.375 completion tokens/答，较 v1 anchored 增加 36.56%；完整正文可用中位数增加约 25.52%。两批分开执行，不能将该差异当成严格时序交替的因果估计。这里是直接生成适配器耗时，不含正常 API 检索或 Thinking 控制；也不是与当前 false 完整生成的对照。

每轮八种输入配置，第二轮正文逐槽完全重复，总共八个不同正文；不能把 16 次重复当成 16 道独立新题。质量未过时，成本增加或仍比历史完整生成快都不改变准入结论。

## Disposition

保留档案首节改进这一有限证据，同时保留新全文遗漏和字幕首节失败。M2-D01/M2-D02 未关闭，v2 不接生产、不冻结新留出、不改默认。后续若继续探索，须解决“改善首节时损害剩余所问内容”的选择耦合，不能只对已有题追加必选句或借放宽判据得到通过。

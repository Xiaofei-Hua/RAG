# Holdout v19 Preflight Revision

r1 retained in holdout-v19-r1.json. Before any question model call, complete zero-model preflight found third query matched existing comparison phrase 哪一 and would use the unchanged full route. r2 only replaces query phrase “哪一版能作为执行单” with equivalent “成为执行单的条件”. All corpus, semantic rubrics, other queries and frozen production unchanged. No model output informed this revision; baseline and candidate will both use r2. Critic reruns full preflight before actual measurement.

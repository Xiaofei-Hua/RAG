# Mechanism v16 Critic Review

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v16/{results,model-http}.jsonl`，同七题 Fast/Thinking 的 14 槽。独立审读实际 selection 与正文；未读 defender、未调用模型或修改生产。

## Decision

**严格 12/14，不批准 Conditional v16 Wiring 或后续生产 API 扩大。** 木玩具两答的实际首节只有标题与适用范围，主要交付许可留在第二节，既有 F-16 复现。全文、相关性、已问/未问未知与引用均 14/14；首节 12/14。default false 保持。

| Case | Fast slot / strict | Thinking slot / strict | Actual result |
|---|---|---|---|
| L4 | 1 / P | 5 / P | 完整主要许可/范围及全部步骤用途 |
| Archive | 2 / P | 6 / P | v15 丢掉的编号关联与用途恢复 |
| Room | 3 / P | 7 / P | 全文及首节通过 |
| Toy | 4 / F | 8 / F | 全文完整，交付许可未进首节 |
| Greenhouse | 9 / P | 12 / P | 开阀完整许可居首，记录用途/未知完整 |
| Patchwork | 10 / P | 13 / P | 所问补领费未知保留，未问义卖费排除 |
| Insect | 11 / P | 14 / P | 队徽/未问聚餐未知排除，所问未知保留 |

原文标题、首节长度、无害重复不扣分。L4 原“所有条件都在首节”指标仍未通过，不新增为本轮门槛。原先已审正文相同的槽合并阅读，其余改动逐份核对。

## Blocking Evidence — F-16

- **id / label / severity**: F-16，issue (blocking)，Critical；critic §2(a)，既有“主要规则先交代”的目标缺陷再次出现。
- **location**: results 第 4、8 行，实际完整键 `4:领取单与玩具编号核对一致、领回者逐项确认附件并签收，三项都完成才交出物件；待领通知本身不代表交付已经获准。`。
- **symptom**: 原始类别为 `step`；首节原文是“星楠修复站木玩具领回流程。本流程适用于已经在本站登记的木制拼插玩具，不处理电动或带电池玩具。”主要许可只出现在“操作步骤”。
- **impact**: Toy 冻结 lead_rubric 明确要求首节包含三项交付许可；后文完整不能补救这两槽。对应 v13/v14/v15 的首节原本通过，构成该维度退步。
- **root_cause**: 完整键和直接类别保证了本批条款事实对应，但没有保证主要操作许可归 main_rule；资料标题被标为 main_rule 不等同主要规则已经表达。既有规范前置未移动该 step，渲染与选择一致。
- **recommendation**: 保留失败，不实施本轮条件接线、不改默认；不能以“类别结构合法、全文完整”报告 14/14。
- **verification / status**: 两种真实上下文均复现，原冻结首节语义判据未通过；F-16 仍 open。

## Isolation and Combination

新 wire 保留原用户消息/实际检索上下文和参数；只使用冻结 full-key prompt 及完整键→六类字符串 schema。全部完整键集合、required 与实际原文一致，无额外键。将实际类别按完整键还原到既有原文渲染，离线 14/14 与可见正文一致；检查没有调用模型。

本轮检验的是 **完整原文 key + 去掉 answers + 直接类别值的组合**。队徽错位、未问费用和档案遗漏在本批修复，不能单独归因某个组件，也不能用这些收益抵消首节失败。

## Same-Boundary Cost

14 次新 HTTP 全为 generation、每答一次、全部 stop，无 length；最大输出 879 tokens。保留 2048 输出/context4096，未新增预算开关。仅比较最终 wire `end - start`，不混用旧 API first_body。

| Scope | n | Stored v13 P50/P95 s | v16 P50/P95 s | Mean output tokens v13→v16 |
|---|---:|---:|---:|---:|
| All | 14 | 5.428 / 7.361 | 6.051 / 9.311 | 541.57 → 637.29 |
| Fast context | 7 | 7.224 / 7.402 | 8.189 / 9.372 | 632.57 → 750.29 |
| Thinking context | 7 | 5.109 / 5.429 | 5.918 / 6.061 | 450.57 → 524.29 |

平均报告输入 tokens 1294→1147；P95 线性插值，旧批与新批非随机交替。成本与组合收益如实保留，生产阻塞来自实际首节语义失败，不是额外性能门槛。

# Mechanism v14 Critic Review

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v14/{inputs.json,results.jsonl,model-http.jsonl}`，14 个真实检索上下文；原始对照由 original_directory / original_index 定位。原 index 指最终 model-http 的 index，不是 API results 行号。独立审读全部可见正文和选择；未读 defender、未调用模型、未改生产。

## Decision

**严格 13/14，不批准短语义 key 生产接线。** 昆虫 Fast 的队徽错位修复，但拼布 Thinking 新增未问的义卖摊位报名费用；同输入 v13 对应答案没有该信息。旧 13/14 → 新 13/14，一槽改善、一槽退步，其余十二槽通过。F-17 仍 open（Critical），生产保持 v13 / default false。

本结论不是因生成更慢、首节较长、标题、段落位置或无害重复而失败。阻塞是冻结 rubric 明确要求排除的真实无关信息。

## Quality

F/L/R/A/N/C = 全文所问事实 / 首节 / 相关性 / 所问未知 / 未问未知省略 / 引用。全部 14 答为中文；已问未知、动作、条件、记录、用途与主要许可均保留。未问未知新增失败一槽，不能因它是真实资料就当作相关答案。

| Slot | Case | Mode | v13 strict | v14 F/L/R/A/N/C | v14 strict |
|---:|---|---|---|---|---|
| 1 | L4 | Fast | P | P/P/P/P/P/P | P |
| 2 | Archive | Fast | P | P/P/P/P/P/P | P |
| 3 | Room | Fast | P | P/P/P/P/P/P | P |
| 4 | Toy | Fast | P | P/P/P/P/P/P | P |
| 5 | L4 | Thinking | P | P/P/P/P/P/P | P |
| 6 | Archive | Thinking | P | P/P/P/P/P/P | P |
| 7 | Room | Thinking | P | P/P/P/P/P/P | P |
| 8 | Toy | Thinking | P | P/P/P/P/P/P | P |
| 9 | Greenhouse | Fast | P | P/P/P/P/P/P | P |
| 10 | Patchwork | Fast | P | P/P/P/P/P/P | P |
| 11 | Insect | Fast | F | P/P/P/P/P/P | P |
| 12 | Greenhouse | Thinking | P | P/P/P/P/P/P | P |
| 13 | Patchwork | Thinking | P | P/P/F/P/F/P | F |
| 14 | Insect | Thinking | P | P/P/P/P/P/P | P |

L4 两答将“首次定位基准/周期偏移/旧托盘不可替代”移到记录用途段，主要许可与范围仍在首节，全文用途完整，允许。旧“全部条件都在首节”指标仍不通过，不新增为本次门槛。Toy Thinking 首节多一个原始记录标题，未增加无关业务事实，不算实质退步。Archive/Room 两模式可见正文与原 v13 相同；其余改变均逐份读完。

## Concrete Evidence

昆虫 Fast 保留原始第三来源温室记录。v14 的实际键与选择为：

- `9:流程没有承诺处理时限。` → answers=处理时限，role=limit；
- `13:记录说明没有给出照片文件` → answers=文件大小上限，role=limit；
- `14:观察队的队徽由三个圆环组` → answers=未询问，role=omit；
- 聚餐未知及温室第三来源全部 omit。

可见正文两项所问未知正确，队徽消失；不能仅因选择看似正确就忽略其它题。拼布 Thinking 实际选择 `15:本记录没有提供义卖摊位的` → **answers=补领费用，role=limit**。其真实原文是“本记录没有提供义卖摊位的报名费用”，不是遗失纸样的补领费用。可见末节完整展示了这条未问未知。

### F-17 — Unasked Information Remains After Semantic Keys

- **Label**: issue (blocking, must-fix)
- **id**: F-17（既有相关性问题的本轮复验）
- **severity**: Critical；critic §2(a)，目标无关信息混入仍复现，并在原来通过的同输入槽出现新退步。
- **location**: v14 results 第 13 行、selection.clauses 的实际键 `15:本记录没有提供义卖摊位的` 及条件与边界段。
- **symptom**: 用户问遗失纸样补领费，回答附带未问的义卖摊位报名费未知。
- **impact**: 相关性与未问未知排除失败；首节和所问事实完整不抵消该新增内容。
- **root_cause**: 短语义 key 修复了一个定位错位，但本槽仍把另一事项的费用未知关联为补领费用。可读前缀不能独立保证对象/动作关系一致。
- **recommendation**: 不接线，不启默认；保留这组原始输入/选择/正文作为开发对照。后续仅验证通用语义关系改进，不按费项、队徽或实体删句。
- **verification**: 原七题全部所问内容和首节不丢，实际未问信息排除；继续沿既定多轮/API/新冻结留出流程，当前本轮未通过。
- **status**: open

## Isolation and Rendering

14 个 inputs.request 与原 model-http 中最终生成请求逐项一致，original_answer 与相应首轮 API 正文一致。新 wire 请求只改精确系统提示标识说明及 schema properties/required 的完整键；用户消息、实际检索上下文、模型参数和其它 schema 均保持。不存在额外检索、控制或基线模型调用。

全部实际键等于编号加原文前 12 字符；逐键映射回原数字槽后，用当前 v13 原文渲染离线重放，14/14 与实验可见正文一致（正常统一尾注除外）。这仅确认真实选择如何成为正文，不代替上述语义评判。14 次新 HTTP 均为 generation、每答 1 次、stop，无重试。

## Comparable Generation Cost

只使用两侧最终 model-http 的 **end - start**；没有把新生成耗时与旧 API first_body 比较。旧 Thinking 的控制/检索时间不混入这张表，端到端首见需后续 API 测量。

| Scope | n | v13 generation P50/P95 s | v14 generation P50/P95 s | Mean output tokens v13→v14 |
|---|---:|---:|---:|---:|
| All | 14 | 5.428 / 7.361 | 7.475 / 10.451 | 541.57 → 714.36 |
| Fast context | 7 | 7.224 / 7.402 | 9.348 / 11.047 | 632.57 → 832.00 |
| Thinking context | 7 | 5.109 / 5.429 | 6.639 / 7.698 | 450.57 → 596.71 |

P95 线性插值，旧留存批与新批并非随机交替。报告的平均输入 tokens 1294→1317，输出约增加 31.9%；键的额外成本符合预期，调用数保持一次。速度退让如实记录，但否决生产的直接原因是已复现的质量退步。

**praise (non-blocking)**：语义 key 在保留第三来源的昆虫 Fast 上纠正了真实错位，全部七题事实覆盖和首节未退步；这为进一步最小实验提供依据，不能据此宣称全局相关性已解决。


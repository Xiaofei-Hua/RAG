# API v17 Critic Review

**Date**: 2026-11-11  
**Evidence**: `procedure-relevance-api-v17-a` 16 答、`procedure-relevance-api-v17-b` 12 答及原始 model-http；分别对照 `procedure-relevance-api-v13-baseline` 相同四题两轮和 `procedure-relevance-holdout-v13-baseline` 前两轮。独立审读，未读 defender、未调用模型、未改候选。

## Decision

**真实 API 严格 28/28，开发对照通过，可以冻结后进入真正新留出；默认仍 false。** 七题全文、实际首节、相关性、所问未知与引用均通过，无新实质退步。B 组未问参观/义卖/聚餐未知也全部省略。不是把离线回放计作新生成：28 槽均有独立真实最终请求，实际正文分别与已经独立审过的 v16 选择经当前 v17 生产渲染完全相同。

A 保留原 20 文档 corpus 与四题，B 保留原 6 文档与三题；逐项核对题目/资料/rubric 没有修改。原基线缺陷已在 `api-v13-critic.md`、`holdout-v13-critic.md` 记录，本报告沿用相同判定，不重写旧失败。

| Side | Full | Lead | Relevant | Citation | Asked unknowns | Strict |
|---|---:|---:|---:|---:|---:|---:|
| matched complete-generation baseline | 2/28 | 18/28 | 21/28 | 21/28 | 28/28 | 2/28 |
| v17 | 28/28 | 28/28 | 28/28 | 28/28 | 28/28 | 28/28 |

B 组未问未知排除为 7/12→12/12。Toy 三项完成许可实际在首节；Insect 队徽与 Patchwork 未问义卖费均省略，Archive 编号关联和用途保留。原文标题、无害重复、较长首节没有单独扣分。

## Slot Record

F/L/R/C/U=全文/首节/相关性/引用/所问未知。原 baseline slot 是对应 results 行号；相同正文合并审读，但每槽实际路由与调用均核验。

| Group / slot | Round / mode | Case | Original baseline slot | Baseline F/L/R/C/U | v17 all five / strict |
|---|---|---|---:|---|---|
| a/1 | 1 / fast | L4 | 6 | F/P/P/P/P | P / P |
| a/2 | 1 / fast | Archive | 7 | P/P/P/P/P | P / P |
| a/3 | 1 / fast | Room | 9 | F/P/P/P/P | P / P |
| a/4 | 1 / fast | Toy | 10 | F/P/P/P/P | P / P |
| a/5 | 1 / thinking | L4 | 17 | F/P/P/P/P | P / P |
| a/6 | 1 / thinking | Archive | 18 | F/P/P/P/P | P / P |
| a/7 | 1 / thinking | Room | 20 | F/P/P/F/P | P / P |
| a/8 | 1 / thinking | Toy | 21 | F/P/P/P/P | P / P |
| a/9 | 2 / fast | L4 | 28 | F/P/P/P/P | P / P |
| a/10 | 2 / fast | Archive | 29 | P/P/P/P/P | P / P |
| a/11 | 2 / fast | Room | 31 | F/P/F/F/P | P / P |
| a/12 | 2 / fast | Toy | 32 | F/P/P/P/P | P / P |
| a/13 | 2 / thinking | L4 | 39 | F/P/P/F/P | P / P |
| a/14 | 2 / thinking | Archive | 40 | F/P/P/P/P | P / P |
| a/15 | 2 / thinking | Room | 42 | F/P/P/P/P | P / P |
| a/16 | 2 / thinking | Toy | 43 | F/F/P/P/P | P / P |
| b/1 | 1 / fast | Greenhouse | 1 | F/F/P/P/P | P / P |
| b/2 | 1 / fast | Patchwork | 2 | F/F/F/F/P | P / P |
| b/3 | 1 / fast | Insect | 3 | F/P/F/F/P | P / P |
| b/4 | 1 / thinking | Greenhouse | 4 | F/F/F/P/P | P / P |
| b/5 | 1 / thinking | Patchwork | 5 | F/F/F/P/P | P / P |
| b/6 | 1 / thinking | Insect | 6 | F/F/P/P/P | P / P |
| b/7 | 2 / fast | Greenhouse | 7 | F/P/P/P/P | P / P |
| b/8 | 2 / fast | Patchwork | 8 | F/P/P/F/P | P / P |
| b/9 | 2 / fast | Insect | 9 | F/F/P/P/P | P / P |
| b/10 | 2 / thinking | Greenhouse | 10 | F/F/F/P/P | P / P |
| b/11 | 2 / thinking | Patchwork | 11 | F/F/F/F/P | P / P |
| b/12 | 2 / thinking | Insect | 12 | F/F/P/P/P | P / P |

## Actual Route and Cost

候选两组共 **70 HTTP = 28 generation + 42 control**，对应基线也 70 次。每答只有 1 次最终 generation；Fast 总 1 次，Thinking 总 4 次。28 答全部 direct-role clauses、stop、API 200，SSE token 拼接等于 done.full_response 和存盘 answer；未看到 rubric/coverage 等离线元数据进入最终生成输入。

A/1 与 A/9 的 L4 Fast 原基线另带英文 R7 来源，候选只保留两个中文来源，这是此前已验证、未变的中文资格/证据选择行为；不把两侧所有上下文误称完全相同。其余 26 配对槽最终来源与顺序相同。v17 也未更改该选择规则。

下面比较同口径 API 完整首见；模型生成另用最终 wire 时间，不混用：

| Scope | n/side | Baseline first P50/P95 s | v17 first P50/P95 s | Mean final output tokens baseline→v17 |
|---|---:|---:|---:|---:|
| All | 28 | 12.832 / 16.891 | 9.343 / 10.779 | 1023.82 → 637.29 |
| A | 16 | 12.832 / 16.659 | 9.379 / 10.802 | 1050.50 → 627.00 |
| B | 12 | 13.072 / 16.226 | 9.054 / 10.668 | 988.25 → 651.00 |
| Fast | 14 | 10.776 / 15.521 | 8.732 / 9.936 | 1010.36 → 750.29 |
| Thinking | 14 | 14.744 / 16.858 | 9.510 / 10.807 | 1037.29 → 524.29 |

最终 wire generation P50 为 10.585→6.296 秒。P95 线性插值，留存 baseline 与新批非随机交替，未宣称统计显著或所有场景普遍保证。

代码边界与英文/普通原路径未变，沿用已审 v13 的 28/28 原请求一致证据及当前回归；本轮没有重复运行无改动的控制模型，也不宣称原英文质量问题已解决。已暴露七题通过仍不能替代冻结后的新留出。


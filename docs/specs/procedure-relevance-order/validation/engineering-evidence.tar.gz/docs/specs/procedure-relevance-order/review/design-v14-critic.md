# Design v14 Critic Review

**Date**: 2026-11-11  
**Scope**: `design.md` v14 Semantic Clause Keys；精确 `validation/semantic-key-prompt.txt`；已存 v13 API 开发/新留出候选首轮真实请求。未读 defender，未调用模型，未改生产。

## Decision

**可开始临时 14 答最小实验；新增设计 Critical/High: 0。** 不是生产接线或默认启用批准。已有 F-17 仍 open、default false；成功后仍按既定多轮/API/重新冻结的新留出验证，失败不扩大。

## Mechanism and Isolation

`praise (non-blocking)`：本设计针对真实可定位的错位：v13 昆虫 Fast 中实际条款 14 是队徽，却被写成 answers=处理时限、role=limit。固定键改为 `编号:原文前12字符`，让受约束输出在分类前包含当前条款原文提示，是可证伪的单一机制；没有队徽、时限、实体白名单或后置删句。

精确 prompt 与 v13 相比只替换标识说明一行，原 answers/role、业务记录/外观语义、已问/未问未知等均未改。原用户 messages 和数字条款全文保留；完整新键内的编号及原文开头用于对应既有全文。动态 schema 的 properties/required 一并使用真实新键；临时解码按完整预定键映射回原条款，不能按位置配对或接受仅前缀相似的键。分句、来源、分类、规范词前置、原文渲染和预算保持原样。

编号使相同前缀仍可唯一映射；原文前缀并不证明正确理解，仍须按实际可见正文评审。v4 的自由长标识列表曾重复至 length，本次是短键固定 required map，具备足够机制差异进入最小检验；不以此预言本次一定成功。

## Executable Comparison

核对 `procedure-relevance-api-v13-candidate` 与 `procedure-relevance-holdout-v13-candidate` 已存首轮记录，确有全部 7 个中文题 × Fast/Thinking 的 14 个 clauses 请求，每个原请求只有一次 generation、temperature=0、max_tokens=2048。条款数 13–25；Fast 昆虫的第三温室记录来源在原消息中，可直接保留触发条件。只重跑新键候选，不重复调用旧基线、检索或控制模型；旧回答作为同输入对照。

按既有每题冻结 rubric 独立检查全文、实际首节、相关性、已问/未问未知及引用，同时看全部 7 题是否有新实质退步，不能只看队徽是否消失。原文标题、无害重复和首节长度仍不单独失败。若 length、解析或渲染失败，如实计入结果，不追加纠错模型。

额外输出约为每槽不超过 12 个原文字符及分隔符，当前 13–25 槽约增加 156–300 个前缀字符；token 增幅依实际分词，不能把字符直接当 token。记录实际耗时 P50/P95、输出 tokens、finish_reason 和调用数即可，不增加所有分位数全面更优的门槛。

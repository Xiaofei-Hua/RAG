# Holdout v17 Critic Review

**Date**: 2026-11-12  
**Mode**: 完整 critic，生成热路径；无新增安全边界。  
**Evidence**: 冻结 `validation/holdout-v17.json` r1、`freeze-v17.md`、`runtime-resume-v17.json`，以及 `data/eval/procedure-relevance-holdout-v17-{baseline,candidate}/{results,model-http}.jsonl` 各18答。独立审读实际正文、首节、selection 与最终请求；未读本轮 defender 结论，未调用模型、修改候选或协议，未重复已通过测试矩阵。

## Decision

**v17 新留出不合格，不具备默认启用资格；默认 false 保持。Critical: 1（既有 F-16 在新题复现），High: 0。** 候选严格 **12/18**：离线包与雨量月表各六答通过；陶艺六答全文完整，但实际首节只有标题和范围，主要开放许可仍留在第二节。对应陶艺 baseline 六答的首节全部完整，因此这是目标维度的实质退步，不能由全文覆盖、相关性改善或速度收益抵消。

本三题在冻结后独立新建并先完成完整资格预检；本次失败如实保留，现转为开发题。不能针对本题修正后仍称其为新留出；后续默认资格需要重新冻结后真正新的独立留出。未引入本任务以外的全系统完美门槛。

## Quality

F/L/R/C/A/U 为全文、实际首节、相关性、引用、所问未知、未问未知排除；严格通过要求各项均通过。全文单独检查所问准备、动作、条件、记录和用途，不用它代替首节。正常标题、较长首节、分行和无害重复均不单独判失败。

| Side | F | L | R | C | A | U | Strict |
|---|---:|---:|---:|---:|---:|---:|---:|
| Baseline | 2/18 | 17/18 | 16/18 | 16/18 | 18/18 | 17/18 | 2/18 |
| v17 | 18/18 | 12/18 | 18/18 | 18/18 | 18/18 | 18/18 | 12/18 |

候选三种正文分别在两模式三轮完全相同；每槽实际请求、selection、完成状态与正文均核对，同文合并语义审读，不把重复采样当18个独立新题。陶艺保留了正常送展、异常分支、开放单关联和所有记录用途，正确省略地毯及未问课程费用；离线包保留非制包人签名、本版修订号、整包重试、旧版撤下记录及所有所问未知；雨量月表保留原页0与未观测区别、未观测仍可复核、缺页待查及修订/姓名改字记录，未混入书柜或摄影展截止日。Fast 检索中的第三份他业务资料也全部省略。

## Slot Review

P/F=通过/失败；两侧槽顺序一致。C=陶艺、O=离线包、R=雨量月表。所有候选均实际使用完整键 clauses 路由，每答最终 generation 一次。

| Slot | Round | Mode | Case | Baseline F/L/R/C/A/U | Baseline strict | v17 F/L/R/C/A/U | v17 strict |
|---:|---:|---|---|---|---|---|---|
| 1 | 1 | Fast | C | F/P/P/P/P/P | F | P/F/P/P/P/P | F |
| 2 | 1 | Fast | O | F/P/P/P/P/P | F | P/P/P/P/P/P | P |
| 3 | 1 | Fast | R | F/P/P/P/P/P | F | P/P/P/P/P/P | P |
| 4 | 1 | Thinking | C | F/P/P/P/P/P | F | P/F/P/P/P/P | F |
| 5 | 1 | Thinking | O | P/P/P/P/P/P | P | P/P/P/P/P/P | P |
| 6 | 1 | Thinking | R | F/P/P/P/P/P | F | P/P/P/P/P/P | P |
| 7 | 2 | Fast | C | F/P/F/P/P/P | F | P/F/P/P/P/P | F |
| 8 | 2 | Fast | O | F/P/P/P/P/P | F | P/P/P/P/P/P | P |
| 9 | 2 | Fast | R | F/P/P/P/P/P | F | P/P/P/P/P/P | P |
| 10 | 2 | Thinking | C | F/P/F/P/P/F | F | P/F/P/P/P/P | F |
| 11 | 2 | Thinking | O | F/P/P/P/P/P | F | P/P/P/P/P/P | P |
| 12 | 2 | Thinking | R | F/P/P/P/P/P | F | P/P/P/P/P/P | P |
| 13 | 3 | Fast | C | F/P/P/F/P/P | F | P/F/P/P/P/P | F |
| 14 | 3 | Fast | O | F/P/P/P/P/P | F | P/P/P/P/P/P | P |
| 15 | 3 | Fast | R | F/F/P/P/P/P | F | P/P/P/P/P/P | P |
| 16 | 3 | Thinking | C | F/P/P/P/P/P | F | P/F/P/P/P/P | F |
| 17 | 3 | Thinking | O | P/P/P/P/P/P | P | P/P/P/P/P/P | P |
| 18 | 3 | Thinking | R | F/P/P/F/P/P | F | P/P/P/P/P/P | P |

### Baseline Evidence

- 陶艺1/4/7/10/16缺按布置图摆放等正常送展步骤；4还缺入馆记录及待处理检查保留/不覆盖旧检查等要求，16缺开放单关联。13虽有完整准备，却缺开放单关联及用途，并把其他业务的姓名改字记录类推成作者简介改字的必留记录，引用陶艺两来源无法支持该要求。推断标记不能使“需保留”成为资料事实。
- 陶艺7另带“保留被替代月表、追溯月表数值变动”的明确他业务内容；10带浅灰地毯和未问课程报名费未知。它们分别失败相关性，10同时失败未问未知排除。
- 离线包2/8/11/14没有说明收集路线文件、登记文件信息并建立装包清单的准备动作；11还未说明追溯路线资料的用途。5/17准备、分支、字段及用途完整，判通过。已完整表达下载的必要许可条件，不要求再逐字重复“压缩完成本身不等于许可”。
- 雨量3/6/9/12缺正常建立/逐日填写动作及“有原页的未观测仍可复核”这项所问状态；部分还漏逐日复核字段或原表/修订表关联。15有准备，但缺未观测可复核及逐日复核记录，且首个结论段没有固定雨量筒人工月表范围，后文范围不能补首节。18有未观测可复核，但缺正常准备与逐日记录，并将补页、修订和姓名改字的详细记录错误引用到确认流程来源，而字段实际在记录要求来源。

## Finding

### F-16 — Natural Permission Remains Outside the Lead

- **Label**: issue (blocking, must-fix)
- **id**: F-16（既有发现复现，不另复用编号）
- **severity**: Critical；按 critic §2(a)，本次目标“先给主要规则和范围”在冻结候选的真实新题再次复现，且相同题 baseline 首节通过。
- **location**: candidate results 第1/4/7/10/13/16行、各自最终 wire 的 `3:布展员登记作品号...` 条款；`core/procedure_generation.py:182`、`:190`；REQ-702/704/705，生成热路径。
- **symptom**: 实际“规则与适用范围”只写陶艺流程标题、馆内桌面已烧成作品范围和记录说明标题；“一个台面获准开放的依据是该台全部作品有当前摆位检查记录，且策展员在台面开放单确认底座稳固、通道可通行”全部在“操作步骤”。两模式各三轮均如此。
- **impact**: 用户明确先问的主要开放许可没有进入实际首节；全文完整不能闭合顺序目标。六槽构成首节实质退步，不批准默认。
- **root_cause**: 实际 unit 3 将准备、主要许可、松动处置和调整复查合在一个完整键，模型选为 step；标题被选 main_rule。渲染只按角色和既定规范词前置，不能确保自然表达的主要许可进入 lead。完整键保证对应正确，并不保证问题要求的排序关系正确。
- **recommendation**: 保持 v17 默认 false、保存失败并把本批退为开发；在 `prepare_procedure` 条款组织、`ProcedureAnswer` 角色表达与 `render_procedure` 首节组合这一现有边界提出最小一般性修订。先以混合条款中的主要许可为已复现目标验证，不直接按陶艺实体或单句措辞补白名单后冒称新留出成功，不追加模型调用。
- **verification**: 永久回归需覆盖本次真实 selection 与实际首节，要求全台当前检查及策展员底座/通道确认前置，同时全文、所问未知、omit 与来源不退步；后续同旧rubric开发实测、重新冻结后的全新留出和默认实际冒烟依原流程验收。
- **status**: open；本报告没有业务修复 commit 或回归通过可填，F-16 不得标 closed。

## Actual Route and Cost

两侧各 **45次 HTTP = 18 generation + 27 control**，Fast 每答总1次、Thinking 每答总4次。所有最终生成均一次、stop、API 200/complete。候选全为直接 clauses，无 answers 字段；每槽实际完整键精确对应请求 schema，类别均来自冻结六类。两侧18个对应槽的最终来源名、顺序和原文相同；Fast 各含三份资料，Thinking 各含对应两份资料，不把第三份无关来源省略误报为不同检索实验。

最终参数均 none/top_p .8/2048，baseline .7、candidate 0 与冻结方案一致。最大候选输出838 tokens，无 length。未看到 coverage、manual_required、rubric、freeze 或 publication_contract 等离线元数据进入请求。SSE token 拼接、done.full_response 与会话存盘正文各侧18/18一致；这些终态事实不代替语义质量。

| Scope | n/side | Baseline complete-first P50/P95 s | v17 complete-first P50/P95 s | Mean final output tokens baseline→v17 |
|---|---:|---:|---:|---:|
| All | 18 | 13.312 / 16.943 | 9.492 / 9.906 | 1069.89 → 684.83 |
| Fast | 9 | 12.286 / 13.408 | 9.448 / 9.633 | 1073.56 → 811.00 |
| Thinking | 9 | 14.676 / 17.310 | 9.790 / 9.907 | 1066.22 → 558.67 |

完整首见是正常检索/编排/检查后第一个实际正文，不是状态事件；最终 wire generation P50/P95 另为 **11.840/13.563→7.745/9.434秒**，不与API时间混用。平均报告输入tokens 978.50→1199.50；完整原文键有输入/回显成本，整体输出仍下降。P95线性插值；固定批次先baseline后candidate，非随机交替，不宣称统计显著或普遍保证。

恢复运行记录为同Ollama 0.24.0-format-backport、Qwen3.5:9b Q4_K_M、context4096、全GPU；启动前空prompt返回 `done_reason=load`、正文为空，只加载权重，不计测量题调用，也没有预生成测试答案。

**praise (non-blocking)**: 完整原文角色分类在本新留出保持全部所问事实与未知、排除无关资料，单调用预算和实际性能收益成立。明确承认这些收益，同时保留首节真实失败，才能为下一次最小修订提供有效依据。

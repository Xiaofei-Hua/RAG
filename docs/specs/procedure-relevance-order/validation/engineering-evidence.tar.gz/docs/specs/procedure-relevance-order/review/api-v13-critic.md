# API v13 Critic Review

**Date**: 2026-11-11  
**Evidence**: `validation/api-development-v13.json`；`data/eval/procedure-relevance-api-v13-{baseline,candidate}/{results,model-http}.jsonl`，两侧各44槽，11题×Fast/Thinking×两轮。独立逐答审读；相同候选正文合并审读但保留每槽状态。未读defender，未调用模型，未改生产代码。

## Decision

**四个中文实际改动路径严格16/16，通过本次API开发对照；可以冻结候选与中文资格，进入独立全新中文留出。默认仍false。** 相对基线未见新实质退步：全文与首节完整，所问未知保留，无关装饰/库存未入正文，引用正确。已暴露题的通过不替代新留出。

16槽实际均使用clauses，每答一次generation、stop且complete。L4/Archive/Room及Thinking Toy与已审机制实验正文相同；Fast Toy两轮为另一份相同正文，已独立检查三项交付许可、修复员交接、代领/附件/地址分支、全部记录用途及未知，亦通过。

## Changed Chinese Quality

| Side | Full | Lead | Relevant | Citation | Asked unknowns | Strict |
|---|---:|---:|---:|---:|---:|---:|
| baseline | 2/16 | 15/16 | 15/16 | 13/16 | 16/16 | 2/16 |
| candidate | 16/16 | 16/16 | 16/16 | 16/16 | 16/16 | 16/16 |

F/L/R/C/U=全文/首节/相关性/引用/所问未知。首节较长、必要重复、标题留存不单独失败；首节必须实际包含主要许可与范围，后文不能补救。辅助answers不作语义证明。

| Slot | Round / mode | Case | Baseline F/L/R/C/U | Candidate F/L/R/C/U |
|---:|---|---|---|---|
| 6 | 1 / Fast | L4 | F/P/P/P/P | P/P/P/P/P |
| 7 | 1 / Fast | Archive | P/P/P/P/P | P/P/P/P/P |
| 9 | 1 / Fast | Room | F/P/P/P/P | P/P/P/P/P |
| 10 | 1 / Fast | Toy | F/P/P/P/P | P/P/P/P/P |
| 17 | 1 / Thinking | L4 | F/P/P/P/P | P/P/P/P/P |
| 18 | 1 / Thinking | Archive | F/P/P/P/P | P/P/P/P/P |
| 20 | 1 / Thinking | Room | F/P/P/F/P | P/P/P/P/P |
| 21 | 1 / Thinking | Toy | F/P/P/P/P | P/P/P/P/P |
| 28 | 2 / Fast | L4 | F/P/P/P/P | P/P/P/P/P |
| 29 | 2 / Fast | Archive | P/P/P/P/P | P/P/P/P/P |
| 31 | 2 / Fast | Room | F/P/F/F/P | P/P/P/P/P |
| 32 | 2 / Fast | Toy | F/P/P/P/P | P/P/P/P/P |
| 39 | 2 / Thinking | L4 | F/P/P/F/P | P/P/P/P/P |
| 40 | 2 / Thinking | Archive | F/P/P/P/P | P/P/P/P/P |
| 42 | 2 / Thinking | Room | F/P/P/P/P | P/P/P/P/P |
| 43 | 2 / Thinking | Toy | F/F/P/P/P | P/P/P/P/P |

基线失败依据：

- L4 6/28/39遗漏准备、检查后记录或检查/追溯用途；17遗漏保存机台/托盘/样张记录的追溯用途。39还把检查记录日期/结果/失败样张及合并未知信息错配到来源。
- Archive 18/40遗漏调阅编号关联档号/阅览证号/计划日期及其用途；18另缺交接边界和历史状态用途。Fast两轮7/29完整通过。
- Room 9缺等候不承诺、预约号关联字段及一次使用用途；20缺等候不承诺且交接/结束记录字段错引办理规则。31缺编号关联，实际带入“资料室今年订了18本地方年鉴”，同号追加结论段错引办理规则。42缺申请/容量/等候分支、改期与电话例外、同号追加结论。
- Toy 10/21/43缺修复员交玩具号、换件清单和检查结果给接待员；32缺多项记录用途与委托纸保存等细节。43还缺领取单关联与用途，首段未给适用范围，后文范围不补首节。

legacy全部条件首节单列：本次L4基线4/4、候选0/4；候选失败处理及未知在后段，符合当前主要规则/范围标准，但不改写旧标准。R7为未改英文路径：基线仅38的首节满足全部条件且引用正确，候选四槽均存在换头起算遗漏或错误绑定等问题；该观察不归因v13。

## Unchanged Controls

**28/28对照槽最终generation request逐字段相同**，包括prompt、用户上下文、schema、参数；均为原basis/conditions/conclusion格式。三英文程序控制未因候选开关先删改证据。输出波动来自同一原请求的重复生成，不计为v13改进或退步；下面仍保留实际失败。

普通题16槽：基线15/16，候选16/16。唯一基线失败是34（Thinking第二轮电池题），只并列540/600分钟，没有明确回答芦序记录更长；其它比较限制、零值、校准起算、价格未知与交付起保均通过。候选16槽全部通过，不能将34的变动归功于v13。

英文12槽仍有明显质量问题，逐槽观察如下。P/F是严格整题判断；长首段或语义等价表达不因未逐字引用而失败。

| Slot | Case / mode / round | Baseline | Candidate | Material observations |
|---:|---|---|---|---|
| 5 | R7 / Fast / 1 | F | F | 两侧缺准备/记录/用途和换头重启；候选操作事实大量错引check_notes。 |
| 16 | R7 / Thinking / 1 | F | F | 基线把周期复查通过泛化为新37小时起点；候选缺记录/用途及换头起算。 |
| 27 | R7 / Fast / 2 | F | F | 基线大量操作事实错引check_notes且缺准备/用途；候选缺准备/用途并把失败重检绑定重启37小时。 |
| 38 | R7 / Thinking / 2 | F | F | 基线缺初检/周期用途；候选将失败重检后的通过当新计时起点，缺周期用途。 |
| 8 | Caption / Fast / 1 | F | F | 基线缺文稿ID/草稿链接、审核字段、标题例外与部分用途；候选缺前三用途并混入联赛积分/记分卡/remote games，部分未知段错配引用。 |
| 19 | Caption / Thinking / 1 | F | P | 基线首节缺预录英语室内范围，全文缺文稿ID/草稿链接和独立审核用途；候选全文语义及首节通过。 |
| 30 | Caption / Fast / 2 | F | F | 基线返工漏完整播放复查及用途；两侧首节范围不全，均有联赛内容或积分未知混入。 |
| 41 | Caption / Thinking / 2 | F | F | 基线缺文稿ID/全部草稿链接及退稿用途；候选全文完整，但首节没有明确排除直播/翻译，后文不能补首节。 |
| 11 | League / Fast / 1 | F | F | 两侧缺建比赛记录的字段与附卡步骤；首节没有限定排除，基线另缺卡/版本链接与追溯用途。 |
| 22 | League / Thinking / 1 | F | F | 两侧缺建记录；基线另缺纠正后确认、桌号例外及部分用途。 |
| 33 | League / Fast / 2 | F | F | 基线首节缺主要展示许可与排除范围，全文缺纠正确认、桌号例外及公开展示记录；候选缺建记录且首段范围无排除。 |
| 44 | League / Thinking / 2 | F | F | 基线用中文回答英语题且多项缺漏/异议字段错引；候选缺建记录、纠正确认、桌号例外和公开展示记录。 |

英文严格0/12→1/12仍是未改请求的实际观察，不构成英文已获修复的证据；后续默认范围须继续明确限定中文。

## Calls, Publication and Cost

两侧各118次HTTP = **44 generation + 74 control**。88个最终generation全为单次、stop；API200、complete，token拼接=done正文=results.answer。Fast每答总1次；除联赛外Thinking每答总4次；联赛Thinking两轮在两侧均走既有rewrite，总8次（7 control+1 generation）。不能把控制调用算为新增生成，也不能把所有Thinking写成总4。

| Scope | n/side | Baseline first-body P50/P95 s | Candidate first-body P50/P95 s | Mean output tokens baseline→candidate |
|---|---:|---:|---:|---:|
| Changed Chinese | 16 | 12.832 / 16.659 | 7.872 / 9.277 | 1050.50 → 532.38 |
| Chinese Fast | 8 | 10.784 / 13.656 | 7.462 / 7.664 | 1006.75 → 618.50 |
| Chinese Thinking | 8 | 14.744 / 17.452 | 8.459 / 9.356 | 1094.25 → 446.25 |
| English controls | 12 | 11.620 / 17.095 | 10.838 / 19.392 | 890.33 → 892.25 |
| Ordinary controls | 16 | 4.170 / 5.961 | 3.834 / 5.791 | 251.06 → 243.12 |
| All slots | 44 | 9.523 / 16.424 | 7.554 / 13.390 | 716.11 → 525.34 |

首见为完整检查后可见正文，P95线性插值。分批运行不冒称随机交替；英文P95变高如实保留，但相同请求波动不追加新的候选门槛。当前核心证据是中文完整性/相关性改善且单调用下首见更快，下一步是冻结后真正新中文留出，不是直接开启默认。

# Mechanism v2 Critic Review

**Date**: 2026-11-11  
**Inputs**: frozen `validation/development.json`; `data/eval/procedure-relevance-mechanism-v2/results.jsonl`, `model-http.jsonl`, `prompts.json`.  
**Independence**: 独立阅读实际全文、quote/IDs、原始来源和HTTP记录；未读 defender、未调用模型。8个题/顺序组合在两轮的正文与quote完全相同，合并审读并保留16槽结论。

## Decision

**不能进入生产接线。** 严格整题8/16；v2修复了档案首节位置，但没有修复字幕首节的独立审核条件，并新丢了部分全文事项。增加quote后仍不能把“摘录已出现发布许可”当成“角色与所有许可条件齐全”。

相对v1 anchored，首节由8/16升至12/16，全文完整却由16/16降至10/16，严格整题仍8/16。无关句和引用均16/16通过，16次实际生成均单调用并stop。保持默认false；v1 F-03的档案部分得到本开发样本支持，字幕部分仍open，不能整体关闭。

## Metrics

| Metric | v1 anchored | v2 rule_lead |
|---|---:|---:|
| Full semantics | 16/16 | 10/16 |
| Actual lead | 8/16 | 12/16 |
| No irrelevant facts | 16/16 | 16/16 |
| Supported citations | 16/16 | 16/16 |
| Strict answer | 8/16 | 8/16 |
| Quote includes required main rule/role | N/A | 12/16 |
| First body P50 | 3.726 s | 4.678 s |
| First body P95 | 4.266 s | 6.240 s |
| Mean completion tokens | 332.0 | 453.4 |
| Recorded generation calls | 16 | 16 |

时间为分批实验的描述统计，非交替配对收益或API线上结论；P95为样本线性插值。额外输出平均约121 token，本批完整首见中位数高约0.95秒。没有以该耗时变化新增性能门禁，拒绝原因是实际语义退步及目标未闭合。

quote维度仅为诊断，严格整题仍按冻结的全文/首节/相关性/引用四维。旧“全部条件入首节”口径另记R7/L4为0/8（包括价格等未知未全部在首节），不改写历史失败。

## Evidence

| Code | Reproduced failure |
|---|---|
| R1 | R7反顺序2/2全文未选入“Repeat the reference-sheet check after every 37 accumulated operating hours.”；仅有有效时间/待机排除、初次起算和换头后新37小时间隔，不能代替用户明确询问的正常周期复查触发规则。对应原始编号11没有被选入。 |
| A1 | Archive原顺序2/2全文缺“每个调阅编号关联申请档号、阅览证号和计划日期，用于对应一次完整调阅。”；缺编号关联的三个字段及用途，原始编号10没有被选入。其余初核/候补/修正重核记录、异常和未知信息仍有，不能概括成所有记录都丢失。 |
| C1 | Caption两顺序4/4的rule_quote和实际首节都仅写同音频/字幕版本经reviewer批准发布，没有“未参与编辑的审核者”或“independent review”。独立性虽在后续准备动作中出现，仍不满足冻结lead_rubric。 |
| C2 | Caption反顺序2/2全文还缺job card的转录稿标识、所有草稿链接（含拒稿），以及转录稿匹配避免过期稿、完整回放发现相邻提示间遗漏、独立审核分离编写与发布决定三项用途。相应原始编号2/5/6均未选入。 |

正向结果也完整保留：

- Archive4/4的quote与实际首节均已包含共同清点签名完成交接后才能阅览，且明确开放纸档/工作日馆内/不外借；没有墙钟或年鉴。
- R7/L4的quote与首节均有实际操作许可及范围，原文事件限定仍在，没有将换头/换托盘重置错误推广为普通复查重置；L4四答全文完整。
- Caption原顺序全文完整，反顺序仍保留阻塞确认、完整回放、退回循环、同版本批准、音频变更重新走流程、标题拼写例外以及未知期限。其失败范围如C1/C2，不夸大为整个流程错误。
- 规则/范围字段有重叠或额外相关条款，但实际正文来自所选真实来源。本轮不新增“quote与全部IDs严格逐字相等”门禁；没有因相关原文重复单独扣分。

## Findings

### F-05 — Quoting the Release Sentence Still Misses Reviewer Independence

- **Label**: issue (blocking, must-fix)
- **id**: F-05
- **severity**: Critical；critic §2(a)，v1已发现的首节条件缺失仍真实复现。
- **location**: 本报告C1，结果槽7/8/15/16；REQ-702/705。
- **symptom**: quote与首节都未包含独立审核角色条件；后节补充不能抵消。
- **impact**: 首节未完整回答用户要求优先交代的主要发布规则。
- **root_cause**: 先摘一句发布许可仍会遗漏另一条款限定的审核者资格，quote并未形成完整的许可条件集合。
- **recommendation**: v2不接生产；下一机制须围绕实际许可依赖与角色条件修订，不能将摘录字段存在当成功证据。
- **verification**: 原判据下同4题/两顺序/多轮检查实际首节，同时不丢全文所问事项。
- **status**: open

### F-06 — Changing Lead Generation Changes Full-answer Coverage

- **Label**: issue (blocking, must-fix)
- **id**: F-06
- **severity**: High；已复现覆盖回归，违背REQ-701/704的动作、记录及用途契约。
- **location**: 本报告R1/A1/C2，结果槽2/5/8/10/13/16。
- **symptom**: 相对v1 anchored原先完整的同输入，6槽新增周期复查规则、编号关联或记录用途遗漏。
- **impact**: 首节改善以全文退步为代价，无法按用户要求接受。
- **root_cause**: 保留后续addresses结构不等于保持原选择；改变前导解码使后续条款覆盖发生变化。
- **recommendation**: 保留失败并返回设计阶段；不以8/16整体不变、相关性全过或某一目标题修复为上线依据。
- **verification**: 下一候选必须恢复这些具体必需事项，并在未放宽的四维判据下逐答通过。
- **status**: open

## Slot Review

O=原顺序，R=反顺序；P/F分别为通过/失败。槽号与本批results行号、HTTP index一致。每槽实际调用1；quote仅诊断。

| Slot | Round | Case | Order | Quote | Full | Lead | Relevant | Citation | Strict | First body s | Tokens | Notes |
|---:|---:|---|---|---|---|---|---|---|---|---:|---:|---|
| 01 | 1 | R7 | O | P | P | P | P | P | P | 5.526 | 515 | — |
| 02 | 1 | R7 | R | P | F | P | P | P | F | 4.809 | 444 | R1 |
| 03 | 1 | L4 | O | P | P | P | P | P | P | 4.497 | 415 | — |
| 04 | 1 | L4 | R | P | P | P | P | P | P | 4.513 | 424 | — |
| 05 | 1 | Archive | O | P | F | P | P | P | F | 5.465 | 512 | A1 |
| 06 | 1 | Archive | R | P | P | P | P | P | P | 6.267 | 593 | — |
| 07 | 1 | Caption | O | F | P | F | P | P | F | 4.147 | 372 | C1 |
| 08 | 1 | Caption | R | F | F | F | P | P | F | 3.908 | 352 | C1,C2 |
| 09 | 2 | R7 | O | P | P | P | P | P | P | 5.487 | 515 | — |
| 10 | 2 | R7 | R | P | F | P | P | P | F | 4.828 | 444 | R1 |
| 11 | 2 | L4 | O | P | P | P | P | P | P | 4.490 | 415 | — |
| 12 | 2 | L4 | R | P | P | P | P | P | P | 4.546 | 424 | — |
| 13 | 2 | Archive | O | P | F | P | P | P | F | 5.478 | 512 | A1 |
| 14 | 2 | Archive | R | P | P | P | P | P | P | 6.231 | 593 | — |
| 15 | 2 | Caption | O | F | P | F | P | P | F | 4.170 | 372 | C1 |
| 16 | 2 | Caption | R | F | F | F | P | P | F | 4.148 | 352 | C1,C2 |

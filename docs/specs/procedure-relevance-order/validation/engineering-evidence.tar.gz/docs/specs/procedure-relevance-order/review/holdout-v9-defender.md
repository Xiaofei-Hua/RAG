# v9 Holdout Review — Defender

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-holdout-{baseline,candidate}-v2/{results,model-http}.jsonl`, one-based rows; `validation/holdout-v9.json` r3.  
**Independence**: 独立审读正式两侧各 18 答及请求/响应，未读 critic、调用模型或改候选/判据。预检中断目录不计入；两次预检修正均在阅读新正文前，仅调整明确流程/非比较表述，原副本保留。

## Decision

**v9 不合格，默认必须继续 false。** Baseline 严格 **1/18**，候选严格 **6/18**，候选仅活动室两模式三轮通过。总分提升不能抵消木玩具六槽新出现的无关装饰内容，也不能替代首节主要规则。候选实际 15 槽走 clauses，其中 6 槽通过；另 3 槽联赛 Thinking 在原 rewrite 后走完整生成，不能当作分类机制成功证据。

三题已暴露，后续只能作为开发回归；不能修改这些题的规则/问法或增补个别词后再称“新留出通过”。本报告保留本轮失败，不批准默认启用。

## Per-slot Assessment

C = 完整动作/条件/分支/记录用途/未知及问题语言；L = 首节主要规则和范围；R = 相关性；S = 严格整题。首节长度和无害重复不单独失败。带 * 的首节语义范围/许可正确，但整答语言错误，仍判整题失败。

| Row | Round / mode | Case | B C / L / S | C C / L / R / S | Candidate route | Body time B → C (s) |
|---:|---|---|---|---|---|---:|
| 1 | 1 / Fast | 活动室 | P / P / P | P / P / P / P | clauses | 11.8766 → 2.2398 |
| 2 | 1 / Fast | 木玩具 | F / P / F | P / F / F / F | clauses | 12.0486 → 3.2126 |
| 3 | 1 / Fast | 联赛 | F / F / F | P / F / P / F | clauses | 7.6944 → 2.0072 |
| 4 | 1 / Thinking | 活动室 | F / P / F | P / P / P / P | clauses | 14.3424 → 6.6502 |
| 5 | 1 / Thinking | 木玩具 | F / P / F | P / F / F / F | clauses | 16.8336 → 5.1551 |
| 6 | 1 / Thinking | 联赛 | F / F / F | F / F / F / F | original after rewrite | 19.1996 → 19.4985 |
| 7 | 2 / Fast | 活动室 | F / P / F | P / P / P / P | clauses | 10.3350 → 2.0110 |
| 8 | 2 / Fast | 木玩具 | F / P / F | P / F / F / F | clauses | 10.2471 → 3.0023 |
| 9 | 2 / Fast | 联赛 | F / F / F | P / F / P / F | clauses | 9.6735 → 1.7502 |
| 10 | 2 / Thinking | 活动室 | F / P / F | P / P / P / P | clauses | 17.0941 → 6.4547 |
| 11 | 2 / Thinking | 木玩具 | F / P / F | P / F / F / F | clauses | 10.6766 → 5.0308 |
| 12 | 2 / Thinking | 联赛 | F / P* / F | F / P* / P / F | original after rewrite | 19.6260 → 17.3137 |
| 13 | 3 / Fast | 活动室 | F / P / F | P / P / P / P | clauses | 11.8931 → 2.0209 |
| 14 | 3 / Fast | 木玩具 | P / F / F | P / F / F / F | clauses | 14.7294 → 3.0042 |
| 15 | 3 / Fast | 联赛 | F / F / F | P / F / P / F | clauses | 11.5127 → 1.7493 |
| 16 | 3 / Thinking | 活动室 | F / P / F | P / P / P / P | clauses | 15.2290 → 6.4588 |
| 17 | 3 / Thinking | 木玩具 | F / P / F | P / F / F / F | clauses | 16.9208 → 5.0319 |
| 18 | 3 / Thinking | 联赛 | F / F / F | F / P* / P / F | original after rewrite | 20.0895 → 19.3705 |

## Blocking Findings

### H9-D01 — High, accepted/open: Unrelated form appearance retained

- **Location / symptom**: 候选 `results.jsonl:2,5,8,11,14,17` 的“记录与用途”均包含领取单页脚蓝色圆点，问题没有询问样式。Baseline 对应六槽没有该事实，构成真实相关性退步。
- **Root cause**: 实际模型分类将该条判为 record；例如第 2 槽 clause 16 为 record。不是 renderer 恢复 omit，也不是来源/结构合法可以证明相关。
- **Impact**: 直接重现用户要求解决的“同实体无关内容混入中文流程”。
- **Recommendation / verification**: 保持 false；后续机制应以逐条问题关联和记录的业务含义改善选择，再用独立新题检验。现有六槽原文及 wire 已复现，不以颜色/实体黑名单或修改本题绕过。

### H9-D02 — High, accepted/open: Main permission absent from visible lead

- **Location / symptom**: 木玩具六槽首节只有范围和标题；编号核对、附件确认、签收后的真实交付条件仅在操作段。联赛 Fast 三槽（3/9/15）首节有争议、离场和桌位标签例外，却没有双方确认且全部异议已解决的发布门槛。
- **Root cause**: 模型将主许可放在 step。木玩具第 2 槽 clause 4、联赛第 3 槽 clause 2 均可见此分类；后者还与建记录的准备句同单元。已冻结规范词前置没有把这些原句移入首节，范围/主题标签不能代替主规则。
- **Impact**: 九个实际 clauses 槽违反用户明确的信息顺序。完整规则在后文不补救首节；不夸大为全文捏造放行，全文原文仍正确完整。
- **Recommendation / verification**: 否决 v9 默认资格，保留原判据及九槽证据。下一机制另行设计并验证，不只补本题中的“才交出”或“once”等词来追认留出。

活动室六槽的主许可、等候/改期/改电话分支、门卡错误处理、损坏保持处理中、记录字段/三项用途及两项未知均齐。木玩具全文和联赛 Fast 全文也完整，相关出处正确；这些真实收益不能抵消上述两项 High。

## Baseline and Unchanged Fallback Evidence

Baseline 第 1 槽活动室完整通过；其余活动室分别缺电话例外/不承诺安排/同号追加结论（4）、编号关联和记录用途（7）、不承诺安排且把结束判断写到现场交接阶段（10）、不承诺安排/不借邻室门卡（13）、电话例外/改期历史用途（16）。部分记录字段还错引办理规则而不是记录说明。

木玩具 baseline 2/5/8/11/17 省略修复员向接待员传递编号/换件清单/结果，若干槽同时缺领取单关联或记录用途、历史保留；14 全文完整但首节没有已登记木制拼插/电动电池排除范围。联赛 baseline 多轮缺开立记录的字段、修正后确认或桌位标签例外等；12 还以中文回答英文题。以上均按原完整语义判定，不因没有逐字复述而失败。

联赛 Thinking 三轮在两侧都经过原 rewrite；实际最终 request 三对完全相同，仍是 basis/conditions/conclusion。候选 6 缺准备/修正等细节、首节范围不全并混入酒红横幅；12/18 答成中文，仍有准备、记录或例外遗漏。12 把 scorekeeper draft 改成监管员草稿并错引部分记录来源；18 用“赛后”表述开赛后离场、把 table label 写作表格标签。记录这些失败，但不把未改完整生成的随机变化归因为 clauses；也不修改 rewrite 回退边界来重跑同题。

## Calls and Cost

两侧均 **18 次最终 generation、57 次总模型调用**，没有新增最终生成或验证调用：9 个 Fast 槽各 1 次；6 个普通 Thinking 槽各 4 次；3 个联赛 Thinking 槽因既有 rewrite 各 8 次。不能沿用开发集 Thinking 固定 4 次的统计。两侧最终生成均 stop/complete，token 拼接、done 与保存的 answer 一致；这些终态不证明语义合格。

| Scope | B P50 / P95 (s) | C P50 / P95 (s) | Generation completion B → C |
|---|---:|---:|---:|
| Fast，9 槽 | 11.5127 / 13.6571 | 2.0209 / 3.1292 | 9,353 → 1,428 |
| Thinking，9 槽 | 16.9208 / 19.9041 | 6.4588 / 19.4473 | 9,654 → 3,540 |
| 实际候选 clauses 对应 15 槽 | 11.8931 / 16.9728 | 3.0042 / 6.5162 | 15,947 → 2,295 |
| 原 rewrite 对应 3 槽 | 19.6260 / 20.0432 | 19.3705 / 19.4857 | 3,060 → 2,673 |
| 全部 18 槽 | 13.1955 / 19.6955 | 4.1217 / 19.3897 | 19,007 → 4,968 |

首见时间包含真实 API 控制与检索，P95 为线性分位数。Generation prompt 合计 17,766 → 18,291；15 个对应槽为 15,105 → 15,630。速度收益明显，但不满足相关性与首节要求，不能用速度抵消。

## F-15 Routing Regression

六个路由回归无设计/实现阻塞。`test_procedure_route_requires_explicit_noncomparison_request` 固定 bounded local、flag=true、rewrite_count=0，直接调用既有 segmented_enabled，验证普通如何/how、明确流程/step-by-step，以及“不一致”保守回退/“有误”准入，并断言模型 calls 为空。`validation/routing-regression.log` 为 6 passed，生产算法未变。它覆盖实际预检边界，不保证运行时不会发生既有 rewrite；本轮真实 wire 已单独披露该区别。

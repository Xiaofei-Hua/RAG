# Mechanism v9 Independent Review — Defender

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v9/{results,model-http}.jsonl`, one-based rows; `procedure-relevance-mechanism-v9-replay/results.jsonl`; frozen `validation/development.json`.  
**Independence**: 未读 critic、未调用模型、未修改判据或创建留出。实际 16 槽有 8 个不同正文；逐文审读后保留每槽结论。

## Decision

**v9 真实开发实验完整性、首节、相关性、引用及原严格语义判据均 16/16。可进入条件生产接线、红绿测试和原定真实 API 对照；尚不能默认启用。** R7 reversed 的固定标题有一处 Medium 呈现问题，见下文；停机事实并未丢失，不把标题问题误报为内容遗漏。

确定性重放四槽上述各维度均 4/4，`model_calls=0`。这是重用 v5 四份分类验证新渲染，不计四份新模型答案或生成成本。随后真实 16 答独立完成，无错误/截断；第二轮对应正文与第一轮相同，不把重复正文当成新增题目覆盖。

## Per-slot Review

P 表示通过冻结判据。正文首见时间包含本次直接生成和输出检查，不是生产 API 或检索总时延。

| Row | Round | Case / order | Complete | Lead | Relevant | Cited | Strict | Body time (s) | Completion tokens |
|---:|---:|---|:---:|:---:|:---:|:---:|:---:|---:|---:|
| 1 | 1 | R7 / original | P | P | P | P | P | 1.8158 | 131 |
| 2 | 1 | R7 / reversed | P | P | P | P | P | 1.7172 | 131 |
| 3 | 1 | L4 / original | P | P | P | P | P | 1.8925 | 122 |
| 4 | 1 | L4 / reversed | P | P | P | P | P | 1.6715 | 122 |
| 5 | 1 | 档案 / original | P | P | P | P | P | 2.0524 | 158 |
| 6 | 1 | 档案 / reversed | P | P | P | P | P | 2.0871 | 158 |
| 7 | 1 | 字幕 / original | P | P | P | P | P | 1.7418 | 131 |
| 8 | 1 | 字幕 / reversed | P | P | P | P | P | 1.7909 | 131 |
| 9 | 2 | R7 / original | P | P | P | P | P | 1.7516 | 131 |
| 10 | 2 | R7 / reversed | P | P | P | P | P | 1.7032 | 131 |
| 11 | 2 | L4 / original | P | P | P | P | P | 1.6313 | 122 |
| 12 | 2 | L4 / reversed | P | P | P | P | P | 1.6515 | 122 |
| 13 | 2 | 档案 / original | P | P | P | P | P | 2.0589 | 158 |
| 14 | 2 | 档案 / reversed | P | P | P | P | P | 2.0744 | 158 |
| 15 | 2 | 字幕 / original | P | P | P | P | P | 1.7305 | 131 |
| 16 | 2 | 字幕 / reversed | P | P | P | P | P | 1.8016 | 131 |

## Semantic Evidence

- R7 两序首节均有干燥室内 16–28℃及初检通过才开始扫描，换头通过才恢复和重新起算也清楚。全文保留每 37 活跃扫描小时、待机不计、初检/换头起算差别、失败停机到修正复查通过、准备/序列号/日期/失败记录，以及初始、周期、换头和追溯用途；户外/潮湿及价格未知均在。reversed 的失败规则在后节，未改变先前许可含义。
- L4 两序首节均有无结露室内 19–26℃、初检通过起算、350 正式标签及测试/作废排除、换托盘检查通过重新起算。全文准备、失败停机恢复、记录、失败样张保留、四项目的和未知均齐，未将旧托盘资格转给新托盘。
- 档案两序首节实际包含共同清点签名交接后才开始阅览、适用范围及三个状态分支/异常不关闭规则。申请字段、各阶段记录、编号关联、未通过记录保留、追加复核结论、三项用途及两个未知完整。条件先说明，后续申请步骤没有宣称提前放行。
- 字幕两序首节含范围、准备和阻塞条件、全程检查、独立审核资格及同版本批准，再说明批准后音频变更/拼写例外。审核退回位于这些步骤之后，返工重做全程检查和新版本审核；三项曾遗漏用途及退稿历史用途均完整，记录字段和未知齐全。首节较长不另行扣分，后节无须重复已完整展示的动作。

16 答均未带入包装/库存/墙钟/年鉴/银框干扰；保留原文和实际来源，无新增许可、期限、价格或场景规则。旧的“所有关键条件和未知都必须在首节”诊断在 R7/L4 共 8 槽仍为 0/8，仅单独记录，不替代已冻结的 lead_rubric，也不回改旧失败。

## Finding and Cost

**V9-D01 — Medium; accepted/open.** `results.jsonl:2`、`:10` 的 `Unspecified information` 同时承载已知失败停机规则和未知服务费/户外规则。根因是完整混合条款分类为 limit，而固定标题声称该组均未规定；正文条件、否定和来源仍完整。建议将此组标题统一为 `条件与边界 / Conditions and boundaries`，不改分类、原文、顺序、词表或模型请求。以现有 R7 reversed 正文做标题/完整原文 golden 即可验证；不需要另加模型调用或语义判分器。

真实 wire 为 **16 次 generation、每槽一次、全部 stop**；qwen3.5:9b、temperature 0、top_p .8、none、2048 未变。首见 **P50 1.7713 s / P95 2.0776 s**（线性分位数）；总 completion **2,168**，平均 **135.5**；总 prompt **14,476**，平均 **904.75**。v5 四个相同输入的 messages/schema 与本轮完全相同，支持将已有四答首节改善归于渲染变化；其余四题序输入是本轮新增分类验证。

相对 v1 baseline 的 10/16 严格通过、4,702 completion tokens 和 3.7283 s 首见 P50，本轮已见开发样本质量和直接生成成本更好；这些分批实验不是随机化生产时延结论。选择 v9 作为目前最小合格机制候选，保留既定 API、候选冻结与新留出验证，默认仍 false。

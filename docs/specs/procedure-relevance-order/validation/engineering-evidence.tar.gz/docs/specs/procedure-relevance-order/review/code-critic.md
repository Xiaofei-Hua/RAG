# Code Critic Review

**Date**: 2026-11-11  
**Target**: 当前六个tracked文件的v9接线diff：`core/procedure_generation.py`、`core/local_rag_generation.py`、`data/profiles/general.yaml`及单元/API/golden。完整critic；未读defender、未调用模型、未改业务代码。

## Decision

**未发现Critical/High或其他需修复的代码问题；可以继续既定真实API对照。** 生产实现与已通过的v9机制一致，默认false保留。此次代码评审不批准默认启用，仍需API、新留出及最终矩阵。

## Implementation Assessment

- **praise (non-blocking)**: `procedure_schema`以实际条款建立必需字符串键和五类别枚举；Pydantic严格类别、实际键集合及非stop检查共同约束解码结果。旧自由段落结构已从生产调用点移除，没有残留生产引用。
- **praise (non-blocking)**: `render_procedure`只把已选step中的冻结通用规范词前置，先完成前置再判断首节是否为空。omit、record、limit保持原类别；各条只展示一次、组内保持原序、全文原文和实际来源保留，不推导新许可。四次线性分组仍为O(n)，无新增模型调用。
- **praise (non-blocking)**: 固定标题跟随已合格证据语言；原资格判断已经要求入选证据与所需语言一致，未改变跨语/低相关证据边界。末节中性标题已实现，混合失败条件与未知边界的中英文回归均覆盖。
- `general.yaml`仍为唯一生产prompt来源；没有引入quote、addresses、order、角色回指合并或schema文本注入。none/temp0/top_p0.8/2048预算保持，普通比较/rewrite/非流程及资格不足仍走原完整生成。
- 缺/多槽位、非法类别、前置后仍无lead及非stop在原完整发布边界前失败；既有stream/API处理转为unavailable而不追加生成。测试核对检查前没有正文、单调用、完成性及API失败confidence=None。输出检查、PII、取消/队列与持久化边界没有新增逻辑；无shared_state新键或新持久化。

## Verification

审读`validation/red.log`和`green.log`：同一单元+进程内E2E定向矩阵为 **22 failed / 34 passed → 56 passed**。API参数化覆盖Fast/Thinking、JSON/SSE、stop/length及混入可剔除证据，检查可见首节、实际来源、保存正文/历史完成性和单次生成。未为重复确认而重跑该已通过矩阵。

另独立执行一次离线重放：通过`uv run --frozen --no-sync python -`调用生产`prepare_procedure`、`procedure_schema`和`render_procedure`，输入v9保存的全部16份选择，对照原HTTP请求与完整正文。**16/16条款、schema、system prompt及渲染正文一致**；仅末节标题按已批准设计改为“条件与边界 / Conditions and boundaries”。模型调用 **0**。这直接核验临时实验到生产接线的行为迁移，不计为新真实样本或新语义证据。

固定词法前置的适用范围与模型分类的语义局限仍按设计保留；当前没有新的实测失效据此扩展规则或测试门禁。真实API和候选冻结后新留出将检验生产整体收益及未见题表现。

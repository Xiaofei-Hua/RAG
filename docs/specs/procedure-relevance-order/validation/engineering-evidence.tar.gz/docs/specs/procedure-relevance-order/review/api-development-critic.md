# API Development Critic Review

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-api-{baseline,candidate}/{results,model-http}.jsonl`，冻结`validation/api-development.json`。独立逐槽评审64答，完全相同正文合并审读但保留每槽判断；未读defender、未调用模型。

## Decision

**被改流程候选16/16通过，未见实质退步；可以冻结当前实现并进入已批准的新留出。默认仍false。** 基线流程严格4/16，候选同时保全动作/条件/记录/用途、首节许可、相关性和引用。

普通未改路径本批有波动：基线15/16、候选13/16。候选电池比较三个槽只并列数值，未明确所给记录谁更长，按原契约记失败；不以流程收益抵消或隐藏。16个普通槽两侧完整generation request逐一相同（提示、schema、参数及资料均未变），候选仍走basis/conditions/conclusion；依原计划单列观察，不据此调整未改prompt或增设逐答全胜门禁。全32答严格分别19/32与29/32，不能只报流程成功率为总体成功率。

## Quality Evidence

| Group | Side | Full | Lead | Relevant | Citation | Strict |
|---|---|---:|---:|---:|---:|---:|
| Procedure | baseline | 4/16 | 14/16 | 15/16 | 14/16 | 4/16 |
| Procedure | candidate | 16/16 | 16/16 | 16/16 | 16/16 | 16/16 |
| Ordinary | baseline | 15/16 | — | 16/16 | 16/16 | 15/16 |
| Ordinary | candidate | 13/16 | — | 16/16 | 16/16 | 13/16 |

候选R7两模式保留普通37有效小时、初检/换头起算、失败恢复、指定参考纸与编号、检查记录、四用途和未知边界；Fast将失败条件与未知户外规则放在中性末节，事实完整。L4保留350正式标签、排除项、事件起算、准备/记录和用途。档案首节包含共同清点签名后的阅览许可，后续编号关联、记录用途及未知完整。字幕首节包含独立审核及同版本批准，三个曾遗漏的用途、全部草稿链接和返工全回放均保留。无包装库存、墙钟年鉴、告示板事实或不相关来源进入候选答案。

基线失败据实际全文记录如下，不沿用旧批次猜测：

| Code | Slots | Actual observation |
|---|---|---|
| B1 | 3 | Q2校准全文未保留“正常连续使用”适用条件。 |
| B2 | 5 | R7漏指定参考纸准备及初始建立工作参考的用途；另把L4记录引用为R7依据。 |
| B3 | 13 | R7漏换头通过后重新起算37小时、日期/结果/失败记录及所问用途等。 |
| B4 | 21 | R7缺准备、记录和用途；末尾另把新37小时起算写成未绑定换头的泛化句；引用含L4记录。 |
| B5 | 6 | L4缺保存记录用于追溯偏移来源的用途。 |
| B6 | 14 | L4缺指定定位纸、机台/托盘编号、检查日期/样张编号/结果及失败样张保留、追溯用途。 |
| B7 | 22 | L4缺检查日期/样张编号/结果和追溯用途；已提保留失败样张，不重复误报该项。 |
| B8 | 15 | 档案缺调阅编号关联档号/阅览证号/计划日期及对应完整调阅用途。 |
| B9 | 31 | 档案缺上述编号关联及用途，也缺保留候补/退回/未结历史用于追溯状态变化的用途。 |
| B10 | 8 | 字幕将输入解阻写成提供改正稿即结束，未保留匹配确认；审核退回后漏重复完整回放。 |
| B11 | 16 | 字幕缺转录稿标识及全部草稿链接；明确展示银色告示板；首个结论段未保留翻译轨排除范围。 |
| B12 | 24 | 字幕缺转录稿标识/全部草稿链接及所问用途。 |
| B13 | 32 | 字幕缺转录稿标识/全部草稿链接和三用途；首个结论段仍把解阻写成提供改正稿，且未保留翻译轨排除范围。 |
| C1 | 9,17,25 | 候选普通电池题只列9/10小时或540/600分钟及不同负载限制，未给“所给记录芦序更长”的直接比较。 |

基线的长首个结论段仍按完整可见结论审查，不因包含分行/重复就失败；没有新增“第一句包含全部规则”标准。旧全部关键条件入首节口径单列R7/L4：baseline6/8（R7 Thinking两答未把全部起算/未知条件放在首节），candidate0/8；当前冻结首节只要求主要规则与范围，该历史口径不用于改变本轮结论。

## Calls and Performance

两侧各 **80次实际HTTP = 32 generation + 48 control**。Fast每答1次generation，总1次；Thinking每答1次generation加原有3次control，总4次。64次generation均stop，API均200/complete；每答token拼接与done正文一致。候选16流程实际使用clauses schema，16普通题仍使用原完整schema。没有增加生成或核验模型。

完整首见时间包含正常API工作；P95为样本线性插值。两侧为先后分批运行，按同题/模式/轮次对照，不能声称随机交替实验消除了所有时序影响。

| Group/mode | n/side | Baseline P50/P95 s | Candidate P50/P95 s | Mean generation tokens baseline→candidate |
|---|---:|---:|---:|---:|
| Procedure/all | 16 | 10.796 / 14.591 | 3.636 / 6.018 | 910.81 → 144.88 |
| Procedure/Fast | 8 | 9.748 / 13.390 | 1.938 / 3.072 | 967.00 → 154.25 |
| Procedure/Thinking | 8 | 11.740 / 14.766 | 4.997 / 6.079 | 854.62 → 135.50 |
| Ordinary/all | 16 | 4.179 / 5.804 | 4.068 / 5.765 | 243.19 → 251.62 |
| Ordinary/Fast | 8 | 3.204 / 3.958 | 3.417 / 3.905 | 242.12 → 249.50 |
| Ordinary/Thinking | 8 | 5.358 / 5.924 | 5.570 / 5.815 | 244.25 → 253.75 |

流程完整首见中位数下降约66%，生成输出减少约84%；普通路径耗时/输出波动如实保留，不要求所有分位数全面更优。样本是已暴露开发集，尚无新题泛化结论。

## Slot Review

F/L/R/C=全文/首节/相关性/引用，P/F=通过/失败，—=该普通题无流程首节评分。两侧槽顺序一致；每槽generation均1，Fast总1/Thinking总4。

| Slot | Round | Mode | Case | Baseline F/L/R/C | Baseline strict | Candidate F/L/R/C | Candidate strict | Notes |
|---:|---:|---|---|---|---|---|---|---|
| 1 | 1 | Fast | Battery | P/—/P/P | P | P/—/P/P | P | — |
| 2 | 1 | Fast | Zero | P/—/P/P | P | P/—/P/P | P | — |
| 3 | 1 | Fast | Calibration | F/—/P/P | F | P/—/P/P | P | B1 |
| 4 | 1 | Fast | Missing | P/—/P/P | P | P/—/P/P | P | — |
| 5 | 1 | Fast | R7 | F/P/P/F | F | P/P/P/P | P | B2 |
| 6 | 1 | Fast | L4 | F/P/P/P | F | P/P/P/P | P | B5 |
| 7 | 1 | Fast | Archive | P/P/P/P | P | P/P/P/P | P | — |
| 8 | 1 | Fast | Caption | F/P/P/P | F | P/P/P/P | P | B10 |
| 9 | 1 | Thinking | Battery | P/—/P/P | P | F/—/P/P | F | C1 |
| 10 | 1 | Thinking | Zero | P/—/P/P | P | P/—/P/P | P | — |
| 11 | 1 | Thinking | Calibration | P/—/P/P | P | P/—/P/P | P | — |
| 12 | 1 | Thinking | Missing | P/—/P/P | P | P/—/P/P | P | — |
| 13 | 1 | Thinking | R7 | F/P/P/P | F | P/P/P/P | P | B3 |
| 14 | 1 | Thinking | L4 | F/P/P/P | F | P/P/P/P | P | B6 |
| 15 | 1 | Thinking | Archive | F/P/P/P | F | P/P/P/P | P | B8 |
| 16 | 1 | Thinking | Caption | F/F/F/P | F | P/P/P/P | P | B11 |
| 17 | 2 | Fast | Battery | P/—/P/P | P | F/—/P/P | F | C1 |
| 18 | 2 | Fast | Zero | P/—/P/P | P | P/—/P/P | P | — |
| 19 | 2 | Fast | Calibration | P/—/P/P | P | P/—/P/P | P | — |
| 20 | 2 | Fast | Missing | P/—/P/P | P | P/—/P/P | P | — |
| 21 | 2 | Fast | R7 | F/P/P/F | F | P/P/P/P | P | B4 |
| 22 | 2 | Fast | L4 | F/P/P/P | F | P/P/P/P | P | B7 |
| 23 | 2 | Fast | Archive | P/P/P/P | P | P/P/P/P | P | — |
| 24 | 2 | Fast | Caption | F/P/P/P | F | P/P/P/P | P | B12 |
| 25 | 2 | Thinking | Battery | P/—/P/P | P | F/—/P/P | F | C1 |
| 26 | 2 | Thinking | Zero | P/—/P/P | P | P/—/P/P | P | — |
| 27 | 2 | Thinking | Calibration | P/—/P/P | P | P/—/P/P | P | — |
| 28 | 2 | Thinking | Missing | P/—/P/P | P | P/—/P/P | P | — |
| 29 | 2 | Thinking | R7 | P/P/P/P | P | P/P/P/P | P | — |
| 30 | 2 | Thinking | L4 | P/P/P/P | P | P/P/P/P | P | — |
| 31 | 2 | Thinking | Archive | F/P/P/P | F | P/P/P/P | P | B9 |
| 32 | 2 | Thinking | Caption | F/F/P/P | F | P/P/P/P | P | B13 |

**praise (non-blocking)**: 真实API保住机制实验的完整性和首节收益，且节省生成输出和完整首见时间，没有通过增加调用换质量。未发现当前被改流程的新Critical/High；下一步按原计划冻结、新留出、独立评审，结果合格后才判断默认。

# Design v2 Independent Review — Defender

**Date**: 2026-11-11  
**Object**: `design.md:25–29` and independently reviewed mechanism-v1 results.  
**Independence**: 未读 critic、未调用模型、未改业务代码或创建新留出。

## Decision

**准许进入 v2 的 16 答最小实验；无新增 Critical/High 设计阻塞。** 该结论只授权实验，尚不批准生产接线或默认启用。v1 三变体报告及逐槽失败已归档到 `review/mechanism-v1-defender.md`。

v1 anchored 的全文覆盖和相关性均为 16/16，但首节只有 8/16；实际地址文字已经声称回答“开始阅览的主要规则”，对应 IDs 却没有交接许可，见 `data/eval/procedure-relevance-mechanism-v1/results.jsonl:14,16`。因此，把抽象事项标签变为先摘取实际许可原句，再选对应 IDs，是针对已观测选择失败的不同解码假设，不是再次重复泛泛首节要求。

## Bounded Conditions

| Review point | Decision | Evidence / condition |
|---|---|---|
| 一次生成内先抽取实际规则 | accepted | `design.md:27` 明确 quote 在 IDs 前，涵盖决定许可的角色和先决条件；无新增调用。 |
| 保留既有全文收益 | accepted | `design.md:28` 保留后续 addresses、来源与指代分句、温度/预算/none；不换回已复现遗漏的 lead-only。 |
| quote 不成为新的可信正文 | accepted | `design.md:27` 只用 IDs 原文渲染；quote 不展示、不替代引用，也不根据 quote 正确就判可见首节通过。 |
| 实验规模和对照 | accepted | `design.md:29` 为四道已见题 × 两顺序 × 两轮，复用 v1 anchored，承认分批运行不是严格时间交替配对。 |

quote 正确而 rule IDs 漏掉独立审核角色或交接条件，仍按同一冻结标准判首节失败；scope IDs 混入无关事实，也仍判相关性失败。评审继续读实际可见首节及全文，不能以字段名、合法 JSON、非空 quote 或 ID 数量证明语义。这是既有验收的直接应用，不要求新增在线核验、全文匹配器或另一模型。

字幕中许可角色可能位于较长的指代合并条款，选入它会增加首节重复文本。只要原文前提保留、所问规则与范围实际齐全，无害重复不单独判失败；同时如实报告输出 token 和完整首见成本，不能把全部动作搬进首节后忽略成本。原文切分保持既有机制，不为缩短首节临时改成会丢指代关系的片段。

## Next Decision

维持 2048/none/温度 0、每答一次最终生成及完整 stop 后原检查发布。16 答继续按冻结的严格整题、首节、相关性与引用标准审查，保留所有失败。若本轮修复首节且没有全文/相关性退步，再独立决定生产接线；当前 false 的真实 API 对照和冻结后新留出仍在之后。v2 未经实测，不关闭 M-D01，也不因新增 quote 就声称主规则已经可靠选择。

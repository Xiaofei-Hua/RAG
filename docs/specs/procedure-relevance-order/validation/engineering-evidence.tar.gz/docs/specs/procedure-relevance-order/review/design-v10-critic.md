# Design v10 Critic Review

**Date**: 2026-11-11  
**Scope**: `design.md`末节“Semantic Roles and Short Question Links”，`validation/roles-prompt.txt`与`validation/linked-prompt.txt`。独立设计评审；未读defender结论，未调用模型，未改生产代码。

## Decision

**准许开始既定临时12答实验；新增Critical=0、High=0、Medium=0、Low=0。** 本结论只允许检验机制，不批准生产接线、合并或默认启用。v9的F-16/F-17仍未闭环，默认false保持；正式新留出失败见`holdout-v9-critic.md`。

## Assessment

- **praise (non-blocking)**：`main_rule/scope`直接表达实际许可与适用范围，`record`区分业务字段/用途和载体样式，针对已经复现的首节与相关性失效提出可检验假设；不按题目实体、颜色或自然许可用语扩充词表。
- **praise (non-blocking)**：两份精确提示共用相同语义说明。roles只输出类别，linked仅追加短`answers → role`关联；与同输入v9直接对照，能观察语义类别变化和额外关联的边际收益。关联内容不展示、不作真实性证明，判断仍以实际原文正文为准。
- 12槽严格为已暴露木玩具/联赛两题×两来源顺序×一轮×三变体。资料、冻结rubric、原文分组/引用、规范词表及渲染/失败处理保持一致；`none/0/.8/2048`与4096上下文预算不变，每答一次最终生成。记录实际stop/输出tokens/耗时即可比较关联字段成本，不另增模型或语义检查门禁。
- 首节必须含主要许可与范围，全文必须保留所问动作、条件、分支、记录、用途和未知，且相关性/引用均通过；不能用正确类别名或短关联替代可见结果，不能因首节较长另加失败条件。
- [CoD论文](https://arxiv.org/abs/2502.18600)和[作者官方实现](https://github.com/sileix/chain-of-draft)提供简短中间草稿的研究动机；它们不证明当前9B逐条分类有效。设计明确采用最小消融确认迁移收益，未把论文结果当成本任务证据。

## Next Decision

若roles与linked同等通过，优先更小的roles；若均失败，保留失败证据，不接生产。候选通过后再按既定七开发题×两顺序×两轮确认；生产接线仍需独立评审与红绿证据，随后重新冻结并创建真正全新留出。此次12答不能计为新留出或稳定性证明。

# Defender Review — v19 Production Wiring

**Date:** 2026-11-12  
**Scope:** 冻结v17归档相对生产修复`915f421`的差异、真实golden和红绿/回放证据。独立代码审阅，无模型调用、无生产编辑；未读本轮code critic。

## Decision

**接线符合已批准的一行方案，无新增Critical/High。可保持冻结候选进入真正新留出；默认仍false。F-16尚需新留出及最终门禁，不以代码/单测通过替代质量验收。**

## Evidence

- `core/procedure_generation.py:155`唯一运行机制变化为`_REFERENCE.search(sentence)`→`match(sentence)`。判断之前仍先strip，句首指代继续回连；句中指代不再吞并前句。原文追加、来源映射、编号完整键、角色/规范词、渲染、资格与调用/降级路径未改，生产prompt仍v17原文，未采用v18。
- 相对v17代码包，只有上述文件、`tests/unit/test_procedure_generation.py`和`tests/fixtures/procedure_relevance_regressions.json`改变。原两份回归fixture完整保留，新第三份陶艺Thinking的units和selection与真实v19第2答相同。
- 新同步/异步参数化回归`:501`走实际`generation_chain`，覆盖准备出的完整units、真实选择、整篇expected answer、实际首节含开放依据、排除无关项、单次最终调用及实际schema键。既有`:228`永久测试继续覆盖“先检查样张。该次合格后开始计数。”的句首回连及失败事件独立。
- 已读`validation/v19-red.log`：两参数在旧分组下失败；`v19-green.log`：相关单元/进程内E2E 72 passed。没有重跑已通过矩阵。
- `production-replay-v19.log`记录20/20真实输入的units/context/schema与生产一致、40/40发布正文零模型回放一致。独立检查的真实golden来源与当前代码改动支持该接线结论；不把回放当新语义采样。
- 完整矩阵日志为1336 passed、6 skipped、3项既有warnings、branch coverage75%，修复commit为915f421。没有前端改动或新依赖/持久化/shared_state字段。

## Boundary

本评审确认临时实验的一行干预已进入正确生产位置并有可追溯回归。其效果边界仍是已暴露十题；新留出协议在`freeze-v19.md`的09:33:05 UTC冻结之后独立创作，正常资格预检及真实两侧结果将分别审查，不能提前给默认资格。

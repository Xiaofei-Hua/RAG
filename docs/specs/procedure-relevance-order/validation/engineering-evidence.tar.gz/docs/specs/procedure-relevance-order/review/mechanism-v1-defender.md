# Mechanism v1 Independent Review — Defender

**Date**: 2026-11-11  
**Inputs**: frozen `validation/development.json`; `data/eval/procedure-relevance-mechanism-v1/{protocol,prompts}.json` and `{results,model-http}.jsonl`. All result references below use one-based JSONL rows.  
**Independence**: 未读 critic；完整审读首轮 24 个不同正文，并确认第二轮逐槽正文完全重复后继承同一语义裁定；核对全部 48 次实际请求/响应与耗时。未调用模型、改题/标准/业务代码或创建新留出。

## Decision

**没有最小合格候选，不能进入生产接线或默认启用。** `lead-only` 为 6/16 严格整题通过，`lead+addresses` 为 8/16，旧选择基线为 10/16。两种新结构都未解决中文档案首节后置；字幕首节也未保留独立审核条件。`lead-only` 另有实际全文遗漏和 R7 无关内容退步。

`addresses` 相对 lead-only 保留了更多完整信息并消除了本批无关事实，值得如实记录；但首节规则失败仍构成完整题失败，不能以 16/16 全文覆盖替换用户明确要求的首节标准。当前继续 false，不选“较不差”的候选冒充合格，不消耗新留出。

## Frozen Criteria and Totals

`Complete` 仅表示全文动作、条件、分支、记录、用途和所问未知边界齐全，不包含首节或相关性；`Lead` 依冻结 `lead_rubric` 审第一实际正文节，标题不算规则。`Relevant` 排除无关事实；`Cited` 表示实际主张有对应来源。`Strict` 要求四项同时通过。原文中通用措辞没有被改成“仅限此阶段”时，不仅因归入某小节或无害重复判失败。

| Variant | Complete | Lead | Relevant | Cited | Strict |
|---|---:|---:|---:|---:|---:|
| baseline / 旧选择 | 14/16 | 10/16 | 12/16 | 16/16 | **10/16** |
| lead / lead-only | 8/16 | 8/16 | 14/16 | 16/16 | **6/16** |
| anchored / lead+addresses | 16/16 | 8/16 | 16/16 | 16/16 | **8/16** |

相对旧选择的逐槽严格配对：lead-only 为 4 条 Pass→Fail、6 条 Pass→Pass、6 条 Fail→Fail、0 条 Fail→Pass；anchored 为 2 条 Pass→Fail、8 条 Pass→Pass、6 条 Fail→Fail、0 条 Fail→Pass。该实验的 baseline 是旧条款选择，**不是**当前 false 的完整生成，不能将这里的成本或质量结果称为相对生产默认的收益。

旧“首节囊括全部条件/起算/失败/未知”的口径另报：三个变体均 0/16。本轮使用已冻结的新首节口径，不以旧口径追加失败，也不改写历史报告。

## Findings

### M-D01 — Main rule remains outside the visible lead

- **Severity**: High; **Status**: accepted, open; 阻止本轮候选准入。
- **Location**: `results.jsonl:13,14,16,18,37,39,41,42`（两个新结构的全部档案答）；`:19,20,22,24,43,45,47,48`（全部新字幕答）。
- **Symptom**: 档案首节有范围、申请/核对或未知事项，但没有共同清点签名完成交接后才能阅览；该条件仍在后续交接节。字幕 anchored 两种顺序及 lead original 首节有同版本审批，却没有独立审核条件；lead reversed 首节连审批放行规则都没有，规则在后续 Release 节。
- **Impact**: 全文后段齐全不能满足用户先交代主规则的要求。字幕 original 的旧基线首节同时写明版本审批与 independent review，两个新变体构成实际配对退步。
- **Root cause**: 在合法 `lead` 和声称回答主规则的 `addresses` 中，模型仍用范围/未知或前置申请事项替代许可事实；字段位置没有可靠驱动事实选择。档案 anchored 的地址文字明写“开始阅览的主要规则”，却仍未选择对应条款。
- **Recommendation**: 不将 v1 接默认；后续机制须实际使首节选择所问许可条件，不能仅添加另一条“请先回答”指令或把后段正确当作关闭。
- **Verification**: 逐节读正文，再回到 selection 确认：档案 original lead IDs 为 `[1,2,3,4,5,8]`，anchored 为 `[1,2,3,4,5,8,15]`，都没有交接条款 6；reversed 同样缺首节交接条款 15。字幕 anchored 首节没有独立审核原文或其目的条款；lead reversed 首节 `[10,14,8]` 没有审批条款 12。

### M-D02 — Lead-only loses requested record fields and purposes

- **Severity**: High; **Status**: accepted, open; 不接受以更短输出作为收益。
- **Location**: `results.jsonl:13,18,39,41`（档案）；`:19,24,45,47`（字幕）。
- **Symptom**: 档案全文没有编号关联档号/阅览证号/计划日期及对应完整调阅的用途，也没有初核、候补转可取、修正重核的经办人/时间/结果和未通过记录保留。字幕 original 漏独立审核分离编写与发布决策的用途；reversed 另漏脚本匹配避免过时脚本、全程播放查相邻 cue 遗漏的目的。
- **Impact**: 用户明确所问的信息缺失。不能把已有其他记录或“独立 reviewer”动作当成缺失字段/目的的替代。
- **Root cause**: 简化后的选择集中于流程节，遗漏另一来源中跨阶段记录与目的；不是源文、检索或 renderer 丢失。
- **Recommendation**: 旧基线/anchored 已保留的完整内容须作为开发回归，不以条款 ID 数量或正文长度计质量。
- **Verification**: 已读后续全部正文，遗漏项没有在其他小节补回。档案两个顺序都未选关联/核对记录条款；字幕 lead original 未选独立审核目的，reversed 未选两条解释用途的原文。

### M-D03 — Lead-only introduces unrelated facts in R7 original order

- **Severity**: Medium; **Status**: accepted, open; 仍是冻结 strict 标准下的实质失败。
- **Location**: `results.jsonl:1,27`。
- **Symptom / impact**: Document Limitations 加入蓝色包装盒和 92 箱库存，虽然有来源，却不回答室外使用与服务价格；旧选择同槽没有这些事实。
- **Root cause**: lead-only 将来源末尾的装饰事实并入未知事项节；不是 ID 非法或引用失配。
- **Recommendation / verification**: 保留这条真实配对退步。anchored 同槽仅选对应室外规则/价格未知原文，显示有限相关性改善，但其其他首节失败仍未关闭。

## Whole-Answer Details

R7 三变体均保留干燥室内 16–28°C、初检通过才运行及初始起算、37 个活动扫描小时/不计待机、换头通过后的独立新周期、失败停机到排因重检通过、准备/日期/结果/失败记录、各检查目的与追溯、室外和价格未知。首节的失败停机规则加范围符合冻结 `lead_rubric`，不追加“必须同时再写初检许可”的新门槛。R7 lead original 只因无关包装/库存严格失败。

L4 三变体均完整保留无结露室内 19–26°C、初次样张通过才打印和起算、350 正式标签/测试和作废不计、换托盘合格重新起算、失败暂停与复检恢复、准备机台/托盘/定位纸、后续记录与失败样张、四项所问用途和两个未知边界。合并原文中的换托盘触发条件仍明确，没有把该重置改为普通周期复查一律重置。重复原文没有单独计失败。

档案 baseline 与 anchored 的全文均包含三个申请分支、修正重核、交接放行、归还一致关闭、异常保持未结并复核、全部记录字段及三类用途、两项未知；baseline 两顺序都有墙钟/年鉴且首节错序，anchored 去掉无关事实但首节仍错序。lead-only 的缺失见 M-D02。

字幕 anchored 全文动作、返修完整播放、同版本审批、音频变更重启、仅标题拼写例外、transcript identifier、全部草稿链接、播放/review记录、四项用途及未知均齐。baseline original 全部通过；baseline reversed `results.jsonl:23,46` 全文缺 transcript identifier 和保留每份草稿链接，保留退稿用途不能替代这两个要求，首节也没有独立审核条件。该旧基线失败同样保留。

## Per-Slot Status

O=original，R=reversed；C=Complete，L=Lead，Rlv=Relevant，S=Strict；所有 48 槽 Cited=Pass。P/F 为人工语义裁定。第二轮每槽与对应首轮正文相同，但仍单独列出。

| Row | Round | Case / order | Variant | C | L | Rlv | S |
|---:|---:|---|---|:---:|:---:|:---:|:---:|
| 1 | 1 | R7 / O | lead | P | P | F | F |
| 2 | 1 | R7 / O | anchored | P | P | P | P |
| 3 | 1 | R7 / O | baseline | P | P | P | P |
| 4 | 1 | R7 / R | anchored | P | P | P | P |
| 5 | 1 | R7 / R | baseline | P | P | P | P |
| 6 | 1 | R7 / R | lead | P | P | P | P |
| 7 | 1 | L4 / O | lead | P | P | P | P |
| 8 | 1 | L4 / O | anchored | P | P | P | P |
| 9 | 1 | L4 / O | baseline | P | P | P | P |
| 10 | 1 | L4 / R | anchored | P | P | P | P |
| 11 | 1 | L4 / R | baseline | P | P | P | P |
| 12 | 1 | L4 / R | lead | P | P | P | P |
| 13 | 1 | 档案 / O | lead | F | F | P | F |
| 14 | 1 | 档案 / O | anchored | P | F | P | F |
| 15 | 1 | 档案 / O | baseline | P | F | F | F |
| 16 | 1 | 档案 / R | anchored | P | F | P | F |
| 17 | 1 | 档案 / R | baseline | P | F | F | F |
| 18 | 1 | 档案 / R | lead | F | F | P | F |
| 19 | 1 | 字幕 / O | lead | F | F | P | F |
| 20 | 1 | 字幕 / O | anchored | P | F | P | F |
| 21 | 1 | 字幕 / O | baseline | P | P | P | P |
| 22 | 1 | 字幕 / R | anchored | P | F | P | F |
| 23 | 1 | 字幕 / R | baseline | F | F | P | F |
| 24 | 1 | 字幕 / R | lead | F | F | P | F |
| 25 | 2 | R7 / O | anchored | P | P | P | P |
| 26 | 2 | R7 / O | baseline | P | P | P | P |
| 27 | 2 | R7 / O | lead | P | P | F | F |
| 28 | 2 | R7 / R | baseline | P | P | P | P |
| 29 | 2 | R7 / R | lead | P | P | P | P |
| 30 | 2 | R7 / R | anchored | P | P | P | P |
| 31 | 2 | L4 / O | anchored | P | P | P | P |
| 32 | 2 | L4 / O | baseline | P | P | P | P |
| 33 | 2 | L4 / O | lead | P | P | P | P |
| 34 | 2 | L4 / R | baseline | P | P | P | P |
| 35 | 2 | L4 / R | lead | P | P | P | P |
| 36 | 2 | L4 / R | anchored | P | P | P | P |
| 37 | 2 | 档案 / O | anchored | P | F | P | F |
| 38 | 2 | 档案 / O | baseline | P | F | F | F |
| 39 | 2 | 档案 / O | lead | F | F | P | F |
| 40 | 2 | 档案 / R | baseline | P | F | F | F |
| 41 | 2 | 档案 / R | lead | F | F | P | F |
| 42 | 2 | 档案 / R | anchored | P | F | P | F |
| 43 | 2 | 字幕 / O | anchored | P | F | P | F |
| 44 | 2 | 字幕 / O | baseline | P | P | P | P |
| 45 | 2 | 字幕 / O | lead | F | F | P | F |
| 46 | 2 | 字幕 / R | baseline | F | F | P | F |
| 47 | 2 | 字幕 / R | lead | F | F | P | F |
| 48 | 2 | 字幕 / R | anchored | P | F | P | F |

## Actual Calls, Inputs and Cost

16 个 round/case/order 配对组中，三变体实际 human message 完全一致，包含同一问题、同序资料和重建后的条款/来源映射；离线 rubric 等字段没有进入 messages。lead 与 anchored 的实际提示仅差最后一行 addresses 说明及 schema 字段；anchored 属性顺序确实在 IDs 前。每变体 16 次生成，总计 48 次；没有控制、追加核验、重试或第二次生成。全部实际调用为 qwen3.5:9b、temperature 0、top_p .8、none、2048，全部 stop，全文渲染检查后给出 complete。协议完成不代表语义合格。

下面是直接生成适配器的完整正文可用耗时，不是 API 检索或 Thinking 总耗时，也不是模型首 token。P95 使用样本线性插值；每变体只有四道已暴露题、八种来源配置、两个重复轮次，不能当作 16 个独立问题。

| Variant | Complete body P50 / P95 (s) | Total P50 / P95 (s) | Completion tokens total / mean | Mean prompt tokens | Calls |
|---|---:|---:|---:|---:|---:|
| baseline | 3.7283 / 4.3852 | 3.7283 / 4.3852 | 4,702 / 293.875 | 838.75 | 16 |
| lead | 2.9418 / 3.1522 | 2.9418 / 3.1522 | 3,880 / 242.500 | 868.75 | 16 |
| anchored | 3.7264 / 4.2664 | 3.7264 / 4.2664 | 5,312 / 332.000 | 900.75 | 16 |

lead 相对旧选择的完整首见中位数约减少 21.10%、输出 token 减少 17.48%，伴随真实遗漏，不能算合格优化。anchored 相对旧选择的中位数几乎不变（减少约 0.05%）、输出 token 增加 12.97%；相对 lead 增加 89.5 token/答、耗时中位数增加 26.67%，换来本批全文和相关性改善，却未满足首节。

## Disposition

本批未观察到 H1 所期待的首节改善；H2 在本批相对 lead-only 有相关性与完整性改善，但未消除主要失败。这不证明任何显式首节结构都无效，只否决当前两个候选的准入。保留全部实验及三个 findings，不调整冻结标准、不按标题/addresses 宣称目标已回答。后续若修订机制，仍用这些开发题先验证；尚无理由进行生产接线、默认变更或独立新留出。

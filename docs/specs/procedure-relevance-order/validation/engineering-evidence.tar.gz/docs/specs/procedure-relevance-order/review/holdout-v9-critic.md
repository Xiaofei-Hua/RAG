# Holdout v9 Critic Review

**Date**: 2026-11-11  
**Evidence**: 正式`data/eval/procedure-relevance-holdout-{baseline,candidate}-v2/{results,model-http}.jsonl`；冻结r3问题与预定rubric。逐答审读18+18槽，候选相同正文合并审读但保留每槽状态。未读defender结论，未调用模型；早期中断目录不计验收。

## Decision

**v9不合格，不能默认启用；默认false保持。** 候选严格6/18，六答活动室通过；木玩具六答首节缺实际交付条件并展示蓝色圆点，联赛Fast三答首节缺实际公开展示条件。完整性改善和速度收益不能抵消这些实质退步。

实际使用v9 clauses的只有15答：活动室6、木玩具6、联赛Fast3；其中严格6/15。联赛Thinking三轮在两侧都经历原rewrite，最终使用原basis完整生成，单列而不冒称v9覆盖。三题现已暴露，降为开发；不得按本题修调后重新称为新留出。

## Quality and Route

| Scope | Side | Full | Lead | Relevant | Citation | Strict |
|---|---|---:|---:|---:|---:|---:|
| All slots | baseline | 2/18 | 15/18 | 18/18 | 16/18 | 1/18 |
| All slots | candidate | 15/18 | 9/18 | 11/18 | 17/18 | 6/18 |
| Actual clauses slots / matched baseline | baseline | 2/15 | 12/15 | 15/15 | 13/15 | 1/15 |
| Actual clauses slots | candidate | 15/15 | 6/15 | 9/15 | 15/15 | 6/15 |

Full检查所问事实、动作、记录和用途；首节、相关性与引用独立，不能因Full通过就称整题通过。接受语义等价的限定范围，例如“only in-person, untimed club practice rounds”，不要求机械复述排除词；不因长首节、分行或无害重复扣分。错误回答语言仍计全文失败。

候选活动室六答均保留交接入场许可、改期位置与电话例外、错门卡重核、新增损坏未结、全部记录用途及未知边界，无装饰事实。木玩具所问业务内容和全部用途也都保留，但首节只有范围；实际交付条件仍在操作步骤，蓝点进入记录段。联赛Fast全部资料内容保留，但首节展示争议、离场及桌号例外，双方确认及每个异议已解决的主要许可留在第二节。

原始选择确认木玩具第4条主要许可被标step，第16条蓝点被标record；两模式相同。联赛Fast第2条包含建记录及实际展示许可，被标step。程序如实执行分类和冻结前置词，并没有丢原文或伪造来源；失败来自语义分类和前置启发式未满足用户问题。

## Baseline and Unchanged Fallback Observations

| Code | Slots | Material observation |
|---|---|---|
| B1 | 4 | 活动室缺只改电话不改位置、等候不承诺及同预约号追加处理结论，还把已占用场次概括为流程不适用。 |
| B2 | 7 | 活动室缺预约号关联及对应一次使用用途、变更记录解释位置变化的用途。 |
| B3 | 10 | 活动室把“记为已结束”放入现场交接阶段，后文正确结束规则不能抵消；缺等候不承诺。 |
| B4 | 13 | 活动室缺等候不承诺及不借邻室门卡；一次交接记录字段段错引办理规则而非记录说明。 |
| B5 | 16 | 活动室缺只改电话例外、变更记录用途；多处记录字段/取消费用/追加结论错引办理规则。 |
| B6 | 2,5,8,11,17 | 木玩具缺修复员向接待员交玩具编号/换件清单/检查结果；2/5另缺领取单关联，2/8/11另有多项记录用途遗漏，11还缺保留待复核/委托纸保存/补齐另记不覆盖等记录细节。 |
| B7 | 14 | 木玩具全文完整，但首个结论段未给已登记木制拼插及电动/电池排除范围；后文范围不能补首节。 |
| B8 | 3,6,9,12,15,18 | 联赛均缺建记录时的轮次/两玩家代码/桌号及附记分卡；3/6/12/18另缺纠正原因后双方确认，3/6/9/15/18缺仅改桌号例外，若干答还缺记录/用途。12整体用中文回答英语问题。 |
| U1 | candidate 6 | 原rewrite完整路径缺建记录、纠正后确认与桌号例外，并混入酒红横幅。 |
| U2 | candidate 12,18 | 原rewrite完整路径用中文回答英语问题，且有动作/记录/用途遗漏；12把异议记录字段错引办理规则。 |

基线槽1完整通过；槽14全文完整但首节失败。三份候选rewrite槽与对应基线的完整generation request相同，故其波动不归因为v9分类，也不隐去其实际质量。没有据此修改未改prompt。

### Lead Recheck

复核只读实际首段，不借后文补范围。原17/18把槽3/15仅列适用对象当作完整排除范围，判定过宽，现改为15/18；严格整题仍1/18，不改变候选失败结论。下列六槽均在首段写了双方确认与主管解决所有异议的实际展示许可。

| Baseline slot | Actual first-paragraph scope excerpt | Lead decision |
|---:|---|---|
| 3 | “For Brindle practice league (in-person, untimed rounds at the club)” | F：只列对象，无限定排除；后部另述ranked/remote不能补救。 |
| 6 | “applies to in-person, untimed club practice rounds only” | P：接受only限定现场非计时练习的等义范围，未逐字列出ranked/remote。 |
| 9 | “For Brindle practice league (in-person, untimed rounds only)” | P：practice league及only限定现场非计时轮次，按等义范围接受。 |
| 12 | “仅涵盖俱乐部面对面、非计时练习轮次；排名赛和远程比赛不适用” | 首节语义P；英语问题用中文回答已计Full失败。 |
| 15 | “applies to in-person, untimed practice rounds at the club” | F：无only或明确排除，不能把后文当首节。 |
| 18 | “applies only to in-person, untimed practice rounds at the club” | P：限定范围的等义表达，未逐字列出ranked/remote。 |

可见基线具备直接概括许可条件的能力，但不再用原17/18为下一设计背书；新组合须独立实测。

## Calls and Cost

两侧各 **57次HTTP = 18 generation + 39 control**；所有最终generation单次、stop，API200/complete，token拼接与done正文一致。Fast总1次；中文Thinking总4次（3 control＋1 generation）；联赛Thinking发生既有rewrite，总8次（7 control＋1 generation）。不能把本批所有Thinking写成总4，也不能把控制调用当成额外最终生成。

| Scope | n/side | Baseline P50/P95 s | Candidate P50/P95 s | Mean generation tokens baseline→candidate |
|---|---:|---:|---:|---:|
| All | 18 | 13.196 / 19.696 | 4.122 / 19.390 | 1055.94 → 276.00 |
| Actual clauses slots / matched baseline | 15 | 11.893 / 16.973 | 3.004 / 6.516 | 1063.13 → 153.00 |
| Unchanged rewrite slots | 3 | 19.626 / 20.043 | 19.371 / 19.486 | 1020.00 → 891.00 |

时间为完整首见，P95线性插值；分批对照不冒称随机交替。实际改动路径节省输出和时间，但质量失败已足以否决默认，无需增加性能门槛。

## Slot Review

F/L/R/C=全文/首节/相关性/引用，P/F=通过/失败。两侧槽顺序一致；每槽最终generation均1。

| Slot | Round | Mode | Case | Baseline F/L/R/C | Baseline strict | Candidate F/L/R/C | Candidate strict | Candidate route |
|---:|---:|---|---|---|---|---|---|---|
| 1 | 1 | Fast | Room | P/P/P/P | P | P/P/P/P | P | clauses |
| 2 | 1 | Fast | Toy | F/P/P/P | F | P/F/F/P | F | clauses |
| 3 | 1 | Fast | League | F/F/P/P | F | P/F/P/P | F | clauses |
| 4 | 1 | Thinking | Room | F/P/P/P | F | P/P/P/P | P | clauses |
| 5 | 1 | Thinking | Toy | F/P/P/P | F | P/F/F/P | F | clauses |
| 6 | 1 | Thinking | League | F/P/P/P | F | F/P/F/P | F | rewrite/basis |
| 7 | 2 | Fast | Room | F/P/P/P | F | P/P/P/P | P | clauses |
| 8 | 2 | Fast | Toy | F/P/P/P | F | P/F/F/P | F | clauses |
| 9 | 2 | Fast | League | F/P/P/P | F | P/F/P/P | F | clauses |
| 10 | 2 | Thinking | Room | F/P/P/P | F | P/P/P/P | P | clauses |
| 11 | 2 | Thinking | Toy | F/P/P/P | F | P/F/F/P | F | clauses |
| 12 | 2 | Thinking | League | F/P/P/P | F | F/P/P/F | F | rewrite/basis |
| 13 | 3 | Fast | Room | F/P/P/F | F | P/P/P/P | P | clauses |
| 14 | 3 | Fast | Toy | P/F/P/P | F | P/F/F/P | F | clauses |
| 15 | 3 | Fast | League | F/F/P/P | F | P/F/P/P | F | clauses |
| 16 | 3 | Thinking | Room | F/P/P/F | F | P/P/P/P | P | clauses |
| 17 | 3 | Thinking | Toy | F/P/P/P | F | P/F/F/P | F | clauses |
| 18 | 3 | Thinking | League | F/P/P/P | F | F/P/P/P | F | rewrite/basis |

## Findings

### F-16 — Natural Permission Rules Remain Outside the Lead

- **Label**: issue (blocking, must-fix)
- **id**: F-16
- **severity**: Critical；critic §2(a)，首节目标在真实新题的改动路径下再次复现。
- **location**: 候选木玩具6槽及联赛Fast3槽；冻结`core/procedure_generation.py:183`、REQ-702/705。
- **symptom**: 真正交付/展示许可被分类step，冻结规范词前置没有把它们移到首节；后文完整不能补救。
- **impact**: 用户明确要求先给的主要放行规则仍后置，九个实际v9答案失败。
- **root_cause**: 抽象lead分类与词法前置没有可靠表达“本题主要许可”的语义关系。
- **recommendation**: v9不默认启用；本批退为开发，后续提出一般性语义机制，不能只针对两种表述补词后冒称留出通过。
- **verification**: 后续机制须在原rubric下同时通过首节与全文，并在重新冻结后的真正新留出验证。
- **status**: open

### F-17 — Record Classification Admits Unasked Form Decoration

- **Label**: issue (blocking, must-fix)
- **id**: F-17
- **severity**: Critical；critic §2(a)，同实体无关内容混入目标在新中文题复现。
- **location**: 木玩具6槽的第16条record及记录段；`data/profiles/general.yaml:27`、REQ-701/705。
- **symptom**: 领取单模板页脚蓝色圆点被当作用户要求的记录内容，六次实际v9回答均展示。
- **impact**: 同题基线未带入装饰事实，候选产生明确相关性退步。
- **root_cause**: 每条必做分类只保证考虑过条款，不能保证把业务字段/用途与记录载体外观区分正确。
- **recommendation**: 保留完整失败，不用首节修复掩盖相关性；后续最小实验须同时处理问题相关性，不能按颜色/实体删句。
- **verification**: 原业务字段、用途及未知全部保留，同时排除未问装饰；重新冻结后的新题仍需独立验证。
- **status**: open

**praise (non-blocking)**: v9保住15个实际路径答案的完整所问业务内容，活动室六答及调用预算也通过；这些收益为后续机制提供依据，但不抵消F-16/F-17。

# Design v7 Independent Review — Defender

**Date**: 2026-11-11  
**Object**: `design.md` section v7; independently verified v3/v6 results.  
**Independence**: 未读 critic、未调用模型、未生产编码或创建留出。

## Decision

**准许四答隔离 pilot；无新增 Critical/High 实验设计阻塞。** 恢复 v3 flow_rule 原 prompt、schema 结构与生成/展示顺序，仅保留已设计的同来源明确角色回指合并，能从失败的 v6 组合中隔离这个有直接原文依据的输入边界修复。v6 字幕首节实际已出现完整独立资格与版本审批，值得单独检验；不代表独立修复已使全文合格。

## Existing Boundaries

- 只合并同来源相邻组中的已规定 a/an + 短语 + who/which/that 与 the + 同短语回指；原文、来源、其他分句行为不改，不带入 section/order 或题目专用 actor 规则。
- 实际条款数量/编号会随合并变化，enum 和映射按准备后的实际条款更新；这是本次输入边界变量，不宣称与 v3 的带编号 messages 完全相同。原 corpus/query/source 顺序及任务要求保持。
- 生成仍 answer→lead，展示仍 lead→answer，none/温度 0/top_p .8/2048、单调用和完整 stop 后原检查保持。首节因合并变长不单独失败，夹带无关内容或遗漏所问事项仍照原 rubric 失败。
- 四答按冻结首节、完整动作/条件/记录/用途/未知、相关性与引用逐答审查；旧 v3 字幕用途遗漏仍须检查，不能因独立资格修复忽略全文。

四答都合格再按既定流程补齐 16 答；失败保留证据并停止补跑，不提前接生产、默认启用或创建留出。本次是已批准组件的隔离消融，不增加新的方案或门禁。

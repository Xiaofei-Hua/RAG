# Defender Review — v14 Semantic Clause Key Experiment

**Date:** 2026-11-11  
**Evidence:** `data/eval/procedure-relevance-mechanism-v14/{inputs.json,results.jsonl,model-http.jsonl}`；原七题冻结 rubric。独立审读 14 个 selection 与可见正文及其已存 v13 对照，未读 critic、未调用模型、未修改生产。

## Decision

**v14 严格 13/14，所选 v13 对照也是 13/14；不批准短语义 key 生产接线，默认维持 false。** 修正了照片 Fast 的队徽错选，却在裁片 Thinking 新增未问的义卖报名费未知。全文相关事实、首节、所问未知与引用均 14/14；相关性和未问未知排除 13/14。这不是结构失败或输出截断，也没有新事实缺漏，但未达到修复旧错且不引入新实质相关性退步的条件。

没有新的 Critical/High 安全或降级发现。新增误选记 Medium 质量问题；按设计“失败不接线”结束该候选的扩大，不把它升级为泛化防御门禁。

## Controlled Comparison

14 份实际最终 HTTP 请求逐对核验：将新键映回原 ID、还原唯一 system 标识说明后，请求完全相同；user messages、原检索上下文、值 schema、参数未变。照片 Fast 保留第三份温室记录，未删原触发环境。每个实际键均为编号加该原条款前 12 字符，required 键集与返回一致，保存 selection 与真实 raw content 一致。这些仅证明消融执行正确，不代替下面的语义审读。

`original_index` 是旧 **model-http 行号**，并非一律等于旧 results 行号。已从原目录实际调用及对应 model_end 找回答案；inputs 保存的 old answer 也对应真实旧结果。A=`procedure-relevance-api-v13-candidate`，H=`procedure-relevance-holdout-v13-candidate`。

## Per-slot Semantic Results

C=完整相关动作/条件/分支/记录及用途；L=首节实际许可与范围；R=相关性；A=已问未知；O=未问且不支持操作的未知排除；Q=引用支持。v14 的 C/L/A/Q 均为 14/14；仅第 13 答 R/O 失败。原 v13 仅本表第 11 对照 R 失败，其余各维度通过。

| Row | Case / mode | Original results / HTTP line | v13 strict | v14 strict | Actual observation |
|---:|---|---|:---:|:---:|---|
| 1 | L4 / fast | A:6 / HTTP 6 | P | P | 定位用途移至记录，所问事实均保留 |
| 2 | 档案 / fast | A:7 / HTTP 7 | P | P | 与 v13 同正文，完整 |
| 3 | 活动室 / fast | A:9 / HTTP 9 | P | P | 与 v13 同正文，完整 |
| 4 | 木玩具 / fast | A:10 / HTTP 10 | P | P | 完整；准备处于步骤组 |
| 5 | L4 / thinking | A:17 / HTTP 35 | P | P | 与本轮1同文，完整 |
| 6 | 档案 / thinking | A:18 / HTTP 39 | P | P | 与 v13 同正文，完整 |
| 7 | 活动室 / thinking | A:20 / HTTP 47 | P | P | 与 v13 同正文，完整 |
| 8 | 木玩具 / thinking | A:21 / HTTP 51 | P | P | 首节多出本题记录说明标题，无害；交付许可完整 |
| 9 | 温室 / fast | H:1 / HTTP 1 | P | P | 与 v13 同正文，完整 |
| 10 | 裁片 / fast | H:2 / HTTP 2 | P | P | 仅省略源标题，无实质差异 |
| 11 | 照片 / fast | H:3 / HTTP 3 | F | P | 队徽和聚餐均 omit；时限/大小未知正确保留 |
| 12 | 温室 / thinking | H:4 / HTTP 7 | P | P | 巡查分支回步骤组，未丢事实 |
| 13 | 裁片 / thinking | H:5 / HTTP 11 | P | F | 新增未问义卖报名费未知；原 v13 没有 |
| 14 | 照片 / thinking | H:6 / HTTP 15 | P | P | 时限未知归条件组；正文完整且无关内容排除 |

全文审读保留了各题主要许可与范围以及所问完整流程：L4 初始/350张/托盘重启及定位用途；档案候补/退回/交接/异常未结与状态记录；活动室门卡重核和损坏处理中；木玩具代领资格、全清单重核和五项记录用途；温室湿盆、外流恢复与每阶段记录；裁片双签认、误切新卡和成片/余料；照片同意加双核对、未裁切原图、待定种名/补交/修订/撤回和记录用途。标题、组别位置、首节较长或无害重复未单独失败。

L4 旧“全部关键边界都在首节”的 legacy 条件仍未全满足：不合格处理在步骤，v14 旧托盘资格说明在记录；v13 不合格处理也在步骤。按当前冻结的“主要规则+一般范围”首节判据通过，不倒改早期 legacy 失败。

## Mechanism Evidence

照片 Fast（本轮 `results.jsonl:11` / `model-http.jsonl:11`）：
- `9:流程没有承诺处理时限。` → answers“处理时限”、limit；
- `14:观察队的队徽由三个圆环组` → “未询问”、omit；
- 文件大小 limit、聚餐 omit，第三份温室来源全部 omit。可见正文完整，旧错本槽已修复。

裁片 Thinking（本轮 `results.jsonl:13` / `model-http.jsonl:13`）：

| Field | Finding |
|---|---|
| id | DV14-01 |
| severity | Medium |
| symptom | 条件组出现“本记录没有提供义卖摊位的报名费用” |
| impact | 未问且不支持裁片流程的费用未知进入答案，原 v13 同输入该槽省略，构成相关性退步 |
| root_cause | 独立键 `15:本记录没有提供义卖摊位的` 被标 answers“补领费用”、role=limit；所问是遗失纸样补领费，实际该条是义卖摊位报名费。短原文可见仍未保证对象/动作对应 |
| recommendation | 不接线；保留本次结果，不按义卖实体删句或称此批为新留出 |
| verification | 请求含完整原条款；raw selection 与实际正文均保留误选；旧 H results:5 / model-http:11 不含该未知 |
| status | accepted — experiment not qualified |

这不是“只要未知就全保留”：两版本都省略多项其他未知。它是具体的问题关联错误，原文、引用均真实，所以 Q=P；R/O=F。所问弹力布课程与遗失纸样补领费仍完整保留，未误报为答案缺失。

## Final-generation HTTP Cost

只比较各次最终 generation 的 HTTP **end-start**，未把本次临时生成时间对比旧 API first_body，也未把旧 Thinking 控制调用计入最终 generation 耗时。

| Mode (n) | v13 HTTP P50 / P95 (s) | v14 HTTP P50 / P95 (s) | Input tokens | Output tokens |
|---|---:|---:|---:|---:|
| fast (7) | 7.224 / 7.402 | 9.348 / 11.047 | 9838 → 9999 | 4428 → 5824 |
| thinking (7) | 5.109 / 5.429 | 6.639 / 7.698 | 8278 → 8439 | 3154 → 4177 |
| all (14) | 5.428 / 7.361 | 7.475 / 10.451 | 18116 → 18438 | 7582 → 10001 |

14 次新调用均为单次 generation、stop，无追加模型或重试；最长输出 1079 tokens，未出现早期长自由标识循环至 2048 截断。输出共增 **31.9%**，输入增 **1.8%**；HTTP P50/P95 增 **37.7% / 42.0%**。这是已存 v13 对照与本次 v14 的本机观测，非同时随机化测速。现有收益只体现原照片错位被修复，未得到整组质量净增，故这些成本不能支持本候选直接接线。

## Boundary

七题均已暴露，本次是机制消融。没有证明新领域泛化或三轮 API 稳定性；也未新增这些之外的门槛。生产仍 v13/default=false，本报告不修改候选或 rubric。


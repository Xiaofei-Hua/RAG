# Holdout v13 Preflight Critic Review

**Date**: 2026-11-11  
**Scope**: `validation/holdout-v13.json` r1，冻结 v13 候选的完整离线资格与输入/判据边界。未读 defender 结论，未读新留出生成正文，未调用模型，未修改协议或生产代码。

## Decision

**通过，可开始 false baseline / true candidate 各 18 答（3 题 × Fast/Thinking × 3 轮）。新增 Critical/High: 0。** 本结论仅批准验证，默认启用仍须真实结果支持。

2026-11-11 21:16 CST 已在任何正式生成前向主 Agent 发出通过结论。当前运行的相关代码及 profile 与 `candidate-v13-code.tar.gz` 冻结内容相同。协议声明创作发生在冻结之后、作者未调用模型；本次检查没有利用新模型输出修改题目或判据。

## Complete Eligibility

在冻结的 general / bounded / qwen3.5:9b / loopback:11434/v1 条件下，实际执行 `segmented_enabled`、`select_procedure_evidence` 和 `prepare_procedure`；使用真实来源名、资料全文及 `render_untrusted_evidence` 构造正常上下文，未只检查“流程”关键词。

| Case | Question / evidence language | Enabled | Selected sources | Prepared units | Source IDs |
|---|---|---:|---:|---:|---|
| 温室花架浇水 | zh / zh, zh | true | 2 / 2 | 16 | 1, 2 |
| 拼布小样裁片 | zh / zh, zh | true | 2 / 2 | 15 | 1, 2 |
| 昆虫照片入册 | zh / zh, zh | true | 2 / 2 | 15 | 1, 2 |

各条款均对应原始来源，来源映射与上下文校验通过。false 侧三题 `segmented_enabled` 均为 false。以上检查模型请求为 0。

正常 API runner 上传全部 6 份 corpus，提问仅传 query、会话和模式；case.sources 是预期相关来源，不强制过滤检索。六份资料均为中文，另以完整六来源执行相同选择/prepare 检查，三题也均通过；因此其他题资料被检索到时，不会因语言资格意外退回。真实运行的检索内容、rewrite 与最终 schema 仍按既定方案记录，不把原完整生成回退算作候选收益。

## Input and Rubric

`tests/integration/run_bounded_api_probe.py` 的正常上传/聊天入口只读取 corpus 内容与 query，不向模型发送 coverage、manual_required、lead_rubric、strict_rubric、freeze 或评审信息。此次离线上下文也只有正常原文证据。

三题为温室浇水、拼布裁片、自然观察入册的新业务流程；规则使用自然许可条件和分支，没有实体白名单，也不要求照抄规范词。逐条核对后，rubric 所列动作、记录、用途、范围和许可均来自资料及问题，不要求问题外细节。

| Case | Asked unknowns | Unasked information to omit |
|---|---|---|
| 温室 | 单盆用水量、夜间自动设置 | 建成年份、公众参观场次未知 |
| 拼布 | 弹力布课程、遗失纸样补领费用 | 义卖次数、义卖摊位费用未知 |
| 昆虫 | 处理时限、文件大小上限 | 队徽外观、聚餐日期未知 |

`praise (non-blocking)`：未知分类同时有应保留和应省略的实例，能直接检验 v13 的语义区分；未知并未被一律要求保留。首节检查主要许可与适用范围，全文检查用户所问各环节；允许等义表达、正常改述、无害重复和较长首节，不要求全系统各项全面更优。可按原冻结标准开展真实验证。

# Production v17 Critic Review

**Date**: 2026-11-11  
**Scope**: `core/procedure_generation.py`、`data/profiles/general.yaml`、相关 unit/E2E 与真实 golden；对照已审冻结 v13。未读 defender、未调用模型、未改业务代码。

**Decision: 代码评审 Critical/High: 0；接线通过，可继续既定 API 验证。默认仍 false，新留出与默认批准尚未完成。**

- `_clause_key` 使用实际 id 与完整原文，schema properties/required、精确键集检查及渲染查找共用；没有按序号、前缀或返回位置模糊配对。`dict[str, ClauseRole]` 保留严格六类枚举，非法值、缺多键与同 id 错原文失败仍由原生成降级处理。
- “完成才”只补入既有规范表达；仅命中已选 step 后前置，不恢复 omit，不修改 record/limit，不改写许可事实。原始 unit 顺序和来源去重仍由程序控制，与 JSON 键返回顺序无关。
- profile prompt 与冻结 `full-key-prompt.txt` 完全相同；无 answers。`local_rag_generation.py`、`segmented_generation.py`、`local_rag_policy.py` 与冻结 v13 相同，中文资格、英文原路、默认 false、最终单调用与不可用/None 契约未变。
- 红绿日志为 28 failed / 42 passed → 70 passed。审读现有结果，未无理由重跑通过矩阵。覆盖完整键/非法 role/无首节/non-stop/输出检查、不同操作完成条件、omit/record/limit 与“刚才/人才”负例。真实昆虫/拼布分类及正文 golden 和逆序返回回放保留实际失败回归，不把 mock 当模型语义保证。
- PII E2E 同时修改证据原文及其固定完整键，将电话放在实际会展示的交付记录里；正文/历史断言仍要求脱敏，JSON/SSE、完整状态、失败 confidence=None 及一次 generation 断言保持，未通过键错配绕过 PII 检查。

## Independent Zero-Model Replay

我用当前生产渲染独立回放全部 v16 的 14 份真实 selection：**只有 Toy 第 4、8 槽正文顺序改变，其余逐字相同；每槽原文条款与来源集合不变，0 模型调用。** 两个实际首节现同时包含适用范围与“领取单/编号一致、逐项确认附件并签收、三项完成才交出”的完整许可；此前其余 12 槽已经独立通过，故回放严格 14/14。没有把此回放记作新生成或新留出。

`praise (non-blocking)`：改动针对实际失效，保留事实/选择，把缺失的完成条件展示位置修正，接线没有引入额外模型成本。API 多轮与后续真正新留出仍决定默认资格，本报告不预先批准。

# Design

## Problem and Research
只修复合格中文流程的无关内容与首节许可后置。真实失败有两个原因：数字/截断标识及自写问题关联会选错事项；任意位置的指代匹配把准备、许可、异常并成一个难以分类的大条款。提高混合条款优先级未解决后者，不继续堆提示词。
从[Kyosuke Nishida](https://www.knishida.info/publications/)的[QFE](https://aclanthology.org/P19-1225/)借鉴问题驱动抽取，从[Nicola De Cao](https://nicola-decao.github.io/)的[GENRE](https://arxiv.org/abs/2010.00904)及[SEAL](https://arxiv.org/abs/2204.10628)借鉴可读标识。从[LlamaIndex Sentence Window](https://developers.llamaindex.ai/python/examples/node_postprocessor/metadatareplacementdemo/)借鉴细粒度单元与周边上下文分开处理；这里只改分句，不改索引或增加检索。研究任务不同，不以论文代替本地9B实测；失败实验和完整修订保存在[验证归档](validation/README.md)。

## Algorithm and Hypotheses
H1：一次JSON对“编号:完整原文”直接选择main_rule/scope/step/record/limit/omit，比数字/短前缀加自写关联更易对应真实事项。完整键集合必须匹配实际条款，不根据返回顺序或近似正文配对；分类仍可能错，schema合法不是语义证明。实验支持组合，不单独归因某一字段。
H2：程序负责展示顺序，降低模型同时概括、选取、排序的负担。main_rule/scope进入首节；只把已选step的通用明确规范及“完成才”条件前置，不恢复omit，不移动record/limit，不推导许可。不用单个“才”或实体/动作词表。各组保持来源原序，每条完整原文只出现一次并附真实引用。
H3：只用_REFERENCE.match回连句首指代；句中“该/其”等不自动吞并前句，独立许可可独立分类。句首“该次…”仍与前句合并。原句、来源及相邻上下文全部保留于同一次请求，不拆分分号条件；这不是完整指代解析器，需实际验证条件/用途完整性。

## Architecture and State
core/procedure_generation.py拥有ProcedureAnswer、动态schema、条款分组与渲染；_clause_key为共同标识来源。general.yaml是prompt唯一来源，使用已验证v17完整键原提示，拒绝v18优先级提示；core/local_rag_generation.py复用原最终生成请求。参数none/temperature0/top_p.8/2048、context4096，完整生成控制保留.7。
select与prepare共同限定中文目标；仍限已验证本地loopback9B/general、明确流程、非比较、rewrite_count=0、合格同语种资料。英文原context不预删，其它问题回原完整生成。仅既有真实reranker概率可排除极弱异语资料，缺失None不当0。
完整stop→组合原文→既有引用/PII检查一次→整体发布。Fast同步/异步/JSON/SSE和Thinking共用入口，首个正文为完整已检查回答。无新增shared_state键、REST字段、依赖或持久化；generation_evidence对应实际生成来源，不改原retrieval_evidence。

## Failure and Security
缺多键、错正文键、非法类别、无首节、非stop及引用/输出检查失败沿用不可用、confidence=None，不追加模型调用。取消/排队不变。资料仍是不可信引用，忽略其中指令，PII检查后才发布。无新增安全边界或假设性防御工作。

## Budget and Validation
分类/渲染O(条款字符总数)，完整原文回显有成本，但不增加LLM、embedding、reranker或judge调用，也不扩大2048预算。v19开发40答最大879输出tokens；相对v17平均多15.30tokens、最终生成P50多0.207秒，成本可接受，不声称这一步更快或任意长输入保证。
验收为所问事实/分支/记录用途完整、实际首节主要规则与范围、排除无关事实、已问与未问未知及真实引用；首节长度、无害标题变化不判失败，不要求每题每个分位数全面更优。v19十个暴露题两模式两轮40/40通过，旧失败留出只算开发；API首见与直接生成计时分别报告。
永久golden覆盖真实完整键分类、未问装饰/费用排除、完成条件、句内指代独立许可；单元+进程内E2E覆盖句首回连、英文原路、None降级、单调用、JSON/SSE/保存/PII。v19红2失败→绿72，20请求与生产分组/context/schema一致、40答零模型回放。未改前端；最终后端矩阵/coverage及GitHub必要UI检查执行。
冻结v19后独立作者新建3题/6资料，先做segmented_enabled/select/prepare完整资格预检，再真实API false/true各18答（两模式各三轮）。模型输出前固定问题/资料/rubric；失败保留并转开发，不反复改题冒充新留出。重复采样不当独立新题，评分只离线，既有未改英文/普通请求对照不反复调用。

## Rollout and Migration
当前默认false；仅开发和新留出无实质退步、无新增调用且成本可接受后改true，并验证真实默认与显式false回滚。显式false仍优先，修改或移除后重启方可启用；fair调度不受影响。
[breaking, conditional] 默认启用仅覆盖上述合格中文流程；旧显式试用的英文流程回原完整生成，未扩大模型/远程API/比较/改写资格。README/API/部署示例同步范围、限制、结果和回滚。最终独立critic/defender/tracking闭环及GitHub检查后合并main；不部署到另一个含用户未提交改动的工作区。

## v20 — Question-relative Placement
v19新留出12/18：广播两模式三轮的完整待播许可已经独立成条，仍被六类模型标step，首节只剩范围及其它局部分支。全文/相关性/未知/引用18/18，主要许可从基线正确首节后移，默认不启用；该批转开发并保留。分句已修但角色本身仍有重叠：操作许可也是一个流程步骤，业务分类未稳定服从用户的开头问题。
重新核对[Coarse-to-Fine Query Focused Summarization](https://aclanthology.org/2020.emnlp-main.296/)关于“主题相关”与“回答问题的证据”区别；论文包含学习模块，此处只借鉴问题—证据对应关系，不增加其模型或宣称迁移保证。v20假设直接预测相对用户子问题的回答位置，较六类业务角色更少歧义：完整原文键保持不变，值仅opening/detail/omit。opening直接回答用户‘先说明/交代’的内容（未指定则主许可/范围），detail覆盖其余所问细节和明确未知，omit为未问事项。去掉容易交叠的main_rule/step/record业务类别和规范词二次提升，不继续补许可关键词或让所有正文冒充首节。原文、分组、问题、来源、语言资格、预算与调用不变；渲染两节为规则与适用范围、流程细节与记录，正文来源顺序和全文事实保留。代价是减少细节分栏，不能把无关事实排除或业务用途完整性放宽。
精确prompt见position-prompt.txt。独立设计评审后先仅用广播两模式实际最终请求进行2次最小实验（改schema枚举/prompt/相应两组渲染，原文和参数不改）；失败则停止此假设。通过后全部13个已暴露题26实际上下文两轮52答，首节与全文按原rubric独立审读，旧v19/v17对应调用作同口径控制，不能把直接生成当API时间。成功才接线生产、真实golden红绿、再冻结并创作新留出；任何阶段实质失败继续默认false，不挪首节定义或把暴露题当新题。

## v21 — Orthogonal Opening Flag
v20先导1/2，Fast在第三份同类干扰文档存在时把整组所问记录unit11–16误选omit；输入记录/问题齐全，非截断或渲染问题，停止52答扩展。许可两答已前置，但少类别没有分开“是否相关”和“回答位置”，本次失败保留。
v21按独立critic建议保留v19六类原定义和完整原文键，对每条输出紧凑二元数组[role,opening_bool]。相关性/完整性仍由role决定，false不等于omit；opening只作为已选step的额外前置信号，与原规范词前置并集，main_rule/scope及record/limit/omit原行为不变。这样许可允许是step且opening=true，记录允许是record且false，不因后置丢弃。仍用四节原渲染，不额外生成摘要、问答或模型调用。此为待实测的因子分离，不宣称模型内部原因已被证明。
精确prompt为orthogonal-opening-prompt.txt，保留v17原六类说明，仅增加二元格式/开头子问题的独立标志。schema使用固定两项tuple（prefixItems为原enum与boolean，min/maxItems=2），无需自由解释或重复一遍完整键；预计每条增加少量布尔/数组token，不扩大2048预算/none/0/.8/4096。真实成本须实测；允许合理少量延迟成本，不要求各题分位数全面更优。
独立设计评审后仍先广播实际Fast/Thinking两输入，不改原文/资料/问题；同时核对真实首节与全部记录/未知/引用。失败即停，通过才全13已暴露题52答。成功再生产红绿、冻结、新留出与默认判断。v20候选不接线、不冒充已修；默认继续false。

## v22 — Opening Before Role
v21两答均首节失败，核心许可返回[step,false]，全文/记录均保住；tuple格式实际兼容，无额外调用，Fast/Thinking输出1116/761tokens。该先导停止，未启动52答。观察到后输出的布尔判断沿用了先输出的业务类别，不能据此证明模型内部原因。
v22只交换同一条款tuple的生成顺序为[opening_bool,role]，enum/prompt六类内容与前置逻辑不变，精确提示只改数组位置用语（opening-first-prompt.txt）。假设先回答用户开头问题，再决定内容分类，可减轻已有step类别对随后位置判断的约束；这只是可证伪的顺序消融，不增字段/摘要/推理模式或调用。参考[Let Me Speak Freely](https://aclanthology.org/2024.emnlp-industry.91.pdf)及[原工具作者的复现实验](https://blog.dottxt.co/say-what-you-mean.html)对结构/指令顺序与任务一致性的讨论；两方并不支持‘结构化必然降低质量’，此处不迁移其准确率，也不新增论文的多调用格式转换。
仍只运行原广播两实际请求；任一首节/全文失败停止，通过才原定52开发。所有原标准和默认false不变，v21失败独立归档。

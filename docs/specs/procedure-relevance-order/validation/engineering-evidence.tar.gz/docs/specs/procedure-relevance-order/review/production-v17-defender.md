# Defender Review — v17 Production Wiring

**Date:** 2026-11-11  
**Scope:** 相对冻结 v13 代码包审查 `core/procedure_generation.py`、`data/profiles/general.yaml`、单元/API测试与真实golden。未读 critic、未调用模型、未改生产。

## Decision

**未发现 Critical/High 阻塞；接线与已批准 v16+v17 最小方案一致，可继续既定真实 API 验证。默认仍 false；不把本报告当作默认启用或新留出通过。**

完整原文key、删除answers和相应提示精简属于组合机制；“完成才”只修展示位置，不改变模型选择或恢复omit。

## Code Findings

- `core/procedure_generation.py:32` 的同一 `_clause_key` 同时用于 schema、完整键集合校验、规范前置和最终取条款。键包含实际编号与完整原文，没有按序号/返回位置模糊匹配；同id改正文也会拒绝。
- `:27` 的严格 `dict[str,ClauseRole]` 直接限制六类；`:36` 生成各真实键required、禁止额外键、值为同六类string enum。已删除answers对象，旧形状不被误当有效分类。
- `:174` 先检查stop和结构，再检查完整实际键集；“完成才”只在已选step上前置。record/limit不提升、omit不恢复；展示仍取units里的原文与source_id，组内顺序由原units确定，不由返回键顺序决定。
- 唯一规范词增量为 `完成才`，未单加“才”，未添加实体/费项规则。没有修改资格、调用预算、来源选择、shared_state或降级通道。默认 `LOCAL_RAG_SEGMENTED=false` 保留。
- general.yaml 实际运行提示与冻结 `full-key-prompt.txt` 完全相同，没有混入v15句或实验评分元数据。

## Verification

已读 `validation/v17-red.log`（28 failed / 42 passed）与 `v17-green.log`（70 passed）。测试覆盖同id错正文、缺多键、非法role、无lead、非stop和检查失败的单调用不可用路径；原英文完整路径/上下文和None降级保留。

`tests/unit/test_procedure_generation.py:476` 用不同操作“核对与登记完成才启动”验证step前置，并覆盖record/limit/omit及“刚才/人才”不误提升。`:452` 的真实照片/裁片分类回放验证已问未知保留、无关队徽/义卖排除，并反转返回键顺序确认展示来自原units。它是渲染契约，未冒充模型语义保证。

API PII用同一文字替换同步修改原文和对应完整key，电话出现在实际选中的最终交付记录中；Fast/Thinking、JSON/SSE、done/持久化/历史及未完成confidence=None断言仍在。不存在只改mock key而让实际源文错位、继而绕过输出检查的假通过。

另做独立零模型重放：14份真实v16选择经当前生产渲染，仅Toy第4/8槽正文位置改变，其他12答完全相同；两Toy许可均进首节，所有14份当前schema与原真实v16请求schema相同。Toy golden选择等于真实v16 Thinking选择；两份新增回归fixture选择也对应实际原输出。新 `procedure_relevance_regressions.json` 是永久测试依赖，应随本次变更一并提交。

## Boundary

当前API a 两轮16答已独立语义核对通过；b仍需完成审读。代码、离线回放和mock测试不替代真实API及新留出。完整原文key增加输出规模的边界仍按设计诚实报告；本评审没有新增长度开关或假设性安全门禁。


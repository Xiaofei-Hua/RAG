# Design v3 Independent Review — Defender

**Date**: 2026-11-11  
**Object**: `design.md` section v3; v1/v2 actual results; `core/local_rag_generation.py:20,59`.  
**Independence**: 未读 critic、未调用模型、未修改业务代码或创建新留出。

## Decision

**准许两个 answer-first 变体各 16 答、合计 32 答的最小实验；无新增 Critical/High 设计阻断。** 当前生成在完整 stop 后才发布，生成字段顺序与可见顺序可以分开；已有 GroundedAnswer 先生成 basis/conditions/conclusion，再把 conclusion 放在可见开头，代码依据成立。它证明接线形式可行，不证明流程质量收益。

v2 的档案首节改善同时伴随全文遗漏，全部 stop，故现有失败不是 token 截断。先完成实际步骤与记录选择，再选择首节，是针对该选择相互影响的可检验假设；两变体复用既有字段，只改变生成顺序及一句相应说明，规模合适，不需额外模型、计划或程序猜测规则。

## Conditions and Interpretation

- 实际请求和响应应体现 `answer → lead`；可见正文仍严格为 `lead → answer`，只在完整 stop 和原输出检查后发布。后续报告根据实际行为确认，不凭 schema 属性排列假定模型已按该次序输出。
- 其余输入、分句、来源资格、字段内容、语义要求、温度 0、none 和 2048 预算保持；题目专用提示、ID 必选表、后置补句或删句均不属于本实验。
- 继续用原冻结完整题、首节、相关性与引用标准；v2 的 R7 普通周期、档案编号关联和字幕记录/用途遗漏必须保留为开发失败证据。首节进步不能抵消这些内容退步。
- 两种 answer-first 都合格时选择字段更少的 anchored 版本；没有合格版本则不接生产、不默认启用、不创建新留出。

设计中“先决定复杂首节挤掉后续事项”应作为**待验证的因果解释**，已有结果只证明二者共同发生；“不增加输出长度”准确含义是**不新增必填输出字段**，实际 completion tokens 和完整首见仍可能变化，照既定指标实测即可。这两处是结论措辞澄清，不扩大实验或增加新的交付门禁。

v2 全量评审已归档 `review/mechanism-v2-defender.md`：严格 8/16、全文 10/16、首节 12/16、相关性与引用各 16/16，每答一次。v3 未实测前不关闭对应 High findings；本次仅批准上述最小实验。

# Conditional Production Design Review — Defender

**Date**: 2026-11-11  
**Object**: `design.md` — Conditional v9 Production Integration; v9 saved experiment, existing `core/procedure_generation.py` / `core/local_rag_generation.py`, core/test contracts.  
**Independence**: 未读 critic、未生产编码或调用模型。

## Decision

**无 Critical/High 设计阻塞，批准在默认 false 下实施 v9 并运行已定红绿矩阵和真实 API 对照。** v9 的 16 答语义结果支持从实验适配器接入生产；它不替代集成验证、新留出或默认启用决策。

固定逐条分类把输出降至每答 122–158 tokens，同时实际保留完整动作/目的和主许可。生产仅替换内部 ProcedureAnswer/request schema 与渲染，并更新 general.yaml 为已测 v5 prompt，边界适当。真实条款 required properties、禁止额外键、严格类别和渲染键集合核对直接保障这次分类契约，不是额外的泛化防御工程。

## Implementation Conditions

1. 沿用实验的原分句、原文和引用；只有 step 中冻结的规范表达可前置，omit 不恢复，record/limit 不因命中词上移。保持源顺序、每条一次，不带入 v6 回指合并、v8 schema 注入或额外排序/摘要。
2. “无 lead”应指**前置处理后仍无可见 lead**，与已测 `probe_procedure_promoted.py` 相同；不要新增“模型必须先原生标出 lead”的未测要求。非法/不完整输出走现有不可用终态和 None，不再生成；接口不泄露未检查正文。
3. 将 limit 固定标题改为中性 `条件与边界 / Conditions and boundaries`，处理已复现的 R7 混合已知/未知原文。此项不修改 prompt/schema/事实选择，不把缺陷误报为事实遗漏。
4. 固定标题跟随已通过资格检查的证据语言；该检查已对齐所需输出语言，跨语资格不足仍走原完整生成。内部准备结果携带语言即可，无 API/shared_state/持久化变更。
5. 保留一次最终生成、2048/none/temperature 0、原输出检查和取消/完成性契约。普通比较、rewrite、非流程和不合格资料不改路由；不引入用户可见的分类实现细节。

## Validation and Remaining Boundary

既定单元/golden 和 Fast/Thinking JSON/SSE 进程内 E2E 足以覆盖本次行为差异：真实槽位/类别、前置与 omit 边界、首节原文/标题、完整发布及失败 None/不增加生成。先记录红再同矩阵绿，沿用已有取消和终态测试，不扩展假设故障清单。

其后执行原定八开发题、两模式、两轮 false/true 真实 API 对照；直接机制的约 1.8 秒不是 API 总时延承诺。冻结候选后再独立创建三题新留出并完成既定三轮两模式；本次未创建留出。只有这些证据达到原无实质退步和单生成要求，才改默认并同步文档、breaking 迁移、显式 false 回滚及默认实际冒烟。旧失败保留，不用结构检查或性能收益抵消语义退步。

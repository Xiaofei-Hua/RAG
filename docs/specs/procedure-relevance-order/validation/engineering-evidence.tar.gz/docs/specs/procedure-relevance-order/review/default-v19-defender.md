# Default v19 Defender Review

**Decision: 真实默认验证通过用户当前验收标准，可继续既定 CI 与合并流程；尚不声称已合并。** 核心机制 `915f421fe3208740391ddcd0b979234c57090f1a`，默认/回滚接线 `eeac9860d9a63e8f7a538c95916f725b659d35e3`。独立逐答读取六份实际正文，再自行核对请求、selection、来源、调用及保存结果；没有新增模型调用或重跑。

## Actual Answers

| Row | Mode | Case | Critical content / records / purposes / unknowns / relevance / citations | Lead |
|---|---|---|---|---|
| 1 | Fast | 广播 | P | 主要待播许可在第二节，已接受限制 |
| 2 | Fast | 编组 | P | P |
| 3 | Fast | 灯光 | P | P |
| 4 | Thinking | 广播 | P | 同 row1 的已接受限制 |
| 5 | Thinking | 编组 | P | P |
| 6 | Thinking | 灯光 | P | P |

六答完整保留 v19 冻结语料中的动作、条件、变更例外、记录字段与用途、已问未知及真实引用，没有带回装饰、其他活动未知或第三来源事实。广播整段试听/另一编辑签记并未丢失，仍在操作节；没有把该位置限制改判为首节通过。原严格首节为 **4/6**，当前用户接受条件下内容合格为 **6/6**。

## Default Route and Delivery

`data/eval/procedure-relevance-default-v19` 的六槽 policy/scheduler/segmented 均为 default；探针在进程入口分别移除 `LOCAL_RAG_POLICY`、`LOCAL_LLM_SCHEDULER`、`LOCAL_RAG_SEGMENTED`，而非显式 true。默认生产差异仅为 `segmented_enabled` 的缺省值，v20/v21 输出结构与提示没有接入。

自行比对同 query/mode 的 v19 冻结候选第一轮：六份实际最终请求、selection、正文及检索来源完全一致；真实响应均为完整原文 key→六类 string，没有 tuple 或新位置字段。总 **15 HTTP=6 generation+9 control**，Fast 每答总1次、Thinking每答总4次，每答最终生成都1次。六次均自然 stop、200/complete，最大873输出tokens。SSE token拼接、done.full_response、results正文以及只读SQLite会话AI正文六槽全部一致。

本次 API 首正文 P50/P95=10.001/10.266秒，Fast三答9.846/10.253、Thinking三答10.156/10.168秒；仅作默认路径冒烟观测，不用六答估计新的普遍性能结论。配对效果仍以[新留出结果](../results.md)与[证据归档](../validation/README.md)为准。

## Regression and Status

已读默认回归红1失败/1通过→相关绿92通过日志；已读最终矩阵 **1336 passed、6 skipped、3既有warnings、branch coverage 75%**。默认与显式false的一次调用/请求契约、原英文等旁路、输出检查与None降级回归继续有效；未因为默认通过追加测试范围。

F-16 维持 **High / defended-with-alternative（用户知情接受的展示限制）**，位置未技术修复。历史严格12/18及当时否决保留；新的用户标准不豁免正文遗漏、错误许可、错引或无关回流。当前没有新增阻断发现，最终 GitHub 检查与 main 合并由主线程完成后另记录。

# Mechanism v6 Pilot Independent Review — Defender

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v6-pilot/{results,model-http}.jsonl`; one-based rows.  
**Independence**: 完整审读四答与真实选择/请求/响应，未读 critic、未调用模型、未改判据或创建留出。

## Decision

**v6 不合格，不补跑至 16 答。** 内容覆盖 4/4、首节 3/4、相关性 1/4、引用 4/4，严格整题 **0/4**。三答把所有条款标为 step 并依原编号排序，全部显示无关事实；另一个正确保留分类的档案 original 首节仍仅范围。

| Row | Case / order | Content | Lead | Relevant / cited | Strict | Body time (s) | Completion tokens |
|---:|---|:---:|:---:|:---:|:---:|---:|---:|
| 1 | 档案 / original | P | F | P / P | F | 5.8432 | 507 |
| 2 | 档案 / reversed | P | P | F / P | F | 8.0383 | 732 |
| 3 | 字幕 / original | P | P | F / P | F | 5.1609 | 451 |
| 4 | 字幕 / reversed | P | P | F / P | F | 4.7944 | 413 |

Content 只指全文相关事实/字段/用途/未知齐全，不代表选择和书面组织已合格。首节按原冻结标准，不因长段或有意义重复扣分。

## Verified Facts

**V6-D01 — High, accepted/open: 分类退化导致相关性退步。** 第 2 答所有 17 条、第 3/4 答所有 13 条均为 `section=step`，order 逐项等于原编号，没有 omit。档案 reversed 明文带入绿色墙钟与 18 本年鉴，字幕两答明文带入银框公告板。所有类别/序号合法，仍不构成有效语义分类或操作排序。

**V6-D02 — High, accepted/open: 档案 original 首节仍未给许可。** 第 1 答分类保留记录、未知与 omit，相关全文齐全；RuleLead 只选条款 1 的范围，交接清点签名后才能阅览仍在后续步骤组。不能因其他三答首节通过而关闭它。

字幕两种顺序的实际首节已经完整包含 reviewer who did not edit it、该 reviewer 对同音频/字幕版本审批才可发布以及适用范围。原文资格与审批合并的边界变化在输出中可观察；不是仅隐藏 quote 正确。两答仍因银框失败，因此不能把组合结果称成功，也不能把独立角色保留的效果直接归功于 section/order。

所有档案申请分支、编号/各类记录/用途、交接与关闭条件及未知保留；字幕完整准备/阻塞、全程播放/返修、版本审批、音频变更与拼写例外、identifier/草稿链接、记录、四项用途与未知也保留。主要失败是选择偏题与一个首节缺规则，不夸大为全文事实都错。

## Calls and Disposition

四答都是一次真实生成、stop、完整渲染检查后 complete；参数均 qwen3.5:9b、temperature 0、top_p .8、none、2048。合计 **2,103 completion tokens**、**4,156 prompt tokens**，平均 525.75 completion tokens/答。较 v5 pilot 的 144.5 tokens/答明显增多，且未取得合格整题；两批不是严格时序交替的性能因果实验。

保留四答，停止复杂分类/排序组合的补跑，不生产接线、不改默认。已观察到的角色回指边界效果可以按新的隔离实验验证，不携带本轮未奏效的 section/order 框架。

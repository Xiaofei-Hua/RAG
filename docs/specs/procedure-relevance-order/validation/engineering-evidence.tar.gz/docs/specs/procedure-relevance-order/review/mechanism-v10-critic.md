# Mechanism v10 Critic Review

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v10-pilot/{results,model-http}.jsonl`，12槽逐答审读；冻结开发rubric不变。未读defender，未调用模型。

## Decision

**无合格候选，不扩大或接生产。** v9严格0/4，roles 1/4，linked 2/4。roles保留全部所问内容且去掉装饰，linked增加成本并在联赛反序漏所问事实；F-16未闭环。两候选排除本批装饰是收益，但不能据此宣称F-17已获新留出验证。

| Slot | Case / order | Variant | Full | Lead | Relevant | Citation | Strict |
|---:|---|---|---|---|---|---|---|
| 1 | Toy / original | roles | P | F | P | P | F |
| 2 | Toy / original | linked | P | P | P | P | P |
| 3 | Toy / original | v9 | P | F | F | P | F |
| 4 | Toy / reversed | linked | P | P | P | P | P |
| 5 | Toy / reversed | v9 | P | F | P | P | F |
| 6 | Toy / reversed | roles | P | P | P | P | P |
| 7 | League / original | roles | P | F | P | P | F |
| 8 | League / original | linked | P | F | P | P | F |
| 9 | League / original | v9 | P | F | P | P | F |
| 10 | League / reversed | linked | F | F | P | P | F |
| 11 | League / reversed | v9 | P | F | F | P | F |
| 12 | League / reversed | roles | P | F | P | P | F |

Toy原序roles把真正三项交付许可留在step，只有题名与范围进入首节；linked两序和roles反序首节正确。v9原序带入蓝点，反序排除蓝点。联赛六答首节均缺真正展示许可；v9反序另带入酒红横幅。linked反序把所问异议期限和“草稿不是已确认结果”标omit，实际全文随之遗漏。

联赛原序unit2同时含建记录与真正发布条件，两个候选均标step。linked的answers已写“公开显示的具体步骤与条件”，仍未将规则置于首节；反序对应unit6也为step。混合语义条款受首句动作影响是合理解释，尚未由隔离实验证明。事实是短关联没解决分类与展示位置绑定的问题。

## Cost and Direction

12条HTTP均为generation，每答1次、stop且complete，原始JSON选择与记录一致；同题同序三变体用户输入相同。输出预算2048、none/0/.8保持。

| Variant | n | Mean output tokens | P50 / P95 elapsed s |
|---|---:|---:|---:|
| v9 | 4 | 131.00 | 1.825 / 2.019 |
| roles | 4 | 132.25 | 1.861 / 7.427 |
| linked | 4 | 426.75 | 4.986 / 5.303 |

P95线性插值；roles首答8.375秒单列为观测，不凭四答归因提示开销。linked输出明显增加且未获得四槽全通过，不能选为当前候选。

**praise (non-blocking)**：业务信息与载体样式的说明在两个候选四槽均排除装饰，同时roles保住全文。下一步在同次输出中用自然语言概括首节、固定原文选择保留细节，比继续加类别或关联指令更值得最小实验；基线可见首段能直接概括许可，但不保证新组合成功，也不再引用原17/18高分（复核更正见`holdout-v9-critic.md`）。

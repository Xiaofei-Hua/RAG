# Defender Review — v16 Full-Clause Classification

**Date:** 2026-11-11  
**Evidence:** `data/eval/procedure-relevance-mechanism-v16/{results,model-http}.jsonl`；原七题 rubric 与已审 v13/v14/v15 对照。独立核验14份真实 selection 与可见正文，未读 critic、未调用模型、未改业务。

## Decision

**严格 12/14，当前不能批准 Conditional v16 Wiring 或后续 API 扩大。** 全文完整、相关性、已问未知、未问未知排除和引用均14/14；首节12/14。木玩具 Fast/Thinking 首节只有标题与范围，实际交付许可在步骤中，未满足原冻结首节要求。

三处旧错确已修复：照片 Fast 不再带队徽，裁片 Thinking 不再带义卖费用，档案 Thinking 恢复记录关联与用途。必须同时报告新的首节退步，不能由这三项改善推成14/14。完整原文 key、删除 answers 及相应提示精简是组合效果，未证明某个单因子的独立贡献。

无新增 Critical/High 安全或降级问题；首节质量失败依既定“任何语义退步不接线”条件处理，默认仍 false。

## Per-slot Results

| Case | Fast row / result | Thinking row / result |
|---|---|---|
| L4 | 1 / P | 5 / P |
| 档案 | 2 / P | 6 / P |
| 活动室 | 3 / P | 7 / P |
| 木玩具 | 4 / F（首节） | 8 / F（首节） |
| 温室 | 9 / P | 12 / P |
| 裁片 | 10 / P | 13 / P |
| 照片 | 11 / P | 14 / P |

其余变化主要为保留本题源标题或相关规则的组别位置；首节长度、无害重复与标题不扣分。温室 Thinking 首节仍有完整开阀条件，报架号不等于许可虽放步骤不使首节失败。L4按现行主要规则+范围标准通过，旧全部边界首节标准不倒改。

## Confirmed First-section Failure

`results.jsonl:4,8` 和对应 `model-http.jsonl:4,8`：完整真实键

“领取单与玩具编号核对一致、领回者逐项确认附件并签收，三项都完成才交出物件；待领通知本身不代表交付已经获准。”

两次真实模型都分类为 **step**。实际首节仅展示“木玩具领回流程”及已登记木制拼插/不含电动或电池玩具范围；三项许可全部到下一节才出现。原 v13/v14 首节含许可，该变化是直接退步。全文仍完整，因此只判L失败，不误报丢事实或放宽许可。

为排除实验适配器问题，将14份真实role只换回现有生产所需的数字键形状，用既有渲染规则做零模型重放：14/14正文与存档一致。旧渲染规则不会将此 step 句前置；不是临时正文写错。固定lead存在和来源合法均不能代替实际首节语义。

## Request and Wire Cost

14份请求保留原user/context与参数；schema键全部对应id+完整原文，值为六类string enum，没有answers。实际system与冻结full-key-prompt完全相同，raw selection与保存值相同。全部一次generation且stop，无length；最大输出879 tokens，未追加调用。

以下仅比较最终 generation 的 HTTP end-start，不与 API first_body 混比：

| Mode | v13 P50/P95 (s) | v14 P50/P95 (s) | v16 P50/P95 (s) | Output tokens v13/v14/v16 |
|---|---:|---:|---:|---:|
| fast | 7.224 / 7.402 | 9.348 / 11.047 | 8.189 / 9.372 | 4428 / 5824 / 5252 |
| thinking | 5.109 / 5.429 | 6.639 / 7.698 | 5.918 / 6.061 | 3154 / 4177 / 3670 |
| all | 5.428 / 7.361 | 7.475 / 10.451 | 6.051 / 9.311 | 7582 / 10001 / 8922 |

v16总输入16058、输出8922 tokens；v13为18116/7582，v14为18438/10001。去掉自写关联抵消了一部分完整原文回显成本，v16输出仍比v13多约17.7%。这是本机顺序实验的观测，不外推为稳定性能保证。预算本轮足够，但质量前提未成立，不进入生产长度回退或API扩展设计。

## Disposition

Conditional v16 Wiring 的技术增量虽小，前提是14答独立语义通过；本次未满足，所以未批准代码接线、默认启用或新留出创作。保留组合方案收益与失败证据，未新增题目词表、后置删句或任何防御门禁。


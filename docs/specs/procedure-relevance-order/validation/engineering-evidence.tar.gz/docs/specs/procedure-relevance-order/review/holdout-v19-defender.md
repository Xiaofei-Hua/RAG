# Holdout v19 Defender Review

## Decision

**未通过默认资格，保持 `LOCAL_RAG_SEGMENTED=false`。** 独立逐答读取 baseline/candidate 各 18 答，以及候选全部原始 selection 后，候选严格通过 **12/18**。短音频题两模式三轮的主要待播许可均留在第二节。全文事实与覆盖、相关性、引用、已问未知及未问未知均通过 18/18；这些收益不能代替用户明确要求的首节主要许可。

本报告先完成独立判断并落盘，未读取本轮 critic 结论。评审无模型调用、无重跑、无生产或协议修改。当前修复代码 `915f421fe3208740391ddcd0b979234c57090f1a`。

## Evidence and Scope

- [冻结记录](../validation/freeze-v19.md)：2026-11-12 09:33:05 UTC；独立新题 r1 创建于 09:42:33 UTC。三新域是短音频播单、双人练习赛编组、排练灯光提示单。
- [冻结协议 r2](../validation/holdout-v19.json)；生成前第三 query 的既有比较路由冲突仅等义改写，r1 与修订记录保留。语料、rubric 和候选均未根据模型答案调整。
- 两侧原始文件为 `data/eval/procedure-relevance-holdout-v19-{baseline,candidate}/{results,model-http}.jsonl`；各 18 答、45 次模型 HTTP，其中 18 次最终生成。公开归档入口为 [Validation Evidence](../validation/README.md)，当前结论汇入 [Results](../results.md)。
- 评价实际全文及实际首节，baseline 的首节是完整 `conclusion`（包括其中列表与空行），候选是“规则与适用范围”节。接受同义、文中自然承接、长首节、无害重复和标题；不把每一局部分支都要求放在首节。基线以“该执行单需三项确认”自然承接同一文件时，不因未逐字重复“同一版”另判首节失败。

## Semantic Results

`F`=全文所问事实/步骤/条件/记录用途，`L`=首节范围+主要许可，`R`=相关性，`C`=引用对应支持（包括不把来源歪说成其他事实），`U`=已问未知，`N`=未问无关未知省略；P/F 为通过/失败。

| Row | Round / Mode | Case | Baseline F/L/R/C/U/N | Candidate F/L/R/C/U/N |
|---|---|---|---|---|
| 1 | R1 Fast | 短音频 | F/F/P/P/P/P | P/F/P/P/P/P |
| 2 | R1 Fast | 编组 | F/P/P/P/P/P | P/P/P/P/P/P |
| 3 | R1 Fast | 灯光 | F/P/P/F/P/P | P/P/P/P/P/P |
| 4 | R1 Thinking | 短音频 | F/F/P/P/P/P | P/F/P/P/P/P |
| 5 | R1 Thinking | 编组 | F/P/P/F/P/P | P/P/P/P/P/P |
| 6 | R1 Thinking | 灯光 | F/P/P/F/P/P | P/P/P/P/P/P |
| 7 | R2 Fast | 短音频 | F/F/P/F/P/P | P/F/P/P/P/P |
| 8 | R2 Fast | 编组 | F/P/P/F/P/P | P/P/P/P/P/P |
| 9 | R2 Fast | 灯光 | F/P/F/F/P/P | P/P/P/P/P/P |
| 10 | R2 Thinking | 短音频 | F/F/P/P/P/P | P/F/P/P/P/P |
| 11 | R2 Thinking | 编组 | F/P/P/P/P/P | P/P/P/P/P/P |
| 12 | R2 Thinking | 灯光 | F/P/P/F/P/P | P/P/P/P/P/P |
| 13 | R3 Fast | 短音频 | F/F/P/P/P/P | P/F/P/P/P/P |
| 14 | R3 Fast | 编组 | F/P/P/P/P/P | P/P/P/P/P/P |
| 15 | R3 Fast | 灯光 | F/P/P/F/P/P | P/P/P/P/P/P |
| 16 | R3 Thinking | 短音频 | F/F/P/P/P/P | P/F/P/P/P/P |
| 17 | R3 Thinking | 编组 | F/P/P/F/P/P | P/P/P/P/P/P |
| 18 | R3 Thinking | 灯光 | F/P/P/F/P/P | P/P/P/P/P/P |
| Total | 18 answers | | 0/12/17/8/18/18 | 18/12/18/18/18/18 |

严格同时通过由 baseline 0/18 提升至 candidate 12/18。不能据此声称目标闭环或无实质退步：baseline 的六个短音频首节虽缺完整范围，却已有整段试听和另一编辑签记的主要许可；候选六答将该许可移到第二节，范围前置不能抵消这一组件的退步。

正文判读依据：

- 短音频候选六答保留当前文件整段试听、独立编辑签记、补录后整段复听、剪切换号/复核、仅标题变更例外、发出后错号停旧发新并逐人通知；所有播单关联、收件、试听、待补、剪切、更正、改字字段及用途完整。baseline 六答都漏播单编号关联节目日期/版次/片段号这一记录及相应用途，并有收件人或试听字段遗漏。其首节均未完整交代周末预录范围，候选范围补齐但许可后移。
- 编组候选六答完整保留双人资格/成员不重复/本轮桌号不重复/当前版组长签字及全部异常分支。轮次关联、核对人、待核待补、重排、退出和姓名改字记录及用途完整。baseline 六答漏轮次号与日期/组号/版次关联及核对人；R3 Thinking 又把新版签字作废要求泛化为任何待核/待补处理。候选实际首节均完整。
- 灯光候选六答完整保留同版执行许可、“该场第一个提示点”整场返工、走位新版/重走/重新确认、页眉例外、未完成逐项交接及各记录用途。baseline 六答漏提示单号与剧目/日期/场次/版次关联；R1 Thinking、R2 Fast/Thinking、R3 Fast 首节把“该场”误说为“首场/第一场”，后文正确句不消除矛盾。R2 Fast 还带入题外“待播文件”类比。多答把记录文件事实只挂在流程文件名下；候选引用按来源保留，无此错配。
- 两侧均未编造所问时长/费用/次数/留存期。候选排除窗帘、会刊封面、折叠椅，以及未问比赛截止、讲座费用、纪念册留存未知；Fast 检索带入的第三份题外文档所有单元均 `omit`。

## Finding DH19-01

| Field | Evidence |
|---|---|
| id / severity | DH19-01 / High（已复现的主要规则首节退步，拟并入既有首节行为组；等待交叉评审统一 ID） |
| location | `core/procedure_generation.py:182`、`:190` 的角色映射/前置；候选 results rows 1,4,7,10,13,16；对应 wire indices 1,7,16,22,31,37 |
| symptom | 六答 unit 4“标成待播的片段都有当前文件的整段试听记录，并有另一位值班编辑签记，确认首尾对应文稿且语音完整；收件或拖入列表还不算完成播出编排。”均标为 `step`；实际首节有范围、补录/改字/错号规则，主要待播许可在第二节。 |
| impact | 用户要求先说达到什么状态才列为待播，六次均未履行；与基线相比该主要许可实质后移。全文仍有事实，因此不夸大为知识丢失或不可用。 |
| root_cause | 这是已独立的完整句 unit，不是 v19 句中指代误合并。模型将状态许可归为操作，现有规范词前置没有命中该陈述式许可；标题 `main_rule` 不等于实际主要规则。 |
| recommendation | 保留 false，沿主要许可语义分类问题做最小有证据实验；不因本例直接扩实体/题目词表，不把全部步骤搬首节。不要求撤销已经证实的 search→match 修复。 |
| verification | 同题 Fast/Thinking 各三轮、六份原始 `clauses` 与六份完整首节一致；其余两题主要许可均在实际首节。 |
| status | accepted / open；未获默认资格，不把分组修复通过或严格分数提升当成关闭证据。 |

五步自裁决：①事实为真，selection 和展示共同证明；②正常中文请求六次可触发；③影响直接落在用户主要目标，不能以延迟收益抵消；④属于既定首节范围，不增加验收标准；⑤全文完整是保留收益而非等价的首节替代，维持失败结论。

## Calls and Cost

两侧均为同模型/引擎/context 4096、`none`、上限 2048、top_p .8、无重试；按冻结实现，baseline 完整生成温度 .7，candidate 结构选择温度 0。三轮用于复现稳定性，不视作三个独立新题。18/18 最终生成均自然 `stop`，API 200、`generation_complete=true`，token 拼合与 done/保存的 results 正文一致；没有用单次 schema 合法代替语义通过。

| Metric | Baseline | Candidate |
|---|---:|---:|
| All API first-body P50 / P95 (s) | 13.050 / 15.158 | 9.927 / 10.142 |
| Fast API first-body P50 / P95 (s) | 10.714 / 13.819 | 9.750 / 10.115 |
| Thinking API first-body P50 / P95 (s) | 13.781 / 14.945 | 10.067 / 10.176 |
| All generation HTTP P50 / P95 (s) | 10.476 / 12.403 | 8.118 / 9.839 |
| Fast generation HTTP P50 / P95 (s) | 10.608 / 13.635 | 9.623 / 9.843 |
| Thinking generation HTTP P50 / P95 (s) | 10.408 / 11.566 | 6.681 / 6.911 |
| Final-generation output mean / max tokens | 968.33 / 1326 | 709.00 / 873 |
| Final-generation input mean tokens | 981.67 | 1220.33 |
| Final generation / total HTTP calls | 18 / 45 | 18 / 45 |

每答最终生成仍 1 次，Fast 总 1 次、Thinking 总 4 次；此处 HTTP 分位数只计 generation，API 首正文另列。候选减少输出、缩短本样本延迟，但完整 key/schema 增加输入。该成本收益成立，首节缺陷仍使默认启用失败。

## Post-independent Adjudication

独立报告落盘后读取 [critic](holdout-v19-critic.md)。DH19-01 并入既有 **F-16，Critical / accepted / open**：初评 High 修正为仓库 `prompts/critic.md:28` 的 §2(a) 等级，目标首节 BUG 仍可复现。不是额外新增一个缺陷。

1. 事实：critic 引述 unit 4 与六个实际第二节正确，`procedure_generation.py:182,190` 对应角色及规范词处理正确；分句已独立，不能继续把原因归为句内指代。
2. 触发：正常两模式三轮六答均触发，baseline 同槽主要许可本在首节；引用原文和实际正文提供直接证据。
3. 成本/影响：影响本次核心顺序要求，必须接受；一次请求内改建模有相称实验路径，延迟下降不能作为缓解。
4. 范围：REQ-702/704/705 明确覆盖，不是另起全系统质量门禁。
5. 替代：完整正文和范围前置不等价于主要许可前置；无等价缓解，维持 false，v20 仅准入实验，不关闭 F-16。

baseline 子维度保留独立判读差异：defender 接受“同日本社双人练习队”的肯定范围及“该执行单需三项确认”对同一文件的自然承接，给 L=12/18；critic 对排除范围及同版绑定要求显式表达，给 L=4/18。defender 将棋赛“执行单形成”视为当轮安排形成的泛称，未单独扣相关性/引用；critic 视为跨域条款，R/C 各少 1。原始报告不互相覆盖。两方 baseline 严格 0/18、candidate 严格 12/18、六个主要许可后移及默认失败均一致，最终决定不依赖上述宽严差异。

# Production v13 Design Critic Review

**Date**: 2026-11-11  
**Scope**: `design.md`的“Production Wiring for v13”、已测`linked-unknown-prompt.txt`，当前`core/procedure_generation.py`与`core/local_rag_generation.py`接线位置。独立评审，未读defender、未调用模型、未改生产代码。

## Decision

**可按既定红绿实施默认false的生产候选；新增Critical=0、High=0。** 前提的八槽实测已经独立通过，见`mechanism-v13-critic.md`。这不批准默认启用；F-16/F-17仍待完整后续验证闭环。

## Assessment

- **praise (non-blocking)**：ProcedureClause固定`answers → role`，实际条款动态键齐全，采用已测六类角色与提示。answers仅内部短关联，程序仅依role选择原文，不依据“未询问”等文字再删改；这与L4反序实际通过的行为一致。
- main_rule/scope映射lead，step沿用已冻结规范词前置，record/limit不挪、omit不恢复。引用由原文来源生成，不引入v11自由摘要或source_ids生成数组；非omit内容完整保留，单次完整检查及stop发布不变。
- 中文资格放在`_eligible_evidence`共同边界，能同时约束prepare与前置select。只阻止prepare仍可能先删改英文证据，设计已明确避免；英文回归应验证完整schema、原temperature=.7、原context及单调用。中文弱异语证据过滤保留真实概率与None不作0的既有契约。
- 不支持语言、比较、rewrite及非明确流程仍回原完整生成；失败、取消、排队及不可用None沿用，不追加调用。没有新增shared_state键、持久化或外部安全边界，无需扩展额外防御门禁。
- 已列单元/golden与进程内Fast/Thinking JSON/SSE红绿、实际中文原文和引用检查、生产离线重放及真实API。general.yaml为唯一生产prompt来源，历史英文golden不能冒充候选语义验证；这些检查与改动直接相关。

## Remaining Validation

实现后先完成既定定向红绿与离线重放，再至少两轮真实API对照；重新冻结后由独立评审者创建全新中文留出，含未问未知干扰。未改英文路径保留请求控制；仅在中文被改路径无实质退步、单调用和耗时合格后另行决定默认。显式false回滚与中文限定范围须同步文档。

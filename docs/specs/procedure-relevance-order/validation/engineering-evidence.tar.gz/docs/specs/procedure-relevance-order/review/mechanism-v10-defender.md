# Defender Review — v10 Pilot

**Date:** 2026-11-11  
**Evidence:** `data/eval/procedure-relevance-mechanism-v10-pilot/{results,model-http}.jsonl`，逐行编号。独立审读 12 答与冻结 toy/match rubric；未读 critic、未运行模型、未改生产代码。

## Decision

**无合格候选，停止扩大 v10。** `v9` 严格 0/4，`roles` 1/4，`linked` 2/4。两个新变体都排除装饰事实，确有相关性收益；但联赛首节仍失败，linked 反序另丢所问未知，不能生产接线。

## Per-slot Assessment

C=全文动作/条件/记录用途/未知完整；L=首节主许可及范围；R=相关性；S=严格整题。12 答的实际展示原文及来源引用均通过，均 stop/complete；不以较长首节或无害标题重复判失败。

| Row | Case / order | Variant | C | L | R | S | Concrete issue |
|---:|---|---|:---:|:---:|:---:|:---:|---|
| 1 | Toy / original | roles | P | F | P | F | 交付三条件仅在操作段 |
| 2 | Toy / original | linked | P | P | P | P | — |
| 3 | Toy / original | v9 | P | F | F | F | 首节缺交付规则；蓝色页脚入记录 |
| 4 | Toy / reversed | linked | P | P | P | P | — |
| 5 | Toy / reversed | v9 | P | F | P | F | 首节缺交付规则 |
| 6 | Toy / reversed | roles | P | P | P | P | — |
| 7 | Match / original | roles | P | F | P | F | 双方确认且全部异议解决只在操作段 |
| 8 | Match / original | linked | P | F | P | F | 同上 |
| 9 | Match / original | v9 | P | F | P | F | 同上 |
| 10 | Match / reversed | linked | F | F | P | F | 首节同上；所问异议期限和草稿非确认被 omit |
| 11 | Match / reversed | v9 | P | F | F | F | 首节同上；酒红横幅入记录 |
| 12 | Match / reversed | roles | P | F | P | F | 首节同上 |

联赛原序 unit 2、反序 unit 6 把“建记录并附计分卡”和“双方确认且 steward 解决全部异议后才能公开”合在同组，三个变体都标 step。Linked 原序关联写“公开显示的具体步骤与条件”仍判 step；反序关联只写开记录的字段，连主许可都未体现。该现象支持“混合原文组的单一类别不适合作为语义首节”的解释，但不证明模型内部因果。

Linked 反序把明确被问到的异议解决期限（unit 3）写“未询问”并 omit；可见合理格式/先关联再分类不能保证覆盖。所有 linked 原始 JSON 实际均先 answers 后 role，失败不能归咎于未按该生成顺序输出。

## Calls and Cost

每答一次最终调用，共 12 次；原始 HTTP JSON 与保存 selection 逐答一致。参数保持 none、0、.8、2048。所有 token 均为真实输出，首个 roles 的较高耗时保留，不擅自剔除或解释为预热。

| Variant | Input tokens | Output tokens | Body P50 / max (s) |
|---|---:|---:|---:|
| v9 | 3,952 | 524 | 1.825 / 2.024 |
| roles | 4,284 | 529 | 1.861 / 8.375 |
| linked | 4,552 | 1,707 | 4.986 / 5.317 |

Linked 输出为 roles 的约 3.23 倍，仅修复本轮木玩具原序首节，未获得跨题稳定收益。四槽样本只作最小实验判断，不声称稳定延迟分位数。

## Next Hypothesis

自然语言首节与固定原文覆盖分工，比继续叠加分类指令更值得最小验证：首节不再受混合条款单一标签支配，细节保留逐条选择的覆盖优势。其自然语言事实、并列许可和资格仍可能出错，不能用来源合法替代真实语义验收；此处仅支持下一实验方向，不批准生产。基线“首节 17/18”不是本 defender 已核实统计；按 `holdout-v9-defender.md` 为 12/18 语义首节通过，其中一答语言错误。

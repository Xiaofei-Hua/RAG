# Mechanism v4 Independent Review — Defender

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v4/{results,model-http}.jsonl`, one-based rows.  
**Independence**: 只核验保存的请求、原始响应和正文；未读 critic、未运行模型、未改判据或创建留出。

## Decision

**v4 不合格，停止剩余实验合理；不接生产、不改默认。** 当前归档是四条已完成调用，而不是三条全部失败：R7 原序/逆序两答都因重复长 enum 达到 2048 token 上限；L4 原序/逆序两答实际 stop、完整发布，正文按冻结标准通过。不得把 L4 的 stop 记成 length，也不因两条 L4 成功继续补跑已无准入可能的矩阵。

| Row | Case / order | Finish | Completion tokens | Complete body (s) | Total elapsed (s) | Outcome |
|---:|---|---|---:|---:|---:|---|
| 1 | R7 / original | length | 2,048 | None | 20.6107 | unavailable / incomplete |
| 2 | R7 / reversed | length | 2,048 | None | 20.5019 | unavailable / incomplete |
| 3 | L4 / original | stop | 846 | 9.3843 | 9.3843 | complete; strict Pass |
| 4 | L4 / reversed | stop | 908 | 9.8891 | 9.8891 | complete; strict Pass |

## Verified Failure and Cost

R7 两条原始响应都停留在第一个 answer 段的 clause_ids 数组，同一长标识完整出现 **87 次**，其后还有未写完的重复前缀。原序重复的是 R7 范围条款尾号 1，逆序是同一原文尾号 9。不是必要的较长完整答案耗尽预算，而是选项在解码中持续重复；两答都没有可用正文，`first_body_s=None`、`generation_complete=false`、`reason=LengthFinishReasonError`。未把不可用的首见时间记成 0，也未把部分 JSON 当完成。

四条实际调用均 qwen3.5:9b、temperature 0、top_p .8、none、2048，每答一次生成，没有追加生成或核验。已完成调用共使用 **5,850 completion tokens**、**4,614 prompt tokens**。样本提前停止，不报告虚构的 16 答结果，不用两条成功答的低分位数掩盖不可用答；未测的其余题目没有质量结论。

## L4 Semantic Check

两条 L4 的实际首节都包含无结露室内 19–26°C 范围和初次定位样张通过才正式打印/起算；全文保留 350 正式标签、测试/作废不计、换托盘重检合格后恢复并重新起算、失败暂停/排因复检、指定定位纸及机台/托盘准备、日期/样张/通过失败及失败样张记录、全部所问用途、室外规则和价格未知。无蓝包装/库存，引用映射到完整原文；长标识没有截断用户正文的事实。按原冻结标准完整性、首节、相关性和引用均通过，无害重复不单独判失败。

## Disposition

现有证据足以否决**当前长字符串 enum + 开放重复选择列表**的 v4 候选；不外推为所有可读标识方案均无效。保留四次原始结果，默认 false，无需跑完剩余 12 槽或增加预算。后续若改成固定槽位分类，应作为新的选择机制单独评审；本报告没有提前批准其分类结果或效果，也不会把“每条填过槽位”当作语义完整证明。

# Code v13 Critic Review

**Date**: 2026-11-11  
**Scope**: 当前六文件tracked diff：`core/procedure_generation.py`、`core/local_rag_generation.py`、`data/profiles/general.yaml`、`tests/unit/test_procedure_generation.py`、`tests/e2e/test_segmented_api.py`及`tests/fixtures/local_segmented_procedure.json`。独立评审；未读defender，未调用模型，未改生产代码。

## Decision

**新增Critical=0、High=0，可继续既定真实API与新留出验证；默认false保持。** 没有发现生产算法偏离已审v13机制或新增调用/状态/降级失效。两轮开发严格16/16，不能据此默认启用；F-16/F-17最终闭环仍取决于后续被改路径验收。

## Implementation

- **praise (non-blocking)**：`ProcedureClause`严格定义answers和六类role；动态schema为每个实际条款要求一个完整槽。解析后核对实际键集合，只按role决定原文展示，answers不进入正文也不改变选取。这保留了实测“辅助标注不等于事实证明”的契约。
- main_rule/scope进入lead，step使用原冻结规范词前置；record/limit保留位置，omit不恢复。各组按原文单位顺序组合，每条一次，来源从实际单位取得；标题为中性条件与边界，没有自由首节、实体词规则或新增生成调用。
- `_eligible_evidence`共同边界限制中文目标语言，prepare和前置select均受约束。英文在筛证据前回原输入；普通比较、rewrite与不明确流程保持原路。中文极弱异语去除仍要求真实概率、强中文证据与既有阈值，None不作0。
- `local_rag_generation`仅改接动态procedure schema，原完整生成参数不变。解析/stop/缺多键/类别或字段不合法仍落既有不可用终态，检查前不发布部分正文；没有新shared_state、持久化或外部边界，取消与排队代码未变。`core/segmented_generation.py`默认值仍false。
- general.yaml与已测提示逐字一致；中文Toy真实输出成为当前golden。测试覆盖字段顺序、原文引用与隐藏标注、中文资格、英文schema/温度/context/单调用及不预删异语证据，Fast/Thinking的JSON/SSE、历史落盘、PII处理及失败confidence=None。

## Verification

已读归档红绿日志：`validation/v13-red.log`为23 failed/42 passed，`v13-green.log`为65 passed；这部分是核验已有日志，未重复执行已绿矩阵。

critic独立运行零模型离线重放，使用生产prepare/schema/render处理两轮16份实测选择：原文单位、渲染正文16/16相同；schema除title注释外约束等价，生产prompt与真实请求相同。原HTTP16次均generation、stop，每答一次。第二轮正文与首轮逐槽相同，全文/首节/相关性/引用/未知及严格判断均16/16，详见`mechanism-v13-critic.md`。

另外对`api-development-v13.json`的11题执行完整离线路由预检（bounded本地模型stub、rewrite_count=0，零网络）：恰四中文流程进入候选，三英文流程及四普通题走原完整路径，英文select返回原证据。实际API仍需核实检索和rewrite后的最终路径，不把离线资格当作运行时覆盖。

## Documentation Note

非阻断：API协议R7继承的`routing_expectation`仍写v5 compact资格，与顶层明确“三英文原路径控制”不一致。建议只修正这一离线说明，不改query、来源事实或rubric；实际完整路由已确认是原路径。

接下来完成正在运行的真实API对照，再冻结候选与中文资格并创建独立新留出；英文失败仍是未解决范围，不能将英文原路径波动计为候选收益。

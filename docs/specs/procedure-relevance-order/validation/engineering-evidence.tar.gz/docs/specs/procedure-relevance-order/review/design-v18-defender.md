# Defender Review — v18 Mixed-Clause Priority

**Date:** 2026-11-12  
**Scope:** `design.md:30`及`validation/priority-key-prompt.txt`相对冻结`full-key-prompt.txt`的单句修订。独立于本轮critic，未读取其结论；没有调用模型、修改生产或题目。

## Decision

**允许既定40答临时实验；本设计没有新增Critical/High准入阻塞。当前v17的首节Critical仍open，默认必须false。此批准不是prompt生产接线、目标闭合或默认启用认证。**

修订直接针对真实混合unit的单标签优先级，不拆原文、不改来源、不加实体/规范词、不追加模型调用。仅在实测没有旧能力退步后才具备接线依据，之后仍需要真正新留出。

## Factual Basis and Design Assessment

1. v17六份陶艺选择均把条款3（登记、主要开放条件、松动、复检）标为step：candidate `model-http.jsonl:1,7,16,22,31,37`；六份正文首节实际没有许可，见`holdout-v17-defender.md`。这是可触发的主要规则错位，不是对潜在风险的推测。
2. 旧prompt `full-key-prompt.txt:3,5`要求主要许可属于main_rule，同时`:9`要求混合条款按最主要类别分类。实际混合unit的大部分字数是操作步骤，两条指示可能把同一unit导向不同角色。新`:9`明确以所问主要许可优先，再适用范围，其余按主要类别；消除了这个直接的分类优先级歧义。
3. “主要操作”仍受`:3`的用户所问事项和`:8`的omit相关性约束，不等同于把任意资料中的许可都提前。新prompt没有恢复omit或让程序自行推导许可。是否出现模型忽视相关性、过度前置或新的遗漏，应由原十题包含的干扰/未知逐答检验，不凭提示文字宣称保证。
4. 原文单元与其内部事件条件保持，当前`core/procedure_generation.py:181`自然把main_rule映射到首节；即使整条较长，冻结标准已接受长首节和无害重复。该路线无需为命中陶艺增加“获准/开放依据”等词表，也不重建分句算法，符合已复现问题的最小范围。

## Experiment Qualification

| Item | Assessment |
|---|---|
| Inputs | 10个已暴露中文题×两模式＝20个原始最终请求，各两轮40答；完整query、上下文、schema/keys及rubric保持 |
| Treatment | 只替换优先级一句；其余prompt、none/temperature0/top_p0.8/2048与当前渲染/检查保持 |
| Control | 已存v17同题同模式实际请求与正文；陶艺失败保留，不把新输出替换原记录 |
| Quality | 全文、实际首节、相关性、所问/未问未知及引用逐答评；六个陶艺错位必须关闭，已通过七开发题和另两新题不能出现实质退步 |
| Cost | 每次仍一次最终generation；临时重放的耗时只与最终generation wire同口径比较，不当作API首见 |
| Follow-through | 通过后最小prompt/golden红绿接线；再冻结，独立另建全新留出，真实API两模式三轮baseline/candidate，随后才讨论默认 |

复用已保存最终请求适合本次隔离单句分类变化，避免把未改检索重新采样引入为额外变量。此前真实API/单元已覆盖未改接线；新冻结后的全链路留出仍保留，因而本阶段不重复全开发API合理，不降低最终质量门槛。临时实验的成功仅证明这20个上下文中的干预结果，不能把40答当40个独立新题。

## Remaining Boundaries

- 优先级描述能否被9B稳定执行尚无新实测，本报告不提前关闭`DH17-01`。
- 该干预可能只改善展示位置；所有原未知/关联记录/相关性判据必须继续保留，不能只核陶艺首节。
- 模型输出更短或更快不能抵消新遗漏/无关内容；旧数据与新实验的速度应标明同机顺序与不同批次局限。
- 未改变代码范围、shared_state、降级、资格、安全边界或单调用预算，不新增题外防御门禁。

## Critic Adjudication

独立准入意见归档后读取`design-v18-critic.md`。其结论同为允许40答临时实验、无新增Critical/High；没有新的具体finding可逐条裁决。逐项核验其单句变更、原请求/schema/预算保持、完整开发语义评测和真正新留出要求，均与`design.md:30`及实际两个prompt文件相符，采纳该准入边界。

既有F-16的五步裁决见`holdout-v17-defender.md`末节：accepted但未修复、仍open。设计合理不提前关闭目标缺陷。

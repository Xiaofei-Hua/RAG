# Holdout v17 Preflight Critic Review

**Date**: 2026-11-11  
**Scope**: `validation/holdout-v17.json` r1 与 `candidate-v17-code.tar.gz` 冻结候选。未读 defender 评测结论或任何新留出模型输出，未调用模型，未改协议/候选。

## Decision

**通过，可启动 false baseline / true candidate 各 18 答（三题 × 两模式 × 三轮）。新增 Critical/High: 0。** 22:17 CST 已在正式模型运行前向 root 发出通过结论；本结论仅为实验准入，不是默认启用批准。

冻结记录时间为 2026-11-11 14:06:51 UTC；作者及协议说明本三题在冻结后独立创作且未调用模型。当前相关运行代码/profile 与冻结归档一致。未根据生成输出调整题目、词语、原文或 rubric。

## Full Eligibility

使用 general / bounded / qwen3.5:9b / loopback:11434/v1，实际执行 **segmented_enabled + select_procedure_evidence + prepare_procedure**，包含真实来源名、全文和正常 `render_untrusted_evidence` 上下文；不是只检查流程关键词或单独 prepare。

| Case | Query/evidence | Enabled | Selected | Prepared units | Source IDs |
|---|---|---:|---:|---:|---|
| 陶艺布展 | zh / zh, zh | true | 2/2 | 13 | 1,2 |
| 步道离线包 | zh / zh, zh | true | 2/2 | 17 | 1,2 |
| 雨量月表 | zh / zh, zh | true | 2/2 | 15 | 1,2 |

各条款对应实际原文，来源映射和上下文检查通过。正常 runner 上传全六来源、由检索选择，case.sources 不强制过滤；另用全部六来源实际 select/prepare，三题也均通过（45 槽），不存在异语证据资格遗漏。此检查不宣称全六来源输入的质量/预算已通过，真实检索及最终 schema 仍在正式结果中核对。false 侧三题均不进入候选。模型调用为 0。

## Inputs and Fair Criteria

正常入口只提交 corpus/query 与来源名；coverage、manual_required、lead/strict rubric、freeze 等评审信息离线，不能进入生成。协议保持原首节主要许可/一般范围、全文所问动作/条件/记录用途/未知/引用的语义标准，接受等义表达、标题和无害重复，不要求所有局部分支塞在首节。

三题为新的布展、地图包维护、人工雨量数据流程。主要许可自然写为“开放依据”“下载依据”“可标为已确认具有”，没有为“完成才”修复专造命中句或实体白名单。记录要求来自资料且被问题明确询问，未加问题外必答细节。

| Case | Asked unknowns | Unasked information to omit |
|---|---|---|
| 陶艺 | 展品保险办理、包装寄回费 | 地毯外观、课程报名费未知 |
| 离线包 | 可用空间下限、旧链接天数 | 地图交换会、绘图讲座日期未知 |
| 月表 | 补报截止日、原纸保管年限 | 书柜外观、摄影展截止日未知 |

`praise (non-blocking)`：未知同时覆盖应保留与应排除项，并含不同事项共享“费用/截止日”的自然情形；能检验真实语义对应而非无差别保留未知。零值与未观测、独立签认、异常未办结等要求均来自所问流程，不是新增全系统门槛。

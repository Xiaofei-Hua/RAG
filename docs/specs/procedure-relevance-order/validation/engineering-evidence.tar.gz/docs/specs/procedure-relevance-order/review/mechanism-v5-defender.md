# Mechanism v5 Pilot Independent Review — Defender

**Date**: 2026-11-11  
**Evidence**: `data/eval/procedure-relevance-mechanism-v5-pilot/{results,model-http}.jsonl`; one-based row references.  
**Independence**: 完整阅读四答及真实选择/请求/响应，未读 critic、未调用模型、未改判据或创建留出。

## Decision

**pilot 不合格，不补跑原 v5 至 16 答。** 四答都保留了全部相关事实、记录、用途和所问未知，排除了装饰事实；但首节 0/4、严格整题 0/4。字幕 reversed 还把 review/return 放在准备之前，不符合所问流程的组织顺序。

| Row | Case / order | Content coverage | Lead | Relevant / cited | Strict | Body time (s) | Completion tokens |
|---:|---|:---:|:---:|:---:|:---:|---:|---:|
| 1 | 档案 / original | P | F | P / P | F | 2.1356 | 158 |
| 2 | 档案 / reversed | P | F | P / P | F | 2.1642 | 158 |
| 3 | 字幕 / original | P | F | P / P | F | 1.7995 | 131 |
| 4 | 字幕 / reversed | P | F | P / P | F | 1.8719 | 131 |

Content coverage 仅指事实/字段/目的/未知信息齐全，不代表书面首节与操作顺序也合格。四答旧“全部条件在首节”诊断亦全部失败，不据此另加本轮门槛。

## Findings and Verified Gains

**V5-D01 — High, accepted/open: 首节仍未回答完整主规则。** 档案两答首节仅范围/资料标题，共同清点签名后才能阅览留在步骤组。字幕 original 首节仅范围；reversed 首节有同音频/字幕版本审批规则，但缺独立审核条件，不能概括为四答都只有范围，也不能因为 reversed 有部分审批规则就判合格。类别值合法与非空 lead 没有解决这个语义问题。

**V5-D02 — Medium, accepted/open: reversed 跨来源步骤顺序退化。** 第 4 答 Procedure 先呈现审核记录和退回循环，之后才准备 job card/transcript、起草和播放，再处理审批后的音频变化。原因是组内沿资料原序拼装，review notes 逆序置于 workflow 前。所有条件文字仍保持，不应夸大为允许未审批发布；但这不是用户要求的按准备、编辑、审核顺序说明。

档案编号关联字段、三类核对记录、交接/归还/异常字段及复核追加、三项目的、候补/退回/关闭条件、两项未知均完整。字幕 identifier/全部草稿链接、播放/review字段、阻塞到匹配、返修全程播放、新版本审批、音频变更重启、仅标题拼写例外、四项用途与两项未知也齐全。墙钟/年鉴和银色公告板都被 omit。固定槽位在这四个输入上确实保住内容且较紧凑，不把“每条有标签”单独当成这些收益的证据。

## Calls and Disposition

四次均实际单次最终生成、stop，完整原文渲染检查后 complete。参数均 qwen3.5:9b、temperature 0、top_p .8、none、2048。合计 578 completion tokens、3,888 prompt tokens；没有追加模型。1.7995–2.1642 秒是直接适配器的完整正文可用时间，不是正常 API 全链路收益。

维持 false，归档四答后停止原 v5 补跑。下一设计可以检验把覆盖分类、首节选择与组内展示顺序分开，但须独立审查和实测；不能仅因本批内容齐全就关闭首节和顺序缺陷。

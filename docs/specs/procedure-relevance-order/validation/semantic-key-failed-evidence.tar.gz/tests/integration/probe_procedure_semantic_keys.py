"""Replay real Chinese generation inputs with readable fixed clause keys."""
import asyncio
import copy
import json
import os
import re
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
os.environ.update(PYTHON_DOTENV_DISABLED="1", LOCAL_RAG_POLICY="bounded", LLM_MODEL="qwen3.5:9b", OPENAI_BASE_URL="http://127.0.0.1:11434/v1", OPENAI_API_KEY="ollama", DOMAIN_PROFILE="general", LOCAL_LLM_SCHEDULER="fair", LOCAL_RAG_SEGMENTED="true", EMBEDDING_PROVIDER="api")
from langchain_core.messages import AIMessage
from run_bounded_api_probe import capture_model
from core.procedure_generation import render_procedure
from core.segmented_generation import CheckedParagraphs
from agent.guardrails.manager import GuardrailManager
from models.llm_models import get_llm


def read_inputs():
    cases=[]; corpus={}
    for name in ["api-development-v13.json", "holdout-v13.json"]:
        protocol=json.loads((ROOT/"docs/specs/procedure-relevance-order/validation"/name).read_text())
        corpus.update(protocol["corpus"])
    for folder in ["procedure-relevance-api-v13-candidate", "procedure-relevance-holdout-v13-candidate"]:
        directory=ROOT/"data/eval"/folder
        rows=list(map(json.loads,(directory/"results.jsonl").read_text().splitlines()))
        wire=list(map(json.loads,(directory/"model-http.jsonl").read_text().splitlines()))
        for row in rows:
            if row["round"] != 1:
                continue
            calls=[r for r in wire if row["model_start"]<r["index"]<=row["model_end"] and r["call_class"]=="generation"]
            assert len(calls)==1
            call=calls[0]; request=call["request"]
            schema=request["response_format"]["json_schema"]["schema"]
            if "clauses" not in schema["properties"]:
                continue
            units=[]; source_names={}; sid=None
            for line in request["messages"][-1]["content"].splitlines():
                m=re.match(r"\[证据(\d+)\] 来源=(.*?) \| 标题=",line)
                if m:
                    sid=int(m[1]);source_names[sid]=m[2]
                m=re.match(r"\[条款(\d+)\] (.*)",line)
                if m:
                    assert sid is not None
                    units.append({"id":int(m[1]),"source_id":sid,"text":m[2]})
            assert [str(u["id"]) for u in units]==schema["properties"]["clauses"]["required"]
            assert set(source_names)==set(range(1,len(source_names)+1))
            sources=[source_names[i] for i in range(1,len(source_names)+1)]
            cases.append({"case_id":row["case_id"],"mode":row["mode"],"original_directory":folder,"original_index":call["index"],"original_answer":row["answer"],"original_first_body_s":row["first_body_s"],"request":request,"units":units,"sources":sources,"contexts":[corpus[n] for n in sources]})
    assert len(cases)==14
    return cases


async def main():
    cases=read_inputs()
    out=Path(sys.argv[1]).resolve();out.mkdir(parents=True,exist_ok=False)
    old_prompt=(ROOT/"docs/specs/procedure-relevance-order/validation/linked-unknown-prompt.txt").read_text()
    prompt=Path(sys.argv[2]).resolve().read_text() if len(sys.argv)>2 else (ROOT/"docs/specs/procedure-relevance-order/validation/semantic-key-prompt.txt").read_text()
    (out/"inputs.json").write_text(json.dumps(cases,ensure_ascii=False,indent=2))
    (out/"prompt.txt").write_text(prompt)
    os.chdir(out);counter=capture_model(out/"model-http.jsonl")
    model=get_llm();model.cache=False;checker=GuardrailManager().check_output
    for case in cases:
        request=copy.deepcopy(case["request"])
        assert request["messages"][0]["content"]==old_prompt
        request["messages"][0]["content"]=prompt
        slots=request["response_format"]["json_schema"]["schema"]["properties"]["clauses"]
        mapping={f'{u["id"]}:{u["text"][:12]}':str(u["id"]) for u in case["units"]}
        slots["properties"]={key:slots["properties"][uid] for key,uid in mapping.items()}
        slots["required"]=list(mapping)
        configured=model.bind(reasoning_effort="none",temperature=0,top_p=.8,max_tokens=2048,extra_body={"max_tokens":2048},response_format=request["response_format"])
        row={k:case[k] for k in ["case_id","mode","original_directory","original_index","units","sources"]}
        started=time.perf_counter();before=counter[0]
        try:
            async with asyncio.timeout(45):message=await configured.ainvoke(request["messages"])
            value=json.loads(message.content);row["selection"]=value
            assert set(value)=={"clauses"} and set(value["clauses"])==set(mapping)
            adapted=AIMessage(content=json.dumps({"clauses":{mapping[k]:v for k,v in value["clauses"].items()}},ensure_ascii=False),response_metadata=message.response_metadata)
            rendered=render_procedure(adapted,case["sources"],{"units":case["units"],"language":"zh"})
            publisher=CheckedParagraphs(checker,case["sources"],case["contexts"]);publisher.append(rendered)
            row.update(answer=publisher.text,first_body_s=time.perf_counter()-started,finish_reason=message.response_metadata.get("finish_reason"),usage=message.usage_metadata)
        except Exception as exc:
            row.update(error=str(exc),first_body_s=None)
        row.update(elapsed_s=time.perf_counter()-started,model_calls=counter[0]-before,model_end=counter[0])
        with (out/"results.jsonl").open("a") as f:f.write(json.dumps(row,ensure_ascii=False)+"\n")
        print(json.dumps({k:v for k,v in row.items() if k not in {"answer","selection","units","sources"}},ensure_ascii=False),flush=True)

asyncio.run(main())

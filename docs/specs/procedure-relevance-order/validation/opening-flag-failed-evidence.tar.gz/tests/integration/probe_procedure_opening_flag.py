"""Test an independent opening flag with existing clause roles."""
import asyncio
import copy
import json
import os
import re
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
os.environ.update(PYTHON_DOTENV_DISABLED="1", LOCAL_RAG_POLICY="bounded", LLM_MODEL="qwen3.5:9b", OPENAI_BASE_URL="http://127.0.0.1:11434/v1", OPENAI_API_KEY="ollama", DOMAIN_PROFILE="general", LOCAL_LLM_SCHEDULER="fair", LOCAL_RAG_SEGMENTED="true", EMBEDDING_PROVIDER="api")
from run_bounded_api_probe import capture_model
from langchain_core.messages import AIMessage
from core.procedure_generation import render_procedure
from core.segmented_generation import CheckedParagraphs
from agent.guardrails.manager import GuardrailManager
from models.llm_models import get_llm


def jsonlines(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def read_inputs():
    directory = ROOT / "data/eval/procedure-relevance-mechanism-v19"
    old = json.loads((directory / "inputs.json").read_text())
    answers = jsonlines(directory / "results.jsonl")
    calls = jsonlines(directory / "model-http.jsonl")
    cases = []
    for case in old:
        row = next(x for x in answers if (x["case_id"], x["mode"], x["round"]) == (case["case_id"], case["mode"], 1))
        call = next(x for x in calls if x["index"] == row["model_end"])
        cases.append({**{k: case[k] for k in ["case_id", "mode", "units", "sources", "contexts"]}, "request": call["request"], "reference_directory": directory.name, "reference_wire_index": call["index"], "reference_answer": row["answer"]})
    directory = ROOT / "data/eval/procedure-relevance-holdout-v19-candidate"
    answers = jsonlines(directory / "results.jsonl")
    calls = jsonlines(directory / "model-http.jsonl")
    for row in answers:
        if row["round"] != 1:
            continue
        generations = [x for x in calls if row["model_start"] < x["index"] <= row["model_end"] and x["call_class"] == "generation"]
        assert len(generations) == 1
        call = generations[0]
        request = call["request"]
        human = request["messages"][-1]["content"]
        sources = [m[2] for m in re.finditer(r"^\[证据(\d+)\] 来源=(.*?) \| 标题=(.*)$", human, re.M)]
        units = []
        for match in re.finditer(r"^\[证据(\d+)\] 来源=.*?(?=^\[证据|\Z)", human, re.M | re.S):
            source_id = int(match[1])
            for clause in re.finditer(r"^\[条款(\d+)\] (.*)$", match[0], re.M):
                units.append({"id": int(clause[1]), "source_id": source_id, "text": clause[2]})
        keys = {f'{u["id"]}:{u["text"]}' for u in units}
        assert keys == set(request["response_format"]["json_schema"]["schema"]["properties"]["clauses"]["required"])
        cases.append({"case_id": row["case_id"], "mode": row["mode"], "units": units, "sources": sources, "contexts": ["\n".join(u["text"] for u in units if u["source_id"] == i) for i in range(1, len(sources) + 1)], "request": request, "reference_directory": directory.name, "reference_wire_index": call["index"], "reference_answer": row["answer"]})
    assert len(cases) == 26
    return cases


def render_opening_flags(message, case):
    assert message.response_metadata.get("finish_reason") == "stop"
    value = json.loads(message.content)
    assert set(value) == {"clauses"}
    clauses = value["clauses"]
    assert set(clauses) == {f'{u["id"]}:{u["text"]}' for u in case["units"]}
    roles = {}
    for key, selection in clauses.items():
        assert isinstance(selection, list) and len(selection) == 2
        role, opening = selection
        assert role in {"main_rule", "scope", "step", "record", "limit", "omit"}
        assert isinstance(opening, bool)
        roles[key] = "main_rule" if role == "step" and opening else role
    adapted = AIMessage(content=json.dumps({"clauses": roles}, ensure_ascii=False), response_metadata={"finish_reason": "stop"})
    return value, render_procedure(adapted, case["sources"], {"units": case["units"], "language": "zh"})


async def main():
    cases = sorted(read_inputs(), key=lambda c: c["case_id"] != "holdout_v19_spoken_audio_playlist")
    pilot = len(sys.argv) > 2 and sys.argv[2] == "pilot"
    if pilot:
        cases = [c for c in cases if c["case_id"] == "holdout_v19_spoken_audio_playlist"]
    out = Path(sys.argv[1]).resolve()
    out.mkdir(parents=True, exist_ok=False)
    prompt = (ROOT / "docs/specs/procedure-relevance-order/validation/orthogonal-opening-prompt.txt").read_text()
    (out / "inputs.json").write_text(json.dumps(cases, ensure_ascii=False, indent=2))
    (out / "prompt.txt").write_text(prompt)
    os.chdir(out)
    counter = capture_model(out / "model-http.jsonl")
    model = get_llm()
    model.cache = False
    checker = GuardrailManager().check_output
    for roundno in ((1,) if pilot else (1, 2)):
        for case in cases:
            request = copy.deepcopy(case["request"])
            request["messages"][0]["content"] = prompt
            slots = request["response_format"]["json_schema"]["schema"]["properties"]["clauses"]["properties"]
            for key, slot in list(slots.items()):
                slots[key] = {"type": "array", "prefixItems": [slot, {"type": "boolean"}], "minItems": 2, "maxItems": 2}
            configured = model.bind(reasoning_effort="none", temperature=0, top_p=.8, max_tokens=2048, extra_body={"max_tokens": 2048}, response_format=request["response_format"])
            row = {k: case[k] for k in ["case_id", "mode", "units", "sources", "reference_directory", "reference_wire_index"]}
            row["round"] = roundno
            started = time.perf_counter()
            before = counter[0]
            try:
                async with asyncio.timeout(45):
                    message = await configured.ainvoke(request["messages"])
                selection, rendered = render_opening_flags(message, case)
                publisher = CheckedParagraphs(checker, case["sources"], case["contexts"])
                publisher.append(rendered)
                row.update(selection=selection, answer=publisher.text, generation_checked_s=time.perf_counter()-started, finish_reason=message.response_metadata.get("finish_reason"), usage=message.usage_metadata)
            except Exception as exc:
                row.update(error=str(exc))
            row.update(elapsed_s=time.perf_counter()-started, model_calls=counter[0]-before, model_end=counter[0])
            with (out / "results.jsonl").open("a") as f:
                f.write(json.dumps(row, ensure_ascii=False)+"\n")
            print(json.dumps({k:v for k,v in row.items() if k not in {"answer", "selection", "units", "sources"}}, ensure_ascii=False), flush=True)

asyncio.run(main())

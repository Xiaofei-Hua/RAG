# Candidate Freeze v19

UTC: 2026-11-12T09:33:05.038205+00:00

基线origin/main=9b79b006a89620ec58b4d46538913f20bfc5e54e，候选fix/procedure-relevance-order。代码见candidate-v19-code.tar.gz；生产仍为v17完整原文键/六类prompt，唯一新机制为句首_REFERENCE.match替代任意位置search。默认false。

独立critic/defender已批准全开发40/40（十个已暴露题、两模式、两轮），先导2答单列；保留旧失败记录。生产新golden红2失败→绿72通过，20个真实请求的units/context/schema与生产精确一致，40答零模型回放一致。句首指代仍回连，句中指代不吞并独立许可，原文/调用预算不变。

冻结后由独立defender新创3题/6份资料，不复用已暴露题及答案；critic零模型完整segmented_enabled/select/prepare资格预检。实际API false/true各18答（两模式各三轮），期间不改prompt/schema/分组/渲染/问题/语料/rubric。事实完整、实际首节主要规则与范围、相关性、已问/未问未知及真实引用分别验收；不要求每句或每个延迟分位数全面优于基线。失败转开发并保留，质量未通过不改默认；通过后默认冒烟及最终门禁。

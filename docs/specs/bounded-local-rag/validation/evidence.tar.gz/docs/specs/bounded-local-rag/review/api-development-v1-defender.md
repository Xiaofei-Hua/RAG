# API Development v1 Defender — Bounded Local RAG

**Review date**: 2026-11-10。  
**Evidence**: `data/eval/bounded-local-rag-api-dev-v6/{results,model-http}.jsonl` 全部 16 槽和 40 次模型请求，冻结 development.json，实际 LangGraph/API 回归、manager 异常修复、当前动态 schema 代码及已落盘红绿。未读另一评审或留出，未运行模型/测试；此为独立 Agent 语义审阅。

## Decision

**本批为 13 条主要语义完整、1 条比较结论不完整、2 条安全拒收后未交付答案，不是 14/14 正文全部合格。** 保留默认 legacy，继续修复后按既定 16 槽复测，不能将安全拒收记为正确回答，也不应退回只交付开关而停止当前目标。

允许所提最小修订：每请求限定合法 source_ids 枚举、同步两个输出预算字段，以及通用提示要求比较结论明确表达对象关系。它们落实已批准的有效编号、实效预算和完整结论契约，不增加模型调用、专用题型分支或新实验矩阵。留出继续未读。

## All-Slot Quality Assessment

| Case | r1 Fast | r1 Thinking | r2 Fast | r2 Thinking |
|---|---|---|---|---|
| 电池记录比较 | **Incomplete**：数值/工况/引用正确，但只列芦序 10 小时、赤砚 9 小时，没有明确谁更长/短。 | Pass：明确赤砚短于芦序，9 小时=540 分钟，与 600 分钟比较；负载限制完整。 | Pass：明确芦序长于赤砚，600 分钟=10 小时，不能外推同负载。 | Pass：同样明确比较与适用条件。 |
| 零值/缺测 | Pass：10 分钟、0 毫秒=0 秒、结果为零不等于缺测；引用双方。 | Pass：同义正确，首句与后文一致。 | Pass：条件、换算和零值含义完整。 | Pass：没有将不同单位推为不同量，也未宣称设备普遍绝对精准。 |
| 校准周期 | Pass：全文保留正常连续使用、建议、120 日历日、首次确认/换后先校准起点。 | Pass：同一完整义务，来源正确。 | Pass：首句简写由后文明确完成首次确认、校准完成日起算，无矛盾。 | Pass：首句及后文条件/起点完整。 |
| 英文价格/保修 | **Unavailable**：原 JSON 引用 0，程序拒收。 | **Unavailable**：原 JSON 引用 0，程序拒收。 | Pass：价格未给，18 个月 from delivery，未编造价格或以 42 mm 代替。 | Pass：同一事实与缺值边界完整。 |

电池 r1 Fast 的全文（results.jsonl 第 1 行）没有比较关系，只能由读者从两数自行推断。该题冻结义务要求明确记录中的大小结论；此前已按相同标准区分“列两数”和“回答谁更长”。这里不是要求固定句式或某种单位：其它槽用“赤砚短于芦序”或分钟单位均可通过。

成功英文答复的业务正文为英文，末尾仍有固定中文 AI 提示；照实保留这一应用层语言边界，不称全文纯英文。各正常正文的引用均对应实际支持资料，没有将多出的无关召回材料用作事实依据：Fast 来源卡通常 3 篇，而每题必要资料为 1 或 2 篇；来源总数不等于 gold 来源命中数或引用支持率。Thinking 的来源列表通常是所需的 1/2 篇。

## Rejected IDs and Minimum Correction

model-http.jsonl 第 4、20 行分别为 r1 Fast/Thinking 英文题生成，原 JSON 的 basis/conclusion 都使用 source_ids=[0]，而实际 context 是 1-based 编号。内容中的价格/保修事实本身正确，仍不能替错误 ID 配上猜测的来源。当前拒收有效，API 分别返回生成未完成/生成失败文案；这两槽是交付失败、语义不可评，不计 0 分或正确缺价拒答。

`core/local_rag_generation.py:60–82` 当前在每次 generate/async generate 时创建 schema，将 CitedParagraph.source_ids.items.enum 设置为 `[1..len(sources)]`，再执行一次模型调用；后验 `render_answer` 的空白/越界拒绝仍在。新 schema 是请求局部对象，不缓存某个请求的 N；平行来源列表仍由实际 kept evidence 提供，不以去重来源卡或模型自造文件名替代。该约束可减少已复现 0 编号输出，**不等于自动检查文本语义支持**，也不能替代整题质量审阅。

统一 max_tokens 与 max_completion_tokens 为生成 2048、control 256，可消除已观察到的两字段冲突，符合原设计。保留非法 JSON/ID、length、空输出的单次安全降级，不补全来源、不偷偷重试。

对比较提示的补充无设计阻断：建议写“conclusion 不能**仅**重复 basis 的数值清单；数量比较必须明确表达对象间更大/更小/相同等关系”。保留必要数值和条件，避免误解为结论禁止重复数字。该规则没有题名/具体答案，是原“明确比较关系”的具体化。按同一 prompt golden 红绿和原 16 槽复测即可；本批失败记录不覆盖。

## Wire and Timing

16 槽各只有一次最终生成：Fast 共 8 次生成；Thinking 共 8 次 intent、8 次工具规划、8 次 grade、8 次生成，合计 **40 次 HTTP**，未见在线语义 judge 或第二次生成。所有实际请求 reasoning_effort=none，响应没有 reasoning/reasoning_content；工具调用正常 finish_reason=tool_calls，其余 stop。

本批 wire 的生成参数仍是 max_tokens=2048 / max_completion_tokens=4096，控制为 256 / 4096，因此本批不能冒称两字段已同步。读取期间新代码已显式绑定 max_tokens，待修订后的请求回归/真实复测确认，不用后续代码改写旧 wire 事实。

原始 first_body_s 包括失败文案：r1 Fast 英文 2.280 s、r1 Thinking 英文 4.393 s 均不是有效答案 TTFT，应为 None。14 条有业务正文的首段到达为约 **2.180–6.060 s**，其中 r1 Fast 电池仍不完整；不能删除三条非完整结果后宣称整体质量/性能门槛通过。没有 180 s 超时，也不使用历史预算终态计算加速百分比。

## Actual Graph/API and Exception Regression

`tests/e2e/test_bounded_local_rag_api.py:25–114` 参数化 Fast/Thinking × JSON/SSE × 正常/输出检查抛错。Thinking 构造真实 AgentHarness、register_defaults、graph 节点与 manager after-hook；外部模型 HTTP 和检索被密封替换，意图分类被固定路由，但**没有用 mock harness 替代待验证的生成/发布顺序**。Fast 显式恢复真实 async 生成入口。用例核对一次生成、零 judge、None/degraded、SSE token 拼接等于 done，以及回复和会话历史中没有原始测试电话号码。

异常场景直接让 check_output 抛出 RuntimeError。旧 after-hook 异常被 lifecycle 记录后吞掉，原始 PII 因而能留下；`api-red-corrected-fixture.log` 真实出现该 PII 断言失败。当前 manager 在 bounded 下将最后消息改为明确输出检查错误并记录 output_check_degraded，BLOCK/ESCALATE 同样改为安全终态，避免依赖 lifecycle 的通用异常吞掉机制。Fast 既有 finalize 错误分支对称处理。未更改 legacy 异常行为，没有吞掉 asyncio 取消并发起新请求。

已读证据：早期 api-red 与修 fixture 后的 red 均为 **8 failed**，其中抛错后的 PII 失败直接支持此修复，不能把所有 8 个失败都泛称同一个生产缺陷；`api-green.log` 为 **25 passed**。`id-enum-red.log` 为 **3 failed / 14 passed**，分别暴露预算字段、编号约束和 control 参数；本次读取时尚无独立 id-enum-green.log，不擅填后续 green 数量。主 Agent 正继续既定红绿/真实复测，本 defender 未运行额外检查。

## Final Disposition

当前修订方向与异常修复没有新增设计阻断。旧批次质量尚未全通过；下一步仍是修复、完整复测和独立结果审核，不是提前默认启用，也不是新增门禁或停止实现。默认 legacy 与未读取留出保持。

# API Development v2 — Independent Critic

Date: 2026-11-10。独立全文读取`data/eval/bounded-local-rag-api-dev-v7/results.jsonl`16槽、`model-http.jsonl`40条和原development资料/manual；按槽model_start/end关联输入输出。未读留出/另一评审，未运行模型/测试或修改业务。

## Decision

**16/16满足本轮核心事实、明确结论、条件、来源与语言义务，原三项失败均闭合；可进入既定独立留出。** 无新增实质阻断。下面单列一处非阻断的引语标示局限，不宣称所有文字或引号逐字来自原文。4个开发问题×2模式×2轮，不是16个独立问题；保留上一API轮13/16的失败，不追溯改判。尚不授默认部署资格。

## Whole-answer Audit

| Case / round | Fast | Thinking | 全文判断 |
|---|---|---|---|
| ih2_06 / 1 | PASS | PASS | 均明确芦序记录续航大于赤砚；10h>9h或600min>540min等价，8W/5W分别归属，不能据此推断同负载优劣，两源完整。Fast不再仅并列数字。 |
| ih2_06 / 2 | PASS | PASS | 上述关系、原值/换算与条件限制全部保留，无按负载比例外推或实体混同。 |
| dev_zero / 1 | PASS | PASS | 明确0ms=0s、计时偏差相同、10分钟基准及零是测量结果而非缺测；两源正确，无相反首结论。 |
| dev_zero / 2 | PASS* | PASS | 同上；Fast一处把正确概括写成原文引语，见下文，不改变支持该答案的实际测量事实。 |
| dev_calibration / 1 | PASS | PASS | Q2、正常连续使用时120日历日、首次投入使用确认起算、更换后先校准再重算，完整并有来源；不按独立截取首句忽略后续明确条件。 |
| dev_calibration / 2 | PASS | PASS | 相同义务完整。适用条件、两个起点和引用无混淆；不要求逐字重列无关否定清单。 |
| dev_missing / 1 | PASS | PASS | 英语正确交付价格未提供、保修18个月从交付起；原source_id=0已消失，实际引用产品资料。 |
| dev_missing / 2 | PASS | PASS | 同上，不将42mm当价格；固定中文平台免责声明单列为既有UI文字，不当模型语言错误。 |

*非阻断表达局限：r2 Fast零值段称资料“指出‘记录的零值是数值，不等于缺测’”。该精确短语来自通用规则，不是资料逐字原文；资料确实写明测试已完成、0为本次记录结果，因此零非缺测这一推导与引用对象正确。应把这段理解为概括/推导，不能宣称逐字引语准确。本轮不因它改变正确结论、重新追加模型轮次或提升原门槛。有限重复亦非原长纠错循环。

## Actual Requests and Publication

40次实际模型HTTP=16 generation+8 intent+8 agent+8 grade；judge/rewrite/补生成0。Fast每槽1次，Thinking每槽4次。intent均rag_query/0.95，agent真实rag_retrieve、grade均yes，无新错误路由。generation均stop，control按stop/tool_calls正常完成；全部无reasoning输出、无length/空答。

生成请求两个预算字段均2048；control两个字段均256，none和原结构化/tool契约保留。每个生成schema的enum严格为实际编号1..N：Fast本轮N=3，Thinking按实际kept为1或2；输出ID全部有效且指向正文所述来源，不因来源顺序不同错绑。没有将非法0后验猜成1。两模式16条公开SSE的token拼接都等于done正文，grounding_faithfulness均None、confidence_degraded均true，不冒充语义核验。

## Useful Body Latency

全部16槽本轮有效，按`first_body_s`的linear(N−1)分位数计算；完整首段在本实现为受检整答发布：

| Mode | N | P50 | P95 | Range |
|---|---:|---:|---:|---:|
| Fast | 8 | 3.188s | 3.931s | 2.106–3.936s |
| Thinking | 8 | 5.669s | 6.009s | 4.232–6.074s |

均满足当前30s开发目标；这是本轮小样本实际API观察，没有成功legacy分母，不报告相对加速比。不能推广为任意负载/问题的P95保证。

引擎前提仍是本轮实际0.24.0-format-backport；官方未修补0.24不可凭相同版本族自动取得schema资格。当前auto默认选择修订已从设计上限定该前提，具体实现/部署与最终留出分别闭环，见runtime-compatibility-critic.md。

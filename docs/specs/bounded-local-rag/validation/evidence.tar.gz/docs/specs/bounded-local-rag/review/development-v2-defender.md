# Development v2 Defender — Bounded Local RAG

**Review date**: 2026-11-10。  
**Scope**: `validation/development.json` 的完整资料、问题与义务；`data/eval/bounded-local-rag-dev-v2/{results,http}.jsonl` 全部 8 次；design 的 v3 Single-pass Evidence-first Output（第 37–41 行）；`core/local_rag_generation.py` 与必要调用方。未读 critic/留出，未运行模型或测试。此为独立 Agent 逐题语义审阅，不是外部真人盲测或关键词评分。

## Decision

**开发机制语义审阅 8/8 通过，可以继续既定真实 API 多轮验证。** 当前结果解决了前版已观察到的零单位首句错误/自相矛盾、引用遗漏和整篇条件遗漏，未发现新的实质事实、关系、条件或引用支持错误。一次 JSON 的结构与渲染机制可接受，不需要追加第二次模型调用。

这只批准进入下一阶段：当前默认仍应 legacy；没有读取或批准冻结留出，更没有得到默认推广或 main 合并资格。前版 8 次失败/成功混合记录继续保留，不用本轮通过覆盖它们。

## Per-Sample Semantic Review

| Round / case | Observed answer and evidence | Decision |
|---|---|---|
| r1 `ih2_06` | 明确芦序记录更长；赤砚 9 小时换为 540 分钟，对比芦序 600 分钟，计算正确。保留 8 W/5 W，限制结论为各自记录，拒绝相同负载外推。事实/比较结论引用两份相应记录。 | Pass |
| r2 `ih2_06` | 相同正确比较，分别给两方原始记录与负载，再明确没有同负载数据，未编造能效或按比例外推。各单方事实引用本方，结论引用双方。 | Pass |
| r1 `dev_zero` | 首句即在 10 分钟条件下相同；0 毫秒/0 秒统一单位后同为 0，零为本次测量结果，不是缺测。正文与首句一致，单方值和双方推导的引用对应。 | Pass |
| r2 `dev_zero` | 相同结论与单位推导；“测量结果为无偏差”限定在本次 10 分钟记录，没有推出设备在所有条件下绝对精准。没有前版的指令当资料、错误首句或修正模板。 | Pass |
| r1 `dev_calibration` | 全文明确正常连续使用、建议每 120 个日历日；首次从完成投入使用确认起算，更换后先校准，再从该校准完成日起算。单一真实维护资料支持全部内容。 | Pass |
| r2 `dev_calibration` | 保留同样的建议强度、适用条件和两个起点，还明确排除出厂/收货/入库。结论与后文一致，没有擅改运行日或强制周期。 | Pass |
| r1 `dev_missing` | 全文英文；价格未提供，仍回答保修 18 个月 from delivery，没有以 42 mm 代价格或改成从销售/制造起算。每段引用实际产品资料。 | Pass |
| r2 `dev_missing` | 同样完整区分未知价格与已知保修期限，未因价格缺失全盘拒答；英文和来源均正确。 | Pass |

电池答案选择统一到分钟（9 小时=540 分钟，与 600 分钟比较），与参考的统一到小时（600 分钟=10 小时，与 9 小时比较）是同一正确推导。不能仅因没出现字面“10 小时”判不通过；事实、换算和明确比较结论都已经给出，没有放宽语义要求。

校准两轮的正常连续使用条件在 basis/conditions 明确展示，虽然结论段未再重复这一短语，整篇并未遗漏或否认条件。r1 明确给出唯一正确首次起点，无须把每个错误日期都逐字列出才算“不混淆”；r2 则显式列出了这些排除项。这与前版整篇没有适用条件的失败不同。

当前每篇有简短的结论/依据复述，属于新结构对同一事实的正常呈现，没有数十次元提示循环、自我纠错或相互冲突。不能将这种表达形式差异等同已复现的重复生成故障。

## JSON and Citation Assessment

`CitedParagraph` / `GroundedAnswer` 使用严格字段结构，basis 至少一项、conclusion 必填、conditions 允许空；每段 text/source_ids 均必需。`complete_content` 在解析前拒绝 length/content_filter 或空正文；`render_answer` 严格解析整个 JSON，再拒绝空白段落与越界 ID，不进行修 JSON 的第二次生成。

输出按 conclusion→basis→conditions 排序，仅做空白整理和添加真实来源名，不改写数值、否定或条件。逐条核对 8 份原始 JSON 与结果正文：**8/8 渲染一致，所有 ID 有效，共 34 段**；原始生成次序为 basis→conditions→conclusion。没有删掉错误段、给错误 ID 补全全部来源或用另一模型修正结论。

来源表由调用者传入。Fast 使用实际 kept_documents 顺序，Thinking 使用 prepared evidence 的平行 source 列表；不是用去重来源卡位置。当前 8 份开发上下文的编号、来源表、段落 ID 与实际证据全部对应；段落内同名来源去重只影响显示，不改 ID 映射。schema/ID 合法并不证明语义受到支持，本报告的通过来自上面的独立逐题审阅。

函数生成前仅判断 sources 非空，编号与上下文一致性依赖调用者按已定义契约构造平行表；不能表述为 renderer 能独立验证检索来源真实性。当前已核对调用方及本轮输入满足该契约，无需为本阶段新增泛化来源验证框架。

`generation_chain` 的 sync/async 分支分别只 invoke/ainvoke 一次；无模型补写或 parser-retry。client 的 bounded 分支 max_retries=0，探针关闭模型缓存。`finalize_answer` 仍调用既有输出护栏，失败返回安全终态；但本次探针直接运行 generation_chain，**没有实测完整 API 检索/控制/输出护栏/SSE 发布链**，后续 API 阶段必须继续完成既定覆盖。

## Measurements and Limits

8 次结果的 `error` 均为 null，对应 8 份 HTTP 响应，finish_reason 均为 stop；未见 reasoning/reasoning_content 输出。实际请求包含 reasoning_effort=none、temperature=0.7、top_p=0.8、json_schema 与兼容 max_tokens=2048。原请求还带工厂 max_completion_tokens=4096；兼容字段已经到达请求，但不能把“双字段”说成只发一个字段。

机制调用耗时为 **1.779–3.689 s**。响应报告 completion_tokens 为 **133–319**；这批短答证明当前调用有效完成，不能单凭其都小于上限就宣称已测试满 2048 边界。字符数与 token 不混算；没有用旧 180 秒预算消息算加速百分比。

这些耗时来自给定证据的生成机制探针，不是完整真实 API TTFT/P95，也未测吞吐和跨请求并发。8/8 是两个重复轮次、4 个已暴露开发问题的结果，不是 8 个独立新题，更不是所有数学/代码/领域 profile 的质量保证。允许按既定顺序继续真实 API 验证，保留精确 9B/general 限定和 legacy 回滚；不追加新的实验矩阵或默认门槛。

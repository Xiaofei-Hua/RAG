# API Development v2 Defender — Bounded Local RAG

**Review date**: 2026-11-10。  
**Scope**: `data/eval/bounded-local-rag-api-dev-v7/results.jsonl` 的 16 个完整 API 结果与 `model-http.jsonl` 的 40 条实际请求/响应，对照同一 `validation/development.json`。未读另一评审或冻结留出，未运行模型/测试，未改业务代码；仅新增此报告。这是独立 Agent 语义审阅，不是外部真人盲测。

## Decision

**16/16 的核心回答义务通过，可以进入原定 4 题 × 2 模式各一次的冻结验证。** 所有请求交付了业务正文，无错误终态、空答或预算超时；前批非法 ID 与仅并列数值的问题在本批未再出现。16/16 指完整业务结论、事实、条件、缺值边界和有效来源支持；并非宣称每个引号中的文字都逐字来自原文。下述一处推导误标为引文需保留记录，影响为非阻断的来源表述瑕疵。

没有新增 Critical/High 或进一步扩大矩阵的理由。默认仍为 legacy，当前结论不提前授予默认启用/main 合并资格；留出尚未读取，也不因开发通过声称留出成功。历史批次 13/16 与两条安全终态继续保留。

## All-Slot Assessment

| Case | r1 Fast | r1 Thinking | r2 Fast | r2 Thinking |
|---|---|---|---|---|
| `ih2_06` | Pass：明确芦序续航时长大于赤砚，10 小时/9 小时、5 W/8 W 与不可外推完整。 | Pass：明确 600 分钟大于 540 分钟，原始 9 小时及换算正确；不能比较同负载。 | Pass：明确大小关系、两方负载及同负载数据缺失。 | Pass：芦序长于赤砚，统一到分钟，负载映射与限制正确。 |
| `dev_zero` | Pass：0 秒即 0 毫秒，10 分钟条件下相同；零为记录结果，不是缺测。 | Pass：首句及依据一致，两来源对应。 | 核心义务 Pass；正确相等/非缺测，但有下述引述归属瑕疵。 | Pass：10 分钟、统一单位后的相等及零值含义完整。 |
| `dev_calibration` | Pass：正常连续使用、建议、120 日历日、首次确认与换后先校准/重新起算都在全文明确。 | Pass：同一条件与起点完整；没有把建议改为强制。 | Pass：首句简写由正文明确完成首次确认/校准完成日起算，无矛盾。 | Pass：同样完整，排除出厂/收货/入库没有添加新起点。 |
| `dev_missing` | Pass：价格未提供；18 个月 from delivery，未拿 42 mm 充价格。 | Pass：同一缺值/保修事实及真实产品资料引用。 | Pass：完整区分未知价格与已知保修。 | Pass：未因价格未知全盘拒答，业务正文英文。 |

电池题用分钟还是小时归一化均可；比较关系现在全部明确，不再需要读者自行从两数推出答案。校准适用条件在正文出现即可，不要求每段重复同一句条件，也不要求逐字重述全部错误日期；本次判断保持实质义务而非参考答案字面同构。

英文题四条业务正文均英文，应用末尾仍附固定中文 AI 提示；这是已披露的应用层语言边界，不能称最终 payload 全英文。正常的结论/依据重复没有形成元提示循环或自相矛盾。

## Nonblocking Attribution Note

- **ID / severity / status**: API2-D01 / Medium / open, nonblocking；需保留披露，不作“全无瑕疵”宣传。
- **Location**: results.jsonl 第 10 行（r2 Fast `dev_zero`）；model-http.jsonl 第 22 行的第二个 basis 段。
- **Symptom**: 答案称资料“且指出‘记录的零值是数值，不等于缺测’”。该字面句出现在请求的 system 提示，而不在两份计时器原文；原文实际写测量已完成、0 毫秒/0 秒、该数值是本次测试记录结果。
- **Impact / root cause**: 把正确的通用解释误标成资料的直接引语。零不是缺测、已完成测量的主结论本身可由两份资料推出，且 10 分钟适用范围、数值和来源均正确，没有前版的“偏差不同”“存在测量误差”或普遍精准性无据断言。因此不升级为新实质事实/条件错误，也不撤销本题核心义务通过。
- **Recommendation / verification**: 区分“原文记录”与“据此可知”的推导表述；本报告保留原句与归属核对结果，不删原文掩盖问题。此项不要求另起模型调用、引文字符串扫描门禁或扩大实验；既定冻结验证继续核对来源忠实度。

这是来源叙述准确性的问题，不只是标点不同；同时也不应把语义受支持的解释夸大成设备参数错误。有限影响与后续验证范围已经清楚，可继续原定流程。

## Wire, Evidence Mapping and Publication

- **40 次实际 HTTP**：16 次最终 JSON 生成；Thinking 另有 intent、agent 工具规划、grade 各 8 次。Fast 每请求 1 次，Thinking 每请求 4 次，未见在线语义 judge、第二次生成或重试。
- **预算一致**：16 次生成的 max_tokens/max_completion_tokens 均为 2048；24 次控制均为 256。40 次均 reasoning_effort=none，响应未出现 reasoning/reasoning_content。32 个 stop、8 个工具规划 tool_calls；没有 length。
- **每请求 enum**：Fast 的实际 context 为 3 条，schema 枚举 [1,2,3]；Thinking 比较/零值题为 [1,2]，校准/英文为 [1]。逐槽确认 enum 与当次实际证据数相同，所有输出 ID 均在合法范围。来源显示与该编号对应，没有补来源、错用去重列表位置或静默删除段落。
- **来源卡与证据支持**：Fast 的第三份无关候选仍在来源卡中，不能把总来源数 3 称为 3 个正确 gold；实际事实段没有引用这些无关候选。有关事实/条件的引用都能落到相应完整资料。编号合法不自动等于语义正确，以上质量结论来自人工语义审阅。
- **发布内容**：16 槽的全部 token 拼接、done.full_response 与保存于结果文件的 answer 相同。metadata 均 generation_policy=bounded、grounding_faithfulness=None、confidence_degraded=true，未把未核验写成语义评分通过。这不替代已有 PII/异常路径回归，也不声称本批自然题专门触发了这些异常。

## Observed Timing

| Mode | Completed / attempted | First body range | P50 | P95 (nearest rank) |
|---|---|---|---|---|
| Fast | 8 / 8 | 2.106–3.936 s | 3.188 s | 3.936 s |
| Thinking | 8 / 8 | 4.232–6.074 s | 5.669 s | 6.074 s |

本批所有槽均有业务正文，不需要把错误通知误计为有效 TTFT。分位数是各 8 样本的描述统计，P95 采用 nearest-rank，因此等于该组最大值；不能外推线上尾延迟。这里测的是完整 API 返回正文的时点，不能与之前给定上下文 generation_chain 的耗时混为一类，也不拿历史 180 秒预算终态计算加速百分比。

## Next Authorized Step

在默认 legacy 和当前冻结配置下，按已有计划运行独立 4 题两种模式各一次，保留所有终态与原始请求，再独立审阅。开发仅 4 个已暴露问题、2 个轮次和2种模式；16 槽不是16个独立新题。当前实测收益和主答案完整性已足以进入该步骤，不再为措辞/形式差异扩展无关工作。

# API Development v1 — Independent Critic

Date: 2026-11-10。审阅完整API首个16槽结果`data/eval/bounded-local-rag-api-dev-v6`、40条实际HTTP、原开发资料/manual、当前单次生成/护栏接线及已有红绿。未读留出或另一评审，未运行模型/测试、未改业务。

## Quality Decision

**13/16完整通过，3槽不通过；当前不得判整体质量合格或启用默认。** 这是4个已暴露问题×2模式×2轮，不能当16个独立问题。全部HTTP 200和SSE done仅表示API终态，不等于回答义务满足。

| Case / round | Fast | Thinking | 全文判定依据 |
|---|---|---|---|
| ih2_06 / 1 | FAIL | PASS | Fast只列芦序10h、赤砚9h，没有明确回答哪方记录续航更长；数值、8W/5W限制、两源均正确，属于核心比较结论遗漏，非数值错误。Thinking明确540min短于600min，条件与归属完整。 |
| ih2_06 / 2 | PASS | PASS | 明确芦序记录更长，600min=10h与赤砚9h、两方负载及不能外推同负载结论完整。 |
| dev_zero / 1 | PASS | PASS | 明确0ms=0s、偏差相同，10分钟基准与零为测量结果而非缺测、两源完整。 |
| dev_zero / 2 | PASS | PASS | 同上，无此前首结论与依据相反或单位不同即数量不同的错误。 |
| dev_calibration / 1 | PASS | PASS | 全文包含正常连续使用下120日历日、首次投入使用确认起算、更换后先校准再重新起算和来源。无需逐字再列所有错误起点。 |
| dev_calibration / 2 | PASS | PASS | 同上；没有用制造/收货日期代替正确起点。 |
| dev_missing / 1 | UNAVAILABLE | UNAVAILABLE | HTTP #4/#20原JSON英语事实正确，但各段source_ids均[0]；后验范围检查拒收，公开的是安全生成失败提示，未交付答案。不能算质量PASS，也不将其有效TTFT记0。 |
| dev_missing / 2 | PASS | PASS | 英语完整交付价格未知、保修18个月从交付起，来源ID=1且引用正确；平台固定中文提示不是生成语言失败。 |

除所列3槽外未发现事实、条件、来源或结论实质遗漏；内部标签、格式及有限重复不另当失败。原失败保留，后续修复不追溯改判。

## Calls and Useful Latency

按各槽`model_start/model_end`定位真实HTTP，未用不同模式的请求位置盲目zip。共40次：16 generation、8 intent、8 agent、8 grade，judge/rewrite/补生成均0。Fast每槽1次，Thinking每槽4次；intent均rag_query、confidence0.95，agent实际调用rag_retrieve、grade均yes，未见错误路由。

生成wire为none、T0.7/top_p0.8、实际max_tokens2048；控制为none、max_tokens256。旧SDK同时带max_completion_tokens4096，当前0.24仍读取max_tokens；两字段统一是明确预算的最小修复，不据此改写本轮有效预算。生成均正常stop；后验无效ID两槽仍不能因stop当答案成功。

以下只对完整合格答案的`first_body_s`计算linear(N−1)分位数；失败槽仍在总分母中单列，不从总体成功率消失：

| Mode | Complete / planned | Useful first body P50 | P95 | Range |
|---|---:|---:|---:|---:|
| Fast | 6/8 | 2.996s | 3.286s | 2.180–3.317s |
| Thinking | 7/8 | 5.456s | 5.980s | 4.177–6.060s |

r1 Fast电池、r1 Fast英文、r1 Thinking英文的原到达时间分别3.656/2.280/4.393s，仅是原始正文/安全提示到达，合格TTFT均None。没有有效legacy对照，不宣称相对加速比。

## Minimal Repair and Publication Review

**同意两个已复现问题的最小修复方向，无新增阻断：**每次调用按实际来源表构造`source_ids.items.enum=[1..N]`，保留严格后验检查、整答拒收和单次调用；不把0改成1、不默认引用全部来源。当前`core/local_rag_generation.py:61–83`已每次新建schema并供sync/async共用，不串用其他请求的来源范围；生成绑定max_tokens2048、control256并保留Ollama兼容字段，方向一致。

给通用conclusion规则补“比较必须明确对象关系，不能只重列数值”直接对应r1 Fast电池的核心遗漏；不含题名/固定答案，不增加调用。schema只能约束编号/结构，不能自动证明该比较规则已完成；按既定原16槽复验即可，无须扩大矩阵。新增enum和prompt红绿/新实际结果由后续归档确认，本报告不预判通过。

`tests/e2e/test_bounded_local_rag_api.py`建立真实AgentHarness、真实技能/图与after-hook；只替换外部模型transport、检索及intent，区别于旧假harness拼接。JSON/SSE×Fast/Thinking×正常/检查异常覆盖8场，断言单次生成、judge0、None/degraded、token==最终body、会话不含原PII。`api-red-corrected-fixture.log`确有两项Thinking异常路径泄露原电话的失败，另6项失败为缺公开None字段；不是把最早夹具错误当业务缺陷。`api-green.log`25 passed覆盖该回归和相关单元。

`GuardrailManager.create_after_hook`在bounded检查异常或BLOCK/ESCALATE时，先将最终消息替换为固定安全提示再返回；Fast finalize同样安全回退。全部16槽实际SSE token与done正文一致，公开grounding_faithfulness=None、confidence_degraded=True。Thinking正常复合confidence约0.772–0.775仍不是语义核验通过分数。此发布修复已获已有测试证据支持，不能用它替代本轮3槽未通过的质量事实。

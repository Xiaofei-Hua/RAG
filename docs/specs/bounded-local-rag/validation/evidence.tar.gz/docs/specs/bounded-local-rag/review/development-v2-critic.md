# Development v2 / Strategy v3 — Independent Critic

Date: 2026-11-10。独立读取`data/eval/bounded-local-rag-dev-v2/{results,http}.jsonl`全部8槽、`validation/development.json`资料/manual、design v3章节与`core/local_rag_generation.py`及来源接线。未读取留出或另一评审；未运行模型/测试，未修改业务代码。

## Decision

**本轮8/8完整回答满足实质义务，无新增实质错误，可以继续既定真实API验证。** 4个已暴露问题各2轮，不是8个独立问题。本结论仅为生成机制开发通过，不是检索/控制/发布全链、冻结留出或默认启用资格。既有v1的4/8失败保留，不追溯改判。

## Whole-answer Review

| Round / case | Verdict | 事实、结论、条件与来源 |
|---|---|---|
| 1 / ih2_06 | PASS | 赤砚9h=540min@8W、芦序600min@5W，明确芦序记录更长，不能推断同负载优劣；两源对应。统一为分钟已完成正确换算比较，无需强制再写10h。 |
| 2 / ih2_06 | PASS | 同一完整关系与两方负载、没有其他负载记录的限制均保留；各事实指向相应来源，比较引用两源。 |
| 1 / dev_zero | PASS | 首句与全文一致认定偏差相同，明确0ms和0s统一单位后相等；10分钟与测量结果非缺测保留，两源归属正确。没有此前单位不同因此物理量不同的反结论。 |
| 2 / dev_zero | PASS | 同上；“测量结果为无偏差”限定在本次10分钟记录中，未断言所有场景无误差。没有虚构测量精度或将零当未知。 |
| 1 / dev_calibration | PASS | Q2、正常连续使用时120日历日、首次投入使用确认起算、更换后先校准并从完成日重算，全文完整。正常连续使用在依据及条件段明确保留；正面指定唯一正确起点已消除混淆，不要求逐字复述出厂/收货/入库三个否定项。 |
| 2 / dev_calibration | PASS | 上述条件与起算全部完整，另明确排除出厂/收货/入库；唯一来源对应。 |
| 1 / dev_missing | PASS | 英语回答价格未提供、保修18个月从交付起，来源正确；未编价格或把42mm当价格。 |
| 2 / dev_missing | PASS | 同样完整回答已知与未知、交付起算及引用。省略与问题无关的显示宽度正确。 |

结论/依据/条件有有限重复，是当前结构的表达冗余；没有v1长纠错模板或互相冲突，不能把这种重复自动判为实质质量失败。校准条件在完整已交付正文中存在，不以单独截取首句扩大门槛。

## Wire and Cost Evidence

- 8条实际HTTP与8槽对应，每槽一次生成；各题两轮请求相同。实际输入仅问题、完整对应资料及通用任务规则，不含manual答案/评分标签。
- 均`finish_reason=stop`、无reasoning正文，provider completion_tokens为133–319；不存在length、空答或补生成。
- `reasoning_effort=none`、T0.7/top_p0.8、JSON schema及`max_tokens=2048`实际在请求中。SDK另有max_completion_tokens4096；既有0.24解释max_tokens，不据此误报4096有效预算。短答未碰cap，不把本轮成功当截断路径测试。
- 全8槽生成及本地渲染耗时1.779–3.689s；按linear(N−1)样本P50 **3.095s**、P95 **3.511s**。这是生成机制耗时，不能替代真实API检查后正文延迟，也不以旧180s安全终态计算加速比。
- v1到本轮从4/8到8/8是该组合调整在已知开发题上的观察；schema、任务顺序/规则及编号上下文同时变化，不能单独归因某一字段。

## Single-call Implementation

`core/local_rag_generation.py:13–23`严格结构规定basis至少一项、每段非空text及至少一个source_id；`:34–43`整结构解析、校验ID范围/空白正文，以实际来源表渲染引用，不猜实体或补全部来源。调用者分别使用kept_documents或prepared evidence的平行来源顺序；本轮逐段ID与实际输入编号/文件名一致。

`:46–76`同步/异步各只有一次invoke/ainvoke，未引入LLM修补；解析/ID/length/空答失败由现有调用边界安全降级。程序只是将模型先写的basis/conditions/conclusion排成面向用户的正文，没有改写模型事实来冒充通过。`:79–91`保留输出检查；全链实际发布、None/degraded和控制用途仍以接下来的既定API/E2E验证为准，本次冷探针没有替代它们。

**Findings: 0。** 当前范围无须新增单位算法、judge调用或更大的开发矩阵；继续已约定的两模式真实API与独立留出。

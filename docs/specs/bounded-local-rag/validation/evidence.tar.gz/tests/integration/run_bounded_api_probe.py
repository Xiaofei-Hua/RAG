"""Run isolated real retrieval, graph, output checks and HTTP SSE measurements."""
import argparse
import asyncio
import importlib
import json
import os
import sys
import threading
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

ENV_PATHS = {'MILVUS_DB_URI': 'milvus.db', 'EMBEDDING_REGISTRY_DB': 'embedding_registry.db', 'DOCUMENT_REGISTRY_DB': 'documents.db', 'DOCUMENT_ASSET_DIR': 'originals', 'RAPTOR_DB_PATH': 'raptor.db', 'VISUAL_INDEX_PATH': 'visual_index.db', 'PDF_ASSET_DIR': 'pdf_assets', 'SESSIONS_DB': 'sessions.db'}
MODULE_PATHS = {'agent.eval.inference_store:DEFAULT_DB_PATH': 'inferences.db', 'agent.eval.history:RUNS_DIR': 'eval/runs', 'agent.eval.history:HISTORY_PATH': 'eval/runs/history.jsonl', 'agent.eval.candidates:CANDIDATES_DIR': 'eval/candidates', 'agent.eval.flywheel:RETRIEVAL_MISSES_DB': 'retrieval_misses.db', 'agent.eval.judge:DEFAULT_JUDGE_CACHE_PATH': 'eval/judge_cache.db', 'agent.memory.store:DEFAULT_DB_PATH': 'agent_memory.db', 'agent.feedback.collector:DEFAULT_DB_PATH': 'agent_memory.db', 'agent.feedback.escalation:DEFAULT_DB_PATH': 'agent_memory.db', 'documents.parent_store:DEFAULT_DB_PATH': 'parent_store.db', 'documents.graph_store:DEFAULT_DB_PATH': 'graph_store.db', 'documents.graph_store:DEFAULT_V1_BACKUP_PATH': 'graph_store_v1_backup.db', 'documents.document_registry:DEFAULT_DB_PATH': 'documents.db', 'documents.embedding_registry:DEFAULT_DB_PATH': 'embedding_registry.db', 'agent.harness.orchestrator:DEFAULT_CHECKPOINT_PATH': 'checkpoints.db', 'api.routers.documents:UPLOAD_TMP_DIR': 'uploads', 'core.memory.redis_memory:DEFAULT_SESSION_DB_PATH': 'sessions.db'}


def configure(root, policy):
    assets = Path("/home/outsiderzz/Projects/RAG/models/local_models")
    os.environ.update(PYTHON_DOTENV_DISABLED="1", DEPLOYMENT_ENV="development",
        DOMAIN_PROFILE="general", LOCAL_RAG_POLICY=policy, LLM_MODEL="qwen3.5:9b",
        OPENAI_BASE_URL="http://127.0.0.1:11434/v1", OPENAI_API_KEY="ollama",
        EMBEDDING_PROVIDER="local", EMBEDDING_MODEL="BAAI/bge-m3",
        EMBEDDING_MODEL_PATH=str(assets / "bge-m3"),
        RERANKER_MODEL_PATH=str(assets / "reranker/bge-reranker-v2-m3"),
        HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", COLLECTION_NAME="bounded_acceptance",
        RAPTOR_ENABLED="false", COLPALI_ENABLED="false", GRAPH_RAG_ENABLED="false",
        GRAPH_PPR_ENABLED="false", COLBERT_RERANK_ENABLED="false", QUERY_TRANSFORM_ENABLED="false",
        RETRIEVAL_WORKFLOW_ENABLED="true", EXTERNAL_API_TOOLS_ENABLED="false", OTEL_ENABLED="false",
        ADMIN_API_KEY="", ALLOWED_ORIGINS="http://127.0.0.1", GROUNDING_CHECK_ENABLED="true")
    if policy == "default":
        os.environ.pop("LOCAL_RAG_POLICY", None)
    for key, relative in ENV_PATHS.items():
        os.environ[key] = str(root / relative)
    os.chdir(root)
    for identity, relative in MODULE_PATHS.items():
        name, attr = identity.split(":")
        module = importlib.import_module(name)
        target = root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        if attr.endswith("DIR"):
            target.mkdir(parents=True, exist_ok=True)
        setattr(module, attr, target if isinstance(getattr(module, attr), Path) else str(target))
    from core.memory import redis_memory
    redis_memory._memory_instance = redis_memory.RedisSessionMemory(
        redis_client=redis_memory._SQLiteStore(str(root / "sessions.db")))
    from models.llm_models import get_llm
    get_llm().cache = False


def capture_model(path):
    import httpx
    original = httpx.AsyncClient.send
    lock = threading.Lock()
    count = [0]
    class CapturedStream(httpx.AsyncByteStream):
        def __init__(self, stream, row):
            self.stream, self.row, self.parts, self.written = stream, row, [], False
        async def __aiter__(self):
            async for data in self.stream:
                self.parts.append(data)
                yield data
        async def aclose(self):
            await self.stream.aclose()
            if not self.written:
                self.written = True
                self.row.update(raw=b"".join(self.parts).decode(errors="replace"),
                                end=time.perf_counter())
                with lock, path.open("a") as f:
                    f.write(json.dumps(self.row, ensure_ascii=False) + "\n")
    async def send(client, request, **kwargs):
        if request.url.port != 11434 or request.url.path != "/v1/chat/completions":
            return await original(client, request, **kwargs)
        with lock:
            count[0] += 1
            index = count[0]
        row = {"index": index, "start": time.perf_counter(), "request": json.loads(request.content)}
        response = await original(client, request, **dict(kwargs, stream=True))
        response.stream = CapturedStream(response.stream, row)
        if not kwargs.get("stream", False):
            await response.aread()
        return response
    httpx.AsyncClient.send = send
    return count


async def measure(args, root, protocol, count, ingestion):
    import httpx
    async with httpx.AsyncClient(base_url="http://127.0.0.1:18091", trust_env=False,
                                 timeout=120) as client:
        for name, content in protocol["corpus"].items():
            response = await client.post("/api/documents/upload", files={"file": (name, content.encode(), "text/plain")})
            response.raise_for_status()
            doc_id = response.json()["id"]
            if not await asyncio.to_thread(ingestion.setdefault(doc_id, threading.Event()).wait, 120):
                raise TimeoutError("ingestion timeout")
            detail = (await client.get("/api/documents/" + doc_id)).json()
            if detail["status"] != "indexed":
                raise RuntimeError("ingestion failed: " + json.dumps(detail, ensure_ascii=False))
        print("Corpus indexed", flush=True)
        # 只预热检索，不把预热答案作为测量或缓存。
        from core.retrieval.workflow import get_retrieval_workflow
        warm = await get_retrieval_workflow().aretrieve(protocol["cases"][0]["query"], final_k=4)
        (root / "warmup.json").write_text(json.dumps(warm.diagnostics, ensure_ascii=False))
        async def run_case(repeat, mode, case):
            session = f"{repeat}-{mode}-{case['id']}"
            started = time.perf_counter()
            row = {"round": repeat, "mode": mode, "case_id": case["id"],
                   "policy": args.policy, "first_body_s": None, "events": [],
                   "model_start": None if args.mixed else count[0], "query": case["query"]}
            try:
                async with asyncio.timeout(args.timeout):
                    async with client.stream("POST", "/api/chat/stream", json={
                        "message": case["query"], "session_id": session, "mode": mode,
                    }) as response:
                        row["status_code"] = response.status_code
                        async for line in response.aiter_lines():
                            if not line.startswith("data: "):
                                continue
                            event = json.loads(line[6:])
                            row["events"].append(event)
                            if event.get("type") == "token" and event.get("content") and row["first_body_s"] is None:
                                row["first_body_s"] = time.perf_counter() - started
            except Exception as exc:
                row["error"] = type(exc).__name__
            row.update(elapsed_s=time.perf_counter()-started, model_end=None if args.mixed else count[0])
            done = next((e for e in row["events"] if e["type"] == "done"), {})
            row["answer"] = done.get("full_response")
            with (root / "results.jsonl").open("a") as f:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
            print(json.dumps({k:v for k,v in row.items() if k not in {"events", "answer", "query"}}), flush=True)
        batch_start = time.perf_counter()
        for repeat in range(1, args.rounds + 1):
            if args.mixed:
                for case in protocol["cases"]:
                    await asyncio.gather(*(run_case(repeat, mode, case) for mode in args.modes.split(",")))
            else:
                for mode in args.modes.split(","):
                    for case in protocol["cases"]:
                        await run_case(repeat, mode, case)
        (root / "batch.json").write_text(json.dumps({"elapsed_s": time.perf_counter()-batch_start,
            "model_calls": count[0], "mixed": args.mixed, "policy": args.policy}))



def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--policy", choices=["legacy", "bounded", "auto", "default"], default="bounded")
    parser.add_argument("--rounds", type=int, default=2)
    parser.add_argument("--modes", default="fast,thinking")
    parser.add_argument("--mixed", action="store_true")
    parser.add_argument("--timeout", type=float, default=45)
    args = parser.parse_args()
    protocol = json.loads(args.protocol.read_text())
    root = args.output.resolve(); root.mkdir(parents=True, exist_ok=False)
    configure(root, args.policy)
    count = capture_model(root / "model-http.jsonl")
    from api.main import app
    from api.routers import documents
    ingestion = {}
    process_document = documents._process_document
    def tracked_ingestion(doc_id, *args, **kwargs):
        try:
            return process_document(doc_id, *args, **kwargs)
        finally:
            ingestion.setdefault(doc_id, threading.Event()).set()
    documents._process_document = tracked_ingestion
    import uvicorn
    ready = threading.Event()
    class Server(uvicorn.Server):
        async def startup(self, sockets=None):
            await super().startup(sockets)
            ready.set()
    server = Server(uvicorn.Config(app, host="127.0.0.1", port=18091, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    if not ready.wait(120):
        raise TimeoutError("server startup failed")
    try:
        asyncio.run(measure(args, root, protocol, count, ingestion))
    finally:
        server.should_exit = True
        thread.join(30)


if __name__ == "__main__":
    main()

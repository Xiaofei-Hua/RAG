"""Run the frozen local generation mechanism probe."""
import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
os.environ.update(LOCAL_RAG_POLICY="bounded", LLM_MODEL="qwen3.5:9b",
                  OPENAI_BASE_URL="http://127.0.0.1:11434/v1", DOMAIN_PROFILE="general",
                  PYTHON_DOTENV_DISABLED="1")
import httpx
from core.local_rag_generation import generation_chain
from models.llm_models import get_llm
from core.retrieval.evidence import render_untrusted_evidence

protocol = json.loads(Path(sys.argv[1]).read_text())
out = Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=False)
original = httpx.Client.send

def capture(client, request, **kwargs):
    started = time.perf_counter()
    response = original(client, request, **kwargs)
    if request.url.path == "/v1/chat/completions":
        response.read()
        row = {"request": json.loads(request.content), "response": response.json(),
               "elapsed_s": time.perf_counter() - started}
        with (out / "http.jsonl").open("a") as file:
            file.write(json.dumps(row, ensure_ascii=False) + "\n")
    return response

httpx.Client.send = capture
model = get_llm(); model.cache = False
chain = generation_chain(model)
for repeat in range(1, 3):
    for case in protocol["cases"]:
        context = render_untrusted_evidence([
            {"source": name, "content": protocol["corpus"][name], "title": ""}
            for name in case["sources"]])
        started = time.perf_counter()
        try:
            answer = chain.invoke({"question": case["query"], "context": context, "sources": case["sources"]})
            error = None
        except Exception as exc:
            answer = None; error = type(exc).__name__
        row = {"round": repeat, "case_id": case["id"], "elapsed_s": time.perf_counter()-started,
               "answer": answer, "error": error}
        with (out / "results.jsonl").open("a") as file:
            file.write(json.dumps(row, ensure_ascii=False) + "\n")
        print(json.dumps({k:v for k,v in row.items() if k != "answer"}, ensure_ascii=False), flush=True)

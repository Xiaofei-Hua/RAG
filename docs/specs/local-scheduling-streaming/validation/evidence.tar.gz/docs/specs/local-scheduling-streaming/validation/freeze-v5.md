# Holdout Freeze — Adaptive Release v5

## Freeze Record
- Frozen at: 2026-11-11T05:30:44+00:00
- Independent author: defender
- Policy: `docs/specs/local-scheduling-streaming/design.md` v5, written before this freeze.
- Repository HEAD at freeze: `30e4fe5a0f918ac95c4952d227e3a666c5c45f37`. 当前包含未提交实现；此记录不冒称 HEAD 已包含最终 v5。
- Artifact: `holdout-v5.json`，2 道新题，4 份新来源文档。
- Previous holdout access: none. Model execution before freeze: none.

## Admission Basis
已独立审阅机制 v4 的全部 16 答：非比较题没有新增实质质量问题；比较 R1 只给数值而未直接给排序结论，不能作为全范围分段质量通过。接受 v5 保留已合格比较完整生成路径、仅对其余题使用精简分段的有限范围。当前仅为设计准入，组合 API 质量、覆盖和收益仍待验证，默认仍 false。

## Frozen Cases
| ID | Class | Required evaluation |
|---|---|---|
| v5h_flow_scope | 中文比较，单位换算与两组不同工况 | 明确记录排序、保留全部工况、不能外推相同工况。 |
| v5h_scanner_procedure | 英文非比较，多条件操作流程与说明 | 首块决策条件完整，全文程序/起算/失败处理/未知边界和说明正确。 |

题目和期望判断已在任何模型运行之前固定；不能将本文件和人工判断要求拼进生成上下文。输入仅用户 query 与正常资料证据（包括来源名），其余字段均是离线评价元数据。完整语义评价接受等价表达，不以某一数字或词语命中判分。

## Execution and Interpretation
按既定两模式、两轮及相应 baseline 对照执行；记录全部尝试槽位、实际选用 schema、完成/不完整状态、最终生成调用次数、首块及全篇时延。分别审首块和全文，不将拒答、未完成内容或漏条件答案计为有效首块。比较题保留完整生成时不宣称比较也加速；按实际分流覆盖与整体收益汇报。

冻结后不得据新题面或输出改变 prompt、比较词表或题目期望。若输出用于归因修复，该题立即转开发集，不能继续称未暴露留出。实现可以按已经冻结的 v5 通用设计补完，不能新增针对本题的特殊分支。没有新增模型、调用或评分服务。

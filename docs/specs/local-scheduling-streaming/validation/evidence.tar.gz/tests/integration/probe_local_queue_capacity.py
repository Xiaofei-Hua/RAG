"""Exercise admission limits and stream cancellation with the actual local model."""
import asyncio
import json
import os
import sys
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
os.environ.update(PYTHON_DOTENV_DISABLED="1",LOCAL_RAG_POLICY="bounded",LOCAL_LLM_SCHEDULER="fair",LLM_MODEL="qwen3.5:9b",OPENAI_BASE_URL="http://127.0.0.1:11434/v1",DOMAIN_PROFILE="general")
from run_bounded_api_probe import capture_model
from models.llm_models import get_llm
from models.local_rag_policy import control_kwargs
from models.local_model_queue import _model_queue, ModelBusyError

async def main():
    out=Path(sys.argv[1]); out.mkdir(parents=True,exist_ok=False)
    calls=capture_model(out/"model-http.jsonl")
    model=get_llm(); model.cache=False
    short=model.bind(**control_kwargs(model))
    stream=model.bind(reasoning_effort="none",max_tokens=2048,extra_body={"max_tokens":2048}).astream("请详细解释如何整理一套技术文档，按章节说明检索、引用、版本和维护方法。")
    await anext(stream)
    assert _model_queue.active_count==1
    admitted=asyncio.Event(); released=asyncio.Event(); full=asyncio.Event(); attempted=0; rejected=0
    submit,release=_model_queue.submit,_model_queue.release
    def tracked_submit(*args):
        nonlocal attempted
        try:return submit(*args)
        finally:
            attempted+=1
            if attempted==10:admitted.set()
    def tracked_release(ticket):
        release(ticket)
        if _model_queue.active_count==0:released.set()
    _model_queue.submit=tracked_submit; _model_queue.release=tracked_release
    async def wait():
        nonlocal rejected
        try:
            await short.ainvoke("只回复OK")
            return "unexpected_admitted"
        except ModelBusyError as exc:
            if exc.reason == "queue_full":
                rejected += 1
                if rejected == 2: full.set()
            return exc.reason
        except asyncio.CancelledError:return "cancelled_waiting"
    tasks=[asyncio.create_task(wait()) for _ in range(10)]
    await asyncio.wait_for(admitted.wait(),5)
    await asyncio.wait_for(full.wait(),5)
    assert _model_queue.pending==8
    for task in tasks:
        if not task.done():task.cancel()
    outcomes=await asyncio.gather(*tasks)
    assert outcomes.count("queue_full")==2 and outcomes.count("cancelled_waiting")==8
    assert calls[0]==1 and _model_queue.pending==0
    started=time.perf_counter()
    timeout_outcome=await wait()
    waited=time.perf_counter()-started
    assert timeout_outcome=="queue_timeout" and waited>=30 and calls[0]==1
    started=time.perf_counter()
    await stream.aclose()
    await asyncio.wait_for(released.wait(),5)
    close_s=time.perf_counter()-started
    assert _model_queue.pending==_model_queue.active_count==0
    started=time.perf_counter()
    result=await short.ainvoke("只回复OK")
    report={"overload_outcomes":outcomes,"model_calls_before_followup":1,
        "timeout_reason":timeout_outcome,"timeout_s":waited,"cancel_to_slot_free_s":close_s,
        "followup_s":time.perf_counter()-started,"followup_answer":result.content,
        "actual_model_calls":calls[0],"active":_model_queue.active_count,"pending":_model_queue.pending,
        "note":"Held an actual streaming response after its first chunk to keep the lease occupied; timeout measures admission, not GPU compute."}
    (out/"results.json").write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps(report,ensure_ascii=False))
asyncio.run(main())

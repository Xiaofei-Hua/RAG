"""Cancel live generation before its completion and immediately admit another call."""
import asyncio,json,os,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
os.environ.update(PYTHON_DOTENV_DISABLED="1",LOCAL_RAG_POLICY="bounded",LOCAL_LLM_SCHEDULER="fair",LLM_MODEL="qwen3.5:9b",OPENAI_BASE_URL="http://127.0.0.1:11434/v1",DOMAIN_PROFILE="general")
from run_bounded_api_probe import capture_model
from models.llm_models import get_llm
from models.local_rag_policy import control_kwargs
from models.local_model_queue import _model_queue
async def main():
 out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False);calls=capture_model(out/"model-http.jsonl")
 model=get_llm();model.cache=False; freed=asyncio.Event();release=_model_queue.release
 def tracked(ticket):
  release(ticket)
  if _model_queue.active_count==0:freed.set()
 _model_queue.release=tracked
 stream=model.bind(reasoning_effort="none",max_tokens=2048,extra_body={"max_tokens":2048}).astream("请详细解释如何整理一套技术文档，逐章说明版本、索引、引用、校准流程和运行维护。")
 first=""
 async for chunk in stream:
  if chunk.content:first=chunk.content;break
 assert _model_queue.active_count==1
 started=time.perf_counter();await stream.aclose();await asyncio.wait_for(freed.wait(),5);closed=time.perf_counter()-started
 started=time.perf_counter();answer=await model.bind(**control_kwargs(model)).ainvoke("只回复OK")
 report={"first_chunk":first,"cancel_to_slot_free_s":closed,"followup_s":time.perf_counter()-started,"followup_answer":answer.content,"actual_model_calls":calls[0],"active":_model_queue.active_count,"pending":_model_queue.pending}
 (out/"results.json").write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))
asyncio.run(main())

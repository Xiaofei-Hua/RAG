"""Paired mechanism probe with real model and local output checks."""
import asyncio
import json
import os
import sys
import time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
os.environ.update(LOCAL_RAG_POLICY="bounded", LLM_MODEL="qwen3.5:9b", OPENAI_BASE_URL="http://127.0.0.1:11434/v1", DOMAIN_PROFILE="general", PYTHON_DOTENV_DISABLED="1", LOCAL_LLM_SCHEDULER="off")
from run_bounded_api_probe import capture_model
from core.local_rag_generation import generation_chain, finalize_answer
from core.segmented_generation import stream_answer
from core.retrieval.evidence import render_untrusted_evidence
from agent.guardrails.manager import GuardrailManager
from models.llm_models import get_llm

async def main():
    protocol = json.loads(Path(sys.argv[1]).read_text())
    out = Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=False)
    count = capture_model(out / "model-http.jsonl")
    model = get_llm(); model.cache = False
    checker = GuardrailManager().check_output
    for repeat in (1,2):
        for case in protocol["cases"]:
            for variant in (["buffered","segmented"] if repeat==1 else ["segmented","buffered"]):
                os.environ["LOCAL_RAG_SEGMENTED"] = str(variant=="segmented").lower()
                contexts = [protocol["corpus"][name] for name in case["sources"]]
                inputs = {"question":case["query"], "sources":case["sources"], "context":render_untrusted_evidence([
                    {"source":name,"content":protocol["corpus"][name],"title":""} for name in case["sources"]])}
                started=time.perf_counter(); before=count[0]
                row={"round":repeat,"case_id":case["id"],"variant":variant,"events":[],"first_body_s":None}
                try:
                    if variant=="buffered":
                        answer = await generation_chain(model).ainvoke(inputs)
                        answer = finalize_answer(answer,case["sources"],contexts)
                        row.update(answer=answer,first_body_s=time.perf_counter()-started)
                    else:
                        async for event in stream_answer(model,inputs,checker,contexts):
                            row["events"].append(event)
                            if event["type"]=="token" and row["first_body_s"] is None:
                                row["first_body_s"]=time.perf_counter()-started
                            if event["type"]=="done":
                                row.update(answer=event["full_response"],outcome=event["generation_outcome"])
                except Exception as exc:
                    row["error"]=type(exc).__name__
                row.update(elapsed_s=time.perf_counter()-started,model_calls=count[0]-before)
                with (out/"results.jsonl").open("a") as f: f.write(json.dumps(row,ensure_ascii=False)+"\n")
                print(json.dumps({k:v for k,v in row.items() if k not in {"events","answer"}},ensure_ascii=False),flush=True)
asyncio.run(main())
